# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
#
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app. The configuration follows a
# balanced approach focused on performance while maintaining debuggability.
#
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keeps readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to MediaPlayer (native playback)
# - YES to MediaSessionCompat and MediaButtonReceiver (media button routing)
# - YES to NotificationController (notification actions)
# - YES to PlaybackScope and PlaybackScopeDialog (favorites and scope)
# - YES to EdgeScrollHelper (shared fast-scroll on playlist and scope dialog)
#
# The app is organised around ten subsystems, plus one cross-cutting concern
# that touches every activity. The ten match the list in the README's
# "Inside the codebase" section, in the same order.
#
#   * The playback state machine — MusicService. A single state enum, two
#     monotonic counters, and a two-index model hold every transition-related
#     value. State mutations run on the main thread; raw MediaPlayer calls
#     run on a dedicated HandlerThread. The music-stream volume receiver is
#     a facet of this machine: registered in onBind and unregistered in
#     onDestroy, so once the user has opened the player a drop to zero
#     pauses and a raise above zero resumes or starts. A transient audio
#     focus loss is remembered and resumed on gain; a permanent loss is
#     not resumed. A duck request lowers the MediaPlayer's own output
#     volume for the interruption's duration instead of pausing.
#
#     In v1.4.0 the same machine owns the three-tier playlist:
#     mFullPlaylist is the database reflection, mScopedPlaylist is the
#     PlaybackScope-filtered subset, and mCurrentPlaylist is the active
#     queue. rebuildPlaylists() is the single mutator for the latter two,
#     and applies the grace period that keeps the current and target songs
#     in the queue regardless of the active scope. Favorites ride on the
#     same three lists: commitFavorites(Map) writes the per-song bit
#     through SongDatabase.setFavorite(String, boolean) and rebuilds the
#     playlists from it. The favorite column is written only by that
#     targeted path and by the fresh-row branch of the insert; every
#     other metadata write goes through SongDatabase.updateSongMetadata,
#     which never touches the column.
#
#   * The album-art gesture classifier — MusicPlayer. A single touch on
#     the album-art container is classified on its first significant move
#     into one of five states: TOUCHED, CAROUSEL, VOLUME, PLAYBACK, and
#     CANCELLED. The classifier owns all four gestures the album art
#     supports — the carousel swipe, the volume drag, the centre swipe to
#     play or pause, and the double-tap favourite. The PLAYBACK gesture
#     requires twice the touch slop of travel and commits on release; the
#     TOUCHED state is the resting state from which the double-tap
#     favourite is detected.
#
#   * The playback window — PlaybackWindow, produced by
#     MusicService.getWindowSnapshot(). An immutable value holding the
#     three paths the album-art carousel renders: the previous
#     neighbour, the current song, the next neighbour, plus the service's
#     monotonic transition counter.
#
#   * The playback scope — PlaybackScope and PlaybackScopeDialog. An
#     immutable value object with seven kinds (ALL, FAVORITES,
#     LOOSE_TRACKS, FOLDERS, GENRES, ARTISTS, ALBUMS) and four filter
#     sets, serialized to preferences as JSON. The dialog presents the
#     seven modes as a flat list, expands a mode's filter list when
#     selected, and computes the song count the selection would yield
#     from the same matcher the service uses. The dialog does not bind
#     the service; it returns a scope through OnScopeAppliedListener,
#     and the caller broadcasts the serialized scope to the service
#     through APPLY_PLAYBACK_SCOPE.
#
#   * The notification surface — NotificationController. Owns the
#     playback notification, the library notification, both channels,
#     and the media session metadata and playback state. Commits through
#     commitFromBroadcast(generation, snapshot), called by
#     MusicService.broadcastUpdate() immediately after sendBroadcast
#     returns, so the notification and the player screen commit the
#     same snapshot on the same main-thread turn. A generation filter
#     drops any read whose generation is strictly lower than the last
#     committed generation.
#
#   * The Metadata Editor — MetadataEditor. Two modes, VIEW and EDIT.
#     Reads and writes go through MetadataReader and MetadataWriter,
#     whose status enums drive every branch. The write path identifies
#     the target by the content URI the session selected; the absolute
#     path is derived from that URI or accepted from the caller only
#     when the database confirms the two describe the same file. The
#     post-write reread is verification only: a reread failure cannot
#     suppress the METADATA_UPDATED broadcast.
#
#   * The overlay stack — OverlayManager and ToastManager. OverlayManager
#     is the process-wide, reason-keyed dim-and-spinner overlay.
#     ToastManager is the operation-stack manager for persistent overlays
#     and temporary toasts.
#
#   * The album-art carousel — AlbumArtCarousel. A pure renderer of the
#     window the service publishes. The transport buttons drive the same
#     slide the swipe gesture produces, through animateToNext() and
#     animateToPrevious().
#
#   * The edge fast-scroll — EdgeScrollHelper. A vertical drag that
#     starts inside the list's leftmost or rightmost 32dp scrolls the
#     list proportionally to the total scrollable range. Shared by the
#     playlist and the playback scope dialog so both surfaces use the
#     same edge width, engagement threshold, and scroll rate.
#
#   * Split-screen behaviour — per-activity. Every activity declares the
#     same configChanges set and adjusts its own content when the window
#     resizes, instead of being recreated.
#
#   * The storage observer — StorageObserver. A single content observer on
#     MediaStore.Audio.Media.EXTERNAL_CONTENT_URI. A change notification
#     starts a quiet period; if no further change arrives inside the
#     period, the observer asks PlaylistManager to run a scan. Audio
#     additions, removals, and metadata edits trigger the scan. Image,
#     video, and download writes do not.
#
# The localization subsystem is a cross-cutting concern that touches every
# activity rather than a subsystem of its own. LanguageManager owns the
# selected language; LanguageDialog presents the picker; every activity
# wraps its base context through LanguageManager.wrap in attachBaseContext
# so the framework reads from the matching resource folder for the whole of
# the activity's lifetime.
#
# Section header convention:
# - "Keep <Subject>" for rules that preserve classes, methods, or fields
# - Descriptive headers (Performance, Obfuscation, Logging) for build behavior
#
# The wildcard keep at the top of this file,
#   -keep class com.ark.llama.** { *; }
# covers every specific com.ark.llama.* keep below it. The specific rules are
# documentation of intent and a safety net if the wildcard is ever narrowed.
#
# @author Richard Korbla Adzido
# @version 1.4.0
# @since 1.0.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
# optimizationpasses 5 runs R8's optimizer five times. Each pass inlines,
# removes dead code, and propagates constants. Five passes is the standard
# trade-off between output quality and build time: most projects reach a
# fixed point by pass three or four, and pass five catches the residue.
#
# allowaccessmodification lets R8 widen access modifiers when doing so
# enables inlining across class boundaries.
#
# repackageclasses '' puts every class in the default package after
# processing, which removes the package prefix from class names and shrinks
# the constant pool.
#
# keepattributes preserves the listed debug metadata through the R8 pass.
# SourceFile and LineNumberTable make stack traces readable; Exceptions,
# Signature, Deprecated, EnclosingMethod, and InnerClasses preserve
# reflection-visible metadata that jaudiotagger and AndroidX read.
#
# renamesourcefileattribute SourceFile replaces the source file name in
# stack traces with the literal "SourceFile", collapsing every frame to
# that name in crash reports.
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# Disable Obfuscation (keeps readable stack traces)
# ============================================================================
# dontobfuscate keeps class, method, and field names intact so crash reports
# stay readable.
#
# dontusemixedcaseclassnames is the historical safety rule that keeps R8 from
# generating class names that differ only in case. It applies the moment
# obfuscation is re-enabled.
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Logging Removal in Release
# ============================================================================
# assumenosideeffects tells R8 that these Log methods have no observable
# effect on program state. R8 then removes every call site in the release
# build, along with the string concatenation that produces the message.
#
# The three levels listed are the ones that are stripped:
#   d (debug)   - verbose instrumentation
#   v (verbose) - the same
#   i (info)    - informational
# Log.w (warn) and Log.e (error) remain. They fire on real problems and are
# the ones that reach the crash reporter.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# ============================================================================
# Keep All Application Classes
# ============================================================================
# The wildcard rule that keeps every class, field, and method in the app
# package. Every specific rule below documents the reflective entry point
# each class provides.
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }

# ============================================================================
# Keep MusicService - The Playback State Machine
# ============================================================================
# MusicService is instantiated by the framework from the manifest. LocalBinder
# is the return type of onBind and is cast by every bound activity. The class
# is the sole authority for the playback window: getWindowSnapshot() and the
# two peek functions it computes neighbours from are part of the class and
# are covered by this keep.
#
# Version 1.4.0 adds the three-tier playlist. mFullPlaylist is the database
# reflection, mScopedPlaylist is the PlaybackScope-filtered subset, and
# mCurrentPlaylist is the active queue. rebuildPlaylists() is the single
# mutator for the latter two. setPlaybackScope(), getPlaybackScope(),
# getScopedPlaylist(), getScopedPlaylistSize(), commitFavorites(), and
# toggleFavorite() are the public surface added for favorites and scope.
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

# ============================================================================
# Keep PlaybackWindow - The Playback Window
# ============================================================================
# PlaybackWindow is an immutable value holding the three paths the album-art
# carousel renders and the service's monotonic transition counter. Its three
# public fields are read directly by every consumer; its equals and hashCode
# are called by every window comparison. The class is instantiated by
# MusicService on every broadcast and by MusicPlayer on every received
# broadcast.
-keep class com.ark.llama.PlaybackWindow { *; }

# ============================================================================
# Keep PlaybackScope - The Playback Scope Value Object
# ============================================================================
# PlaybackScope is an immutable value object describing which subset of the
# library the player considers its current play scope. Its Kind enum is
# serialized by name through serialize() / deserialize() and through
# MusicService's persisted preference under the "playback_scope_json" key.
# The Kind names are therefore stable identifiers: a kind renamed in a future
# release would fail to deserialize an older preference, and the fallback is
# PlaybackScope.ALL, so a corrupted or renamed-kind preference resolves to
# the unconstrained library rather than to a broken scope.
#
# The four Set<String> fields (paths, genres, artists, albums) are public
# finals and read directly by PlaybackScope.matches and by
# MusicService.rebuildPlaylists. The factory methods (favorites(),
# looseTracks(), folders(), genres(), artists(), albums()) are called from
# PlaybackScopeDialog and from the callers that construct a scope by kind.
#
# Kind.values() and Kind.valueOf(String) are used reflectively by
# serialize() and deserialize(); the general enum keep below covers them,
# but the specific rule documents the reflective entry point.
-keep class com.ark.llama.PlaybackScope { *; }
-keep class com.ark.llama.PlaybackScope$* { *; }

# ============================================================================
# Keep PlaybackScopeDialog - The Playback Scope Selection Dialog
# ============================================================================
# PlaybackScopeDialog is instantiated by FolderManager. Its layout is created
# programmatically, and its OnScopeAppliedListener interface is implemented
# anonymously at the call site in FolderManager.openPlaybackScopeDialog().
# The background enumeration of genres, artists, and albums runs on the
# dialog's own executor and is posted back to the main thread; the executor
# is shut down in dismiss().
#
# The dialog is the second surface (besides PlaylistActivity) on which
# EdgeScrollHelper installs its proportional edge scroll.
-keep class com.ark.llama.PlaybackScopeDialog { *; }
-keep class com.ark.llama.PlaybackScopeDialog$* { *; }
-keep interface com.ark.llama.PlaybackScopeDialog$OnScopeAppliedListener { *; }

# ============================================================================
# Keep AlbumArtCarousel - The Album-Art Carousel
# ============================================================================
# AlbumArtCarousel is constructed by MusicPlayer and attached to the
# album-art container. Its SwipeCommitListener interface is implemented
# anonymously at the call site in MusicPlayer.initializeViews(). Its private
# SwipeState enum is internal, but is documented here for completeness. A
# single public mutator, setWindow, adopts every window the service
# publishes.
-keep class com.ark.llama.AlbumArtCarousel { *; }
-keep class com.ark.llama.AlbumArtCarousel$* { *; }
-keep interface com.ark.llama.AlbumArtCarousel$SwipeCommitListener { *; }
-keep class com.ark.llama.AlbumArtCarousel$SwipeState { *; }

# ============================================================================
# Keep AlbumArtCache - Process-Scoped Album Art Bitmap Cache
# ============================================================================
# AlbumArtCache is a process-wide singleton backed by an LruCache<String,
# Bitmap> keyed by song path. It is read by AlbumArtCarousel through
# MusicPlayer, and by NotificationController for the playback notification
# and the media session. Both consumers see the same bitmaps for the same
# path; a song's art is decoded once per process for as long as the entry
# remains in the cache. Its asLruCache() method hands the underlying
# LruCache to consumers whose constructors were already built against
# LruCache — such as AlbumArtCarousel's — so the returned instance must be
# the same object every caller reads from. The class is a singleton that
# outlives every activity, so R8's dead-code pass must not narrow it to
# the reachability of any single activity.
#
# Version 1.4.0 adds MetadataEditor's use of the shared cache to evict the
# edited song's art by both path and URI, and MusicService's use of the
# same cache to store the resolved bitmap for the notification's large
# icon. Both are covered by this keep.
-keep class com.ark.llama.AlbumArtCache { *; }
-keep class com.ark.llama.AlbumArtCache$* { *; }

# ============================================================================
# Keep OverlayManager - The Process-Wide Overlay
# ============================================================================
# OverlayManager is a process-wide singleton that registers itself as an
# Application.ActivityLifecycleCallbacks listener. The framework calls every
# lifecycle callback reflectively, so every method on the class is kept. Its
# private SpinnerView is a custom View subclass instantiated programmatically;
# its rotation animator is driven by ObjectAnimator through the "rotation"
# property, which is resolved reflectively.
-keep class com.ark.llama.OverlayManager { *; }
-keep class com.ark.llama.OverlayManager$* { *; }

# ============================================================================
# Keep NotificationController - Notification Management
# ============================================================================
# NotificationController is a process-wide singleton. MusicService reads its
# state through the ServiceStateSource interface. The inner PlaybackState
# class is instantiated by the controller's render path. The controller is
# the sole writer of the media session metadata and of the media session
# playback state. Every user-visible label it draws reads from a string
# resource, so no string constant is kept on the class itself.
-keep class com.ark.llama.NotificationController { *; }
-keep class com.ark.llama.NotificationController$* { *; }
-keep interface com.ark.llama.NotificationController$ServiceStateSource { *; }

# ============================================================================
# Keep PlaylistManager - Playlist Update Operations
# ============================================================================
# PlaylistManager runs folder scans and genre loading on a background
# executor. Its UpdateCallback interface is implemented anonymously at every
# call site. Every overlay message it shows reads from a string resource;
# the two operation IDs it owns (OPERATION_GENRE_UPDATE and
# OPERATION_LIBRARY_RESET) are stack tokens rather than user-visible strings
# and are kept as part of the class.
-keep class com.ark.llama.PlaylistManager { *; }
-keep class com.ark.llama.PlaylistManager$* { *; }
-keep interface com.ark.llama.PlaylistManager$UpdateCallback { *; }

# ============================================================================
# Keep StorageAccessHelper - SAF Operations
# ============================================================================
# StorageAccessHelper is a singleton whose instance is reused across every
# component that touches Storage Access Framework URIs. PlaybackScopeDialog
# reads the folder-path mapping through it to populate the folder list.
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageAccessHelper$* { *; }

# ============================================================================
# Keep StorageObserver - The Storage Observer
# ============================================================================
# StorageObserver extends ContentObserver and is instantiated by MusicPlayer
# with the activity that owns the observer's lifetime. It registers a single
# content observer on MediaStore.Audio.Media.EXTERNAL_CONTENT_URI and asks
# PlaylistManager to run a scan when a change notification settles through
# its quiet period.
-keep class com.ark.llama.StorageObserver { *; }

# ============================================================================
# Keep ToastManager - The Operation Stack
# ============================================================================
# ToastManager is a singleton that implements ActivityLifecycleCallbacks and
# is registered with the Application. Every method on the class is called
# from outside the app package or through the Android framework. Its
# operation stack renders persistent overlays and temporary toasts; the
# overlay is reattached to the current activity on every resume.
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.ToastManager$* { *; }

# ============================================================================
# Keep NavigationController - Centralized Button State Management
# ============================================================================
# NavigationController exposes three listener interfaces plus two enums. The
# enums are used as map keys and as switch discriminants; their names are
# stable identifiers across the app.
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep class com.ark.llama.NavigationController$ButtonGroup { *; }
-keep class com.ark.llama.NavigationController$Operation { *; }

# ============================================================================
# Keep MusicLibrary - Music Library Management
# ============================================================================
# MusicLibrary is instantiated by every component that reads the song list
# (MusicService, MusicPlayer, FolderManager). Its three listener interfaces
# are implemented anonymously.
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.MusicLibrary$* { *; }
-keep interface com.ark.llama.MusicLibrary$OnSongsLoadedListener { *; }
-keep interface com.ark.llama.MusicLibrary$UpdateProgressListener { *; }
-keep interface com.ark.llama.MusicLibrary$LoadProgressListener { *; }

# ============================================================================
# Keep SongDatabase - Database Helper
# ============================================================================
# SongDatabase extends SQLiteOpenHelper. The framework calls onCreate and
# onUpgrade reflectively.
#
# Version 1.4.0 adds the favorite column (schema version 3) and the two
# write paths that keep it safe: updateSongMetadata(Song), which writes
# everything except the favorite column, and setFavorite(String, boolean),
# which writes only the favorite column. The insert path routes an existing
# row through updateSongMetadataInternal so a scan or a genre load cannot
# clobber a user's favorites. The whole three-path arrangement is covered
# by this keep; the class is never narrowed to a single method.
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep CharacterMapper - Metadata Cleaning Utility
# ============================================================================
# CharacterMapper is a final utility class. The nested ParseResult and its
# Status enum are returned by every metadata read and switched on by every
# caller.
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$ParseResult { *; }
-keep class com.ark.llama.CharacterMapper$ParseResult$Status { *; }

# ============================================================================
# Keep MetadataReader and MetadataWriter - ID3 Tag Operations
# ============================================================================
# MetadataReader and MetadataWriter are final utility classes. Their nested
# MetadataBundle, WriteResult, and UpdateBundle classes are returned or
# accepted by their public methods and are read field-by-field at every call
# site.
-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$MetadataBundle { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$WriteResult { *; }
-keep class com.ark.llama.MetadataWriter$UpdateBundle { *; }

# ============================================================================
# Keep EqualizerManager - Audio Effects
# ============================================================================
# EqualizerManager is a singleton that wraps the three audio-effect classes.
# Its EqualizerListener is implemented by EqualizerActivity.
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.EqualizerManager$* { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

# ============================================================================
# Keep ThemeManager and ThemeHelper - Theme Management
# ============================================================================
# Both are singletons. ThemeManager reads from SharedPreferences at
# construction; ThemeHelper caches the current color string. Every activity
# and every dialog reads its theme color from ThemeManager through
# ThemeHelper, so both must be preserved for their public surface to remain
# reachable after R8's dead-code pass.
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep LanguageManager - Selected Language and Locale Application
# ============================================================================
# LanguageManager is a process-wide singleton that owns the selected
# language tag and the supported-language set. It is read from the About
# dialog's language button, from every activity's attachBaseContext override
# through wrap(Context), and from LanguageDialog's factory. It holds two
# parallel string arrays (LANGUAGE_TAGS and LANGUAGE_NAMES) whose entries are
# read by index; preserving the arrays preserves the index contract.
#
# wrap(Context) is called reflectively by the framework, because it runs
# from attachBaseContext, which is itself a framework override. Its return
# value is a Context whose configuration carries the selected locale; that
# context is used for the rest of the activity's lifetime.
-keep class com.ark.llama.LanguageManager { *; }

# ============================================================================
# Keep FolderManager - Folder Management Activity
# ============================================================================
# FolderManager is instantiated by the framework from the manifest.
#
# Version 1.4.0 adds the SCOPE button, which opens the PlaybackScopeDialog.
# The dialog applies the user's selection by broadcasting
# APPLY_PLAYBACK_SCOPE with the serialized scope under the "scope_json"
# extra; MusicService applies the scope on its main thread. FolderManager
# does not bind MusicService, so there is no additional lifecycle for this
# class to manage.
-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderManager$* { *; }

# ============================================================================
# Keep FolderAdapter - Folder List Adapter
# ============================================================================
# FolderAdapter's ViewHolder is instantiated by RecyclerView through the
# createViewHolder path. The FolderItem model and the OnFolderRemoveListener
# interface are reached by the adapter at every bind. PlaybackScopeDialog
# reads FolderItem fields to populate its folder list, so the item is a
# crossing-the-boundary value.
-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }
-keep class com.ark.llama.FolderAdapter$FolderItem { *; }
-keep class com.ark.llama.FolderAdapter$FolderViewHolder { *; }

# ============================================================================
# Keep PlaylistActivity - Playlist Display Activity
# ============================================================================
# Instantiated by the framework from the manifest. The activity installs the
# fast-scroll interceptor on its playlist RecyclerView through
# setupEdgeFastScroll(), which delegates to EdgeScrollHelper.attach(); the
# interceptor itself is an anonymous OnItemTouchListener created inside
# EdgeScrollHelper and reached only from the list. It also owns the sort
# overlay's reason token on the process-wide OverlayManager. Its sort-label
# and sort-toast arrays hold resource IDs, resolved through getString at
# each use site.
#
# Version 1.4.0 adds the pending-favorites staging: the PendingFavorites
# inner class accumulates heart taps made by the user and onPause() flushes
# the batch to MusicService.commitFavorites(Map). The inner class is kept
# for its HashMap and its snapshot() method.
-keep class com.ark.llama.PlaylistActivity { *; }
-keep class com.ark.llama.PlaylistActivity$* { *; }
-keep class com.ark.llama.PlaylistActivity$PendingFavorites { *; }

# ============================================================================
# Keep PlaylistAdapter - Playlist RecyclerView Adapter
# ============================================================================
# PlaylistAdapter's ViewHolder is instantiated by RecyclerView. Its DiffUtil
# callback is instantiated by the adapter on every list update.
#
# Version 1.4.0 adds the per-row heart icon and the FavoriteListener
# interface. The heart's click handler flips the row's Song favorite flag
# and forwards the change to the listener; PlaylistActivity implements the
# listener as a lambda that stages the change in PendingFavorites. The
# ViewHolder now resolves the favoriteIcon TextView alongside the title and
# subtitle.
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }
-keep interface com.ark.llama.PlaylistAdapter$FavoriteListener { *; }
-keep class com.ark.llama.PlaylistAdapter$ViewHolder { *; }

# ============================================================================
# Keep EdgeScrollHelper - Edge Fast-Scroll Interceptor
# ============================================================================
# EdgeScrollHelper is a final utility class with a private constructor. Its
# only public entry point, attach(RecyclerView), installs an anonymous
# OnItemTouchListener on the RecyclerView; that listener is a generated inner
# class of EdgeScrollHelper, not of the caller, and is reached only through
# the RecyclerView's item-touch-listener list. The helper itself is a shared,
# cross-surface utility reached from both PlaylistActivity and
# PlaybackScopeDialog, so it is kept whole alongside the other shared
# utility classes for parity and as a safety net if the package wildcard is
# ever narrowed.
-keep class com.ark.llama.EdgeScrollHelper { *; }

# ============================================================================
# Keep EqualizerActivity - Equalizer UI Activity
# ============================================================================
# Instantiated by the framework from the manifest.
-keep class com.ark.llama.EqualizerActivity { *; }

# ============================================================================
# Keep MetadataEditor - Metadata Editing Activity
# ============================================================================
# Instantiated by the framework from the manifest.
-keep class com.ark.llama.MetadataEditor { *; }

# ============================================================================
# Keep MusicPlayer - Main Activity
# ============================================================================
# Instantiated by the framework from the manifest. The activity owns the
# album-art gesture container and drives the carousel's slide for both the
# swipe gesture and the transport buttons. The activity also overrides
# dispatchKeyEvent to observe volume-up before the window system consumes
# it, and resumes a paused song when the volume is already at the device
# maximum. Its attachBaseContext override reads the selected language
# through LanguageManager.
#
# Version 1.4.0 adds the favorite transport button and the album-art
# double-tap handler. The button's click goes to MusicService.toggleFavorite;
# the double-tap handler uses the same path. The gesture mode enum
# (GestureMode) is renamed so the resting state reads TOUCHED rather than
# UNDECIDED, matching the double-tap's classification rules. The centre
# swipe to play or pause is a fifth gesture the classifier dispatches, and
# the exit button closes the app on a deliberate two-tap gesture.
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Keep CreditsDialog - About Dialog
# ============================================================================
# Instantiated by MusicPlayer on the LLAMA button tap. Its layout is created
# programmatically, and its easter-egg tap counter is stateful per instance.
# The dialog's version header carries the language button whose label is the
# endonym of the currently applied language; the button opens
# LanguageDialog on tap.
-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.CreditsDialog$* { *; }

# ============================================================================
# Keep PresetDialog - Equalizer Preset Dialog
# ============================================================================
# Instantiated by EqualizerActivity. Its OnPresetSelectedListener is
# implemented anonymously at the call site.
-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

# ============================================================================
# Keep ThemeDialog - Theme Selection Dialog
# ============================================================================
# Instantiated by CreditsDialog. Its OnThemeSelectedListener is implemented
# anonymously.
-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }

# ============================================================================
# Keep LanguageDialog - Language Selection Dialog
# ============================================================================
# Instantiated by CreditsDialog when the language button is tapped. Its
# layout is created programmatically and matches the shape of PresetDialog
# and ThemeDialog. Its OnLanguageSelectedListener is implemented
# anonymously at the call site in CreditsDialog.showLanguageDialog().
#
# The endonym array the dialog presents is supplied by
# LanguageManager.getLanguageNames(); the tag array is supplied by
# LanguageManager.getLanguageTags(). Both are passed by reference and are
# read by index, so the two arrays' positional alignment must survive R8's
# passes intact. It does, because LanguageManager itself is kept whole.
-keep class com.ark.llama.LanguageDialog { *; }
-keep class com.ark.llama.LanguageDialog$* { *; }
-keep interface com.ark.llama.LanguageDialog$OnLanguageSelectedListener { *; }

# ============================================================================
# Keep FontAwesome - Icon Font Utility
# ============================================================================
# FontAwesome is a final utility class that loads a Typeface from assets and
# exposes Unicode constants. The constants are read by name at many call
# sites.
#
# Version 1.4.0 adds the HEART constant. It is used by MusicPlayer's
# transport button and by PlaylistAdapter's per-row heart.
-keep class com.ark.llama.FontAwesome { *; }

# ============================================================================
# Keep BluetoothReceiver - Bluetooth Connection-State Handler
# ============================================================================
# Instantiated by the framework from the manifest.
-keep class com.ark.llama.BluetoothReceiver { *; }

# ============================================================================
# Keep Song - Data Model (Serializable)
# ============================================================================
# Song implements Serializable. The four magic methods below are part of the
# serialization contract and must stay under their canonical names.
#
# Version 1.4.0 adds the mFavorite field. The serialVersionUID bumps from 1
# to 2; a version-1 stream deserializes with the flag as false, which is the
# correct value for every song that existed before the flag was introduced.
# The isFavorite() and setFavorite(boolean) accessors are read by
# PlaybackScope.matches, PlaylistAdapter's row bind, PlaylistActivity's
# pending-favorites staging, and MusicService's three-tier playlist. Their
# names are stable across R8's passes because the whole class is kept.
-keep class com.ark.llama.Song { *; }
-keepclassmembers class com.ark.llama.Song {
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Android Components
# ============================================================================
# Every Android component declared in the manifest is instantiated by the
# framework through reflection. Every activity's attachBaseContext override,
# added in v1.3.0 for locale application, is also reached through this
# reflection path.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.view.ViewGroup
-keep public class * extends android.widget.RemoteViews
-keep public class * extends android.appwidget.AppWidgetProvider

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
# Custom views are inflated from XML by the LayoutInflater, which calls the
# (Context, AttributeSet) constructor reflectively. The single-arg and
# three-arg variants are kept for programmatic construction and for styles.
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
# The standard serialization contract requires serialVersionUID and the four
# magic methods to be present under their canonical names.
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Enums
# ============================================================================
# values() and valueOf(String) are used reflectively by the framework and by
# code that persists enum names to SharedPreferences.
#
# Version 1.4.0 adds PlaybackScope.Kind, whose names are serialized by
# PlaybackScope.serialize() and read back by PlaybackScope.deserialize().
# The Kind names are stable identifiers: a renamed kind would fail to
# deserialize an older preference, and the fallback is PlaybackScope.ALL.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
# CREATOR is read reflectively by the Parcel unmarshalling machinery.
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Atomic Classes
# ============================================================================
# java.util.concurrent.atomic is used throughout the app for lock-free state.
-keep class java.util.concurrent.atomic.** { *; }

# ============================================================================
# Keep Handler and Looper
# ============================================================================
# Handler and Looper are used by every component in the app.
-keep class android.os.Handler { *; }
-keep class android.os.Looper { *; }

# ============================================================================
# Keep SystemClock
# ============================================================================
# SystemClock.elapsedRealtime is the monotonic time source used by every
# state machine in the app.
-keep class android.os.SystemClock { *; }

# ============================================================================
# Keep ExecutorService and Future
# ============================================================================
# The three components that own single-thread executors (MusicService,
# MusicPlayer, MusicLibrary) refer to ExecutorService, Executors, and Future
# by their full names.
-keep class java.util.concurrent.ExecutorService { *; }
-keep class java.util.concurrent.Future { *; }
-keep class java.util.concurrent.Executors { *; }

# ============================================================================
# Keep Map and HashMap
# ============================================================================
# MusicService.commitFavorites takes a Map<String, Boolean>; the caller
# stages the map in PlaylistActivity.PendingFavorites and MusicService
# iterates it. The two types are referred to by their full names.
-keep class java.util.Map { *; }
-keep class java.util.HashMap { *; }

# ============================================================================
# Keep Set and HashSet
# ============================================================================
# PlaybackScope carries four Set<String> fields (paths, genres, artists,
# albums). MusicService carries a Set<String> of loose-track paths that
# PlaybackScope.matches consults. The two types are referred to by their
# full names.
-keep class java.util.Set { *; }
-keep class java.util.HashSet { *; }

# ============================================================================
# Keep org.json - Playback Scope Serialization
# ============================================================================
# PlaybackScope.serialize() and deserialize() produce and consume a JSON
# object string through the framework's org.json package. The package is
# part of the Android runtime, so R8 does not strip it, but keeping it here
# documents the dependency and protects against a future release of the
# Android SDK where the classes might be represented differently.
-keep class org.json.** { *; }
-dontwarn org.json.**

# ============================================================================
# Keep Resource IDs
# ============================================================================
# The fields of every R inner class are read by name through the generated R
# class.
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Keep Third-Party Libraries - jaudiotagger, AndroidX, Android Framework
# ============================================================================
# jaudiotagger is a jar dependency with a broad reflective surface: it
# discovers format readers by class name. Kept whole with warnings suppressed
# because the library references classes that are absent from the Android
# runtime.
#
# AndroidX is kept whole because the version in use relies on reflection for
# lifecycle dispatch and fragment restoration.
#
# android.media.** is kept whole because every media class crosses the JNI
# boundary by name.
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class android.media.** { *; }
-dontwarn android.media.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Keep androidx.media Compat Classes
# ============================================================================
# The androidx.media artifact publishes its runtime classes under the
# android.support.v4.media package namespace for binary compatibility. Only
# the MediaButtonReceiver is published under androidx.media. R8 keeps both
# namespaces so the session classes remain available and the notification
# MediaStyle binds to them.
-keep class android.support.v4.media.** { *; }
-keep interface android.support.v4.media.** { *; }
-dontwarn android.support.v4.media.**

-keep class androidx.media.** { *; }
-keep interface androidx.media.** { *; }
-dontwarn androidx.media.**

# ============================================================================
# Keep MediaSessionCompat and Token Types
# ============================================================================
# MediaSessionCompat.Token.getToken() returns the framework
# MediaSession.Token on API 21+. The compat/framework boundary is crossed by
# reflection when Notification.MediaStyle.setMediaSession(...) is called.
# Both ends are kept.
-keep class android.support.v4.media.session.MediaSessionCompat { *; }
-keep class android.support.v4.media.session.MediaSessionCompat$Token { *; }
-keep class android.support.v4.media.session.PlaybackStateCompat { *; }
-keep class android.support.v4.media.MediaMetadataCompat { *; }

-keep class android.media.session.MediaSession { *; }
-keep class android.media.session.MediaSession$Token { *; }
-keep class android.media.session.PlaybackState { *; }
-keep class android.media.MediaMetadata { *; }

# ============================================================================
# Keep AudioTrack and Audio Attributes
# ============================================================================
# AudioTrack, AudioAttributes, and AudioFormat are crossed by name when the
# MediaPlayer opens its output stream.
-keep class android.media.AudioTrack { *; }
-keep class android.media.AudioAttributes { *; }
-keep class android.media.AudioFormat { *; }

# ============================================================================
# Keep AudioFocus Classes
# ============================================================================
# AudioManager and AudioFocusRequest are used by MusicService for the focus
# lifecycle, and both are crossed by name.
-keep class android.media.AudioManager { *; }
-keep class android.media.AudioFocusRequest { *; }

# ============================================================================
# Keep PlaybackParams - Speed and Pitch Adjustment
# ============================================================================
# MusicService.updatePlaybackParams() round-trips a PlaybackParams through
# MediaPlayer.getPlaybackParams() / setPlaybackParams(). The framework side
# of that call crosses the JNI boundary by name. Kept explicitly so the
# crash is prevented if obfuscation is enabled later.
-keep class android.media.PlaybackParams { *; }
-keep class android.media.PlaybackParams$* { *; }

# ============================================================================
# Keep MediaPlayer - Native Playback
# ============================================================================
# MediaPlayer is the audio engine. Every method on it crosses the JNI
# boundary.
-keep class android.media.MediaPlayer { *; }
-keep class android.media.MediaPlayer$* { *; }

# ============================================================================
# Keep MediaMetadataRetriever - Album Art Extraction
# ============================================================================
# MediaMetadataRetriever extracts embedded album art and duration. It is
# crossed by name.
-keep class android.media.MediaMetadataRetriever { *; }

# ============================================================================
# Keep MediaStore Classes
# ============================================================================
# MediaStore, MediaStore.Audio.Media, and MediaStore.Files are queried by
# column name. The column names are string constants on these classes.
-keep class android.provider.MediaStore { *; }
-keep class android.provider.MediaStore$Audio$Media { *; }
-keep class android.provider.MediaStore$Files { *; }

# ============================================================================
# Keep DocumentFile - SAF
# ============================================================================
# DocumentFile is the Storage Access Framework facade, crossed by name when
# a document URI is resolved.
-keep class androidx.documentfile.provider.DocumentFile { *; }

# ============================================================================
# Keep ContentResolver and Cursor
# ============================================================================
# ContentResolver and Cursor are used by every component that reads from
# MediaStore. ContentObserver is the base class of StorageObserver.
-keep class android.content.ContentResolver { *; }
-keep class android.database.Cursor { *; }
-keep class android.database.ContentObserver { *; }

# ============================================================================
# Keep SharedPreferences
# ============================================================================
# Every persistent setting in the app lives in SharedPreferences, including
# the selected language tag written by LanguageManager under the key
# "app_language_tag" in the "LlamaPrefs" file, and the active playback
# scope written by MusicService under the key "playback_scope_json" in
# the same file.
-keep class android.content.SharedPreferences { *; }
-keep class android.content.SharedPreferences$Editor { *; }

# ============================================================================
# Keep Intent
# ============================================================================
# Intent and IntentFilter are used by every component. The LANGUAGE_CHANGED
# broadcast that every activity listens for is delivered as an Intent and
# carries the selected language tag as a string extra. The
# APPLY_PLAYBACK_SCOPE broadcast that carries a serialized PlaybackScope
# from FolderManager to MusicService is delivered as an Intent and carries
# the scope under the "scope_json" extra.
-keep class android.content.Intent { *; }
-keep class android.content.IntentFilter { *; }

# ============================================================================
# Keep KeyEvent - Media Buttons
# ============================================================================
# KeyEvent is the payload of every media button dispatch. It is also the
# payload of the volume-up observation in MusicPlayer.dispatchKeyEvent.
-keep class android.view.KeyEvent { *; }

# ============================================================================
# Keep PowerManager - Wake Lock and Battery Optimization
# ============================================================================
# PowerManager and WakeLock are used by MusicService for the playback
# wakelock. Battery optimization checks read PowerManager too.
-keep class android.os.PowerManager { *; }
-keep class android.os.PowerManager$WakeLock { *; }

# ============================================================================
# Keep Notification Classes
# ============================================================================
# Notification, its Builder, MediaStyle, Action, NotificationChannel, and
# NotificationManager are all crossed by name when the playback notification
# is built and posted.
-keep class android.app.Notification { *; }
-keep class android.app.Notification$Builder { *; }
-keep class android.app.Notification$MediaStyle { *; }
-keep class android.app.Notification$Action { *; }
-keep class android.app.NotificationChannel { *; }
-keep class android.app.NotificationManager { *; }

# ============================================================================
# Keep PendingIntent
# ============================================================================
# PendingIntent wraps every transport action in the notification.
-keep class android.app.PendingIntent { *; }

# ============================================================================
# Keep Uri
# ============================================================================
# Uri is the payload of every Storage Access Framework identifier passed
# through the app.
-keep class android.net.Uri { *; }

# ============================================================================
# Keep Paint and Canvas - Placeholder Generation
# ============================================================================
# The themed placeholder bitmap is built by drawing a drawable onto a canvas
# and tinting it with a PorterDuff color filter. Paint, Canvas, Bitmap,
# BitmapFactory, and the drawable classes are all crossed by name during that
# build.
-keep class android.graphics.Paint { *; }
-keep class android.graphics.Canvas { *; }
-keep class android.graphics.Bitmap { *; }
-keep class android.graphics.BitmapFactory { *; }
-keep class android.graphics.drawable.Drawable { *; }
-keep class android.graphics.drawable.GradientDrawable { *; }
-keep class android.graphics.drawable.InsetDrawable { *; }
-keep class android.graphics.drawable.StateListDrawable { *; }
-keep class android.graphics.PorterDuff { *; }
-keep class android.graphics.PorterDuffColorFilter { *; }
-keep class android.graphics.Typeface { *; }

# ============================================================================
# Keep Animation Classes
# ============================================================================
# Animation, AnimationUtils, and AlphaAnimation are used by every themed
# button and by the toast fade. ObjectAnimator drives the spinner's
# rotation through the "rotation" property on View, resolved reflectively;
# the property setter lives on android.view.View and is not processed by R8.
-keep class android.view.animation.Animation { *; }
-keep class android.view.animation.AnimationUtils { *; }
-keep class android.view.animation.AlphaAnimation { *; }
-keep class android.animation.ObjectAnimator { *; }

# ============================================================================
# Keep ViewPropertyAnimator
# ============================================================================
# View.animate() returns a ViewPropertyAnimator; the carousel's commit and
# spring-back animations and the toast fade-in all use it. It is reached by
# name across the framework boundary.
-keep class android.view.ViewPropertyAnimator { *; }

# ============================================================================
# Keep InputMethodManager
# ============================================================================
# InputMethodManager is used by MetadataEditor and PlaylistActivity to show
# and hide the soft keyboard.
-keep class android.view.inputmethod.InputMethodManager { *; }

# ============================================================================
# Keep Locale and LocaleList - Language Selection
# ============================================================================
# LanguageManager.wrap(Context) builds a Configuration whose locale is the
# selected language. On API 24 and later the configuration carries a
# LocaleList; below that it carries a single Locale. Both classes cross the
# framework boundary by name when the configuration is applied, and
# Locale.setDefault writes the JVM-wide default that String.format reads.
# Keeping both ends preserves the configuration round-trip.
-keep class java.util.Locale { *; }
-keep class android.os.LocaleList { *; }
-keep class android.content.res.Configuration { *; }