# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
#
# This ProGuard configuration file controls code shrinking, optimization,
# and obfuscation for the Llama Music Player app. The configuration follows
# a balanced approach focused on performance while maintaining
# debuggability.
#
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keeps readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to MediaPlayer (native playback)
# - YES to MediaSessionCompat and MediaButtonReceiver (media button routing)
# - YES to NotificationController (notification actions)
# - YES to PlaybackScope and PlaybackScopeDialog (favorites and scope)
# - YES to EdgeScrollHelper (shared fast-scroll on playlist and scope dialog)
#
# The app is organised around a set of subsystems, plus one cross-cutting
# concern that touches every activity. The subsystems match the list in
# the README's "Inside the codebase" section, in the same order. They are:
#
#   playback state machine (MusicService), album-art gesture classifier
#   (MusicPlayer), playback window (PlaybackWindow), playback scope
#   (PlaybackScope / PlaybackScopeDialog), notification surface
#   (NotificationController), metadata editor (MetadataEditor), overlay
#   stack (OverlayManager / ToastManager), album-art carousel
#   (AlbumArtCarousel), edge fast-scroll (EdgeScrollHelper), storage
#   observer (StorageObserver), in-memory song list (MusicLibrary),
#   playlist search surface (PlaylistActivity / PlaylistAdapter), and
#   split-screen behaviour (inside MusicPlayer, EqualizerActivity,
#   FolderManager, MetadataEditor, PlaylistActivity).
#
# The localization subsystem is a cross-cutting concern (LanguageManager,
# LanguageDialog) that wraps every activity's base context through
# LanguageManager.wrap in attachBaseContext.
#
# The wildcard keep at the top of this file,
#   -keep class com.ark.llama.** { *; }
# covers every specific com.ark.llama.* keep below it. The specific
# rules are documentation of intent and a safety net if the wildcard is
# ever narrowed. They are retained in full because narrowing the wildcard
# is a plausible future change (e.g., to enable shrinking of app code),
# and at that point each specific rule becomes load-bearing.
#
# Platform classes (java.*, android.*, org.json.*) are never processed by
# R8 — they are outside the input set — so no keep rule is needed for
# them. The third-party keeps below (jaudiotagger, AndroidX media compat)
# are the ones that do real work.
#
# @author Richard Korbla Adzido
# @version 1.5.0
# @since 1.0.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
# optimizationpasses 5 runs R8's optimizer five times. Each pass inlines,
# removes dead code, and propagates constants. Five passes is the standard
# trade-off between output quality and build time.
#
# allowaccessmodification lets R8 widen access modifiers when doing so
# enables inlining across class boundaries.
#
# keepattributes preserves the listed debug metadata through the R8 pass.
# SourceFile and LineNumberTable make stack traces readable; Exceptions,
# Signature, Deprecated, EnclosingMethod, InnerClasses, and Annotation
# preserve reflection-visible metadata that jaudiotagger, AndroidX, and
# EventBus read.
#
# renamesourcefileattribute SourceFile replaces the source file name in
# stack traces with the literal "SourceFile", collapsing every frame to
# that name in crash reports.
#
# Note: -repackageclasses '' is intentionally omitted. It is contradicted
# by the wildcard keep on com.ark.llama.** (which preserves the package
# for every matched class) and is moot under -dontobfuscate. It can be
# reinstated if the wildcard is ever removed and obfuscation is enabled.
-optimizationpasses 5
-allowaccessmodification
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses
-keepattributes *Annotation*

# ============================================================================
# Disable Obfuscation (keeps readable stack traces)
# ============================================================================
# dontobfuscate keeps class, method, and field names intact so crash
# reports stay readable.
#
# dontusemixedcaseclassnames is the historical safety rule that keeps R8
# from generating class names that differ only in case. It applies the
# moment obfuscation is re-enabled.
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Logging Removal in Release
# ============================================================================
# assumenosideeffects tells R8 that these Log methods have no observable
# effect on program state. R8 then removes every call site in the release
# build, along with the string concatenation that produces the message.
#
# The three levels listed are the ones that are stripped:
#   d (debug)   - verbose instrumentation
#   v (verbose) - the same
#   i (info)    - informational
# Log.w (warn) and Log.e (error) remain. They fire on real problems and
# are the ones that reach the crash reporter.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# ============================================================================
# Keep All Application Classes
# ============================================================================
# The wildcard rule that keeps every class, field, and method in the app
# package. This is the load-bearing rule for the app's own code under
# -dontobfuscate: it prevents R8's shrinker from removing reflectively
# accessed members. Every specific rule below documents the reflective
# entry point each class provides and becomes load-bearing if this
# wildcard is ever narrowed.
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }

# ----------------------------------------------------------------------------
# Specific app-class keeps (documentation + safety net)
#
# Each block below names a class and the reflective entry point it
# provides. All are currently covered by the wildcard above. They are
# retained verbatim so that narrowing the wildcard is a one-line change
# with no further edits required here.
#
# MusicService (playback state machine), LocalBinder, inner classes.
#   Instantiated by the framework; LocalBinder cast by bound activities.
#   Owns the three-tier playlist (mFullPlaylist / mScopedPlaylist /
#   mCurrentPlaylist) and the favorite column write paths
#   (commitFavorites, toggleFavorite, setFavorite).
#
# PlaybackWindow (immutable playback window).
#   Public fields read by every consumer; equals/hashCode by every compare.
#
# PlaybackScope, Kind enum, inner classes.
#   Kind names serialized by name via serialize()/deserialize() and
#   persisted under "playback_scope_json"; renamed-kind fallback is
#   ALL_SONGS. Four Set<String> fields read by matches() and
#   rebuildPlaylists().
#
# PlaybackScopeDialog, OnScopeAppliedListener.
#   Instantiated by FolderManager; listener implemented anonymously.
#
# AlbumArtCarousel, SwipeState, SwipeCommitListener.
#   Constructed by MusicPlayer; SwipeCommitListener implemented
#   anonymously in initializeViews().
#
# AlbumArtCache.
#   Process-wide singleton; asLruCache() hands the same LruCache to every
#   consumer. Must outlive every activity.
#
# OverlayManager (process-wide dim/spinner overlay).
#   Registers as Application.ActivityLifecycleCallbacks; every callback
#   method called reflectively. SpinnerView rotates via ObjectAnimator's
#   "rotation" property.
#
# NotificationController, ServiceStateSource, PlaybackState.
#   Process-wide singleton; sole writer of media session metadata and
#   playback state.
#
# PlaylistManager, UpdateCallback.
#   Runs scans on a background executor; listener implemented anonymously.
#   OPERATION_GENRE_UPDATE / OPERATION_LIBRARY_RESET are stack tokens.
#
# StorageAccessHelper.
#   SAF singleton reused across components.
#
# StorageObserver.
#   Extends ContentObserver; registered on MediaStore.Audio.Media.
#
# ToastManager.
#   Implements ActivityLifecycleCallbacks; operation-stack manager.
#
# NavigationController, ButtonStateListener, ButtonGroup, Operation.
#   Enums used as map keys and switch discriminants.
#
# MusicLibrary, OnSongsLoadedListener, UpdateProgressListener,
# LoadProgressListener.
#   Instantiated per reader; refreshCache() is the sole writer,
#   invalidate() the reset-path counterpart.
#
# SongDatabase.
#   Extends SQLiteOpenHelper; framework calls onCreate/onUpgrade
#   reflectively. Three write paths keep the favorite column safe:
#   updateSongMetadata(Song), setFavorite(String, boolean), and the
#   fresh-row branch of the insert.
#
# CharacterMapper, ParseResult, ParseResult$Status.
#   Final utility; ParseResult returned by every metadata read.
#
# MetadataReader, MetadataBundle, MetadataWriter, WriteResult,
# UpdateBundle.
#   Final utilities; bundles read field-by-field at every call site.
#
# EqualizerManager, EqualizerListener.
#   Singleton wrapping the three audio-effect classes.
#
# ThemeManager, ThemeHelper.
#   Singletons read by every activity/dialog.
#
# LanguageManager.
#   Process-wide singleton. Holds LANGUAGE_TAGS and LANGUAGE_NAMES as
#   parallel arrays read by index; wrap(Context) called from every
#   activity's attachBaseContext.
#
# FolderManager, FolderAdapter, FolderItem, FolderViewHolder,
# OnFolderRemoveListener.
#   Framework-instantiated activity; adapter ViewHolder created by
#   RecyclerView; FolderItem crosses the boundary into PlaybackScopeDialog.
#
# PlaylistActivity, PendingFavorites.
#   Framework-instantiated. PendingFavorites stages heart taps across a
#   lifecycle boundary; flushed in onPause() to
#   MusicService.commitFavorites(Map).
#
# PlaylistAdapter, ViewHolder, OnSongClickListener, FavoriteListener.
#   ViewHolder created by RecyclerView; DiffUtil callback instantiated
#   per update; per-row heart flips Song.favorite and forwards to the
#   listener.
#
# EdgeScrollHelper.
#   Final utility; attach(RecyclerView) installs an anonymous
#   OnItemTouchListener reached only through the list.
#
# EqualizerActivity, MetadataEditor, MusicPlayer.
#   Framework-instantiated activities. MusicPlayer owns the album-art
#   gesture classifier (TOUCHED, CAROUSEL, VOLUME, PLAYBACK, CANCELLED)
#   and dispatches handleGestureDoubleTap() to
#   MusicService.toggleFavorite. dispatchKeyEvent observes volume-up
#   before the window system consumes it.
#
# CreditsDialog, PresetDialog, ThemeDialog, LanguageDialog, and their
# listener interfaces.
#   Programmatic dialogs; listeners implemented anonymously.
#
# FontAwesome.
#   Final utility; Unicode constants read by name (HEART by MusicPlayer
#   and PlaylistAdapter).
#
# BluetoothReceiver.
#   Framework-instantiated broadcast receiver.
#
# Song.
#   mFavorite travels with the song through the three-tier playlist;
#   isFavorite()/setFavorite(boolean) read by PlaybackScope.matches,
#   PlaylistAdapter bind, PendingFavorites, and MusicService.
# ----------------------------------------------------------------------------
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

-keep class com.ark.llama.PlaybackWindow { *; }

-keep class com.ark.llama.PlaybackScope { *; }
-keep class com.ark.llama.PlaybackScope$* { *; }

-keep class com.ark.llama.PlaybackScopeDialog { *; }
-keep class com.ark.llama.PlaybackScopeDialog$* { *; }
-keep interface com.ark.llama.PlaybackScopeDialog$OnScopeAppliedListener { *; }

-keep class com.ark.llama.AlbumArtCarousel { *; }
-keep class com.ark.llama.AlbumArtCarousel$* { *; }
-keep interface com.ark.llama.AlbumArtCarousel$SwipeCommitListener { *; }
-keep class com.ark.llama.AlbumArtCarousel$SwipeState { *; }

-keep class com.ark.llama.AlbumArtCache { *; }
-keep class com.ark.llama.AlbumArtCache$* { *; }

-keep class com.ark.llama.OverlayManager { *; }
-keep class com.ark.llama.OverlayManager$* { *; }

-keep class com.ark.llama.NotificationController { *; }
-keep class com.ark.llama.NotificationController$* { *; }
-keep interface com.ark.llama.NotificationController$ServiceStateSource { *; }

-keep class com.ark.llama.PlaylistManager { *; }
-keep class com.ark.llama.PlaylistManager$* { *; }
-keep interface com.ark.llama.PlaylistManager$UpdateCallback { *; }

-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageAccessHelper$* { *; }

-keep class com.ark.llama.StorageObserver { *; }

-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.ToastManager$* { *; }

-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep class com.ark.llama.NavigationController$ButtonGroup { *; }
-keep class com.ark.llama.NavigationController$Operation { *; }

-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.MusicLibrary$* { *; }
-keep interface com.ark.llama.MusicLibrary$OnSongsLoadedListener { *; }
-keep interface com.ark.llama.MusicLibrary$UpdateProgressListener { *; }
-keep interface com.ark.llama.MusicLibrary$LoadProgressListener { *; }

-keep class com.ark.llama.SongDatabase { *; }
-keep class com.ark.llama.SongDatabase$* { *; }

-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$ParseResult { *; }
-keep class com.ark.llama.CharacterMapper$ParseResult$Status { *; }

-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$MetadataBundle { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$WriteResult { *; }
-keep class com.ark.llama.MetadataWriter$UpdateBundle { *; }

-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.EqualizerManager$* { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

-keep class com.ark.llama.LanguageManager { *; }

-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderManager$* { *; }

-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }
-keep class com.ark.llama.FolderAdapter$FolderItem { *; }
-keep class com.ark.llama.FolderAdapter$FolderViewHolder { *; }

-keep class com.ark.llama.PlaylistActivity { *; }
-keep class com.ark.llama.PlaylistActivity$* { *; }
-keep class com.ark.llama.PlaylistActivity$PendingFavorites { *; }

-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }
-keep interface com.ark.llama.PlaylistAdapter$FavoriteListener { *; }
-keep class com.ark.llama.PlaylistAdapter$ViewHolder { *; }

-keep class com.ark.llama.EdgeScrollHelper { *; }

-keep class com.ark.llama.EqualizerActivity { *; }
-keep class com.ark.llama.MetadataEditor { *; }
-keep class com.ark.llama.MusicPlayer { *; }

-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.CreditsDialog$* { *; }

-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }

-keep class com.ark.llama.LanguageDialog { *; }
-keep class com.ark.llama.LanguageDialog$* { *; }
-keep interface com.ark.llama.LanguageDialog$OnLanguageSelectedListener { *; }

-keep class com.ark.llama.FontAwesome { *; }
-keep class com.ark.llama.BluetoothReceiver { *; }
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Keep Android Components
# ============================================================================
# Every Android component declared in the manifest is instantiated by the
# framework through reflection. Every activity's attachBaseContext
# override is also reached through this reflection path.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.view.ViewGroup
-keep public class * extends android.widget.RemoteViews
-keep public class * extends android.appwidget.AppWidgetProvider
-keep public class * extends android.app.Application

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
# Custom views are inflated from XML by the LayoutInflater, which calls
# the (Context, AttributeSet) constructor reflectively. The single-arg
# and three-arg variants are kept for programmatic construction and for
# styles.
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
# The standard serialization contract requires serialVersionUID and the
# four magic methods to be present under their canonical names. Nothing
# in the app implements Serializable today, so this block is a no-op;
# it is kept so any class that reintroduces the contract is preserved
# without a follow-up edit to this file.
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Enums
# ============================================================================
# values() and valueOf(String) are used reflectively by the framework and
# by code that persists enum names to SharedPreferences. The names of
# PlaybackScope.Kind are serialized by PlaybackScope.serialize() and read
# back by PlaybackScope.deserialize().
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
# CREATOR is read reflectively by the Parcel unmarshalling machinery.
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Resource IDs
# ============================================================================
# The fields of every R inner class are read by name through the
# generated R class.
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Keep Third-Party Libraries - jaudiotagger
# ============================================================================
# jaudiotagger is a jar dependency with a broad reflective surface: it
# discovers format readers by class name. Kept whole with warnings
# suppressed because the library references classes that are absent from
# the Android runtime.
#
# Note: the AndroidX keeps that were previously in this section have been
# removed. AndroidX AARs ship their own consumer ProGuard rules, which R8
# reads automatically. Blanket-keeping androidx.** defeats shrinking of
# library code. Only the AndroidX classes that this app reflects on
# directly are kept below (media compat namespace).
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# ============================================================================
# Keep androidx.media Compat Classes
# ============================================================================
# The androidx.media artifact publishes its runtime classes under the
# android.support.v4.media package namespace for binary compatibility.
# Only the MediaButtonReceiver is published under androidx.media. The
# notification MediaStyle binds to the compat session classes by name
# across the JNI boundary, so those are kept explicitly.
-keep class android.support.v4.media.** { *; }
-keep interface android.support.v4.media.** { *; }
-dontwarn android.support.v4.media.**

-keep class androidx.media.** { *; }
-keep interface androidx.media.** { *; }
-dontwarn androidx.media.**

# ============================================================================
# Keep MediaSessionCompat and Token Types
# ============================================================================
# MediaSessionCompat.Token.getToken() returns the framework
# MediaSession.Token on API 21+. The compat/framework boundary is crossed
# by reflection when Notification.MediaStyle.setMediaSession(...) is
# called. Both ends are kept.
-keep class android.support.v4.media.session.MediaSessionCompat { *; }
-keep class android.support.v4.media.session.MediaSessionCompat$Token { *; }
-keep class android.support.v4.media.session.PlaybackStateCompat { *; }
-keep class android.support.v4.media.MediaMetadataCompat { *; }

# ============================================================================
# Keep DocumentFile - SAF
# ============================================================================
# DocumentFile is the Storage Access Framework facade, crossed by name
# when a document URI is resolved.
-keep class androidx.documentfile.provider.DocumentFile { *; }

# ============================================================================
# Keep EventBus
# ============================================================================
# EventBus delivers events posted by BroadcastTranslator to @Subscribe
# methods, which it discovers reflectively. R8 would otherwise strip
# every @Subscribe method (they have no in-code reference) and every
# ThreadMode constant. The two rules below keep both.
-keepclassmembers class ** {
    @org.greenrobot.eventbus.Subscribe <methods>;
}
-keep enum org.greenrobot.eventbus.ThreadMode { *; }

# ============================================================================
# Silence Common R8 Notes
# ============================================================================
# R8 emits informational notes about reflection on classes it cannot
# see. The notes silenced here are the ones that fire on every build of
# this app and have no effect on the release.
-dontnote org.jaudiotagger.**
-dontnote android.support.v4.media.**
-dontnote androidx.media.**

# ============================================================================
# Silence Optional Dependencies Referenced by jaudiotagger
# ============================================================================
# jaudiotagger references a handful of classes that are not part of the
# Android runtime. R8 warns about each unless the reference is silenced.
# None of these classes is ever loaded at runtime on Android; the
# warnings are informational.
-dontwarn javax.imageio.**
-dontwarn javax.sound.**
-dontwarn java.awt.**
-dontwarn javax.swing.**
-dontwarn org.slf4j.**
-dontwarn org.apache.**
-dontwarn org.w3c.dom.**

# ============================================================================
# End of ProGuard rules
# ============================================================================