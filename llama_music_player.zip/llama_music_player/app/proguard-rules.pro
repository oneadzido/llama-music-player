# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
#
# This ProGuard configuration file controls code shrinking,
# optimization, and obfuscation for the Llama Music Player app. The
# configuration follows a balanced approach focused on performance
# while maintaining debuggability.
#
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keeps readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to MediaPlayer (native playback)
# - YES to MediaSessionCompat and MediaButtonReceiver (media button routing)
# - YES to NotificationController (notification actions)
# - YES to EventBus and the sealed event hierarchy
#
# The app is organised around a set of subsystems, plus one
# cross-cutting concern that touches every activity. The subsystems
# match the list in the README's "Inside the codebase" section, in
# the same order. v1.5.0 replaces every internal broadcast with an
# EventBus event; the rules below keep the event classes and the
# reflection surfaces the bus depends on.
#
# The bus is built with the library's reflective subscriber lookup.
#
# Section header convention:
# - "Keep <Subject>" for rules that preserve classes, methods, or fields
# - Descriptive headers (Performance, Obfuscation, Logging) for build
#   behavior
#
# @author Richard Korbla Adzido
# @version 1.5.0
# @since 1.0.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
# -optimizationpasses 5 runs R8's optimizer five times. Each pass
# inlines, removes dead code, and propagates constants.
#
# -allowaccessmodification lets R8 widen access modifiers when doing
# so enables inlining across class boundaries.
#
# -repackageclasses '' puts every class in the default package after
# processing, which removes the package prefix from class names and
# shrinks the constant pool.
#
# -keepattributes preserves the listed debug metadata through the R8
# pass. SourceFile and LineNumberTable make stack traces readable;
# Exceptions, Signature, Deprecated, EnclosingMethod, InnerClasses,
# and *Annotation* preserve reflection-visible metadata that
# jaudiotagger, AndroidX, Kotlin, and EventBus read.
#
# -renamesourcefileattribute SourceFile replaces the source file name
# in stack traces with the literal "SourceFile", collapsing every
# frame to that name in crash reports.
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# Disable Obfuscation
# ============================================================================
# -dontobfuscate keeps class, method, and field names intact so
# crash reports stay readable.
#
# -dontusemixedcaseclassnames is the historical safety rule that
# keeps R8 from generating class names that differ only in case.
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Logging Removal in Release
# ============================================================================
# -assumenosideeffects tells R8 that these Log methods have no
# observable effect on program state. R8 then removes every call
# site in the release build, along with the string concatenation
# that produces the message.
#
# The three levels listed are the ones that are stripped:
#   d (debug)   - verbose instrumentation
#   v (verbose) - the same
#   i (info)    - informational
# Log.w (warn) and Log.e (error) remain. They fire on real problems
# and are the ones that reach the crash reporter.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# ============================================================================
# Keep All Application Classes
# ============================================================================
# The wildcard rule that keeps every class, field, and method in the
# app package. Every specific rule below documents the reflective
# entry point each class provides.
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }

# ============================================================================
# Keep EventBus
# ============================================================================
# v1.5.0 replaces every internal broadcast with an EventBus event.
# The bus uses reflection in three places:
#
# - @Subscribe methods are called reflectively when a subscriber is
#   added at runtime.
# - ThreadMode is read reflectively by the EventBus builder.
# - ThrowableFailureEvent subclasses are instantiated reflectively
#   by the failure-handling helpers (present in the library even
#   when not used).

# Every @Subscribe method on any class.
-keepclassmembers class ** {
    @org.greenrobot.eventbus.Subscribe <methods>;
}

# The ThreadMode enum, whose constants are read by name.
-keep enum org.greenrobot.eventbus.ThreadMode { *; }

# The failure event base class and its Throwable constructor.
-keepclassmembers class * extends org.greenrobot.eventbus.util.ThrowableFailureEvent {
    public <init>(java.lang.Throwable);
}

# The event hierarchy. Sticky events survive process death and are
# re-read by type on the next launch; a renamed class cannot be
# recovered. The wildcard keeps every event class and every nested
# companion.
-keep class com.ark.llama.event.** { *; }
-keep interface com.ark.llama.event.** { *; }

# ============================================================================
# Keep Kotlin Runtime
# ============================================================================
# The Kotlin runtime generates metadata that libraries read
# reflectively. The @Metadata annotation on every Kotlin class must
# survive so reflection on Kotlin class shapes keeps working; the
# runtime itself is kept whole so R8 does not narrow it to observed
# call sites.
-keep class kotlin.Metadata { *; }
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# ============================================================================
# Keep MusicService - The Playback State Machine
# ============================================================================
# MusicService is instantiated by the framework from the manifest.
# LocalBinder is the return type of onBind and is cast by every bound
# activity. The class is the sole authority for the playback window.
#
# The class owns the three-tier playlist. mFullPlaylist is the
# database reflection, mScopedPlaylist is the PlaybackScope-filtered
# subset, and mCurrentPlaylist is the active queue.
# rebuildPlaylists() is the single mutator for the latter two.
# setPlaybackScope(), getPlaybackScope(), getScopedPlaylist(),
# getScopedPlaylistSize(), commitFavorites(), toggleFavorite(),
# requestResumeFromGesture() are the public surface for favorites,
# scope, and the gesture-resume fix.
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

# ============================================================================
# Keep PlaybackWindow - The Playback Window
# ============================================================================
# PlaybackWindow is an immutable value holding the three paths the
# album-art carousel renders and the service's monotonic transition
# counter. Its three public fields are read directly by every
# consumer; its equals and hashCode are called by every window
# comparison. The class is instantiated by MusicService on every
# event and by MusicPlayer on every received event.
-keep class com.ark.llama.PlaybackWindow { *; }

# ============================================================================
# Keep PlaybackScope - The Playback Scope Value Object
# ============================================================================
# PlaybackScope is an immutable value object describing which subset
# of the library the player considers its current play scope. Its
# Kind enum is serialized by name through serialize() / deserialize()
# and through the persisted preference under the
# "playback_scope_json" key. The Kind names are therefore stable
# identifiers: a kind renamed in a future release would fail to
# deserialize an older preference, and the fallback is
# PlaybackScope.ALL_SONGS.
-keep class com.ark.llama.PlaybackScope { *; }
-keep class com.ark.llama.PlaybackScope$* { *; }

# ============================================================================
# Keep PlaybackScopeDialog - The Playback Scope Selection Dialog
# ============================================================================
# Instantiated by FolderManager. Its OnScopeAppliedListener interface
# is implemented anonymously at the call site.
-keep class com.ark.llama.PlaybackScopeDialog { *; }
-keep class com.ark.llama.PlaybackScopeDialog$* { *; }
-keep interface com.ark.llama.PlaybackScopeDialog$OnScopeAppliedListener { *; }

# ============================================================================
# Keep AlbumArtCarousel - The Album-Art Carousel
# ============================================================================
# Constructed by MusicPlayer and attached to the album-art container.
# Its SwipeCommitListener interface is implemented anonymously at
# the call site. Its private SwipeState enum is internal, but is
# documented here for completeness.
-keep class com.ark.llama.AlbumArtCarousel { *; }
-keep class com.ark.llama.AlbumArtCarousel$* { *; }
-keep interface com.ark.llama.AlbumArtCarousel$SwipeCommitListener { *; }
-keep class com.ark.llama.AlbumArtCarousel$SwipeState { *; }

# ============================================================================
# Keep AlbumArtCache - Process-Scoped Album Art Bitmap Cache
# ============================================================================
# Process-wide singleton backed by an LruCache<String, Bitmap> keyed
# by song path. Read by AlbumArtCarousel through MusicPlayer, and by
# NotificationController for the playback notification and the media
# session. asLruCache() hands the underlying LruCache to consumers
# whose constructors were already built against LruCache.
-keep class com.ark.llama.AlbumArtCache { *; }
-keep class com.ark.llama.AlbumArtCache$* { *; }

# ============================================================================
# Keep OverlayManager - The Process-Wide Overlay
# ============================================================================
# Process-wide singleton that registers itself as an
# Application.ActivityLifecycleCallbacks listener. The framework
# calls every lifecycle callback reflectively. Its private
# SpinnerView is a custom View subclass instantiated
# programmatically; its rotation animator is driven by ObjectAnimator
# through the "rotation" property, which is resolved reflectively.
-keep class com.ark.llama.OverlayManager { *; }
-keep class com.ark.llama.OverlayManager$* { *; }

# ============================================================================
# Keep NotificationController - Notification Management
# ============================================================================
# Process-wide singleton. MusicService reads its state through the
# ServiceStateSource interface. The controller is the sole writer of
# the media session metadata and of the media session playback
# state. Every user-visible label it draws reads from a string
# resource.
-keep class com.ark.llama.NotificationController { *; }
-keep class com.ark.llama.NotificationController$* { *; }
-keep interface com.ark.llama.NotificationController$ServiceStateSource { *; }

# ============================================================================
# Keep ToastManager - The Operation Stack
# ============================================================================
# Process-wide singleton that implements ActivityLifecycleCallbacks
# and is registered with the Application. Every method on the class
# is called from outside the app package or through the Android
# framework. Its operation stack renders persistent overlays and
# temporary toasts; the overlay is reattached to the current activity
# on every resume.
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.ToastManager$* { *; }

# ============================================================================
# Keep NavigationController - Centralized Button State Management
# ============================================================================
# Exposes listener interfaces plus two enums. The enums are used as
# map keys and as switch discriminants; their names are stable
# identifiers across the app.
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep class com.ark.llama.NavigationController$ButtonGroup { *; }
-keep class com.ark.llama.NavigationController$Operation { *; }

# ============================================================================
# Keep PlaylistManager - Playlist Update Operations
# ============================================================================
# Runs folder scans and genre loading on a background executor. Its
# UpdateCallback and ResetCallback interfaces are implemented
# anonymously at every call site.
-keep class com.ark.llama.PlaylistManager { *; }
-keep class com.ark.llama.PlaylistManager$* { *; }
-keep interface com.ark.llama.PlaylistManager$UpdateCallback { *; }
-keep interface com.ark.llama.PlaylistManager$ResetCallback { *; }

# ============================================================================
# Keep StorageAccessHelper - SAF Operations
# ============================================================================
# Singleton whose instance is reused across every component that
# touches Storage Access Framework URIs.
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageAccessHelper$* { *; }

# ============================================================================
# Keep StorageObserver - The Storage Observer
# ============================================================================
# Extends ContentObserver and is instantiated by MusicPlayer with
# the activity that owns the observer's lifetime.
-keep class com.ark.llama.StorageObserver { *; }

# ============================================================================
# Keep MusicLibrary - In-Memory Song List
# ============================================================================
# Instantiated by every component that reads the song list. Its
# three listener interfaces are implemented anonymously.
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.MusicLibrary$* { *; }
-keep interface com.ark.llama.MusicLibrary$OnSongsLoadedListener { *; }
-keep interface com.ark.llama.MusicLibrary$UpdateProgressListener { *; }
-keep interface com.ark.llama.MusicLibrary$LoadProgressListener { *; }

# ============================================================================
# Keep SongDatabase - Database Helper
# ============================================================================
# Extends SQLiteOpenHelper. The framework calls onCreate and
# onUpgrade reflectively.
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep CharacterMapper - Metadata Cleaning Utility
# ============================================================================
# Final utility object. The nested ParseResult and its Status enum
# are returned by every metadata read and switched on by every
# caller.
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$* { *; }

# ============================================================================
# Keep MetadataReader and MetadataWriter - ID3 Tag Operations
# ============================================================================
# Reader and writer object singletons. Their nested MetadataBundle,
# WriteResult, and UpdateBundle classes are returned or accepted by
# their public methods and are read field-by-field at every call
# site.
-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$* { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$* { *; }

# ============================================================================
# Keep EqualizerManager - Audio Effects
# ============================================================================
# Singleton that wraps the three audio-effect classes. Its
# EqualizerListener is implemented by EqualizerActivity.
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.EqualizerManager$* { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

# ============================================================================
# Keep ThemeManager and ThemeHelper - Theme Management
# ============================================================================
# Both are singletons. ThemeManager reads from SharedPreferences at
# construction; ThemeHelper caches the current color string.
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep LanguageManager - Selected Language and Locale Application
# ============================================================================
# Process-wide singleton that owns the selected language tag and
# the supported-language set. wrap(Context) is called reflectively
# by the framework, because it runs from attachBaseContext.
-keep class com.ark.llama.LanguageManager { *; }

# ============================================================================
# Keep FolderManager, FolderAdapter - Folder Management
# ============================================================================
# FolderManager is instantiated by the framework from the manifest.
# FolderAdapter's ViewHolder is instantiated by RecyclerView through
# the createViewHolder path.
-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderManager$* { *; }
-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }
-keep interface com.ark.llama.FolderAdapter$RemoveButtonStateSource { *; }

# ============================================================================
# Keep PlaylistActivity and PlaylistAdapter
# ============================================================================
# Instantiated by the framework from the manifest. PlaylistAdapter's
# ViewHolder is instantiated by RecyclerView. Its DiffUtil callback
# is instantiated by the adapter on every list update. The per-row
# heart icon's click handler is wired in onBindViewHolder.
-keep class com.ark.llama.PlaylistActivity { *; }
-keep class com.ark.llama.PlaylistActivity$* { *; }
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }
-keep interface com.ark.llama.PlaylistAdapter$FavoriteListener { *; }

# ============================================================================
# Keep EdgeScrollHelper - Edge Fast-Scroll Interceptor
# ============================================================================
# Final utility object. Its only public entry point, attach(...),
# installs an anonymous OnItemTouchListener on the RecyclerView.
-keep class com.ark.llama.EdgeScrollHelper { *; }

# ============================================================================
# Keep EqualizerActivity, MetadataEditor
# ============================================================================
# Both instantiated by the framework from the manifest.
-keep class com.ark.llama.EqualizerActivity { *; }
-keep class com.ark.llama.MetadataEditor { *; }

# ============================================================================
# Keep MusicPlayer - Main Activity
# ============================================================================
# Instantiated by the framework from the manifest. The activity owns
# the album-art gesture classifier, the two-tap Home gesture, the
# volume-gesture resume path, and the split-screen layout.
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Keep Dialogs
# ============================================================================
# All five dialogs are instantiated by the app itself. Their
# listener interfaces are implemented anonymously.
-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.CreditsDialog$* { *; }
-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }
-keep class com.ark.llama.LanguageDialog { *; }
-keep class com.ark.llama.LanguageDialog$* { *; }
-keep interface com.ark.llama.LanguageDialog$OnLanguageSelectedListener { *; }
-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

# ============================================================================
# Keep FontAwesome - Icon Font Utility
# ============================================================================
# Final utility object that loads a Typeface from assets and exposes
# Unicode constants. The constants are read by name at many call
# sites.
-keep class com.ark.llama.FontAwesome { *; }

# ============================================================================
# Keep BluetoothReceiver - Bluetooth Connection-State Handler
# ============================================================================
# Instantiated by the framework from the manifest.
-keep class com.ark.llama.BluetoothReceiver { *; }

# ============================================================================
# Keep Song - Data Model
# ============================================================================
# The mFavorite field travels with the song through the three-tier
# playlist. The isFavorite and setFavorite accessors are read by
# PlaybackScope.matches, PlaylistAdapter's row bind,
# PlaylistActivity's pending-favorites staging, and MusicService's
# three-tier playlist.
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Keep Android Components
# ============================================================================
# Every Android component declared in the manifest is instantiated
# by the framework through reflection. Every activity's
# attachBaseContext override is also reached through this reflection
# path.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.view.ViewGroup
-keep public class * extends android.widget.RemoteViews
-keep public class * extends android.appwidget.AppWidgetProvider

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
# Custom views are inflated from XML by the LayoutInflater, which
# calls the (Context, AttributeSet) constructor reflectively. The
# single-arg and three-arg variants are kept for programmatic
# construction and for styles.
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
# The standard serialization contract requires serialVersionUID and
# the four magic methods to be present under their canonical names.
# Nothing in the app implements Serializable today, so this block is
# a no-op; it is kept so any class that reintroduces the contract is
# preserved without a follow-up edit to this file.
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Enums
# ============================================================================
# values() and valueOf(String) are used reflectively by the
# framework and by code that persists enum names to
# SharedPreferences. The names of PlaybackScope.Kind are serialized
# by PlaybackScope.serialize() and read back by
# PlaybackScope.deserialize().
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
# CREATOR is read reflectively by the Parcel unmarshalling
# machinery.
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Atomic Classes
# ============================================================================
# java.util.concurrent.atomic is used throughout the app for
# lock-free state.
-keep class java.util.concurrent.atomic.** { *; }

# ============================================================================
# Keep Handler and Looper
# ============================================================================
# Used by every component in the app.
-keep class android.os.Handler { *; }
-keep class android.os.Looper { *; }

# ============================================================================
# Keep SystemClock
# ============================================================================
# SystemClock.elapsedRealtime is the monotonic time source used by
# every state machine in the app.
-keep class android.os.SystemClock { *; }

# ============================================================================
# Keep ExecutorService and Future
# ============================================================================
# The three components that own single-thread executors
# (MusicService, MusicPlayer, MusicLibrary) refer to
# ExecutorService, Executors, and Future by their full names.
-keep class java.util.concurrent.ExecutorService { *; }
-keep class java.util.concurrent.Future { *; }
-keep class java.util.concurrent.Executors { *; }

# ============================================================================
# Keep Map and HashMap
# ============================================================================
# MusicService.commitFavorites takes a Map<String, Boolean>; the
# caller stages the map in PlaylistActivity.PendingFavorites.
-keep class java.util.Map { *; }
-keep class java.util.HashMap { *; }

# ============================================================================
# Keep Set and HashSet
# ============================================================================
# PlaybackScope carries four Set<String> fields (paths, genres,
# artists, albums). MusicService carries a Set<String> of
# loose-track paths that PlaybackScope.matches consults.
-keep class java.util.Set { *; }
-keep class java.util.HashSet { *; }

# ============================================================================
# Keep org.json - Playback Scope Serialization
# ============================================================================
# PlaybackScope.serialize() and deserialize() produce and consume a
# JSON object string through the framework's org.json package.
-keep class org.json.** { *; }
-dontwarn org.json.**

# ============================================================================
# Keep Resource IDs
# ============================================================================
# The fields of every R inner class are read by name through the
# generated R class.
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Keep Third-Party Libraries - jaudiotagger, AndroidX, Android Framework
# ============================================================================
# jaudiotagger is a jar dependency with a broad reflective surface:
# it discovers format readers by class name. Kept whole with
# warnings suppressed because the library references classes that
# are absent from the Android runtime.
#
# AndroidX is kept whole because the version in use relies on
# reflection for lifecycle dispatch and fragment restoration.
#
# android.media.** is kept whole because every media class crosses
# the JNI boundary by name.
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class android.media.** { *; }
-dontwarn android.media.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Keep androidx.media Compat Classes
# ============================================================================
# The androidx.media artifact publishes its runtime classes under
# the android.support.v4.media package namespace for binary
# compatibility. Only the MediaButtonReceiver is published under
# androidx.media. R8 keeps both namespaces so the session classes
# remain available and the notification MediaStyle binds to them.
-keep class android.support.v4.media.** { *; }
-keep interface android.support.v4.media.** { *; }
-dontwarn android.support.v4.media.**

-keep class androidx.media.** { *; }
-keep interface androidx.media.** { *; }
-dontwarn androidx.media.**

# ============================================================================
# Keep MediaSessionCompat and Token Types
# ============================================================================
# MediaSessionCompat.Token.getToken() returns the framework
# MediaSession.Token on API 21+. The compat/framework boundary is
# crossed by reflection when
# Notification.MediaStyle.setMediaSession(...) is called.
-keep class android.support.v4.media.session.MediaSessionCompat { *; }
-keep class android.support.v4.media.session.MediaSessionCompat$Token { *; }
-keep class android.support.v4.media.session.PlaybackStateCompat { *; }
-keep class android.support.v4.media.MediaMetadataCompat { *; }

-keep class android.media.session.MediaSession { *; }
-keep class android.media.session.MediaSession$Token { *; }
-keep class android.media.session.PlaybackState { *; }
-keep class android.media.MediaMetadata { *; }

# ============================================================================
# Keep AudioTrack and Audio Attributes
# ============================================================================
# Crossed by name when the MediaPlayer opens its output stream.
-keep class android.media.AudioTrack { *; }
-keep class android.media.AudioAttributes { *; }
-keep class android.media.AudioFormat { *; }

# ============================================================================
# Keep AudioFocus Classes
# ============================================================================
# AudioManager and AudioFocusRequest are used by MusicService for
# the focus lifecycle, and both are crossed by name.
-keep class android.media.AudioManager { *; }
-keep class android.media.AudioFocusRequest { *; }

# ============================================================================
# Keep PlaybackParams - Speed and Pitch Adjustment
# ============================================================================
# MusicService.updatePlaybackParams() round-trips a PlaybackParams
# through MediaPlayer.getPlaybackParams() / setPlaybackParams(). The
# framework side of that call crosses the JNI boundary by name.
-keep class android.media.PlaybackParams { *; }
-keep class android.media.PlaybackParams$* { *; }

# ============================================================================
# Keep MediaPlayer - Native Playback
# ============================================================================
# MediaPlayer is the audio engine. Every method on it crosses the
# JNI boundary.
-keep class android.media.MediaPlayer { *; }
-keep class android.media.MediaPlayer$* { *; }

# ============================================================================
# Keep MediaMetadataRetriever - Album Art Extraction
# ============================================================================
# Extracts embedded album art and duration. Crossed by name.
-keep class android.media.MediaMetadataRetriever { *; }

# ============================================================================
# Keep MediaStore Classes
# ============================================================================
# MediaStore, MediaStore.Audio.Media, and MediaStore.Files are
# queried by column name. The column names are string constants on
# these classes.
-keep class android.provider.MediaStore { *; }
-keep class android.provider.MediaStore$Audio$Media { *; }
-keep class android.provider.MediaStore$Files { *; }

# ============================================================================
# Keep DocumentFile - SAF
# ============================================================================
# DocumentFile is the Storage Access Framework facade, crossed by
# name when a document URI is resolved.
-keep class androidx.documentfile.provider.DocumentFile { *; }

# ============================================================================
# Keep ContentResolver and Cursor
# ============================================================================
# ContentResolver and Cursor are used by every component that reads
# from MediaStore. ContentObserver is the base class of
# StorageObserver.
-keep class android.content.ContentResolver { *; }
-keep class android.database.Cursor { *; }
-keep class android.database.ContentObserver { *; }

# ============================================================================
# Keep SharedPreferences
# ============================================================================
# Every persistent setting in the app lives in SharedPreferences,
# including the selected language tag (written by LanguageManager
# under "app_language_tag" in "LlamaPrefs") and the active playback
# scope (written by MusicService under "playback_scope_json" in the
# same file).
-keep class android.content.SharedPreferences { *; }
-keep class android.content.SharedPreferences$Editor { *; }

# ============================================================================
# Keep Intent
# ============================================================================
# Intent and IntentFilter are used by every component, including the
# remaining system-broadcast paths in BluetoothReceiver and
# MusicService's volume receiver.
-keep class android.content.Intent { *; }
-keep class android.content.IntentFilter { *; }

# ============================================================================
# Keep KeyEvent - Media Buttons
# ============================================================================
# The payload of every media button dispatch.
-keep class android.view.KeyEvent { *; }

# ============================================================================
# Keep PowerManager - Wake Lock and Battery Optimization
# ============================================================================
# PowerManager and WakeLock are used by MusicService for the
# playback wakelock.
-keep class android.os.PowerManager { *; }
-keep class android.os.PowerManager$WakeLock { *; }

# ============================================================================
# Keep Notification Classes
# ============================================================================
# Notification, its Builder, MediaStyle, Action, NotificationChannel,
# and NotificationManager are all crossed by name when the playback
# notification is built and posted.
-keep class android.app.Notification { *; }
-keep class android.app.Notification$Builder { *; }
-keep class android.app.Notification$MediaStyle { *; }
-keep class android.app.Notification$Action { *; }
-keep class android.app.NotificationChannel { *; }
-keep class android.app.NotificationManager { *; }

# ============================================================================
# Keep PendingIntent
# ============================================================================
# PendingIntent wraps every transport action in the notification.
-keep class android.app.PendingIntent { *; }

# ============================================================================
# Keep Uri
# ============================================================================
# Uri is the payload of every Storage Access Framework identifier
# passed through the app.
-keep class android.net.Uri { *; }

# ============================================================================
# Keep Paint and Canvas - Placeholder Generation
# ============================================================================
# The themed placeholder bitmap is built by drawing a drawable onto
# a canvas and tinting it with a PorterDuff color filter.
-keep class android.graphics.Paint { *; }
-keep class android.graphics.Canvas { *; }
-keep class android.graphics.Bitmap { *; }
-keep class android.graphics.BitmapFactory { *; }
-keep class android.graphics.drawable.Drawable { *; }
-keep class android.graphics.drawable.GradientDrawable { *; }
-keep class android.graphics.drawable.InsetDrawable { *; }
-keep class android.graphics.drawable.StateListDrawable { *; }
-keep class android.graphics.PorterDuff { *; }
-keep class android.graphics.PorterDuffColorFilter { *; }
-keep class android.graphics.Typeface { *; }

# ============================================================================
# Keep Animation Classes
# ============================================================================
# Animation, AnimationUtils, and AlphaAnimation are used by every
# themed button and by the toast fade. ObjectAnimator drives the
# spinner's rotation through the "rotation" property on View,
# resolved reflectively.
-keep class android.view.animation.Animation { *; }
-keep class android.view.animation.AnimationUtils { *; }
-keep class android.view.animation.AlphaAnimation { *; }
-keep class android.animation.ObjectAnimator { *; }

# ============================================================================
# Keep ViewPropertyAnimator
# ============================================================================
# View.animate() returns a ViewPropertyAnimator; the carousel's
# commit and spring-back animations and the toast fade-in all use
# it.
-keep class android.view.ViewPropertyAnimator { *; }

# ============================================================================
# Keep InputMethodManager
# ============================================================================
# Used by MetadataEditor and PlaylistActivity to show and hide the
# soft keyboard.
-keep class android.view.inputmethod.InputMethodManager { *; }

# ============================================================================
# Keep Locale and LocaleList - Language Selection
# ============================================================================
# LanguageManager.wrap(Context) builds a Configuration whose locale
# is the selected language. On API 24 and later the configuration
# carries a LocaleList; below that it carries a single Locale.
-keep class java.util.Locale { *; }
-keep class android.os.LocaleList { *; }
-keep class android.content.res.Configuration { *; }

# ============================================================================
# Keep API-Level Compatibility Classes
# ============================================================================
# Read through on lower API levels than the one the app compiles
# against.
-keep class android.os.Build { *; }
-keep class android.os.Build$VERSION { *; }

# ============================================================================
# Keep Optional Dependencies Referenced by jaudiotagger
# ============================================================================
# jaudiotagger references a handful of classes that are not part of
# the Android runtime. R8 warns about each unless the reference is
# silenced. None of these classes is ever loaded at runtime on
# Android; the warnings are informational.
-dontwarn javax.imageio.**
-dontwarn javax.sound.**
-dontwarn java.awt.**
-dontwarn javax.swing.**
-dontwarn org.jaudiotagger.**
-dontwarn org.slf4j.**
-dontwarn org.apache.**
-dontwarn org.w3c.dom.**

# ============================================================================
# Keep Kotlin Metadata (if any)
# ============================================================================
# The app is written in Kotlin, but AndroidX and jaudiotagger carry
# Kotlin metadata in some releases. Keeping the annotation preserves
# the reflective surface for the libraries that read it.
-keepattributes *Annotation*, InnerClasses

# ============================================================================
# Keep Application Entry Points
# ============================================================================
# LlamaMusicPlayer is instantiated by the framework before any other
# component. It is kept through the general Application rule here.
-keep class * extends android.app.Application

# ============================================================================
# Silence Common R8 Notes
# ============================================================================
# R8 emits informational notes about reflection on classes it cannot
# see. The three notes silenced here are the ones that fire on every
# build of this app and have no effect on the release.
-dontnote org.jaudiotagger.**
-dontnote android.support.v4.media.**
-dontnote androidx.media.**

# ============================================================================
# End of ProGuard rules
# ============================================================================