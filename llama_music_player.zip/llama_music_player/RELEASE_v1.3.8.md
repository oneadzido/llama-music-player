# Llama Music Player v1.3.8

**Release date:** Oct 27, 2026

---

### Overview

The notification surface commits the same state the player screen
commits, on the same main-thread turn, and only when a transition
commits.

`NotificationController.commitFromBroadcast` is the notification's
primary commit path. `MusicService.broadcastUpdate` calls it
immediately after `sendBroadcast` returns, with the exact snapshot
the broadcast described. The player screen commits inside its
`UPDATE_PLAYER` receiver, which runs synchronously inside that same
`sendBroadcast` call. Both commits land on the same main-thread turn
with the same snapshot: same title, artist, art, playing flag,
generation.

`broadcastUpdate` is the only path that commits the notification.
State changes that occur before a transition commits — a prepare in
flight, a pause scheduled during a prepare, a resume scheduled during
a prepare — do not commit the notification. During PREPARING both
surfaces continue to show the song the previous transition committed;
both advance to the target on the same turn, when the transition
commits. This is what a rapid next/next/next produces: no matter how
fast the taps arrive, the notification never advances to a song the
player screen has not yet advanced to, because neither surface
advances until the transition commits.

A generation filter drops any notification read whose generation is
strictly lower than the last committed generation, so a poll that
captured state before a broadcast cannot re-apply it after the
broadcast lands. The poll remains in place as the safety-net cadence
for position updates and for state changes that do not reach the
notification through a broadcast — art resolving after the commit,
the theme changing.

---

### Fixed

- **Notification play/pause icon matches the audio on every transport
  action** — The icon reads the destination of the current
  transition from the state machine, the same value the player
  screen's icon reads, and commits it on the same main-thread turn as
  the player screen. A play/pause tap from the notification, the
  lockscreen, a headset, or the player screen produces the same icon
  change on both surfaces on the same frame. A pause scheduled
  during a prepare, a resume issued during a prepare, and an
  audio-focus transition that changes the state all reach the
  notification as they reach the player screen: through
  `broadcastUpdate`, with the same snapshot.

- **Notification title, artist, and art match the player screen
  through every transition** — When a transition begins, neither
  surface advances. Both continue to show the song the previous
  transition committed. When the transition commits, both advance to
  the target on the same frame. A rapid sequence of next or previous
  taps holds the previous song on both surfaces until the first
  transition commits, then advances both surfaces in step for each
  subsequent commit. The notification never shows a song the player
  screen has not yet shown.

- **Foreground promotion is retried on failure** — A
  `startForeground` call that throws leaves the controller's
  foreground flag `false`, so the next sync retries the promotion.
  The flag is set only after the call succeeds.

---

### Under the Hood

- `NotificationController.ServiceStateSource` — `long
  getGeneration()`. Returns the service's monotonic transition
  counter. Both `commitFromBroadcast` and `syncOnce` use it to drop
  stale reads.

- `NotificationController.commitFromBroadcast(long, RenderSnapshot)`
  — the notification's primary commit path.
  `MusicService.broadcastUpdate` calls it after `sendBroadcast`
  returns, with the exact snapshot the broadcast described.
  Marshals to the main thread from any other thread. Drops any call
  whose generation is strictly lower than the last committed
  generation.

- `NotificationController.syncOnce()` — reads
  `ServiceStateSource.getGeneration()` first. When the generation is
  strictly lower than `mLastCommittedGeneration`, the read is
  dropped. When it is at or beyond that generation, the snapshot is
  committed and `mLastCommittedGeneration` advances.

- `NotificationController.mLastCommittedGeneration` — the generation
  as of the last committed snapshot. Advanced by both commit paths.
  Reset in `detachService()`, `clearPlaybackNotification()`, and
  `shutdown()`.

- `NotificationController.performPlaybackUpdate()` — the
  `mPlaybackForeground` flag is set only after
  `Service.startForeground` returns.

- `MusicService.mStateSource` — implements `getGeneration()`,
  returning `mGeneration`.

- `MusicService.broadcastUpdate()` — after `sendBroadcast(intent)`,
  builds the same snapshot from the same main-thread state and calls
  `mNotificationController.commitFromBroadcast(generation, snapshot)`.
  The generation is captured before `sendBroadcast` so the commit and
  the broadcast carry the same value.

- `MusicService.beginTransition(int, int)` — does not commit the
  notification. During PREPARING the notification continues to show
  the previous song; it advances to the target when the transition
  commits through `broadcastUpdate`.

- `MusicService.prefetchNotificationArt()` — the art-resolve poke is
  guarded by `mState != ServiceState.PREPARING`. An art resolve that
  lands during PREPARING is picked up by the commit that fires from
  `broadcastUpdate`; an art resolve that lands after the commit pokes
  the controller on the same main-thread turn as the resolve.

- `MusicService.pokeNotificationIfAttached()` — removed. The state
  changes that previously called it commit through `broadcastUpdate`,
  which is the single notification commit path.

- `MusicService` javadoc — "The Commit Turn" describes
  `broadcastUpdate` as the only notification commit path and
  describes the PREPARING hold.

- `NotificationController` javadoc — "Commit Model" and "Generation
  Filtering" sections document the synchronous commit path and the
  generation filter.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana