# Llama Music Player v1.3.8

**Release date:** Oct 27, 2026

---

### Overview

Four fixes ship in this release: the notification surface commits the
same state the player screen commits, on the same main-thread turn;
the notification's three transport buttons fire their own action
rather than the first one the framework happened to cache; the resume
path commits PLAYING synchronously so every surface flips on the same
turn as the user's tap; and the service no longer debounces transport
actions.

`NotificationController.commitFromBroadcast` is the notification's
primary commit path. `MusicService.broadcastUpdate` calls it
immediately after `sendBroadcast` returns, with the exact snapshot
the broadcast described. The player screen commits inside its
`UPDATE_PLAYER` receiver, which runs synchronously inside that same
`sendBroadcast` call. Both commits land on the same main-thread turn
with the same snapshot: same title, artist, art, playing flag,
generation.

`broadcastUpdate` is the only path that commits the notification.
State changes that occur before a transition commits — a prepare in
flight, a pause scheduled during a prepare, a resume scheduled during
a prepare — do not commit the notification. During PREPARING both
surfaces continue to show the song the previous transition committed;
both advance to the target on the same turn, when the transition
commits.

The three media-button PendingIntents the notification attaches to
play/pause, next, and previous carry distinct request codes (1, 2, 3)
and their own keycodes. The framework's PendingIntent cache keys on
request code plus `Intent.filterEquals`, which does not compare
extras; three intents that share `ACTION_MEDIA_BUTTON` and the
`MediaButtonReceiver` component and differ only in `EXTRA_KEY_EVENT`
filter as equal, so a shared request code returns the same
`PendingIntent` for all three, carrying whichever keycode was set
first. Distinct request codes keep the three intents distinct, so a
tap on play/pause dispatches play/pause, a tap on next dispatches
next, and a tap on previous dispatches previous.

`doResume` commits `PLAYING` synchronously — before `player.start()`
is dispatched to the player thread — so the play/pause icon, the
notification title and art, the media session state, and the player
screen's button all flip on the same main-thread turn as the user's
tap. The async continuation exists only to roll the state back to
IDLE if `player.start()` actually fails, and the rollback is guarded
by both `mStartToken` and `mState` so a subsequent user action is
not clobbered by a start that began before it. `doPause` bumps
`mStartToken` at entry so a pause that arrives during an in-flight
resume invalidates the resume's failure continuation. The `READY`
branch of `togglePlayPause` routes through `doResume`, so a
cold-start play uses the same synchronous-commit pattern as a
`PAUSED` resume.

The service no longer debounces transport actions. The 500 ms
per-action debounce was masking the two bugs above — the async
resume, and the async PLAYING commit that left the state undecided
when the second tap arrived. With both fixed, the debounce only
dropped user intent. Every transport action the notification,
lockscreen, headset, or player screen produces now reaches the state
machine on the same main-thread turn that dispatched it. The
player screen's own debounce on its buttons is unchanged; that
debounce prevents accidental double-tap on the small touch targets
and does not interact with the notification path.

A generation filter drops any notification read whose generation is
strictly lower than the last committed generation, so a poll that
captured state before a broadcast cannot re-apply it after the
broadcast lands. The poll remains in place as the safety-net cadence
for position updates and for state changes that do not reach the
notification through a broadcast — art resolving after the commit,
the theme changing.

---

### Fixed

- **Notification play/pause button fires play/pause** — A tap on the
  notification's play/pause action dispatches the play/pause keycode
  to the media session. The three media-button PendingIntents the
  notification attaches to play/pause, next, and previous carry
  distinct request codes; the framework's PendingIntent cache keys on
  request code and `Intent.filterEquals`, and the three intents would
  otherwise filter as equal because they share the same action and
  component and differ only in their extras. Distinct request codes
  keep the three intents distinct in the cache, so each button
  dispatches its own keycode.

- **Notification play/pause icon matches the audio on every
  transport action** — The icon reads the destination of the current
  transition from the state machine, the same value the player
  screen's icon reads, and commits it on the same main-thread turn as
  the player screen. A play/pause tap from the notification, the
  lockscreen, a headset, or the player screen produces the same icon
  change on both surfaces on the same frame.

- **Rapid transport taps are honored** — The service does not
  debounce transport actions. A pause that follows a resume within
  any interval is honored: `doResume` commits PLAYING synchronously,
  so the pause sees `PLAYING` and calls `doPause`, whose
  `mStartToken` bump invalidates the resume's failure continuation.
  A next or previous that arrives while a prepare is in flight is
  stored as the deferred target and played once the current prepare
  completes. A second play on an already-playing song is idempotent,
  and a second pause on an already-paused song is a no-op. Every
  sequence of taps reaches the state machine, and the state machine
  handles it correctly.

- **Notification title, artist, and art match the player screen
  through every transition** — When a transition begins, neither
  surface advances. Both continue to show the song the previous
  transition committed. When the transition commits, both advance to
  the target on the same frame.

- **Foreground promotion is retried on failure** — A
  `startForeground` call that throws leaves the controller's
  foreground flag `false`, so the next sync retries the promotion.
  The flag is set only after the call succeeds.

---

### Under the Hood

- `NotificationController.ServiceStateSource` — `long
  getGeneration()`. Returns the service's monotonic transition
  counter. Both `commitFromBroadcast` and `syncOnce` use it to drop
  stale reads.

- `NotificationController.commitFromBroadcast(long, RenderSnapshot)`
  — the notification's primary commit path.
  `MusicService.broadcastUpdate` calls it after `sendBroadcast`
  returns, with the exact snapshot the broadcast described.
  Marshals to the main thread from any other thread. Drops any call
  whose generation is strictly lower than the last committed
  generation.

- `NotificationController.syncOnce()` — reads
  `ServiceStateSource.getGeneration()` first. When the generation is
  strictly lower than `mLastCommittedGeneration`, the read is
  dropped. When it is at or beyond that generation, the snapshot is
  committed and `mLastCommittedGeneration` advances.

- `NotificationController.mLastCommittedGeneration` — the generation
  as of the last committed snapshot. Advanced by both commit paths.
  Reset in `detachService()`, `clearPlaybackNotification()`, and
  `shutdown()`.

- `NotificationController.performPlaybackUpdate()` — the
  `mPlaybackForeground` flag is set only after
  `Service.startForeground` returns.

- `NotificationController` media-button PendingIntents — the three
  intents the notification attaches to play/pause, next, and
  previous are built through a
  `buildMediaPendingIntent(int requestCode, int keyCode)` helper
  with distinct request codes (1, 2, 3). Each intent carries its own
  `KeyEvent` in `EXTRA_KEY_EVENT`. Distinct request codes are
  required because the framework's PendingIntent cache keys on
  request code and `Intent.filterEquals`; three intents that share
  the same action and component and differ only in their extras
  filter as equal, so without distinct request codes the cache
  returns the same `PendingIntent` for all three.

- `MusicService.mStateSource` — implements `getGeneration()`,
  returning `mGeneration`.

- `MusicService.broadcastUpdate()` — after `sendBroadcast(intent)`,
  builds the same snapshot from the same main-thread state and calls
  `mNotificationController.commitFromBroadcast(generation, snapshot)`.
  The generation is captured before `sendBroadcast` so the commit and
  the broadcast carry the same value.

- `MusicService.beginTransition(int, int)` — does not commit the
  notification. During PREPARING the notification continues to show
  the previous song; it advances to the target when the transition
  commits through `broadcastUpdate`.

- `MusicService.doResume()` — commits PLAYING synchronously through
  `onPlaybackResumed()` before dispatching `player.start()` to the
  player thread. The async continuation exists only for the failure
  rollback, which is guarded by both `mStartToken` and
  `mState == ServiceState.PLAYING`. On failure, the rollback sets
  the state to IDLE, releases the player, releases the wake lock,
  persists the rolled-back state, broadcasts, and re-enters
  reconciliation.

- `MusicService.doPause()` — bumps `mStartToken` at entry. The bump
  invalidates any in-flight resume continuation, so a pause that
  arrives while a resume's `player.start()` is still on the player
  thread is not followed by a rollback that clobbers the committed
  `PAUSED`.

- `MusicService.togglePlayPause()` — the `READY` branch routes
  through `doResume()` so a cold-start play commits PLAYING
  synchronously, matching the `PAUSED` resume path.

- `MusicService.onPlaybackResumed()` — called synchronously from
  `doResume()` before the async `player.start()`. Commits the
  PLAYING state, the wake lock, the media session activation, the
  persisted state, the notification, and the foreground promotion
  on the calling (main) thread.

- `MusicService` transport debounce — removed. The 500 ms per-action
  debounce is gone: `NOTIFICATION_ACTION_DEBOUNCE_MS`,
  `mLastNotificationActionTime`, and `isNotificationActionDebounced`
  are deleted. The state machine handles rapid taps correctly
  because resume commits PLAYING synchronously, pause bumps
  `mStartToken` to invalidate in-flight resumes, and next/previous
  defer via `mDeferredReconcile` when PREPARING.

- `MusicService.onStartCommand()` — the transport dispatch no longer
  calls `isNotificationActionDebounced` before dispatching
  `ACTION_PLAY_PAUSE`, `ACTION_NEXT`, or `ACTION_PREV`.

- `MusicService.setupMediaSession()` — the `onPlay`, `onPause`,
  `onSkipToNext`, `onSkipToPrevious`, and `onStop` callbacks no
  longer call `isNotificationActionDebounced`.

- `MusicService.transitionToIdle()` — no longer clears
  `mLastNotificationActionTime`, because the map no longer exists.

- `MusicService.prefetchNotificationArt()` — the art-resolve poke is
  guarded by `mState != ServiceState.PREPARING`. An art resolve that
  lands during PREPARING is picked up by the commit that fires from
  `broadcastUpdate`; an art resolve that lands after the commit pokes
  the controller on the same main-thread turn as the resolve.

- `MusicService` javadoc — "The Commit Turn" describes
  `broadcastUpdate` as the only notification commit path and
  describes the PREPARING hold. "Play State Truth" describes the
  synchronous PLAYING commit at resume. "Transport Actions" states
  that transport actions are not debounced.

- `NotificationController` javadoc — "Commit Model", "Generation
  Filtering", and "Transport PendingIntents" sections document the
  synchronous commit path, the generation filter, and the distinct
  request codes.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana