# Llama Music Player v1.3.8

**Release date:** Oct 27, 2026

### Overview

One change ships in this release: the notification surface commits the
same state the player screen commits, on the same main-thread turn.

The player screen and the notification read from the same
`MusicService` state machine, but they read from it on different
schedules. The player screen commits inside its `UPDATE_PLAYER`
receiver, which runs synchronously inside the service's
`sendBroadcast` call. The notification was polled on a 100 ms cadence
and additionally poked by the service at the end of
`broadcastUpdate`. That second mechanism had two failure modes. A poll
that had already captured state before a broadcast could land on the
main thread after the broadcast's commit and re-apply the older
snapshot, so the notification briefly drew an older song or the wrong
play/pause icon until the next poll corrected it. And when the state
machine entered `PREPARING`, the service poked the notification
directly so the icon could flip on the tap; that path bypassed the
broadcast, so for a few frames the notification showed the next song
while the player screen still showed the previous one. The two
surfaces converged only when the prepare completed and the next
broadcast fired.

The notification now commits through
`NotificationController.commitFromBroadcast`, which
`MusicService.broadcastUpdate` calls after `sendBroadcast` returns,
with the exact snapshot the broadcast described. The commit lands on
the same main-thread turn the activity's receiver ran on. The
notification writes the same title, artist, art, playing flag, and
generation the activity is writing, at the same instant. A generation
filter drops any read whose generation is strictly lower than the
last committed generation, so a poll that captured state before a
broadcast can no longer re-apply it after the broadcast lands. The
poll remains in place as the safety-net cadence for position updates
and for state changes that do not reach the notification through a
broadcast (art resolving, the theme changing).

### Fixed

- **Notification play/pause icon no longer drifts from the audio** —
  The icon reads the destination of the current transition from the
  state machine, the same value the player screen's icon reads.
  Because the notification now commits that destination on the same
  main-thread turn as the player screen, the two surfaces cannot
  disagree about whether the audio is playing. A pause scheduled
  during a prepare, a resume issued from the lockscreen, a headset
  key, an audio-focus transition — all of them reach the notification
  as they reach the player screen: synchronously, with the same
  snapshot the broadcast described.

- **Notification title, artist, and art no longer lag the audio** —
  When the state machine begins a transition, the destination song's
  identity is committed to the notification in the same turn the
  transition begins, and again — with the same snapshot, at the same
  generation — when `broadcastUpdate` fires. A stale poll that ran
  before the transition cannot overwrite that commit.

- **Foreground promotion is retried on failure** — A
  `startForeground` call that throws no longer leaves the controller
  with a foreground flag that does not match the service state. The
  flag is set only after the call succeeds; a failed promotion leaves
  the flag `false` and the next sync retries.

### Under the Hood

- `NotificationController.ServiceStateSource` — new
  `long getGeneration()` method. Returns the service's monotonic
  transition counter, which both `commitFromBroadcast` and `syncOnce`
  use to drop stale reads.

- `NotificationController.commitFromBroadcast(long, RenderSnapshot)`
  — new primary commit path. Called by `MusicService.broadcastUpdate`
  after `sendBroadcast` returns, with the exact snapshot the
  broadcast described. Marshals to the main thread from any other
  thread. Drops any call whose generation is strictly lower than the
  last committed generation.

- `NotificationController.syncOnce()` — reads
  `ServiceStateSource.getGeneration()` first and drops the read when
  the generation is strictly lower than the last committed
  generation. When the read is at or beyond that generation, it
  commits the snapshot and advances `mLastCommittedGeneration`.

- `NotificationController.mLastCommittedGeneration` — new field.
  Advanced by both commit paths, reset alongside
  `mLastRenderedSnapshot` in `detachService()`,
  `clearPlaybackNotification()`, and `shutdown()`.

- `NotificationController.performPlaybackUpdate()` — the
  `mPlaybackForeground` flag is now set only after
  `Service.startForeground` returns. The previous code set it with a
  `getAndSet(true)` before the call, which left it stuck at `true`
  if the call threw.

- `MusicService.mStateSource` — implements the new `getGeneration()`
  method, returning `mGeneration`.

- `MusicService.broadcastUpdate()` — after `sendBroadcast(intent)`,
  the method now builds the same snapshot from the same main-thread
  state and calls
  `mNotificationController.commitFromBroadcast(generation, snapshot)`.
  The generation is captured before `sendBroadcast` so the commit
  and the broadcast carry the same value.

- `MusicService` javadoc — "The Commit Turn" section updated to
  describe the synchronous commit rather than the poke-then-poll
  model.

- `NotificationController` javadoc — added "Commit Model" and
  "Generation Filtering" sections documenting the new pattern and
  the reason for the filter.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana