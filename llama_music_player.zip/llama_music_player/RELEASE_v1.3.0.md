# Llama Music Player v1.3.0

**Release date:** Oct 11, 2026

## Overview

Llama Music Player is now a multilingual app.

The About dialog gains a language button in its version header,
placed between the VERSION label and the version number in the same
shape the playlist's SORT button takes in its sort-mode header.
Tapping it opens a Languages dialog that matches the Preset and
Theme dialogs. The button's label is the endonym of the currently
applied language — "English", "Español", "日本語", and so on — and
updates the moment a new language is chosen.

Sixteen languages ship in this release. Choosing one recreates the
UI on the new locale in the first frame after the dialog dismisses,
so no restart is needed.

## Added

### Languages dialog

A scrollable picker with the same shape as the Preset and Theme
dialogs. Each row shows the language's endonym — the language's
name in its own script — so a speaker recognises their language
without first switching the app to it. The current language's row
carries a CURRENT indicator in the accent colour and is scrolled
into the vertical centre of the list when the dialog opens.

### Language button in About

The About dialog's version header is now `VERSION` on the left, the
language button centred, and the version number on the right. The
button matches the SORT button in the playlist's header: the same
height, text size, letter spacing, and border selector.

### Sixteen languages

- English (default)
- Español — Spanish
- Français — French
- Deutsch — German
- Italiano — Italian
- Português — Portuguese
- Русский — Russian
- 中文 — Chinese (Simplified)
- 日本語 — Japanese
- 한국어 — Korean
- हिन्दी — Hindi
- العربية — Arabic
- Türkçe — Turkish
- Bahasa Indonesia — Indonesian
- Nederlands — Dutch
- Polski — Polish

## Changed

### Every user-visible string is now a resource

The app previously held most of its user-visible text as hardcoded
English literals in Java source. The entire set has been extracted
to `res/values/strings.xml` and translated into the fifteen
supported languages. Every string the app shows is now read through
`getString(R.string.…)`, which means every string the app shows
follows the system language by default and the user's explicit
choice when one is made.

### Locale application through wrapped base context

Each activity overrides `attachBaseContext(Context)` and wraps the
base context with the selected locale before any activity state
exists. This is the platform's documented mechanism; it means a
locale change requires the activity to be recreated, which the
app does via a `LANGUAGE_CHANGED` broadcast that every activity
listens for.

### Sort labels in the playlist header

The playlist's sort header was previously assembled by string
concatenation from hardcoded constants. It now reads from
`playlist_sort_label_*` resources, so a translator can localise the
direction markers ("A-Z" → "A-Z" in most Latin-script languages,
"あ-ん" for Japanese if desired) without changing the code.

## Under the Hood

### New classes

- `LanguageManager` — owns the language set, the current tag, and
  the `wrap(Context)` helper.
- `LanguageDialog` — the picker itself, structured line for line
  like `PresetDialog`.

### Modified classes

- `CreditsDialog` — `createVersionHeader` now builds a
  `RelativeLayout` with three children; a new `createLanguageButton`
  and `showLanguageDialog` were added; a `LANGUAGE_CHANGED`
  broadcast fires on selection.
- `MusicPlayer`, `PlaylistActivity`, `FolderManager`,
  `EqualizerActivity`, `MetadataEditor` — each gained an
  `attachBaseContext` override, a `LANGUAGE_CHANGED` receiver that
  calls `recreate()`, and the corresponding registration and
  unregistration.
- `NotificationController` — channel names, action labels, and
  placeholders now read from resources.
- `PlaylistManager` — overlay messages now read from resources.
- `ThemeHelper` — unchanged in behaviour; the theme constants are
  still literals because they are the fallback when a theme has
  not been chosen.

### New resources

- `res/values/strings.xml` — rewritten with the full key set.
- `res/values-es`, `-fr`, `-de`, `-it`, `-pt`, `-ru`, `-zh`,
  `-ja`, `-ko`, `-hi`, `-ar`, `-tr`, `-in`, `-nl`, `-pl` — new
  directories, each with a `strings.xml`.

### Note on translation quality

The Latin-script and Cyrillic-script locale files (Spanish, French,
German, Italian, Portuguese, Dutch, Polish, Russian) were produced
with high confidence. The Chinese, Japanese, Korean, Hindi, Arabic,
Turkish, and Indonesian files should be reviewed by a native
speaker before release; the translations are grammatically correct
and register-appropriate, but terminology choices in a few places
would benefit from a translator's eye.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana