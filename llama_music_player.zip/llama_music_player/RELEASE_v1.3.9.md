# Llama Music Player v1.3.9

**Release date:** Nov 02, 2026

---

### Overview

The Metadata Editor's file-targeting is hardened in this release. A
metadata write now lands on the file the user is editing, whichever
entry path the editor was opened through and whichever file the SAF
picker selected during the session. The selected content URI is the
writer's authoritative target; the absolute path the database and the
playback consumers key on is either resolved from that URI or accepted
from the caller only when the database confirms the two describe the
same file. An unresolved URI no longer silently retains a previous
song's path. The MODIFY action prefers the URI the current session
selected over a cached URI stored for a previously-bound song, and
persists the current session's URI against the current path when it
uses it. The save path captures the target URI, the target path, and
the album-art-removed flag before dispatching the write to the
executor, so a later picker result or a later change to a mutable
Activity field cannot redirect an in-progress save. The success
handler reads the written file back and requires the reread's status
to be `SUCCESS` before it writes a database row or publishes the
`METADATA_UPDATED` broadcast; a reread that returns `FILE_UNREADABLE`
or `PARSE_FAILED` is treated as a failed write, so the editor cannot
publish metadata that may not describe the file's current contents.
Every path that resolves a song's identity for the database or the
broadcast now derives its path from the save target rather than from
the Activity's mutable `mFilePath`.

---

### Fixed

- **Metadata writes land on the file the user is editing** — The
  editor treats the URI the current session selected as the write
  target and derives the absolute path from that URI. When the
  editor is opened with a `song_uri` extra, a supplied `song_path`
  is accepted only when `getFilePathFromUri` resolves the URI to it,
  or when `SongDatabase.getSong(suppliedPath)` returns a row whose
  `getUri()` equals the supplied URI; otherwise `mFilePath` stays
  null. When the editor is opened with only a `song_path`, the URI
  is read from the database as before. The path the database and
  the playback consumers key on is therefore always paired with the
  URI the writer used, and a metadata write cannot land on a
  different song's file than the one the user is editing.

- **URI authority for writing** — `performSaveChanges` dispatches
  the write with the session-selected URI as its target. Every
  later use of the song's identity — the database row, the
  broadcast extras, the failure prompt — is derived from that URI,
  never from a second path lookup that could have moved on.

- **An unresolved URI does not retain the previous song's path** —
  When the editor is opened with a `song_uri` extra whose URI
  cannot be resolved to a filesystem path, `mFilePath` is now left
  null unless the database confirms a path is paired with that
  exact URI. The SAF picker result applies the same rule in the
  opposite direction: a pick whose URI has no filesystem path
  clears `mFilePath` to null rather than retaining the previous
  song's path.

- **MODIFY prefers the current session's URI over a cached URI** —
  The MODIFY action previously asked the song database for a stored
  URI before checking the URI the current session had selected. On
  a session where the editor had been opened through one entry path
  and the user then picked a different file through SAF, the cached
  URI for the previously-bound song could replace the picked URI.
  The action now prefers the session's selected URI when it carries
  write permission, persists it against the current path through
  `saveUriToDatabase()`, and only falls back to the stored URI when
  the session has none.

- **In-flight saves are pinned to the target captured at
  dispatch** — `performSaveChanges` now captures the target URI,
  the target path, and the album-art-removed flag into `final`
  locals before it dispatches the write to the executor, and passes
  them to the success and failure handlers as parameters. A later
  SAF pick or a later change to `mGrantedFileUri` or `mFilePath`
  cannot redirect a save that is already running. The write has
  always targeted the captured URI; what changed is that every
  subsequent use of the path — the database row, the broadcast
  extras, the failure prompt — now comes from the same captured
  values.

- **Database rows identify the song that was written** —
  `onSaveSuccess` uses the captured target path for the database
  row, falling back to a path resolved from the saved URI when the
  captured path is null. A path that cannot be derived from either
  source leaves the database row unwritten rather than writing a
  row against the Activity's mutable path.

- **Broadcasts identify the song that was written** — The
  `METADATA_UPDATED` broadcast carries the captured target path, or
  a path resolved from the saved URI when the captured path is
  null. A null broadcast path suppresses the broadcast entirely, so
  a receiver cannot receive a path that belongs to a different
  song. The broadcast is sent only when the post-write reread's
  status is `SUCCESS`.

- **A post-write reread failure does not publish success** —
  `onSaveSuccess` reads the written file back and requires
  `MetadataReader.readMetadataFromUri(savedUri).status == SUCCESS`
  before it writes a database row, sends the `METADATA_UPDATED`
  broadcast, or resumes playback. A reread that returns
  `FILE_UNREADABLE` or `PARSE_FAILED` leaves `mHasTextChanges`,
  `mAlbumArtChanged`, and `mAlbumArtDeleted` intact, so a
  subsequent UPDATE retries the write, and no success toast,
  database row, or broadcast is produced from a metadata bundle
  that may not describe the file's current contents.

- **Failure handling uses the failed target** — `onSaveFailure`
  takes the captured target path as a parameter and, on
  `PERMISSION_DENIED`, writes the fallback database row against
  that path instead of `mFilePath`. A failure that arrived after
  the session's path had already changed now reports and repairs
  the song that was actually being written.

---

### Under the Hood

- `MetadataEditor.onCreate(Bundle)` — When the intent carries a
  `song_uri` extra, the URI is the editor's write target. A
  supplied `song_path` is accepted only when
  `getFilePathFromUri(mGrantedFileUri)` resolves to it, or when
  `SongDatabase.getSong(suppliedPath)` returns a row whose
  `getUri()` equals the supplied URI. Otherwise `mFilePath` stays
  null. When the intent carries only a `song_path`, the URI is
  read from the database as before.

- `MetadataEditor.handleModifyClick()` — MODIFY prefers
  `mGrantedFileUri` when the session-selected URI has write
  permission; the stored URI is consulted only when the session has
  none. When the session-selected URI is used, `saveUriToDatabase()`
  persists it against `mFilePath` before edit mode is entered.

- `MetadataEditor.onActivityResult(int, int, Intent)` — The SAF
  picker branch sets `mGrantedFileUri = selectedUri` and
  `mFilePath = getFilePathFromUri(selectedUri)` unconditionally. A
  null path from a valid URI clears `mFilePath` rather than
  preserving the previous song's path.

- `MetadataEditor.performSaveChanges()` — Captures
  `final Uri targetUri = mGrantedFileUri`,
  `final String targetPath = mFilePath`, and
  `final boolean albumArtWasDeleted = mAlbumArtDeleted` before the
  executor submission. The success and failure handlers take these
  as parameters. The write itself is dispatched with `targetUri`.

- `MetadataEditor.onSaveSuccess(Uri, String, boolean)` — Reads the
  written file back through
  `MetadataReader.readMetadataFromUri(savedUri)`. Only when
  `savedMetadata.status == SUCCESS` does the method write a
  database row, build and send the `METADATA_UPDATED` broadcast,
  and use the reread's metadata for the broadcast extras. The
  database row and the broadcast path are taken from `savedPath`
  when it is non-null, and from `getFilePathFromUri(savedUri)`
  otherwise; neither falls back to `mFilePath`. A null broadcast
  path suppresses the broadcast.

- `MetadataEditor.onSaveFailure(WriteResult, String)` — Takes
  `failedTargetPath` as a parameter and uses it for the
  `PERMISSION_DENIED` database repair row. `mFilePath` is not read
  on this path.

- `MetadataEditor.saveUriToDatabase()` — Called from
  `handleModifyClick()` when the session-selected URI is used, in
  addition to its previous call sites. Writes the URI against
  `mFilePath` through `SongDatabase.insertSong`.

- `MetadataEditor.loadMetadataAsync()` — The path the initial read
  assigns when `mGrantedFileUri != null` comes from
  `getFilePathFromUri(mGrantedFileUri)`. The rest of the read is
  unchanged.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana