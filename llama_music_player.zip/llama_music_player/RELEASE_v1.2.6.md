# Llama Music Player v1.2.6

**Release date:** Oct 8, 2026

## Overview

Two changes ship in this release — a unified animation source for the
transport buttons, and a reduced main-thread cost for the notification
commit.

The next and previous buttons now animate the album-art carousel
exactly as an automatic song change or a headset media button does.
The service resolves the request and returns the window it has just
committed to, in the same main-thread turn, together with the
direction of the request and whether the request resolved to a restart
of the current song. The activity hands that transition to the
carousel, which seeds its commit or restart state from the service's
own answer. The strip's target and the audio's target are the same
value by construction, so the slide completes without a reversal and
the reveal is reachable from a button press under shuffle.

The notification commit no longer rebuilds the same bitmaps and
`PendingIntent` objects on every transition. The controller caches its
themed action icons — three of the four use constant tints and are
identical across every commit, and the fourth depends only on the
theme color — and caches the content, close, and delete intents. A
commit's main-thread work is the builder construction and the IPC.

## Fixed

- **Transport buttons animate identically to automatic transitions**
  — Previously the next and previous buttons started the carousel's
  commit slide from the carousel's own memory of the last window it
  held. The service resolved the request independently, one
  main-thread turn later, and when the two disagreed — a shuffle
  re-pick, a peek memo that had been cleared by a state setter, an
  interrupting transition — the strip was pulled out of its forward
  slide mid-flight and glided back. The animation was correct in
  shape but the reversal read as a stutter.

  The service now resolves the request and returns the window it
  committed to, in the same turn. The activity hands the window, the
  direction, and the restart flag to the carousel. The carousel
  presets its confirmed window before starting a commit, so the
  animation's end action finds it on the frame the slide completes
  and settles synchronously. The state never enters
  `AWAITING_SNAPSHOT`, the `COMMITTING` mismatch branch never fires,
  and the `RESTARTING` branch adopts the incoming window from the
  first frame — identical state to what the automatic path already
  sets up. The reveal is now reachable from a button press.

- **The transport restart nudge is preserved** — Under repeat-one, on
  a single-song playlist, or on a shuffle re-pick that cannot avoid
  the current index, the service resolves the request to a restart of
  the current song. The returned transition carries the restart flag
  and the target window; the carousel adopts the window and runs the
  same below-threshold nudge the automatic restart runs. The two
  paths share the spring force, the outward distance, and the
  `RESTARTING` branch of `setWindow`, so a press and an involuntary
  restart look the same.

- **The notification commit no longer competes with the slide** — The
  main-thread work a commit performs is bounded by the notification
  builder and the notification IPC. The four themed action icons and
  the three `PendingIntent` objects are served from caches on every
  commit after the first.

## Under the Hood

- `MusicService` gained `NeighbourTransition`, an immutable value
  holding the window the service will publish once the transition
  completes, the direction of the request, and whether the request
  resolved to a restart. The class is the service's own answer to a
  next or previous request, produced and consumed inside one
  main-thread turn.

- `MusicService.playNextSongAndResolve()` and
  `MusicService.playPreviousSongAndResolve()` resolve the target,
  assign `mTargetIndex`, force a reprepare when the wrap lands on the
  current index, call `reconcile()`, and return the transition the
  service has just committed to. The resolve, the target assignment,
  the generation bump, and the transition start all happen
  synchronously inside the calling main-thread turn.

- `MusicService.playNextSong()` and `MusicService.playPreviousSong()`
  delegate to the resolve methods.

- `willNextRestartCurrent()` and `willPreviousRestartCurrent()` are
  removed. The restart flag the resolve returns carries the same
  answer.

- `AlbumArtCarousel.animateForTransition(PlaybackWindow, int,
  boolean)` adopts the transition the service resolved and runs the
  matching animation. A restart adopts the incoming window and runs
  the below-threshold nudge. A commit presets the confirmed window
  before starting the slide. A non-neighbour change runs the
  staggered cross-fade.

- `MusicPlayer.playNextSong()` and `MusicPlayer.playPreviousSong()`
  ask the service for the resolved transition and hand it to the
  carousel. The request and the animation run in one main-thread
  turn.

- `NotificationController` gained `mThemedIconCache`, a map keyed by
  the pair of the drawable resource and the tint, and three cached
  `PendingIntent` fields. `getThemedIcon(int, int)`,
  `getContentIntent()`, `getCloseIntent()`, and `getDeleteIntent()`
  build on first use and serve from the cache thereafter. The cache
  is cleared in `shutdown()`.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana