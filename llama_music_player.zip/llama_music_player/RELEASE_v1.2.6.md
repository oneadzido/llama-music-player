# Llama Music Player v1.2.6

**Release date:** Oct 8, 2026

## Overview

Two changes ship in this release — a unified animation source for the
transport buttons, and a reduced main-thread cost for the notification
commit.

The next and previous buttons now animate the album-art carousel
exactly as an automatic song change or a headset media button does.
The service names the direction and the restart of every transition
it begins, publishes them alongside the window on the same broadcast,
and the carousel renders the animation they describe. A button press
is a plain request: it asks the service to advance, and the strip
starts moving on the turn the service's broadcast reaches the
activity, against an idle main thread, in step with the transition
the service is already running. The direction and the restart are
properties of the generation that produced the window, so the
animation the carousel runs and the transition the service is running
are the same value by construction. The slide completes without a
reversal and the reveal is reachable from a button press under
shuffle.

The notification commit no longer rebuilds the same bitmaps and
`PendingIntent` objects on every transition. The controller caches its
themed action icons — three of the four use constant tints and are
identical across every commit, and the fourth depends only on the
theme color — and caches the content, close, and delete intents. A
commit's main-thread work is the builder construction and the IPC.

## Fixed

- **Transport buttons animate identically to automatic transitions**
  — Previously the next and previous buttons started the carousel's
  commit slide from the carousel's own memory of the last window it
  held. The service resolved the request independently, one
  main-thread turn later, and when the two disagreed — a shuffle
  re-pick, a peek memo that had been cleared by a state setter, an
  interrupting transition — the strip was pulled out of its forward
  slide mid-flight and glided back. The animation was correct in
  shape but the reversal read as a stutter.

  The service now names the direction and the restart of every
  transition it begins, as properties of the generation that produces
  the window, and publishes both on the same `UPDATE_PLAYER`
  broadcast that carries the window. The carousel reads them from
  the broadcast and renders the animation they describe. A button
  press is a plain request; the strip starts moving on the turn the
  service's broadcast reaches the activity, against an idle main
  thread, in step with the transition the service is already running.
  There is no prediction for the service to contradict and no second
  broadcast for the carousel to absorb. The reveal is now reachable
  from a button press.

- **The transport restart nudge is preserved** — Under repeat-one, on
  a single-song playlist, or on a shuffle re-pick that cannot avoid
  the current index, the service names the transition's direction and
  sets its restart flag. The carousel adopts the incoming window and
  runs the same below-threshold nudge the automatic restart runs. The
  two paths share the spring force, the outward distance, and the
  `RESTARTING` branch of `setWindow`, so a press and an involuntary
  restart look the same. Both legs of the nudge run on the same
  spring constants, so the out-move and the return share their motion
  model.

- **The notification commit no longer competes with the slide** — The
  main-thread work a commit performs is bounded by the notification
  builder and the notification IPC. The four themed action icons and
  the three `PendingIntent` objects are served from caches on every
  commit after the first. The work that used to land mid-slide on the
  button path — the icon decode-and-rasterize and the binder
  round-trips — is gone from the animation's critical path.

## Under the Hood

- `MusicService` names the direction and the restart of every
  transition as properties of the generation. Four fields carry them:
  `mGenerationDirection` and `mGenerationRestart` hold the values of
  the current generation, and `mNotedDirection` and `mNotedRestart`
  hold the values noted for the next transition to begin.
  `noteTransition(int, boolean)` writes the notes;
  `beginTransition(int, int)` consumes them into the generation it
  creates; `broadcastUpdate()` publishes them alongside the window;
  `clearNotedTransition()` clears them when `reconcile()` decides no
  transition is warranted.

- Every transition entry point notes the direction and restart at the
  moment it decides the target. `playNextSong()` and
  `playPreviousSong()` note `+1` and `-1` respectively, with the
  restart flag set when the request resolves to a restart.
  `onCompletion()` notes `+1`, with the flag set when the automatic
  advance restarts the same song under repeat-one or on a
  single-song playlist. `onStall()` notes `+1` for an advance and
  `0` for a reprepare of the same song. `onPlayerError()`,
  `onPrepareFailed()`, and the three failure paths inside
  `beginTransition` note `+1` and clear the restart flag. The
  explicit-selection entry points — `playSong()`,
  `playSongAtPosition()`, `playSongByPath()`,
  `playPendingSongIfExists()` — do not note; their transitions carry
  direction `0` and the carousel runs the reveal when the song
  changes.

- `MusicService.broadcastUpdate()` publishes the two values as
  `transition_direction` and `transition_restart` extras on the
  `UPDATE_PLAYER` broadcast. They travel with the window and the
  generation, so a receiver that has the window has the transition
  that produced it. `transitionToIdle()` and `stop()` clear both the
  current and the noted values, so an abandoned request does not
  leave a direction for a later, unrelated transition to pick up.

- `AlbumArtCarousel.setWindow(PlaybackWindow, int, boolean)` reads
  the two values alongside the window. Its `adoptInIdle` method uses
  the direction directly — `startCommit(int, boolean)` for a
  neighbour advance, `startBelowThreshold(int)` for a restart,
  `startFade()` when the direction is zero and the current song
  changed — and snaps to rest with no animation when the generation
  is unchanged, the current path is empty, or the direction is zero
  and the song is unchanged. The direction heuristic that inferred
  the transition from the previous window is gone; the service's
  answer is the only source.

- `AlbumArtCarousel`'s restart nudge runs both of its legs on the
  same `SpringAnimation` constants. The outward leg carries the
  strip from rest to the displaced position and the return leg
  carries it back, over the same distance and on the same damping
  ratio and stiffness, so the two halves of the gesture take the
  same time to settle and overshoot by the same small amount. The
  shared motion model is what lets a press and an involuntary
  restart read as one out-and-back gesture rather than as an
  out-move followed by a faster return.

- `AlbumArtCarousel.animateForTransition(PlaybackWindow, int,
  boolean)` is removed. The button path no longer needs a
  pre-animation entry point; every transition arrives through
  `setWindow` on the service's broadcast.

- `MusicService.playNextSong()` and `MusicService.playPreviousSong()`
  are the transport entry points. They assign the target, note the
  direction and restart, and call `reconcile()`. The
  resolve-and-return methods `playNextSongAndResolve()` and
  `playPreviousSongAndResolve()`, and the `NeighbourTransition` value
  class, are removed. The service publishes the transition alongside
  the window on the same broadcast every other transition already
  uses, so a caller that requests a change does not need a second
  return channel.

- `willNextRestartCurrent()` and `willPreviousRestartCurrent()` are
  removed. The restart flag the service notes and publishes carries
  the same answer, and it is resolved once, inside the transition
  that consumes it.

- `MusicPlayer`'s `UPDATE_PLAYER` receiver reads
  `transition_direction` and `transition_restart` from the broadcast
  and forwards both to the carousel's `setWindow`. The
  `refreshCarouselFromService()` and `applyNoSongState()` callers
  pass `0` and `false`, because a re-publication is not a fresh
  transition.

- `MusicPlayer.playNextSong()` and `MusicPlayer.playPreviousSong()`
  are plain requests. The `animateForTransition` call and the
  resolve-and-return call are gone from the activity. A button press
  dispatches the service request on the tap and the strip starts
  moving on the turn the service's broadcast reaches the receiver —
  the same turn an automatic transition's slide starts on.

- The swipe commit listener installed in `MusicPlayer.initializeViews`
  still routes a committed swipe through the same two methods. A
  swipe's commit slide is a continuation of the drag and begins at
  the release, because the strip is already displaced under the
  finger; the service's broadcast arrives during the slide and is
  absorbed by the commit state.

- `NotificationController` gained `mThemedIconCache`, a map keyed by
  the pair of the drawable resource and the tint, and three cached
  `PendingIntent` fields for the content, close, and delete intents.
  `getThemedIcon(int, int)` builds on a miss and serves from the
  cache on every subsequent call; `getContentIntent()`,
  `getCloseIntent()`, and `getDeleteIntent()` build on first use and
  return the cached instance thereafter. The theme-color dependency
  of the play/pause icon is expressed through the key rather than
  through explicit invalidation: a theme change alters the tint,
  which alters the key, which produces a fresh entry on the next
  commit alongside the old. The cache is cleared in `shutdown()`.

- `NotificationController.buildPlaybackNotification` reads its four
  action icons and its three intents through the getters. The
  `buildContentIntent(int flags)` helper is folded into
  `getContentIntent()`, since every caller now reads the cached
  instance. `buildLibraryNotification` reads the content intent
  through the same getter.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana