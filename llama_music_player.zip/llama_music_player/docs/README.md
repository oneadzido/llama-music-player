# Llama Music Player

Llama Music Player is a privacy-respecting Android music player for managing and enjoying a local music collection. It combines background playback, playlist and folder management, audio effects, metadata editing, and a customizable interface.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Android](https://img.shields.io/badge/Android-6.0%2B-brightgreen.svg)](https://developer.android.com)
[![Privacy](https://img.shields.io/badge/Privacy-Policy-blue.svg)](PRIVACY.md)
[![Build](https://github.com/oneadzido/llama-music-player/actions/workflows/main.yml/badge.svg)](https://github.com/oneadzido/llama-music-player/actions/workflows/main.yml)

[![Download Llama Music Player](https://img.shields.io/badge/Download-Llama_Music_Player-brightgreen?style=for-the-badge&logo=android&logoColor=white)](https://github.com/oneadzido/llama-music-player/releases/latest)

---

## Overview

Llama Music Player is designed for listeners who want direct control over music stored on their device. Playback runs through a dedicated service, while focused screens provide access to the library, playlists, folders, equalizer, and metadata tools.

## Features

### Playback and audio

- **Background playback:** Music continues when the app is not in the foreground, with notification and lock-screen controls.
- **Multiple playback controls:** Control playback from the player, notification, headset buttons, and supported media actions.
- **Album-art gestures:** Swipe across artwork to change tracks, use the centre area for play/pause, and the edges for volume.
- **Pitch and speed:** Adjust pitch by −6.0 to +6.0 semitones and playback speed from 0.50× to 1.50×.
- **10-band equalizer:** Shape audio with 60 presets, including a customizable preset, plus bass boost and surround controls.
- **Audio-focus handling:** Playback responds to calls and other audio interruptions with pause, resume, or ducking as appropriate.
- **Bluetooth controls:** Use headset media buttons, with playback-aware handling when a headset disconnects.

### Music library and playlists

- **Common audio formats:** Browse MP3, FLAC, OGG, M4A, AAC, and WAV files.
- **Playlist sorting:** Organize tracks using ten sort modes for title, artist, album, genre, and date.
- **Live search:** Filter playlists as you type across title, artist, album, and genre.
- **Favorites:** Mark tracks and access favorites from the player or playlist.
- **Playback scopes:** Play the full library, favorites, loose tracks, or selections by folder, genre, artist, or album.
- **Scope-aware navigation:** Next, Previous, automatic completion, and playback recovery respect the active scope.
- **Folder import:** Add music folders using Android's Storage Access Framework.
- **Fast scrolling:** Navigate long playlist and scope lists more easily.

### Metadata and presentation

- **Metadata editor:** Edit supported audio tags, lyrics, and embedded album artwork.
- **Sixteen languages:** English, Español, Français, Deutsch, Italiano, Português, Русский, 中文, 日本語, 한국어, हिन्दी, العربية, Türkçe, Bahasa Indonesia, Nederlands, and Polski.
- **Thirty-two theme colours:** Choose an interface colour to suit your preference.
- **Responsive layout:** Player screens adapt to portrait, landscape, and Android split-screen windows.

## Requirements

| Item | Requirement |
|---|---|
| Minimum Android version | Android 6.0 (API 23) |
| Target Android version | Android 15 (API 35) |

## Installation

1. Open the [latest GitHub release](https://github.com/oneadzido/llama-music-player/releases/latest).
2. Download the APK provided with the release.
3. If prompted, allow installation from the app or browser used to open the APK.
4. Open the APK and follow Android's installation instructions.

## First-time setup

1. Open Llama Music Player and grant music-library access when requested.
2. Open **Manager** from the main player screen.
3. Select **Import Folder** and choose a folder containing music. Repeat for other folders as needed.
4. Tap **Update** to scan the selected folders.
5. Return to the player or open **Playlist** to browse and play your tracks.

## Using the app

| Task | Where to go or what to do |
|---|---|
| Play or pause | Swipe up or down in the centre of the album art, or use the transport controls |
| Change songs | Swipe left or right across the album art, or use Previous and Next |
| Adjust volume | Swipe up or down along the edge of the album art |
| Manage favorites | Double-tap the album art or use a heart control in the player or playlist |
| Browse or search tracks | Open **Playlist** and use the search field |
| Sort tracks | Use **Sort** in Playlist |
| Import music folders | Open **Manager**, then choose **Import Folder** |
| Choose a playback scope | Open **Manager**, then choose **Scope** |
| Adjust audio effects | Open **Equalizer** |
| Edit tags or artwork | Open **Metadata** |
| Change theme or language | Open **Llama** and choose the relevant setting |
| Keep playback running | Use the main screen's Home button twice within one second to send the app to the background |

## Permissions

Android requests permissions when a feature needs them. Depending on Android version and the feature being used, the app may request:

- **Music-library access:** `READ_MEDIA_AUDIO` on Android 13 and later, or `READ_EXTERNAL_STORAGE` on earlier supported versions.
- **Notifications:** `POST_NOTIFICATIONS` on Android 13 and later, for playback and library notifications.
- **Bluetooth connection access:** `BLUETOOTH_CONNECT` on Android 12 and later, for headset connection state and media-button handling.
- **Image access:** `READ_MEDIA_IMAGES` on Android 13 and later, or the applicable external-storage permission on earlier versions, when selecting artwork in the metadata editor.

The manifest also declares service and audio-related permissions used for background playback and audio effects, including `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `WAKE_LOCK`, and `MODIFY_AUDIO_SETTINGS`.

## Project documentation

- [Release notes](RELEASE.md) — overview, fixes, preserved behaviour, and validation for the current release.
- [Changelog](CHANGELOG.md) — release-by-release project history.
- [Architecture](ARCHITECTURE.md) — application components, responsibilities, communication, and playback design.
- [Privacy policy](PRIVACY.md) — data handling and permissions.
- [Origin story](ORIGIN_STORY.md) — the story behind the project.

## Credits

- [jaudiotagger](https://www.jthink.net/jaudiotagger/) by jthink Ltd.
- [Font Awesome](https://fontawesome.com/) by Fonticons, Inc.
- [greenrobot EventBus](https://github.com/greenrobot/EventBus) by greenrobot and contributors (Apache License 2.0).

Third-party license texts are included under `app/src/main/assets/licenses/`.

## License

Llama Music Player is licensed under the MIT License. See the [LICENSE](../LICENSE) file for the full license text.

Copyright © 2026 Richard Korbla Adzido.