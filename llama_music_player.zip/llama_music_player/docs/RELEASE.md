# Llama Music Player 1.6.6

This is the unified 1.6.6 release. The earlier 1.6.6 transition package and subsequent unreleased work are consolidated under this release identity.

## Playback and playlist corrections

- Playlist sorting now reorders the service-owned full playlist, then rebuilds the scoped and current playback queues from that reordered source. This addresses the prior failure mode where sorting only the derived current queue was undone by `rebuildPlaylists()`.
- Current and pending playback positions are preserved by song path across the reorder.
- The existing equalizer Activity attachment and playback-parameter notification behavior is retained. Experimental lifecycle/ownership changes that could disrupt existing equalizer controls have been reverted.
- Song title, artist, and seek-bar synchronization no longer waits for album-art carousel settling.

## Validation

- ZIP integrity and XML parsing checks passed.
- Java source brace-balance checks passed for the touched playback classes.
- A Gradle build and physical-device regression test were not completed in this environment; this package must not be considered device-verified.
