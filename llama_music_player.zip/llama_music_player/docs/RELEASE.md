# Llama Music Player v1.6.2 (work-in-progress)

**Release date:** pending verification

Version 1.6.2 addresses locale persistence across activity lifecycle/configuration
changes and equalizer value preservation when a new audio session is attached.
It also corrects the EqualizerActivity refresh method documentation and verifies
the renamed SeekBar drawable references.

## Included changes

- Reapply the app locale after activity resume and configuration changes.
- Format timer digits using the explicit selected locale.
- Wrap dialog contexts in the app locale before view creation.
- Snapshot and restore current equalizer band, bass, surround, pitch, speed,
  and preset state in `EqualizerManager.attachToAudioSession()`.
- Apply playback parameters on the player thread before `start()` and in the
  paused `READY` path.
- Remove `attachPreservingPitchSpeed()` and correct the Javadoc for
  `refreshAllUIControls()`.
- Fix the `EqualizerManager.attachToAudioSession()` Java compilation error
  reported by the release CI run: reuse the method's existing `preferences`
  variable rather than redeclaring it in the nested restoration block.

## Verification status

The CI release build reached `compileReleaseJavaWithJavac` and failed because
`preferences` was redeclared in `attachToAudioSession(int)`. That compile issue
has been corrected in this source patch. A new CI build is required to verify
this correction. Device lifecycle and playback tests have not been run; do not
publish this release until build and device verification are complete.

For the full change history, see the [CHANGELOG](CHANGELOG.md). For
technical specifications, installation, and usage, see the [README](README.md).

Llama Music Player remains licensed under the MIT License.