# Llama Music Player v1.6.6

**Release date:** November 24, 2026

## Overview

Version 1.6.6 is the unified release containing the playlist-sort
synchronization work and the follow-up activity-to-service synchronization
fixes. The earlier 1.6.6 transition package was not published separately;
all of this work is released together under v1.6.6.

The service remains the authoritative owner of playback order, audio-effect
session attachment, and playback parameters. Player song identity and timing
are committed independently of album-art decoding and carousel animation.

## Fixed

- Playlist sort changes reach the bound `MusicService` directly. The service
  applies the sort, rebuilds scoped playlists, remaps current and pending
  playback positions by song path, clears shuffle history, and publishes the
  updated state. The existing `UPDATE_SORT_MODE` broadcast remains the
  fallback when the Activity is not bound.
- Audio effects attach before `AUDIO_SESSION_CHANGED` is published.
- `MusicService` is the sole owner of audio-effect session attachment;
  `EqualizerActivity` observes the shared manager instead of attaching
  effects independently.
- Pitch and speed changes use the bound service and MediaPlayer owner thread,
  with the existing event fallback retained during binding.
- Title, artist, and seek-bar updates are no longer deferred until the
  album-art carousel settles.

## Preserved

- All ten playlist sort modes and their comparators remain unchanged.
- Current-song and pending-transition path anchoring remains intact.
- Equalizer preferences and custom settings remain persisted.
- Existing media-session metadata and album-art loading remain intact.
- Playback generation checks and transport state ownership remain intact.

For the full change history, see [CHANGELOG.md](CHANGELOG.md).