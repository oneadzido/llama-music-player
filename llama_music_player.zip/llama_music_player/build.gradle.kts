// build.gradle.kts
//
// Llama Music Player — Top-Level Build Configuration
// ============================================================================
//
// Configures the buildscript plugin versions for the entire project.
// The Android Gradle Plugin, Kotlin plugin, and Parcelize plugin
// versions are declared here once and reused by every module.
//
// File Location: /build.gradle.kts
//
// @author Richard Korbla Adzido
// @version 1.5.0
// @since 1.0.0
// ============================================================================

plugins {

    /**
     * Android Gradle Plugin 8.7.2. Compatible with Gradle 8.9
     * (declared in gradle/wrapper/gradle-wrapper.properties) and
     * JDK 17 (declared in the app module's compileOptions and
     * kotlinOptions).
     */
    id("com.android.application") version "8.7.2" apply false

    /**
     * Kotlin Android plugin 2.0.21. Compiles every source under
     * app/src/main/kotlin.
     */
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false

    /**
     * Parcelize plugin 2.0.21. Generates Parcelable implementations
     * at compile time for event payloads that cross process
     * boundaries. Version-matched to the Kotlin plugin.
     */
    id("org.jetbrains.kotlin.plugin.parcelize") version "2.0.21" apply false
}

/**
 * Global clean task.
 *
 * Deletes the root project's build directory. Uses the lazy
 * registration form and the modern layout.buildDirectory API
 * rather than the deprecated Project.getBuildDir().
 */
tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}