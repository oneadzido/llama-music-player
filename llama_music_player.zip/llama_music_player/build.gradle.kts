// build.gradle.kts
//
// Llama Music Player — Top-Level Build Configuration
// ============================================================================
//
// Configures the buildscript plugin versions for the entire project.
// The Android Gradle Plugin, Kotlin plugin, Parcelize plugin, and KSP
// versions are declared here once and reused by every module.
//
// File Location: /build.gradle.kts
//
// @author Richard Korbla Adzido
// @version 1.5.0
// @since 1.0.0
// ============================================================================

plugins {

    /**
     * Android Gradle Plugin 8.7.2.
     *
     * Compiles with SDK 36 (Android 16) and is compatible with
     * Gradle 8.9 (declared in
     * gradle/wrapper/gradle-wrapper.properties) and JDK 17
     * (declared in the app module's compileOptions and
     * kotlinOptions).
     *
     * The AGP and Gradle versions are two different tools with
     * independent numbers; AGP 8.7.2 requires Gradle 8.9 or newer.
     * Bumping one without checking the other fails the build at
     * configuration time.
     */
    id("com.android.application") version "8.7.2" apply false

    /**
     * Kotlin Android plugin 2.0.21.
     *
     * The Kotlin compiler plugin compiles every source under
     * app/src/main/kotlin. Version 2.0.21 is the current stable
     * release and is the version the KSP plugin below is pinned
     * to.
     */
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false

    /**
     * Parcelize plugin 2.0.21.
     *
     * Generates Parcelable implementations at compile time,
     * replacing the hand-written code that would otherwise be
     * needed for event payloads that cross process boundaries.
     * Version-matched to the Kotlin plugin (2.0.21).
     */
    id("org.jetbrains.kotlin.plugin.parcelize") version "2.0.21" apply false

    /**
     * KSP (Kotlin Symbol Processing) 2.0.21-1.0.25.
     *
     * Runs the EventBus annotation processor to generate
     * com.ark.llama.event.EventBusIndex, which LlamaEventBus.init()
     * installs on the default EventBus. The KSP version number's
     * first segment is the Kotlin version it is built against; the
     * second is the KSP release itself. `2.0.21-1.0.25` means
     * Kotlin 2.0.21 + KSP 1.0.25.
     */
    id("com.google.devtools.ksp") version "2.0.21-1.0.25" apply false
}

/**
 * Global clean task.
 *
 * Deletes the root project's build directory. Uses the lazy
 * registration form and the modern layout.buildDirectory API
 * rather than the deprecated Project.getBuildDir().
 */
tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}