# Llama Music Player 1.4.0

Llama Music Player brings your music library, playback controls, audio effects, and metadata tools together in one offline Android application. Version 1.4.0 includes favorites and playback scope as part of the everyday listening experience.

## System requirements

- **Android:** 6.0 (API 23) or later
- **Target platform:** Android 15 (API 35)
- **Java:** 17
- **Metadata library:** jaudiotagger 3.0.1

## Music library

Import one or more music folders through Android's Storage Access Framework. The player reads supported audio files from the selected locations and keeps their metadata in its local library. Individual audio files opened from another application can also be played as loose tracks.

The library supports MP3, FLAC, OGG, M4A, AAC, and WAV files. Search filters the playlist as you type, and the ten sort modes arrange tracks by title, artist, album, genre, or file date.

Removing a selected folder removes the songs belonging to that folder. Other selected folders and loose tracks remain in the library.

## Playback

The playback service continues audio when the player screen is not visible. Playback controls are available in the notification and through the Android media session on the lock screen and compatible headset controls.

The album-art surface supports horizontal swipes for previous and next tracks. A vertical gesture along its edge adjusts music volume. Double-tapping the artwork toggles the current song's favorite state.

Audio focus is observed while another application uses the audio output. Short interruptions can pause playback and resume when focus returns; duck requests lower the player's output temporarily. The player also responds to the music-stream volume reaching zero.

## Favorites

Mark the current song with the heart beside the transport controls or by double-tapping the album artwork. In the playlist, use the heart at the end of a song row. Favorite state is stored with the song in the local database and remains available after the app is closed.

Playlist selections are collected while the playlist screen is open and committed together when that screen pauses. The current song can finish playing if its favorite state changes while the Favorites playback scope is active; it leaves the active queue when playback advances.

## Playback scope

Open **MANAGER**, then choose **SCOPE** in the folder manager header. The seven scope modes are:

- **All** — every song in the library
- **Favorites** — songs marked as favorites
- **Loose Tracks** — individual files opened outside the selected folders
- **Folders** — songs from the selected folders
- **Genres** — songs matching the selected genres
- **Artists** — songs matching the selected artists
- **Albums** — songs matching the selected albums

The four filter-based modes allow multiple values within their own category. A scope is one mode at a time; selecting a different category replaces the previous category. Leaving a filter category with no selected values returns playback to **All**. The selected scope is saved on the device and restored on the next launch.

The current song and an already-committed next song remain in the queue while a scope change takes effect. This lets a transition complete naturally without interrupting the audio.

## Audio controls

The equalizer provides ten frequency bands and sixty presets, including a custom preset. Bass Boost and Surround can each be adjusted from 0 to 100 percent. Pitch ranges from -6.0 to +6.0 semitones, and playback speed ranges from 0.50x to 1.50x.

The equalizer attaches to the active playback audio session. Its controls reflect the current effect state, and the screen indicates when no playback audio session is available.

## Metadata editor

The Metadata Editor reads and writes supported tag fields, including title, artist, album, genre, year, track information, lyrics, and embedded album artwork. Artwork can be selected from the device or removed. Changes are written to the selected audio document, and the editor reads the saved metadata back to display the resulting file contents.

## Themes and languages

Choose from 32 theme colors. The interface is available in sixteen languages: English, Spanish, French, German, Italian, Portuguese, Russian, Chinese, Japanese, Korean, Hindi, Arabic, Turkish, Indonesian, Dutch, and Polish. Language selection is available from the Credits dialog.

## Permissions

Android requests access when a feature needs it:

- Music-library access uses `READ_MEDIA_AUDIO` on Android 13 and later, or `READ_EXTERNAL_STORAGE` on earlier versions.
- Notifications use `POST_NOTIFICATIONS` on Android 13 and later.
- Headset connection information uses `BLUETOOTH_CONNECT` on Android 12 and later.
- The Metadata Editor requests image access when the user selects album artwork.
- The media-playback foreground service uses the foreground-service permissions declared in the application manifest. `FOREGROUND_SERVICE_MEDIA_PLAYBACK` is a normal install-time permission, not a runtime prompt.

The application also declares the audio-settings and wake-lock permissions used by its playback and audio-effect features.

## Installation

Download the APK from the Assets section of the [GitHub release](https://github.com/oneadzido/llama-music-player/releases). Open the downloaded APK on the Android device and follow the installation prompts. Android may ask the user to allow installation from the selected source.

## First use

1. Open **MANAGER** from the main player screen.
2. Choose **IMPORT FOLDER** and select a music folder.
3. Choose **UPDATE** to add the selected folder to the library.
4. Return to the player and select a song.

## Privacy

The library, favorites, playback preferences, selected folders, theme, and language preference are stored in application storage. The application does not include an analytics or advertising service and does not send library contents to an app-operated remote service. Android system backup is enabled and may include app data when device backup is turned on. See [PRIVACY.md](PRIVACY.md) for the privacy policy.

## Credits and license

- **jaudiotagger** — metadata reading and writing
- **Font Awesome Free Solid** — interface icons

Llama Music Player is distributed under the MIT License. See [LICENSE](LICENSE).
