# Llama Music Player v1.4.0

**Release date:** Nov 05, 2026

---

### Overview

Favorites and playback scope land in this release. A song can now be
marked as a favorite from the player's transport row, from a
double-tap on the album art, or from a heart on any playlist row, and
the player can be restricted to favorites, to loose tracks, to a
chosen set of folders, genres, artists, or albums. The two features
are joined by a single structural change in `MusicService`: the
playlist is now a three-tier value.

The first tier is `mFullPlaylist`, the immutable reflection of the
database that `setPlaylist` assigns. The second is `mScopedPlaylist`,
the same list filtered by the active `PlaybackScope`. The third is
`mCurrentPlaylist`, the active queue, which is `mScopedPlaylist` plus
the songs at `mCurrentIndex` and `mTargetIndex`. The two extra songs
are the grace period: unfavoriting the playing song while the scope
is Favorites does not silence it, and a target that the user has
already committed to does not drop out of the queue because a scope
change arrived mid-transition. `rebuildPlaylists()` is the single
mutator for the second and third tiers, and it runs on the main thread
inside `setPlaylist`, `setPlaybackScope`, `commitFavorites`, and at
the tail of `onPlaybackStarted` once a transition has moved past the
previous song.

The favorite column is protected by two design choices that matter
for anyone reading the database layer. `SongDatabase.setFavorite(String,
boolean)` writes the column and nothing else; the method exists so
that every other write path — the metadata editor's update, the genre
loader's update, the scan's reconciliation — goes through
`SongDatabase.updateSongMetadata(Song)`, which writes every column
except `favorite`. The insert path is the only other writer: a fresh
row is inserted with `buildContentValues`, which includes the flag; an
existing row is routed through `updateSongMetadataInternal` so that a
scan that touches every song in the library cannot clobber a user's
favorites by accident. The schema bumps to version 3; both tables get
the new column with `DEFAULT 0`.

The playlist editor gained a heart at the trailing edge of every row.
Tapping it flips the row's in-memory flag, rebinds the row for its new
tint, and forwards the change to a `FavoriteListener` that
`PlaylistActivity` implements as a lambda staging the tap in
`PendingFavorites`. Nothing commits to the service until `onPause`.
Staging is what makes a heart-and-unheart pair cost zero database
writes, and it is what makes a burst of favorites across a long
playlist produce one batched commit instead of one per tap. The
transport row grew a sixth button on the same principle: a heart that
toggles the current song's flag through
`MusicService.toggleFavorite()`. The album art's double-tap is a third
entry point to the same commit; a single tap does nothing, and the
swipe gesture still drives the carousel — the double-tap detector
runs only when the touch never crossed the touch-slop radius, so a
horizontal swipe is never mistaken for a tap.

The playback scope dialog is opened from a new SCOPE button in the
folder manager's header, styled to match the playlist's SORT button.
The dialog's top three options — All, Favorites, Loose Tracks — are
single-select; the bottom four — Folders, Genres, Artists, Albums —
are multi-select lists, and choosing a value in one category clears
the other three because a scope is one kind and one set, not a union
of four. The folder list comes from the folder manager's own items;
the other three lists are enumerated from the songs table on the
dialog's executor. A malformed scope preference deserializes to
`PlaybackScope.ALL`, so a corrupted preference cannot leave the
player with a scope that matches nothing.

Two smaller changes are worth noting because they reach the release
notebook. The playlist activity's empty-state message now depends on
the scope: a library with no songs shows the "import folders"
message, and a library with songs filtered to zero by an active
scope shows "No songs in the current playback scope." The two messages
share one slot; only the copy differs. And the metadata broadcast
that the editor publishes now lands on the in-memory playlist even
when no activity is alive, because `MusicService` owns its own
receiver for it — a fix carried over from v1.3.9 and now joined by
the favorites commit's own `FAVORITE_CHANGED` broadcast, which the
two visible surfaces listen for so a theme change can retint every
heart on every visible row without waiting for the next playback
broadcast.

---

### Added

- **Favorites on the transport row, album art, and playlist rows** —
  A new sixth button on the transport row toggles the current song's
  favorite flag through `MusicService.toggleFavorite()`. A
  double-tap on the album art opens the same commit. Every playlist
  row gained a heart at its trailing edge; tapping it flips the
  row's in-memory flag and stages the change in
  `PlaylistActivity.PendingFavorites`. The playlist hearts commit
  in one batch on `onPause`; the transport heart and the album-art
  double-tap commit immediately.

- **Six transport buttons in equal segments** — The transport row
  now holds shuffle, previous, play/pause, next, repeat, and
  favorite. Every button is `layout_width="0dp"`,
  `layout_weight="1"`, `layout_height="48dp"`, and the row's
  leading and trailing padding is 16dp. Six equal segments of the
  leftover width after the padding; on a 320dp screen each button
  is exactly 48dp. Every glyph is 28sp.

- **Playback scope with seven kinds** — A new `PlaybackScope`
  value object with a `Kind` enum — `ALL`, `FAVORITES`,
  `LOOSE_TRACKS`, `FOLDERS`, `GENRES`, `ARTISTS`, `ALBUMS` — and
  four filter sets. `matches(Song, Set)` is the only read; it
  consults `CharacterMapper.isUnknownX(String)` so a song whose
  field is the current locale's placeholder is never matched
  against a stored value.

- **Playback scope dialog** — Opened from the SCOPE button in the
  folder manager's header. Three single-select options (All,
  Favorites, Loose Tracks) and four multi-select lists (Folders,
  Genres, Artists, Albums). The filter lists are populated on a
  background executor; a database failure shows the load-error
  toast and leaves the folder list usable. Applying an empty set
  in a filter category falls back to `PlaybackScope.ALL` rather
  than to a scope that matches nothing.

- **Three-tier playlist** — `MusicService` carries three lists:
  `mFullPlaylist`, `mScopedPlaylist`, and `mCurrentPlaylist`.
  `rebuildPlaylists()` is the single mutator for the second and
  third; it runs on the main thread and is called from
  `setPlaylist`, `setPlaybackScope`, `commitFavorites`, and at
  the tail of `onPlaybackStarted`.

- **Grace period for the current and target songs** —
  `rebuildPlaylists` keeps the songs at `mCurrentIndex` and
  `mTargetIndex` in `mCurrentPlaylist` even when the scope no
  longer matches them. Unfavoriting the playing song in the
  Favorites scope does not silence it; the song plays through and
  drops from the queue when the next transition moves past it.

- **Favorites commit and broadcast** —
  `MusicService.commitFavorites(Map<String, Boolean>)` updates the
  three lists, calls `SongDatabase.setFavorite(String, boolean)`
  for each path, rebuilds the playlists, and announces the change
  through `broadcastUpdate()` and a `FAVORITE_CHANGED` broadcast.
  `PlaylistActivity` stages heart taps in `PendingFavorites` and
  flushes the batch on `onPause`.

- **Favorites schema, version 3** — The songs and loose-songs
  tables gain a `favorite INTEGER DEFAULT 0` column.
  `onUpgrade` handles 2→3 with an `ALTER TABLE` that back-fills
  every existing row with 0. `SongDatabase`'s row reader reads
  the flag when present, and defaults to `false` when the column
  is absent — a defensive fallback for a cursor that predates the
  schema.

- **Metadata-preserving database write path** —
  `SongDatabase.updateSongMetadata(Song)` writes every column
  except `favorite`; the insert path routes an existing row
  through it so a scan or a genre load cannot clobber a user's
  favorites. `SongDatabase.setFavorite(String, boolean)` is the
  only writer of the favorite column on an existing row.

- **SCOPE button in the folder manager header** — Same height,
  text size, letter spacing, selector background, and horizontal
  padding as the playlist's SORT button, on the header row's
  trailing edge. Its click handler opens the scope dialog; its
  enabled state follows `!isUpdating()`, the same gate the IMPORT
  button uses.

- **`Song` favorite field** — `Song` gains a `mFavorite` boolean,
  `isFavorite()`, and `setFavorite(boolean)`. The
  `serialVersionUID` bumps to 2; a version-1 stream deserializes
  with the flag as `false`.

- **`FontAwesome.HEART`** — The filled heart glyph `\uF004` for
  the transport button and the playlist row heart.

- **Empty-state message distinguishes scope from library** — A
  library with no songs shows the "import folders" message; a
  library with songs filtered to zero by an active scope shows
  "No songs in the current playback scope."

- **`SongDatabase` schema and write path** — Detailed in the
  Overview. The change is version-3 schema, the two write paths
  (`updateSongMetadata` for everything except favorite,
  `setFavorite` for favorite only), and the insert-path routing
  that preserves an existing row's favorite flag across a scan.

---

### Under the Hood

- `PlaybackScope` — New class. An immutable value with a `Kind`
  enum and four `Set<String>` fields (`paths`, `genres`, `artists`,
  `albums`). `matches(Song, Set<String>)` consults the set the kind
  names; a null song, a null path, and a field carrying the current
  locale's placeholder all return false. `serialize()` produces a
  JSON object through the framework's `org.json`;
  `deserialize(String)` returns `ALL` for any input that does not
  parse. `ALL` is a static instance.

- `PlaybackScopeDialog` — New class. Top bar with CANCEL, title,
  and APPLY; a `RadioGroup` for the three exclusive modes; four
  `LinearLayout` containers for the multi-select lists. Folder
  rows come from the caller-supplied `List<FolderAdapter.FolderItem>`;
  genres, artists, and albums are enumerated from
  `SongDatabase.getAllSongs()` on the dialog's executor. The
  enumeration filters out `CharacterMapper.isUnknownX(String)`
  values. Applying a scope whose kind is a filter kind with an
  empty set returns `ALL` rather than a scope that matches nothing.
  The executor is shut down in `dismiss()`.

- `Song.isFavorite()` / `Song.setFavorite(boolean)` — New
  accessors. The field defaults `false`, is set by the row reader
  when the schema carries the column, and is preserved across the
  `serialVersionUID` bump.

- `SongDatabase.DATABASE_VERSION` — Bumped to 3.
  `createTable` and `onUpgrade` add the `favorite INTEGER DEFAULT 0`
  column to both tables.

- `SongDatabase.buildContentValues(Song)` — Splits into a full
  builder and a metadata-only builder. The full builder is used by
  the fresh-row branch of the insert path and includes the
  favorite flag. The metadata-only builder is used by the update
  branch and by `updateSongMetadata(Song)`, and deliberately
  excludes the flag.

- `SongDatabase.insertSong(Song)` — Routes an existing row through
  `updateSongMetadataInternal`; a fresh row goes through
  `insertSongInternal` with the full content values. The batch
  insert (`insertSongsBatchInternal`) does the same for each song
  inside its transaction.

- `SongDatabase.updateSongMetadata(Song)` — New public method.
  Updates every column except `favorite`. Called by the metadata
  editor, the genre loader, and the playlist rebuild.

- `SongDatabase.setFavorite(String, boolean)` — New public
  method. Writes the `favorite` column on both the songs and
  loose-songs tables. The only writer of the column on an
  existing row.

- `SongDatabase.RowReader` — Resolves the `favorite` column
  alongside the others; when present, sets the flag on the
  returned song. When absent (a cursor from an older schema), the
  song defaults to not favorited.

- `MusicService.mFullPlaylist` — New field. The immutable database
  reflection, assigned by `setPlaylist`.

- `MusicService.mScopedPlaylist` — New field. `mFullPlaylist`
  filtered by `mPlaybackScope`. Recomputed only by
  `rebuildPlaylists()`.

- `MusicService.mPlaybackScope` — New field. The active scope,
  defaulting to `PlaybackScope.ALL`.

- `MusicService.mLooseTrackPaths` — New field. The set of paths in
  the loose-songs table, refreshed by `rebuildPlaylists()`.
  Consulted by `PlaybackScope.matches` for the loose-track scope.

- `MusicService.rebuildPlaylists()` — New private method. The
  single mutator for `mScopedPlaylist` and `mCurrentPlaylist`. Runs
  on the main thread. Captures the paths at `mCurrentIndex` and
  `mTargetIndex` before rebuilding; adds the songs back into the
  new list if the scope excluded them; re-anchors both indices to
  the captured paths; clears the shuffle peek memos, the shuffle
  history, and the cached window.

- `MusicService.setPlaybackScope(PlaybackScope)` — New public
  method. Stores the scope, persists it under
  `playback_scope_json`, rebuilds the playlists, and broadcasts.

- `MusicService.getPlaybackScope()` — New public method. Returns
  the active scope.

- `MusicService.getScopedPlaylist()` — New public method. Returns
  a copy of `mScopedPlaylist`. A caller that needs the playable
  queue uses `getCurrentPlaylist()`, which includes the grace-period
  songs.

- `MusicService.getScopedPlaylistSize()` — New public method.
  Returns `mScopedPlaylist.size()`.

- `MusicService.commitFavorites(Map<String, Boolean>)` — New
  public method. Applies the map to all three lists, persists each
  path through `SongDatabase.setFavorite`, rebuilds the playlists,
  broadcasts `UPDATE_PLAYER`, and broadcasts `FAVORITE_CHANGED`.
  A per-path database failure is logged and does not abort the
  batch.

- `MusicService.toggleFavorite()` — New public method.
  Convenience wrapper that commits a single-path change for the
  current song.

- `MusicService.setPlaylist(ArrayList<Song>, boolean)` — Assigned
  to `mFullPlaylist` and calls `rebuildPlaylists()` instead of
  using the argument list directly. The anchor resolution and the
  pending-path handling now operate on `mCurrentPlaylist`; the
  anchor's index is re-resolved against the current playlist after
  the rebuild.

- `MusicService.onPlaybackStarted(long, int, Song, int)` — Calls
  `rebuildPlaylists()` immediately after `mCurrentIndex =
  committedIndex`, so the previous song drops from the queue if it
  no longer matches the scope. The current song survives because
  it occupies `mCurrentIndex` at the moment of the rebuild.

- `MusicService.broadcastUpdate()` — Carries three new extras:
  `is_favorite` (the current song's flag), `scope_kind` (the
  active kind's name), and `scope_count` (the scoped playlist
  size). The notification and the activity both read the new
  extras on the same main-thread turn.

- `MusicService` — New `ACTION_APPLY_PLAYBACK_SCOPE` broadcast
  constant, `EXTRA_SCOPE_JSON` extra key, `ACTION_FAVORITE_CHANGED`
  broadcast constant, and a receiver that applies a serialized
  scope on the main thread. The receiver is registered in
  `onCreate` and unregistered in `onDestroy`.

- `MusicService.loadPlaybackScope()` — New private method.
  Deserializes `playback_scope_json` at `onCreate`. A malformed
  value resolves to `ALL`.

- `MusicService.savePlaybackScope()` — New private method. Writes
  `playback_scope_json` on every `setPlaybackScope`. Called from
  the scope-apply receiver and from `setPlaybackScope`.

- `PlaylistActivity.PendingFavorites` — New static inner class. A
  `HashMap<String, Boolean>` with `stage(path, flag)`,
  `isEmpty()`, `snapshot()`, and `clear()`. The playlist row's
  `FavoriteListener` stages; `onPause` flushes and clears.

- `PlaylistActivity.setupAdapter()` — Installs a
  `FavoriteListener` on the adapter that stages heart taps in
  `PendingFavorites`.

- `PlaylistActivity.onPause()` — Flushes `PendingFavorites` to
  `MusicService.commitFavorites` before clearing the map and
  unregistering the theme receiver.

- `PlaylistActivity.showEmptyView(int)` — Takes a string
  resource identifier. `refreshPlaylistFromService` passes
  `playlist_empty_scope` when the active scope is not `ALL`,
  `playlist_empty_state` otherwise;
  `registerLibraryResetReceiver` passes `playlist_empty_state`
  unconditionally, because a reset is always a library-empty
  state.

- `PlaylistActivity.applyThemeToUI()` — Rebinds every visible row
  on a theme change through
  `notifyItemRangeChanged(0, getItemCount())`, so every visible
  heart picks up the new tint without waiting for a playback
  broadcast.

- `PlaylistAdapter.FavoriteListener` — New interface. Called after
  the row's `Song` flag is flipped and the row is rebound; the
  listener's job is to persist or stage the change, not to
  flip it.

- `PlaylistAdapter.ViewHolder` — Resolves `R.id.favoriteIcon`
  alongside the title and subtitle. Binds the heart's glyph,
  tint, content description, and click handler in
  `onBindViewHolder`. The tint follows the current theme color
  when the song is favorited and `TEXT_COLOR_DARK` when not.

- `MusicPlayer.mFavoriteButton` — New field. Resolved in
  `initializeViews` after `mMetadataButton`; typeface, glyph,
  background, and animation set alongside the other control
  buttons. Its click goes through `MusicService.toggleFavorite`
  with the standard 500ms debounce.

- `MusicPlayer.refreshTransportControls()` — Reads the current
  song's favorite flag alongside the playing, repeat, and shuffle
  states and writes the heart's active tint through the same
  `updateControlButton` call the other four buttons use.

- `MusicPlayer.handleGestureDown` / `handleGestureMove` /
  `handleGestureUp` — The gesture mode enum renames `UNDECIDED` to
  `TOUCHED`, which is now both the pre-classification state and the
  state from which a double-tap is detected. On `ACTION_UP` in
  `TOUCHED`, the handler compares the tap time against the last
  recorded tap; two taps inside `ViewConfiguration.getDoubleTapTimeout()`
  call `toggleCurrentFavorite` and reset the timestamp.

- `MusicPlayer.toggleCurrentFavorite()` — New private method.
  Reads the current song's flag, calls
  `MusicService.toggleFavorite`, and shows the appropriate
  favorite toast. The read and the toggle run under
  `mServiceLock` so a concurrent transport tap cannot interleave.

- `MusicPlayer.applyNoSongState()` — Resets the favorite button to
  the inactive tint when the empty state is applied.

- `FolderManager.mScopeButton` — New field. Resolved in
  `initializeViews`; its click handler calls
  `openPlaybackScopeDialog`. Its enabled state is written by
  `updateFolderButtons` from the same `isUpdating` gate the
  IMPORT button uses.

- `FolderManager.openPlaybackScopeDialog()` — New private method.
  Reads the current scope from preferences, constructs a
  `PlaybackScopeDialog`, and, on apply, broadcasts
  `APPLY_PLAYBACK_SCOPE` with the serialized scope.
  `FolderManager` does not bind `MusicService` directly; the
  broadcast is the single write path.

- `FolderManager.updateFolderButtons()` — Includes the scope
  button in the enable/disable pass, gated on `!isUpdating()`.

- `styles.xml` — Adds `PlaybackScopeDialogAnimation`, matching
  the other dialogs' slide-up / slide-down.

- `activity_music_player.xml` — Transport row replaced with six
  equal-weight buttons; the new `favoriteButton` is last.

- `item_song.xml` — The content row becomes a horizontal
  `LinearLayout` with a weighted `textColumn` holding the title
  and subtitle and a 36dp `favoriteIcon` at the trailing edge.
  The structure is RTL-safe because the weight absorbs the
  leftover width on whichever side the text lands.

- `activity_folder_manager.xml` — The header row gains the
  `scopeButton` between the folder count and the trailing edge.

- `strings.xml` — Adds `action_scope`, `action_apply`,
  `scope_dialog_title`, the seven `scope_dialog_option_*` labels,
  `scope_dialog_load_error`, `playlist_empty_scope`,
  `player_toast_favorite_on`, `player_toast_favorite_off`,
  `favorite_commit_failed`, `playlist_favorite_add`,
  `playlist_favorite_remove`, and the three plural counts
  `genre_count`, `artist_count`, `album_count`.

- `proguard-rules.pro` — Adds keeps for `PlaybackScope`,
  `PlaybackScope.Kind`, `PlaybackScopeDialog` and its listener,
  `PlaylistAdapter.FavoriteListener`, `PlaylistActivity.PendingFavorites`,
  `Map` / `HashMap`, `Set` / `HashSet`, and `org.json`. Extends the
  `MusicService`, `SongDatabase`, `Song`, `MusicPlayer`,
  `PlaylistActivity`, `PlaylistAdapter`, `FolderManager`, and
  `FontAwesome` keep blocks with a paragraph documenting the new
  surface. The header's subsystem list is now the README's nine
  subsystems, in the README's order, with a new paragraph under the
  playback state machine describing the three-tier playlist.

- `build.gradle` — `versionCode 32`, `versionName "1.4.0"`. No new
  dependencies. The favorites column ships in the existing
  `SongDatabase`; the scope serialization uses the framework's
  `org.json` package. Both features are implemented entirely in
  application code.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Favorite current song | Tap the heart on the transport row, or double-tap the album art |
| Favorite a playlist row | Tap the heart at the right edge of the row |
| Playback scope | Tap MANAGER, then SCOPE in the header |
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana