# Llama Music Player v1.3.5

**Release date:** Oct 19, 2026

### Overview

A visual consistency pass across every activity and dialog. Separators
have been introduced between adjacent UI elements in headers, list rows,
and the version header, so the interface reads as a continuous sequence
of distinct parts rather than a run of text.

### Changed

**Header and List Separators.** The codebase now uses a single-space
separator (`" "`) between adjacent structural elements, supplied by a
context-specific Java constant in each file. This keeps the XML layouts
clean and ensures the spaces are never stripped by the resource
compiler. 

- **Playlist Header** — The song count and the `SORT` button now sit
  after the sort mode label, separated by `SONG_COUNT_SEPARATOR`.
- **Folder Manager Header** — The folder count now sits after the list
  header, separated by `FOLDER_COUNT_SEPARATOR`.
- **Folder List Rows** — The folder icon, the folder name, and the
  `✕` button are now separated by `FOLDER_ROW_SEPARATOR` in
  `FolderAdapter`.
- **Metadata Editor Header** — The file format now sits after the
  mode label, separated by `FORMAT_LABEL_SEPARATOR`.
- **Credits Version Header** — The `VERSION` label, the language
  button, and the version number are now separated by
  `VERSION_HEADER_SEPARATOR`.
- **Language Dialog Header** — The language count now sits after
  the list header, separated by `LANGUAGE_COUNT_SEPARATOR`.
- **Preset Dialog Header** — The preset count now sits after the
  list header, separated by `PRESET_COUNT_SEPARATOR`.
- **Theme Dialog Header** — The theme count now sits after the
  list header, separated by `THEME_COUNT_SEPARATOR`.

### Under the Hood

- `PlaylistActivity.java` — Added `SONG_COUNT_SEPARATOR`; updated
  `updateTitleAndCount`.
- `FolderManager.java` — Added `FOLDER_COUNT_SEPARATOR`; updated
  `updateFolderCount`.
- `FolderAdapter.java` — Added `FOLDER_ROW_SEPARATOR`; updated
  `onBindViewHolder`.
- `MetadataEditor.java` — Added `FORMAT_LABEL_SEPARATOR`; updated
  `updateFileInfo`.
- `CreditsDialog.java` — Added `VERSION_HEADER_SEPARATOR`; updated
  `createVersionHeader`.
- `LanguageDialog.java` — Added `LANGUAGE_COUNT_SEPARATOR`; updated
  `createHeader`.
- `PresetDialog.java` — Added `PRESET_COUNT_SEPARATOR`; updated
  `createHeader`.
- `ThemeDialog.java` — Added `THEME_COUNT_SEPARATOR`; updated
  `createHeader`.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana