# Llama Music Player v1.3.5

**Release date:** Oct 20, 2026

### Overview

A visual alignment pass across every activity and dialog. Separators
have been replaced with explicit 8dp margins between adjacent UI
elements in headers, list rows, and the version header, guaranteeing a
visible, consistent gap across all screen sizes and languages. The
Music Player timers and the Credits version header now anchor perfectly
to their respective edges in right-to-left languages like Arabic. A
layout wrapping issue in the metadata editor's header has also been
resolved for languages with longer translations.

### Fixed

- **Music Player Timer Alignment** — The current time and total
  duration text views now anchor flush to the left and right ends of
  the seek bar in every language. A flexible spacer between them
  ensures they remain separated without overflowing their bounding
  boxes.

- **Credits Dialog Version Header (RTL)** — The `VERSION` label and
  version number now use relative start and end gravity. In Arabic,
  this anchors the version number to the 16dp trailing edge rather
  than pushing it toward the language button, resolving the uneven
  gaps in the header.

- **Metadata Editor Header Wrapping** — The file format label
  (e.g., "MP3") in the metadata editor's header now correctly sizes
  itself to its content. Previously, the forced single-line constraint
  in right-to-left languages like Arabic could cause unexpected
  wrapping or spacing issues. The label is now anchored to the trailing
  edge with a consistent 8dp start margin.

### Changed

**Header and List Separators.** The codebase has moved away from
string-based separators (`" "`) in Java and now uses explicit visual
margins directly in the XML layouts and programmatic UI builders. This
ensures the spacing is consistent and not subject to text-rendering
quirks.

- **Playlist Header** — The song count and the `SORT` button now sit
  after the sort mode label, separated by an 8dp start margin.
- **Folder Manager Header** — The folder count now sits after the list
  header, separated by an 8dp start margin.
- **Folder List Rows** — The folder icon, the folder name, and the
  `✕` button are now separated by 8dp start margins in
  `item_folder.xml`.
- **Metadata Editor Header** — The file format now sits after the
  mode label, separated by an 8dp start margin.
- **Credits Version Header** — The `VERSION` label, the language
  button, and the version number are now visually separated by their
  respective weights and layout gravity.
- **Language Dialog Header** — The language count now sits after
  the list header, separated by an 8dp start margin.
- **Preset Dialog Header** — The preset count now sits after the
  list header, separated by an 8dp start margin.
- **Theme Dialog Header** — The theme count now sits after the
  list header, separated by an 8dp start margin.

### Under the Hood

- `activity_playlist.xml`, `activity_folder_manager.xml`,
  `item_folder.xml`, `activity_metadata_editor.xml` — Added
  `android:layout_marginStart="8dp"` to adjacent elements in the
  headers and list rows. Removed `android:singleLine` from
  `formatText` in the metadata editor.
- `activity_music_player.xml` — Replaced the weighted timer text
  views with `wrap_content` text views and a flexible `<Space>`
  element to separate them. Added `start` and `end` gravity to the
  timers.
- `PlaylistActivity.java`, `FolderManager.java`, `FolderAdapter.java`,
  `MetadataEditor.java`, `CreditsDialog.java`, `LanguageDialog.java`,
  `PresetDialog.java`, `ThemeDialog.java` — Removed the string
  separator constants and updated the view builders to use
  `LayoutParams.setMarginStart(8dp)` instead.
- `CreditsDialog.java` — Changed the version header text views to use
  relative `START`/`END` gravity and removed manual RTL view swapping
  from `createVersionHeader()`.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana