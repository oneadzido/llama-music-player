# Llama Music Player v1.3.5

**Release date:** Oct 20, 2026

### Overview

A visual consistency pass across every activity and dialog. Separators
have been replaced with explicit 8dp start margins between adjacent UI
elements in headers, list rows, and the version header, guaranteeing a
visible, consistent gap across all screen sizes and languages. A
layout wrapping issue in the metadata editor's header has also been
resolved for languages with longer translations. An RTL alignment pass
has resolved uneven gaps in the Credits dialog and misaligned timers in
the Music Player.

### Fixed

- **Metadata Editor Header Wrapping** — The file format label
  (e.g., "MP3") in the metadata editor's header now correctly sizes
  itself to its content without phantom margins. Previously, the
  forced single-line constraint in right-to-left languages like
  Arabic could cause unexpected wrapping or spacing issues. The label
  is now anchored to the trailing edge with a consistent 8dp start
  margin.

- **Credits Dialog Version Header (RTL)** — The `VERSION` label,
  language button, and version number now use relative `START` and
  `END` gravity. In Arabic, this anchors the label and version number
  flush to the outer edges of the row instead of pushing them inward,
  resolving the uneven gaps and properly centering the language button.

- **Music Player Timer Alignment (RTL)** — The current time and total
  duration text views now use relative `START` and `END` gravity,
  ensuring they sit flush with the left and right ends of the seek bar
  in every language. An 8dp end margin on the current time guarantees
  a consistent gap between the two timers.

### Changed

**Header and List Separators.** The codebase has moved away from
string-based separators (`" "`) in Java and now uses explicit visual
margins directly in the XML layouts and programmatic UI builders. This
ensures the spacing is consistent and not subject to text rendering
quirks.

- **Playlist Header** — The song count and the `SORT` button now sit
  after the sort mode label, separated by an 8dp start margin.
- **Folder Manager Header** — The folder count now sits after the list
  header, separated by an 8dp start margin.
- **Folder List Rows** — The folder icon, the folder name, and the
  `✕` button are now separated by 8dp start margins in
  `item_folder.xml`.
- **Metadata Editor Header** — The file format now sits after the
  mode label, separated by an 8dp start margin.
- **Credits Version Header** — The `VERSION` label, the language
  button, and the version number are now separated by 8dp margins.
- **Language Dialog Header** — The language count now sits after
  the list header, separated by an 8dp start margin.
- **Preset Dialog Header** — The preset count now sits after the
  list header, separated by an 8dp start margin.
- **Theme Dialog Header** — The theme count now sits after the
  list header, separated by an 8dp start margin.

### Under the Hood

- `activity_playlist.xml`, `activity_folder_manager.xml`,
  `item_folder.xml`, `activity_metadata_editor.xml` — Added
  `android:layout_marginStart="8dp"` to adjacent elements in the
  headers and list rows. Removed `android:singleLine` from
  `formatText` in the metadata editor.
- `activity_music_player.xml` — Added relative `gravity` (`start` and
  `end`) to the timer text views and an 8dp end margin to the current
  time.
- `PlaylistActivity.java`, `FolderManager.java`, `FolderAdapter.java`,
  `MetadataEditor.java`, `CreditsDialog.java`, `LanguageDialog.java`,
  `PresetDialog.java`, `ThemeDialog.java` — Removed the string
  separator constants (`SONG_COUNT_SEPARATOR`, `FOLDER_COUNT_SEPARATOR`,
  `FOLDER_ROW_SEPARATOR`, `FORMAT_LABEL_SEPARATOR`,
  `VERSION_HEADER_SEPARATOR`, `LANGUAGE_COUNT_SEPARATOR`,
  `PRESET_COUNT_SEPARATOR`, `THEME_COUNT_SEPARATOR`) and updated the
  view builders to use `LayoutParams.setMarginStart(8dp)` instead.
- `CreditsDialog.java` — Changed version header text views from
  absolute `LEFT`/`RIGHT` gravity to relative `START`/`END` and removed
  manual RTL view swapping.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Language | Tap LLAMA button on main screen, then the language button in the version header |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana