# Llama Music Player v1.2.5

**Release date:** Oct 7, 2026

## Overview

Three changes ship in this release — all in the incoming-file pathway
and the album-art carousel that renders its transition.

Two rapid file opens now resolve in order. Previously, when a second
loose-track insert was still queued while the first one's rebuild ran,
the first rebuild cleared the pending-path slot even though the path
it named had not yet been found in the rebuilt playlist. The second
rebuild then fell through to the persisted last-played path, and the
file the user opened last never played. The pending slot is now
consumed only when it was resolved by its own path.

The album-art carousel now runs a dedicated fade animation when the
current song changes to a path that is not one of the previous
window's neighbours. The incoming-file pathway produces exactly that
shape: the file can land anywhere in the rebuilt playlist, so it is
rarely the immediate neighbour the transport buttons or an automatic
advance would land on. Previously the strip snapped; now it fades out,
renders the new window at the midpoint, and fades back in, over the
same total duration a commit takes.

The incoming file's art is decoded in parallel with the loose-track
insert and the playlist rebuild, so the carousel's shared cache is
usually warm by the time the service's first window reaches it. The
fade midpoint runs 250 ms after the window arrives; a decode started
at hand-off time typically finishes before that, so the fade reads as
outgoing art to incoming art rather than as a fade to the placeholder
and a later snap to the real bitmap.

## Fixed

- **Two rapid loose-track opens resolve in order** — When a user
  opens two audio files in quick succession from another app, each
  file is inserted as a loose track and its own playlist rebuild
  follows. Previously `MusicService.setPlaylist` cleared
  `mPendingSongPath` unconditionally after computing the anchor, so
  the first rebuild — which ran before the second file's insert had
  committed — cleared the slot even though the path it named was
  not yet in the playlist. The second rebuild then found the slot
  empty, fell through to the persisted last-played path, and the
  second file never played. The slot is now consumed only when it
  was resolved by its own path in the rebuilt playlist; a fallback
  to a title match or to index 0 does not consume it. Two rapid
  opens resolve in order: the first rebuild finds the second path
  absent and preserves the slot, the second rebuild finds it
  present, plays it, and clears.

- **The album-art carousel fades on non-neighbour song changes** —
  A current-song change to a path that is not one of the previous
  window's neighbours had no animation shape, so the strip snapped.
  Every other transition animates; this one did not. The incoming-
  file pathway is the ordinary producer of this shape. The carousel
  now runs a two-leg fade over `SWIPE_ANIMATION_MS`, the same total
  duration a commit takes: fade out over the first half, render the
  new window at the midpoint, fade back in over the second half. A
  broadcast arriving before the midpoint overwrites the window and
  is picked up by the midpoint's render, so consecutive transitions
  inside the fade window present the newest current song with the
  intermediate ones skipped. A broadcast arriving after the midpoint
  starts a fresh fade at the fade's end, so consecutive transitions
  chain rather than abort mid-leg. The strip's alpha is restored by
  `cancelSwipe`, which every path that leaves the carousel passes
  through, so a fade cannot leave the strip partially transparent.
  The fade also fires on the cold-start placeholder-to-first-song
  transition, because the same shape — a current path change with
  no neighbour match — describes both. The two are visually
  indistinguishable and both read as a soft reveal.

- **Incoming art is decoded ahead of the service's first window** —
  The carousel's shared cache was cold when the service broadcast
  the incoming file's first `UPDATE_PLAYER`, so the fade midpoint
  rendered the placeholder instead of the real art and a later
  decode snapped the strip. The incoming file's art is now decoded
  on `MusicPlayer`'s metadata loader in parallel with the loose-
  track insert and the playlist rebuild. The decode reuses the same
  path the cold-start preload uses — `MediaMetadataRetriever`,
  downsampled to the album-art maximum, cached under the song's
  path — and hands the bitmap to the carousel through
  `onArtReady` when it resolves. The carousel's shared cache is
  usually warm by the time the first window arrives.

## Under the Hood

- `MusicService.setPlaylist(ArrayList<Song>, boolean)` gained a
  local `pendingResolvedIndex` and a conditional clear: the pending
  slot is consumed only when it was resolved by its own path. A
  fallback to a title match or to index 0 preserves the slot. The
  variable name is local; the method's anchor precedence and
  cold-start pause logic are unchanged.

- `AlbumArtCarousel.SwipeState` gained a `FADING` state. Two
  fields, `mFadeMidpointPassed` and `mFadeWindowAdvanced`, track
  the fade's progress. `startFade()` runs the two legs;
  `setWindow`'s `FADING` case stores the incoming window and marks
  the fade for a re-run if the change arrived after the midpoint;
  `cancelSwipe` restores the strip's alpha to 1 and clears both
  flags. `adoptInIdle`'s `songChanged` predicate was widened to
  allow a null previous current path, so the cold-start
  placeholder-to-first-song transition takes the fade alongside the
  incoming-file case.

- `MusicPlayer.preDecodeIncomingArt(String)` runs on
  `mMetadataLoader`. It calls `loadSongMetadata(filePath)` —
  which decodes into `mAlbumArtCache` as a side effect — then reads
  the cache and calls `mAlbumArtCarousel.onArtReady(filePath,
  bitmap)` on the main thread when a bitmap is present. It is
  invoked from `handleIncomingFile`'s new-song branch, immediately
  after the early `handOffIncomingPath(filePath)` call, so the
  decode starts at the same moment as the loose-track insert and
  the playlist rebuild.

- `AlbumArtCarousel`'s fade uses the same `SWIPE_ANIMATION_MS`
  constant the commit, the spring-back, the below-threshold nudge,
  and the return leg already use. The half-duration is computed as
  `Math.max(1L, SWIPE_ANIMATION_MS / 2L)`, so the total is exactly
  `SWIPE_ANIMATION_MS` and every transition in the app takes the
  same 500 ms.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana