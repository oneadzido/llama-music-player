# Llama Music Player v1.2.9

**Release date:** Oct 11, 2026

## Overview

Two changes ship in this release — the folder controls are disabled
while the app cannot read the music, and the set of runtime
permissions the app needs now has one definition.

The folder scan cannot read the filesystem when the runtime
permissions are not granted. UPDATE would find nothing, and REMOVE
would stage a change with no way to apply it. Both controls now show
as disabled until the permissions are back, so the folder manager
does not present the user with buttons that cannot act. IMPORT stays
live: opening the picker is a separate grant, and it is the user's
legitimate path back to a readable library. The controls re-enable on
the resume that follows a later grant.

The set of permissions the app needs was defined twice — once as the
list `MusicPlayer` requested, once as the read-only mirror it used to
answer the same question on resume. Adding the folder manager as a
third reader made the second definition the wrong shape. The set now
lives in one place, and every reader — the player's request flow, the
player's resume-time check, and the folder manager's enable state —
reads through it.

## Fixed

- **The folder controls are disabled while the app cannot read the
  music** — When the runtime permissions the app needs are not granted,
  `FolderManager`'s UPDATE control and the per-row REMOVE control now
  show as disabled. The state is the honest one: the folder scan
  cannot read the filesystem without the permission, so UPDATE would
  find nothing and REMOVE would stage a change with no way to apply
  it. A control that looks live but cannot act is the same wrong state
  the play button was in.

  IMPORT stays live. Opening the SAF picker is a separate grant, and
  it is the user's legitimate path back to a library the app can read.
  Disabling it would close the door the user needs.

  The controls re-enable on the resume that follows a later grant.
  Nothing is cached to go stale in the meantime: the buttons and the
  per-row remove controls both read one expression of the fact — the
  permission answer combined with the update-in-progress answer — and
  that expression is re-evaluated on every resume and every button
  state change.

## Under the Hood

- New class `PermissionChecker` owns the set of runtime permissions
  the app needs. `allGranted(Context)` answers whether every one is
  granted; `getMissing(Context)` returns the ones that are not. Both
  read the same version-gated set, and `allGranted` is the length of
  `getMissing`'s array, so the two answers cannot disagree. The class
  is the single definition of the fact; the three readers are
  `MusicPlayer.checkPermissionsAndInitialize()` (through
  `getMissing`), `MusicPlayer.onResume()` (through `allGranted`), and
  `FolderManager.areFolderChangesAllowed()` (through `allGranted`).

- `MusicPlayer.hasAllRequiredPermissions()` is removed. It was the
  second definition of the permission set — a read-only mirror of the
  list `checkPermissionsAndInitialize()` requested, kept in sync by
  hand. The resume-time retry now reads
  `PermissionChecker.allGranted(this)` directly. A private method that
  wraps a single static call is the shape the coding conventions rule
  out; the wrapper's only remaining job was to name the query.

- `MusicPlayer.mPermissionsBlocked` is renamed to
  `mPermissionsDenied`. The flag's job is unchanged — it latches on
  the first failed permission check and clears on the next grant,
  and the clearing still resets `mInitializationAttempted` so the
  initialization flow runs again from a clean slate. The new name
  matches the fact the flag carries: the permissions were denied.

- `MusicPlayer.checkPermissionsAndInitialize()` builds no list of its
  own. It asks `PermissionChecker.getMissing(this)`, requests what the
  array names when it is not empty, and proceeds otherwise. The
  permission set is no longer spelled in the activity.

- `FolderManager` gained `areFolderChangesAllowed()`, returning
  `PermissionChecker.allGranted(this) && !isUpdating()`. The composed
  fact has one writer, and both the UPDATE button's enabled state and
  the adapter's per-row remove controls read it.

- `FolderManager.updateFolderButtons()` uses
  `areFolderChangesAllowed()` for the UPDATE button's condition and
  calls it once at the top so the adapter's refresh reads the same
  answer the button just read. The IMPORT button keeps keying on
  `!isUpdating()` alone.

- `FolderAdapter` gained the `RemoveButtonStateSource` interface and a
  constructor parameter that supplies one. The activity implements it
  with a method reference to `areFolderChangesAllowed`. The adapter's
  bind queries the source through `configureRemoveButton` instead of
  reading `NavigationController.isGroupDisabled(FOLDER_ACTIONS)`; the
  private `areRemoveButtonsEnabled()` helper that wrapped that read is
  removed. The enabled state is still a query made on every bind, not
  a cached value, so the answer cannot go stale between binds.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana