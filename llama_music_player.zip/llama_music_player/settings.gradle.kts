// settings.gradle.kts
//
// Llama Music Player — Settings
// ============================================================================
//
// This file defines the project structure and configuration at the
// settings level. It tells Gradle which modules to include in the
// build and where to find dependencies.
//
// File Location: /settings.gradle.kts
//
// Key Responsibilities
// --------------------
//   - Configuring plugin management repositories
//   - Setting dependency resolution strategy
//   - Defining included modules
//   - Setting the root project name
//
// @author Richard Korbla Adzido
// @version 1.5.0
// @since 1.0.0
// ============================================================================

pluginManagement {

    /**
     * Repositories for finding Gradle plugins.
     *
     *   google()             — Android Gradle Plugin and Google-
     *                          published plugins (KSP is on
     *                          Gradle's plugin portal; the Android
     *                          plugin and Kotlin plugin are on
     *                          Google and Maven Central
     *                          respectively)
     *   mavenCentral()       — standard plugins from the community
     *   gradlePluginPortal() — the official Gradle plugin portal
     *
     * The three are ordered by proximity: Google first (the AGP
     * dominates resolution), Maven Central second (Kotlin,
     * coroutines, JUnit), and the Gradle Plugin Portal last as the
     * catch-all.
     */
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {

    /**
     * Central repository configuration for all modules.
     *
     * FAIL_ON_PROJECT_REPOS prevents an individual module's
     * build.gradle.kts from redeclaring repositories, keeping the
     * resolution strategy in this one place. A module that tries to
     * declare its own repositories fails at configuration time, so
     * a developer cannot accidentally introduce a repository a CI
     * runner does not have access to.
     *
     *   google()       — AndroidX and Google libraries
     *   mavenCentral() — jaudiotagger and EventBus
     */
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

/**
 * The app module.
 *
 * Its source files live under app/src/main/kotlin/com/ark/llama,
 * with the EventBus events in app/src/main/kotlin/com/ark/llama/event.
 * No other modules are included.
 */
include(":app")

/**
 * Root project name.
 *
 * Appears in build outputs and task names. Matches the package
 * identifier (com.ark.llama) and the version label in the README.
 */
rootProject.name = "LlamaMusicPlayer"