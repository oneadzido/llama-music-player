# Llama Music Player v1.2.7

**Release date:** Oct 9, 2026

## Overview

Two changes ship in this release — removing a folder no longer wipes
the playlist, and the reveal becomes a one-way fade-in.

The songs table holds song paths. The selected-folder set holds
folder URIs. The folder-update cycle's completion callback passed the
folder URIs to a deletion that reconciles against song paths, so no
row's path ever matched a keep entry and every row was removed. The
completion callback no longer deletes songs; the scan that runs
inside the update cycle is the single reconciler of the songs table,
and it operates on song paths, which are the values the table stores.

The reveal — the animation the carousel runs when the incoming
current path is neither of the previous window's neighbours — no
longer animates the outgoing art. The outgoing art leaves the
viewport in the same frame the incoming art begins to appear, and
the incoming art fades into the viewport alone on the same curve
the commit slide uses, over the same duration.

## Fixed

- **Removing a folder no longer wipes the playlist** — The songs
  table holds song paths. The selected-folder set holds folder URIs.
  The folder-update cycle's completion callback passed the folder
  URIs to a deletion that reconciles against song paths, so no row's
  path ever matched a keep entry and every row was removed. The
  callback fired only when the user had staged the Loose Tracks
  entry for removal — the loose clear runs in the same branch — but
  the deletion inside it targeted the songs table, not the loose
  table, so removing any folder under that combination wiped the
  library.

  The completion callback no longer deletes songs. The scan that
  runs inside the folder-update cycle already reconciles the songs
  table against the paths it found under the kept folders. When the
  user has staged the Loose Tracks entry for removal, the
  loose-songs table is cleared before the scan runs, so the scan's
  reconciliation leaves the songs table holding exactly the songs
  under the kept folders.

  Removing a folder now removes the songs under that folder and
  leaves every other folder's songs and every loose track alone.
  Removing the Loose Tracks entry removes the loose tracks and
  leaves folder songs alone.

## Changed

- **The reveal is a one-way fade-in** — Previously the reveal was a
  staggered cross-fade: the outgoing art faded to zero on the
  emphasized accelerate curve over the first portion of the
  duration, and the incoming art faded in on the emphasized
  decelerate curve over the rest, with a small overlap in the
  middle to guarantee the viewport was never fully transparent.

  The outgoing art no longer has an exit. Its identity is a fact the
  user already knows; the incoming identity is the fact that needs
  to arrive. The incoming art now carries the whole transition on
  its own: it fades from zero to full opacity over 500 ms on the
  emphasized decelerate curve, with the same subtle scale-up the
  cross-fade's incoming leg used. The outgoing art's removal and the
  incoming art's appearance happen in the same frame, so the
  viewport never goes to zero total opacity and no blank frame is
  produced.

## Under the Hood

- `FolderManager.performPlaylistUpdate()`'s completion callback no
  longer clears the loose-songs table and no longer calls
  `SongDatabase.deleteSongsNotInSet` with the selected-folder set.
  The loose-songs table is cleared once, in `saveChanges`, before
  the update is dispatched; the songs table is reconciled once, by
  `PlaylistManager.performScan`, against the song paths the scan
  found under the kept folders.

- `AlbumArtCarousel`'s reveal no longer animates the strip's alpha.
  The outgoing art is taken out of the viewport by setting the
  strip's alpha to `0f` in the same turn the incoming overlay is
  added, and the strip's alpha is restored on the fade's end frame
  before the overlay is removed.

- `AlbumArtCarousel.REVEAL_OUTGOING_FRACTION` and
  `AlbumArtCarousel.REVEAL_OVERLAP_FRACTION` are removed.
  `REVEAL_DURATION_MS` remains at 500 ms, and
  `REVEAL_INCOMING_START_SCALE` remains at `0.97f`.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button on the main screen
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |
| Previous / next song | Swipe left or right across the album art, or tap the transport buttons |
| Playlist fast-scroll | Drag vertically along the left or right edge of the playlist |
| Sort mode | Tap SORT in the playlist header |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana