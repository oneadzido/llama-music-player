# Llama Music Player v1.2.0

**Release date:** Sep 30, 2026

## Overview
Two new interaction features, a split-screen layout, a redesigned
loading indicator, and a set of correctness improvements underneath
them.

## What's New

- **Volume-aware playback** — Reaching volume 0 pauses playback.
  Raising the volume above 0 resumes it. A pause you made yourself,
  or one caused by a Bluetooth disconnect or an audio-focus loss, is
  never undone by raising the volume.
- **Album-art volume gesture** — Swipe up or down along the left or
  right edge of the album art to change the volume. A short toast
  shows the current level as a percentage.
- **Split-screen layout** — The album art resizes with the window.
  At full height it is shown at 300dp. In a tall split window it
  shrinks to 180dp and the volume gesture remains available. In a
  short split window the art hides so the title, artist, progress
  bar, timer, and controls take the space.
- **Redesigned loading indicator** — A rotating ring with a bright
  arc travelling around a dim track, in place of the previous static
  circle. The arc's position is legible on every frame, so the
  indicator reads as moving regardless of how long the underlying
  work takes.

## Media carousel

The notification and the system media controls follow every playback
transition, including rapid skip-forward and skip-back from the
carousel itself. The metadata is delivered to the notification and
the media session as it arrives, with the themed placeholder as the
large icon while a song's album art is still decoding, and with the
real bitmap once the decode resolves. The playback state is written
on every awareness tick, so a state change the carousel missed on
one tick is retried on the next.

## Playback restoration

The last song and its playback position restore reliably on every
cold start, including after a force-kill or an OS-initiated process
teardown. The position is checkpointed on a fixed interval while
music is playing, alongside the existing saves at play, pause, and
seek. A force-kill loses at most five seconds of listening position
instead of the whole song.

## Folder import

Importing a folder after a library wipe prepares the first song
paused. The service has no prior playback signal to honour on a cold
start, so it waits for you to press play rather than starting
playback on its own. Restoring a session after a restart is
unaffected: if you were playing when the process went away,
playback resumes at the saved position.

## Loading overlay

Cold start and the post-scan playlist rebuild both show the same
dim-and-spinner overlay. The playlist rebuild previously used a
background notification as its loading indicator; it now uses the
in-app overlay, so the transition from folder scan to genre loading
stays inside the app's own surface.

## Under the Hood

- `LoadingOverlay` — a reason-keyed dim-and-spinner overlay, one
  instance per activity. The spinner is a private view with a
  lifecycle-bound rotation animator, started on attach and cancelled
  on detach. The overlay is visible while at least one reason token
  is held, so two independent callers can show and hide the overlay
  without interfering with each other.
- `MusicService` monitors the music stream through a content
  observer registered on the music-volume URI. The volume-zero marker
  is set only when the observer itself paused or deferred a pause;
  every other pause path clears it. Only a pause with the marker set
  is undone by raising the volume.
- `MusicService` checkpoints the persisted position on a fixed
  interval inside the existing health monitor, and on
  `onTrimMemory`. The state-change saves remain in place for pause,
  seek, and stop.
- `MusicService.setPlaylist` prepares the anchor paused on every
  cold start. The rule applies whether the anchor came from a
  persisted last-song path or from the fallback to index zero on an
  empty playlist history.
- `MusicService.mStateSource.snapshotForNotification` reports the
  target song's identity during `PREPARING`, so the notification and
  the media carousel advance with the user's tap rather than waiting
  for the transition to complete.
- `NotificationController.applySnapshot` commits a song's identity as
  it arrives, with the themed placeholder as the large icon when art
  has not yet resolved and the real bitmap when it has.
- `MusicPlayer.onConfigurationChanged` reapplies the split-screen
  layout when the window is resized. The album-art size and
  visibility are a pure function of `Configuration.screenHeightDp`.
- `MusicPlayer.proceedWithInitialization` is linear: preload the
  previous song for display, then start and bind the service. The
  activity's preload paints the title, artist, and art while the
  playlist loads, and does not decide whether anything is restored.
- `MusicPlayer`'s album-art container owns the volume gesture.
  A touch that starts in the left or right 20% of the container
  begins the gesture; a touch that starts anywhere else returns
  `false` from the listener and reaches whatever sits behind the
  album art.

---

## System Requirements

- **Minimum SDK:** Android 6.0 (API 23)
- **Target SDK:** Android 15 (API 35)
- **Recommended RAM:** 1 GB or higher

---

## Download

Download the APK from the Assets section of this release.

---

## Installation

1. Download the APK file
2. Enable "Unknown Sources" in your device settings
3. Open the APK file and tap "Install"

---

## First Time Setup

1. Tap the MANAGER button in the top right corner
2. Tap IMPORT FOLDER to select your music folder
3. Tap UPDATE to save your selection
4. The app will scan your folder and build the playlist

---

## How to Use

| Feature | How to Access |
|---------|---------------|
| Equalizer | Tap EQUALIZER button on main screen |
| Metadata Editor | Tap METADATA button on main screen |
| Folder Manager | Tap MANAGER button on main screen |
| Playlist | Tap PLAYLIST button on main screen |
| Themes | Tap LLAMA button on main screen, then THEMES |
| Volume gesture | Swipe up or down along the album-art edge |

---

## Credits

- jaudiotagger by jthink Ltd
- FontAwesome by Fonticons, Inc.

---

## License

Licensed under the MIT License

Copyright (c) 2026 Richard Korbla Adzido

Made with love in Ghana