# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app. The configuration follows a
# balanced approach focused on performance while maintaining debuggability.
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keep readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to SoundTouch compatibility (preserve native methods)
# - YES to AudioDecoder (preserve MediaCodec decoding)
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# CRITICAL: Disable Obfuscation
# ============================================================================
-dontobfuscate
-dontusemixedcaseclassnames
-keepattributes SourceFile,LineNumberTable

# ============================================================================
# Keep Native Methods (SoundTouch JNI)
# ============================================================================
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
-keep class com.ark.llama.SoundTouch { *; }

# ============================================================================
# Keep all app classes (including SoundTouchPlayer and AudioDecoder)
# ============================================================================
-keep class com.ark.llama.** { *; }

# ============================================================================
# PlaybackController - NEW: Centralized playback state manager
# ============================================================================
-keep class com.ark.llama.PlaybackController { *; }
-keep class com.ark.llama.PlaybackController$* { *; }
-keep interface com.ark.llama.PlaybackController$PlaybackControllerListener { *; }

# ============================================================================
# AudioDecoder - Keep MediaCodec/MediaExtractor related classes
# ============================================================================
-keep class com.ark.llama.AudioDecoder { *; }
-keep class com.ark.llama.AudioDecoder$* { *; }

# Keep MediaCodec and MediaExtractor (used by AudioDecoder)
-keep class android.media.MediaCodec { *; }
-keep class android.media.MediaExtractor { *; }
-keep class android.media.MediaFormat { *; }
-keep class android.media.MediaCodec$BufferInfo { *; }

# Keep ByteBuffer (used for audio processing)
-keep class java.nio.ByteBuffer { *; }

# Don't warn about MediaCodec native methods
-dontwarn android.media.MediaCodec
-dontwarn android.media.MediaExtractor

# ============================================================================
# Keep Android Components
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization (Song class saved to SharedPreferences)
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Keep Enums
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Reflection Targets (ThemeHelper, cursor color)
# ============================================================================
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep all adapters, dialogs, receivers
# ============================================================================
-keep class com.ark.llama.*Adapter { *; }
-keep class com.ark.llama.*Adapter$* { *; }
-keep class com.ark.llama.*Dialog { *; }
-keep class com.ark.llama.*Dialog$* { *; }
-keep class com.ark.llama.*Receiver { *; }
-keep class com.ark.llama.*Receiver$* { *; }

# ============================================================================
# Keep managers and services
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Third-party Libraries (jaudiotagger, AndroidX, Android framework)
# ============================================================================
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class android.media.** { *; }
-dontwarn android.media.**
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Performance: Remove verbose logging in release
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

# ============================================================================
# Keep annotations
# ============================================================================
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# ============================================================================
# Keep application entry point
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Additional performance optimizations
# ============================================================================
-repackageclasses ''
-allowaccessmodification