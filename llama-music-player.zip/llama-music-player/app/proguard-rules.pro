# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keep readable stack traces)
# - YES to resource shrinking (smaller APK)
# - YES to ExoPlayer/SoundTouch compatibility
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations (Keep these!)
# ============================================================================

# Aggressive optimization passes for maximum performance
-optimizationpasses 5

# Allow method inlining (improves CPU performance)
-allowaccessmodification

# Merge classes and methods where safe (reduces DEX size, improves startup)
-repackageclasses ''

# Keep line numbers for crash reporting (critical for debugging)
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep other important attributes
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# CRITICAL: Disable obfuscation (keeps stack traces readable)
# ============================================================================
-dontobfuscate
-dontusemixedcaseclassnames

# Keep package names (helps with debugging)
-keepattributes SourceFile,LineNumberTable

# ============================================================================
# Keep Native Methods (SoundTouch JNI) - Required
# ============================================================================
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

-keep class com.ark.llama.PitchShifter { *; }

# ============================================================================
# ExoPlayer / Media3 - Keep all classes (required for playback)
# ============================================================================
-keep class androidx.media3.** { *; }
-keep interface androidx.media3.** { *; }
-dontwarn androidx.media3.**

# ============================================================================
# Keep our custom SoundTouchAudio processor
# ============================================================================
-keep class com.ark.llama.SoundTouchAudio { *; }
-keep class com.ark.llama.AudioProcessor { *; }

# Keep AudioProcessor interface methods (ExoPlayer calls these via reflection)
-keepclassmembers class androidx.media3.exoplayer.audio.AudioProcessor {
    public *** configure(...);
    public *** queueInput(...);
    public *** getOutput(...);
    public *** isActive(...);
    public *** isEnded(...);
    public *** queueEndOfStream(...);
    public *** flush(...);
    public *** reset(...);
}

# ============================================================================
# Keep all app classes (no obfuscation = clear stack traces)
# ============================================================================
-keep class com.ark.llama.** { *; }

# ============================================================================
# Keep Android Components
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View

# ============================================================================
# Keep Custom View Constructors (required for XML inflation)
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization (Song class saved to SharedPreferences)
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

-keep class com.ark.llama.Song { *; }

# ============================================================================
# Keep Enums (values() method used by Android framework)
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable (used for cross-process communication)
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Reflection Targets (ThemeHelper uses reflection for cursor color)
# ============================================================================
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep all adapters, dialogs, receivers (used by framework)
# ============================================================================
-keep class com.ark.llama.*Adapter { *; }
-keep class com.ark.llama.*Adapter$* { *; }
-keep class com.ark.llama.*Dialog { *; }
-keep class com.ark.llama.*Receiver { *; }
-keep class com.ark.llama.*Receiver$* { *; }

# ============================================================================
# Keep managers and services
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep ExoPlayer builder classes (used for initialization)
# ============================================================================
-keep class androidx.media3.exoplayer.ExoPlayer$Builder { *; }
-keep class androidx.media3.exoplayer.audio.DefaultAudioSink$Builder { *; }
-keep class androidx.media3.exoplayer.trackselection.DefaultTrackSelector$Builder { *; }
-keep class androidx.media3.datasource.DefaultDataSource$Factory { *; }
-keep class androidx.media3.exoplayer.source.ProgressiveMediaSource$Factory { *; }

# ============================================================================
# Third-party Libraries
# ============================================================================

# Jaudiotagger - uses reflection for ID3 tag parsing
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# AndroidX - keep everything
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Android Media framework
-keep class android.media.** { *; }
-dontwarn android.media.**

# Suppress Kotlin warnings (ExoPlayer may use Kotlin transitively)
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Performance: Remove verbose logging in release (speeds up execution)
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

# Keep warnings and errors for crash reporting
# -assumenosideeffects class android.util.Log {
#     public static *** w(...);
#     public static *** e(...);
#     public static *** i(...);
# }

# ============================================================================
# Keep annotations
# ============================================================================
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# ============================================================================
# Keep application entry point
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Additional performance: Flatten package hierarchy
# ============================================================================
-repackageclasses ''
-allowaccessmodification