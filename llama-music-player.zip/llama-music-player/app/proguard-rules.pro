# ============================================================================
# Llama Music Player - Release Build Rules (Keep All Classes + Obfuscate)
# ============================================================================
# 
# These ProGuard rules are designed for a release build where we want to:
# - Keep EVERY class in com.ark.llama (no shrinking)
# - Allow full obfuscation (rename classes, methods, fields)
# - Protect Android component names, native methods, serialization, and reflection
# - Remove all Log.d/v/i/w/e calls for performance
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Keep all classes from our package, but allow obfuscation (renaming)
# ============================================================================
-keep,allowobfuscation class com.ark.llama.** { *; }

# ============================================================================
# Native Methods - must keep exact names for JNI
# ============================================================================
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# ============================================================================
# Serialization - keep for Song class and any Serializable objects
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Annotations and Attributes - keep for libraries that use reflection
# ============================================================================
-keepattributes *Annotation*,Signature,SourceFile,LineNumberTable,Exceptions,InnerClasses,EnclosingMethod

# ============================================================================
# Android Framework Components - must keep exact names for system to find them
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.os.AsyncTask

# ============================================================================
# Custom View Constructors - required for XML inflation
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Enums - keep their static methods
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Parcelable - keep creator field
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Reflection Targets - classes accessed via reflection (ThemeHelper cursor)
# ============================================================================
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }

# ============================================================================
# Third-party Libraries - keep them entirely (no shrinking/obfuscation)
# ============================================================================

# Jaudiotagger - audio metadata library
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# AndroidX libraries
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Android Media framework
-keep class android.media.** { *; }
-dontwarn android.media.**

# ============================================================================
# Remove Logging Calls - improves performance in release builds
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ============================================================================
# Optimization Flags - allow full optimization and obfuscation
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-renamesourcefileattribute SourceFile