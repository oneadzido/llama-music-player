# ============================================================================
# Llama Music Player - Open Source Build ProGuard Rules
# ============================================================================
# 
# These rules ensure NO code is lost during shrinking while maintaining
# readable stack traces for crash reporting. The configuration follows
# a balanced approach focused on performance while maintaining debuggability.
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keep readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to SoundTouch compatibility (preserve native methods)
# - YES to AudioDecoder (preserve MediaCodec decoding)
# - YES to DecoderManager (preserve prefill callbacks)
# - YES to PlaybackController (preserve state management)
# - YES to AudioPlayerBridge (preserve dual-player architecture)
# - YES to DisplayManager (preserve UI display components)
# - YES to NavigationController (preserve button state management)
# - YES to MetadataEditor (preserve ID3 tag editing)
# 
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ----------------------------------------------------------------------------
# Optimization Settings
# ----------------------------------------------------------------------------
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-dontobfuscate
-dontusemixedcaseclassnames
-verbose

# Keep important attributes for debugging
-keepattributes SourceFile,LineNumberTable
-keepattributes Exceptions,Signature,Deprecated
-keepattributes EnclosingMethod,InnerClasses,*Annotation*

# ----------------------------------------------------------------------------
# Keep All App Classes - Primary Safety Net
# ----------------------------------------------------------------------------
-keep class com.ark.llama.** { *; }
-keep interface com.ark.llama.** { *; }
-keep enum com.ark.llama.** { *; }

# ----------------------------------------------------------------------------
# Native Methods (SoundTouch JNI)
# ----------------------------------------------------------------------------
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# SoundTouch - Complete native wrapper preservation
-keep class com.ark.llama.SoundTouch { *; }
-keepclassmembers class com.ark.llama.SoundTouch {
    private native <methods>;
    public <init>(int, int);
    public void close();
    public void release();
    public void setPitch(float);
    public void setTempo(float);
    public void putFrames(short[], int);
    public int receiveFrames(short[], int);
}

# ----------------------------------------------------------------------------
# Audio Player Architecture (Dual-Player System)
# ----------------------------------------------------------------------------
# AudioPlayerBridge - Orchestrates NativeMediaPlayer and LlamaPlayer with seamless transition
-keep class com.ark.llama.AudioPlayerBridge { *; }
-keep class com.ark.llama.AudioPlayerBridge$* { *; }
-keep interface com.ark.llama.AudioPlayerBridge$AudioPlayerListener { *; }
-keep enum com.ark.llama.AudioPlayerBridge$ActivePlayer { *; }

# LlamaPlayer - Enhanced player with SoundTouch pitch/tempo control
-keep class com.ark.llama.LlamaPlayer { *; }
-keep class com.ark.llama.LlamaPlayer$* { *; }
-keep interface com.ark.llama.LlamaPlayer$PlaybackListener { *; }
-keep enum com.ark.llama.LlamaPlayer$State { *; }

# NativeMediaPlayer - Fallback player using Android's native MediaPlayer
-keep class com.ark.llama.NativeMediaPlayer { *; }
-keep class com.ark.llama.NativeMediaPlayer$* { *; }
-keep interface com.ark.llama.NativeMediaPlayer$Listener { *; }
-keep enum com.ark.llama.NativeMediaPlayer$State { *; }

# ----------------------------------------------------------------------------
# Decoder Components (Audio Decoding Pipeline)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.AudioDecoder { *; }
-keep class com.ark.llama.AudioDecoder$* { *; }
-keep class com.ark.llama.DecoderManager { *; }
-keep class com.ark.llama.DecoderManager$* { *; }
-keep interface com.ark.llama.DecoderManager$PrefillCallback { *; }

# Keep MediaCodec and MediaExtractor (used by AudioDecoder)
-keep class android.media.MediaCodec { *; }
-keep class android.media.MediaExtractor { *; }
-keep class android.media.MediaFormat { *; }
-keep class android.media.MediaCodec$BufferInfo { *; }

# Keep ByteBuffer (used for audio processing)
-keep class java.nio.ByteBuffer { *; }

# Don't warn about MediaCodec native methods
-dontwarn android.media.MediaCodec
-dontwarn android.media.MediaExtractor

# ----------------------------------------------------------------------------
# Playback State Management (Single Source of Truth)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.PlaybackController { *; }
-keep class com.ark.llama.PlaybackController$* { *; }
-keep interface com.ark.llama.PlaybackController$PlaybackControllerListener { *; }

# Keep atomic state variables (used via reflection? no, but safe to keep)
-keep class com.ark.llama.PlaybackController$State { *; }

# ----------------------------------------------------------------------------
# Services (Background Operations)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.MusicService$* { *; }
-keep class com.ark.llama.MusicService$LocalBinder { *; }

-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.NotificationService$* { *; }

-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.PlaylistService$* { *; }
-keep interface com.ark.llama.PlaylistService$UpdateCallback { *; }

# ----------------------------------------------------------------------------
# Navigation Controller (Global Button State Management)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }
-keep interface com.ark.llama.NavigationController$ButtonStateListener { *; }
-keep enum com.ark.llama.NavigationController$ButtonGroup { *; }
-keep enum com.ark.llama.NavigationController$Operation { *; }

# ----------------------------------------------------------------------------
# UI Components (Display Management)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.DisplayManager { *; }
-keep class com.ark.llama.DisplayManager$* { *; }
-keep interface com.ark.llama.DisplayManager$DisplayListener { *; }

-keep class com.ark.llama.MusicPlayer { *; }

-keep class com.ark.llama.PlaylistActivity { *; }
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep interface com.ark.llama.PlaylistAdapter$OnSongClickListener { *; }

-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.FolderAdapter { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }
-keep interface com.ark.llama.FolderAdapter$OnFolderRemoveListener { *; }

# ----------------------------------------------------------------------------
# Equalizer Components (Audio Effects)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.EqualizerActivity { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.EqualizerManager$* { *; }
-keep interface com.ark.llama.EqualizerManager$EqualizerListener { *; }

-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.PresetDialog$* { *; }
-keep interface com.ark.llama.PresetDialog$OnPresetSelectedListener { *; }

# ----------------------------------------------------------------------------
# Metadata Editor Components (ID3 Tag Editing)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.MetadataEditor { *; }
-keep class com.ark.llama.MetadataEditor$* { *; }

-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataReader$MetadataBundle { *; }

-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.MetadataWriter$* { *; }

# ----------------------------------------------------------------------------
# Theme Components (Dynamic Theme Management)
# ----------------------------------------------------------------------------
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }

-keep class com.ark.llama.ThemeDialog { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }
-keep interface com.ark.llama.ThemeDialog$OnThemeSelectedListener { *; }

-keep class com.ark.llama.CreditsDialog { *; }

# Keep reflection targets (ThemeHelper, cursor color)
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }

# ----------------------------------------------------------------------------
# Utility Classes
# ----------------------------------------------------------------------------
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.CharacterMapper$* { *; }

-keep class com.ark.llama.FontAwesome { *; }

-keep class com.ark.llama.Song { *; }
-keep class com.ark.llama.SongDatabase { *; }

-keep class com.ark.llama.MusicLibrary { *; }

-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }

-keep class com.ark.llama.ToastManager { *; }

-keep class com.ark.llama.BluetoothReceiver { *; }

# ----------------------------------------------------------------------------
# Android Framework Classes (Used by the app)
# ----------------------------------------------------------------------------
# Audio framework
-keep class android.media.AudioTrack { *; }
-keep class android.media.AudioAttributes { *; }
-keep class android.media.AudioFormat { *; }
-keep class android.media.AudioManager { *; }
-keep class android.media.AudioFocusRequest { *; }

# Media framework
-keep class android.media.session.MediaSession { *; }
-keep class android.media.session.PlaybackState { *; }
-keep class android.media.MediaMetadata { *; }
-keep class android.media.MediaPlayer { *; }
-keep class android.media.MediaPlayer$* { *; }
-keep class android.media.MediaMetadataRetriever { *; }

# Content framework
-keep class android.content.ContentResolver { *; }
-keep class android.database.Cursor { *; }
-keep class android.database.ContentObserver { *; }
-keep class android.provider.MediaStore { *; }
-keep class android.provider.MediaStore$Audio$Media { *; }
-keep class android.provider.MediaStore$Files { *; }
-keep class androidx.documentfile.provider.DocumentFile { *; }

# SharedPreferences
-keep class android.content.SharedPreferences { *; }
-keep class android.content.SharedPreferences$Editor { *; }

# Intent and KeyEvent
-keep class android.content.Intent { *; }
-keep class android.content.IntentFilter { *; }
-keep class android.view.KeyEvent { *; }

# Power management (wake lock)
-keep class android.os.PowerManager { *; }
-keep class android.os.PowerManager$WakeLock { *; }

# Notification framework
-keep class android.app.Notification { *; }
-keep class android.app.Notification$Builder { *; }
-keep class android.app.NotificationChannel { *; }
-keep class android.app.NotificationManager { *; }
-keep class android.app.PendingIntent { *; }

# URI and graphics
-keep class android.net.Uri { *; }
-keep class android.graphics.Paint { *; }
-keep class android.graphics.Canvas { *; }
-keep class android.graphics.Bitmap { *; }
-keep class android.graphics.BitmapFactory { *; }
-keep class android.graphics.drawable.Drawable { *; }
-keep class android.graphics.drawable.GradientDrawable { *; }
-keep class android.graphics.drawable.InsetDrawable { *; }
-keep class android.graphics.drawable.StateListDrawable { *; }
-keep class android.graphics.PorterDuff { *; }
-keep class android.graphics.PorterDuffColorFilter { *; }
-keep class android.graphics.Typeface { *; }

# Animation framework
-keep class android.view.animation.Animation { *; }
-keep class android.view.animation.AnimationUtils { *; }
-keep class android.view.animation.AlphaAnimation { *; }
-keep class android.view.ViewPropertyAnimator { *; }

# Input method framework
-keep class android.view.inputmethod.InputMethodManager { *; }

# Display metrics
-keep class android.util.DisplayMetrics { *; }
-keep class android.content.res.ColorStateList { *; }

# ----------------------------------------------------------------------------
# Threading and Concurrency (Used by LlamaPlayer, DecoderManager, etc.)
# ----------------------------------------------------------------------------
-keep class java.util.concurrent.atomic.AtomicBoolean { *; }
-keep class java.util.concurrent.atomic.AtomicInteger { *; }
-keep class java.util.concurrent.atomic.AtomicLong { *; }
-keep class java.util.concurrent.atomic.AtomicReference { *; }
-keep class android.os.Handler { *; }
-keep class android.os.Looper { *; }

# ----------------------------------------------------------------------------
# Custom View Constructors
# ----------------------------------------------------------------------------
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ----------------------------------------------------------------------------
# Android Components
# ----------------------------------------------------------------------------
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog

# ----------------------------------------------------------------------------
# Serialization Support (Song class saved to SharedPreferences)
# ----------------------------------------------------------------------------
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ----------------------------------------------------------------------------
# Enums and Parcelable
# ----------------------------------------------------------------------------
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ----------------------------------------------------------------------------
# Third-Party Libraries
# ----------------------------------------------------------------------------
# jaudiotagger - ID3 tag library for metadata reading/writing
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# AndroidX
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Kotlin (if used)
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ----------------------------------------------------------------------------
# Keep All Callback Interfaces
# ----------------------------------------------------------------------------
-keep interface com.ark.llama.**$*Callback { *; }
-keep interface com.ark.llama.**$*Listener { *; }

# ----------------------------------------------------------------------------
# Keep All Inner Classes and Their Constructors
# ----------------------------------------------------------------------------
-keep class **.*$* {
    *;
}

# ----------------------------------------------------------------------------
# Keep All Resource IDs (used for R.anim, R.drawable, etc.)
# ----------------------------------------------------------------------------
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ----------------------------------------------------------------------------
# Optimization: Remove Logging in Release Builds
# ----------------------------------------------------------------------------
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ----------------------------------------------------------------------------
# Final Safety Net - Keep absolutely everything
# ----------------------------------------------------------------------------
-keep class com.ark.llama.** {
    *;
}
-keepclassmembers class com.ark.llama.** {
    *;
}