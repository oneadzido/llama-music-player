# ============================================================================
# Llama Music Player - Release Build Rules (Optimized)
# ============================================================================
# 
# These rules balance performance optimization with crash prevention.
# - Enables code shrinking and obfuscation for smaller DEX size
# - Removes unused resources via shrinkResources true in build.gradle
# - Standard R8 optimizations (Full Mode not required for this app)
# - Preserves all reflection/JNI/Serialization targets
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Optimization Flags
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-renamesourcefileattribute SourceFile

# ============================================================================
# Keep Android Components (must keep exact names)
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View
-keep public class * extends android.os.AsyncTask

# ============================================================================
# Keep Custom View Constructors (required for XML inflation)
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Native Methods - CRITICAL: must keep exact names for JNI
# ============================================================================
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# Keep SoundTouchPlayer and related JNI classes
-keep class com.ark.llama.PitchShifter { *; }
-keep class com.ark.llama.SoundTouchPlayer { *; }

# ============================================================================
# Serialization - Keep for Song class (saved to SharedPreferences)
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Keep Song class (critical for state persistence)
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Enums - Keep their static methods
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Parcelable - Keep creator field
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Reflection Targets - Used by ThemeHelper
# ============================================================================
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }

# Keep ThemeHelper (uses reflection for cursor color)
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep all classes from our package to prevent reflection crashes
# Unlike the original that used -keep,allowobfuscation, we keep everything
# but still allow some optimization. This is safer for reflection-heavy code.
# ============================================================================
-keep class com.ark.llama.** { *; }

# ============================================================================
# Keep annotations (used by some libraries)
# ============================================================================
-keepattributes *Annotation*,Signature,SourceFile,LineNumberTable,Exceptions,InnerClasses,EnclosingMethod

# ============================================================================
# Keep Inner Classes (used extensively in adapters and receivers)
# ============================================================================
-keepattributes InnerClasses

# ============================================================================
# Keep all BroadcastReceiver inner classes
# ============================================================================
-keep class com.ark.llama.*Receiver { *; }
-keep class com.ark.llama.*Receiver$* { *; }

# ============================================================================
# Keep all adapters (used by RecyclerView)
# ============================================================================
-keep class com.ark.llama.*Adapter { *; }
-keep class com.ark.llama.*Adapter$* { *; }

# ============================================================================
# Keep all dialogs (used by CreditsDialog, PresetDialog, ThemeDialog)
# ============================================================================
-keep class com.ark.llama.*Dialog { *; }

# ============================================================================
# Keep database helper (SQLiteOpenHelper)
# ============================================================================
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep managers and services
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.ToastManager { *; }

# ============================================================================
# Third-party Libraries
# ============================================================================

# Jaudiotagger - uses reflection extensively for ID3 tag parsing
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# AndroidX libraries - keep all
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Android Media framework
-keep class android.media.** { *; }
-dontwarn android.media.**

# ============================================================================
# Remove Logging Calls - improves performance
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ============================================================================
# Keep application entry point (required)
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }