# ============================================================================
# Llama Music Player - ProGuard Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app.
# 
# <p>The configuration follows a balanced approach focused on performance
# while maintaining debuggability:</p>
# <ul>
#   <li>Performance optimizations enabled (inlining, dead code removal)</li>
#   <li>Obfuscation disabled (keeps readable stack traces for crash reporting)</li>
#   <li>Resource shrinking enabled (smaller APK size)</li>
#   <li>SoundTouch native methods preserved</li>
#   <li>AudioDecoder MediaCodec classes preserved</li>
# </ul>
# 
# File Location: /app/proguard-rules.pro
# 
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
# Number of optimization passes to perform (higher = more optimization)
-optimizationpasses 5

# Allow classes to be repackaged into a single package
-allowaccessmodification

# Repackage all classes into the root package
-repackageclasses ''

# Keep source file and line number attributes for stack traces
-keepattributes SourceFile,LineNumberTable

# Rename source file attribute to hide internal file names
-renamesourcefileattribute SourceFile

# Keep additional attributes needed for reflection and debugging
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# Obfuscation Control
# ============================================================================
# Completely disable obfuscation to keep readable class names and stack traces
-dontobfuscate

# Keep class names in original case (don't convert to mixed case)
-dontusemixedcaseclassnames

# Keep source file and line number attributes for crash reporting
-keepattributes SourceFile,LineNumberTable

# ============================================================================
# Native Method Preservation (SoundTouch JNI)
# ============================================================================
# Keep all native methods - ProGuard must not rename or remove them
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# Keep the official SoundTouch class and all its methods
-keep class net.surina.soundtouch.SoundTouch { *; }

# ============================================================================
# Application Class Preservation
# ============================================================================
# Keep all classes in the com.ark.llama package and their members
-keep class com.ark.llama.** { *; }

# ============================================================================
# AudioDecoder Preservation
# ============================================================================
# Keep AudioDecoder class and its inner classes
-keep class com.ark.llama.AudioDecoder { *; }
-keep class com.ark.llama.AudioDecoder$* { *; }

# Keep MediaCodec and MediaExtractor classes (used by AudioDecoder)
-keep class android.media.MediaCodec { *; }
-keep class android.media.MediaExtractor { *; }
-keep class android.media.MediaFormat { *; }
-keep class android.media.MediaCodec$BufferInfo { *; }

# Keep ByteBuffer for audio processing
-keep class java.nio.ByteBuffer { *; }

# Suppress warnings about MediaCodec native methods (these are provided by Android)
-dontwarn android.media.MediaCodec
-dontwarn android.media.MediaExtractor

# ============================================================================
# Android Component Preservation
# ============================================================================
# Keep all Activity subclasses
-keep public class * extends android.app.Activity

# Keep all Service subclasses
-keep public class * extends android.app.Service

# Keep all BroadcastReceiver subclasses
-keep public class * extends android.content.BroadcastReceiver

# Keep all Dialog subclasses
-keep public class * extends android.app.Dialog

# Keep all View subclasses
-keep public class * extends android.view.View

# ============================================================================
# Custom View Constructor Preservation
# ============================================================================
# Keep View constructors for inflation from XML layouts
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Serializable Class Preservation
# ============================================================================
# Keep serialization-related members for Serializable classes
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Keep the Song class (saved to SharedPreferences)
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Enum Preservation
# ============================================================================
# Keep enum values() and valueOf() methods
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Parcelable Preservation
# ============================================================================
# Keep Parcelable CREATOR field
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Reflection Target Preservation
# ============================================================================
# Keep TextView and Editor for cursor color reflection (ThemeHelper)
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }

# Keep ThemeHelper for reflection access
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Adapter, Dialog, and Receiver Preservation
# ============================================================================
# Keep all Adapter classes and their inner classes
-keep class com.ark.llama.*Adapter { *; }
-keep class com.ark.llama.*Adapter$* { *; }

# Keep all Dialog classes and their inner classes
-keep class com.ark.llama.*Dialog { *; }
-keep class com.ark.llama.*Dialog$* { *; }

# Keep all Receiver classes and their inner classes
-keep class com.ark.llama.*Receiver { *; }
-keep class com.ark.llama.*Receiver$* { *; }

# ============================================================================
# Manager and Service Preservation
# ============================================================================
# Keep all manager and service classes
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Third-party Library Preservation
# ============================================================================
# Keep jaudiotagger library classes
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# Keep AndroidX library classes
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Keep Android media framework classes
-keep class android.media.** { *; }
-dontwarn android.media.**

# Suppress Kotlin warnings (not used in this app)
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Logging Removal (Release Build Only)
# ============================================================================
# Remove debug and verbose log calls from release builds for performance
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

# ============================================================================
# Annotation Preservation
# ============================================================================
# Keep all annotations for reflection access
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# ============================================================================
# Application Entry Point Preservation
# ============================================================================
# Keep the main MusicPlayer activity
-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Additional Optimizations
# ============================================================================
# Repackage all classes into the root package
-repackageclasses ''

# Allow access modification for better optimization
-allowaccessmodification