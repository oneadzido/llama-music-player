# ============================================================================
# Llama Music Player - Optimized Open Source Build Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Llama Music Player app. The configuration follows a
# balanced approach focused on performance while maintaining debuggability.
# 
# Balanced approach:
# - YES to performance optimizations (inlining, dead code removal)
# - NO to obfuscation (keep readable stack traces for crash reporting)
# - YES to resource shrinking (smaller APK size)
# - YES to Media3/SoundTouch compatibility (preserve reflection targets)
#
# File Location: /app/proguard-rules.pro
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
# These settings maximize runtime performance and reduce APK size while
# preserving the ability to debug crashes with meaningful stack traces.
# ============================================================================

# Aggressive optimization passes for maximum performance
# Specifies the number of times ProGuard will optimize the bytecode.
# Higher numbers may find more optimization opportunities but take longer.
# 5 passes provides a good balance between build time and optimization.
-optimizationpasses 5

# Allow method inlining and other access modifications
# This permits ProGuard to make methods package-private or private when safe,
# and to inline small methods directly into callers. This improves CPU
# performance by reducing method call overhead and enables more aggressive
# dead code removal.
-allowaccessmodification

# Merge classes and methods where safe
# Flattens the package hierarchy and merges classes when possible.
# This reduces the number of DEX files and classes, which improves:
# - APK size (fewer class overheads)
# - App startup time (faster class loading)
# - Runtime memory usage (fewer loaded classes)
-repackageclasses ''

# Keep line numbers for crash reporting
# Preserves source file names and line numbers in stack traces.
# Critical for debugging crashes reported by users through Google Play.
# Without these attributes, stack traces would only show obfuscated method names
# like "a.b.c" instead of meaningful class and line information.
-keepattributes SourceFile,LineNumberTable

# Replace source file attribute with "SourceFile"
# This reduces string constant pool size while still preserving the ability
# to map stack traces using the mapping file. The actual file name is not
# needed for debugging if we have the mapping file.
-renamesourcefileattribute SourceFile

# Keep other important attributes
# These attributes are required for proper runtime behavior of various
# Java and Android features.
# - Exceptions: Required for exception handling and stack traces
# - Signature: Required for generic type information (used by Gson, etc.)
# - Deprecated: Preserves @Deprecated annotation metadata
# - EnclosingMethod: Required for inner classes to access outer class methods
# - InnerClasses: Required for reflection on nested classes
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# CRITICAL: Disable Obfuscation
# ============================================================================
# Obfuscation is disabled to maintain readable stack traces for crash reporting.
# Since this is an open source app, obfuscation provides minimal security benefit
# while making debugging significantly harder. The performance benefits of
# obfuscation are minimal compared to the optimization settings above.
# ============================================================================

# Completely disable obfuscation
# Without this, class and method names would be renamed to short, meaningless
# strings like "a", "b", "c". This makes stack traces nearly impossible to
# understand without the mapping file, which users don't provide.
-dontobfuscate

# Do not use mixed case class names
# Even when obfuscation is enabled, this prevents generating class names that
# differ only by case (e.g., "a" and "A"), which can cause issues on
# case-insensitive file systems like Windows.
-dontusemixedcaseclassnames

# Keep package names for debugging
# Preserves original package names in stack traces, making them more readable.
-keepattributes SourceFile,LineNumberTable

# ============================================================================
# Keep Native Methods (SoundTouch JNI)
# ============================================================================
# The SoundTouch native library uses JNI (Java Native Interface) to call C++ code.
# ProGuard must preserve these method signatures exactly as they appear in the
# Java source code, otherwise the native library won't be able to find them.
# ============================================================================

# Keep all native method names and their signatures
# The "includedescriptorclasses" flag ensures that parameter and return types
# are also preserved. Native methods are called from C++ code by name and
# signature, so any renaming would cause UnsatisfiedLinkError at runtime.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# Keep the PitchShifter class entirely
# This class contains all JNI methods for SoundTouch. All methods, fields,
# and constructors must be preserved exactly as defined. The native C++ code
# depends on the exact class name, method names, and signatures.
-keep class com.ark.llama.PitchShifter { *; }

# ============================================================================
# Media3 / ExoPlayer - Keep all classes
# ============================================================================
# Media3 (formerly ExoPlayer) uses reflection internally to load components
# and to support different streaming protocols. ProGuard must preserve all
# Media3 classes and their interfaces to prevent runtime crashes.
# ============================================================================

# Keep all Media3 classes (concrete implementations)
# Media3 uses reflection to instantiate renderers, data sources, and other
# components based on media format. If these classes are removed or renamed,
# playback will fail with ClassNotFoundException.
-keep class androidx.media3.** { *; }

# Keep all Media3 interfaces
# Media3 uses interface-based programming and looks up implementations
# via service loaders and reflection. Interfaces must be preserved so that
# Media3 can find the implementing classes.
-keep interface androidx.media3.** { *; }

# Suppress warnings about Media3 classes
# Media3 uses Kotlin internally and may generate some warnings about
# missing classes or metadata. These warnings are safe to ignore.
-dontwarn androidx.media3.**

# ============================================================================
# Keep our custom SoundTouchAudio processor
# ============================================================================
# SoundTouchAudio is our custom AudioProcessor implementation that integrates
# the SoundTouch native library with Media3's audio pipeline. Media3 discovers
# and instantiates audio processors via reflection, so this class must be
# completely preserved.
# ============================================================================

# Keep the SoundTouchAudio class entirely
# This class implements the AudioProcessor interface and provides the bridge
# between Media3 and the SoundTouch native library. All methods, especially
# the AudioProcessor interface methods, must be preserved exactly.
-keep class com.ark.llama.SoundTouchAudio { *; }

# ============================================================================
# Keep all app classes
# ============================================================================
# Since obfuscation is disabled, we need to explicitly keep all app classes
# to prevent ProGuard from removing unused code. With -dontobfuscate, ProGuard
# still removes unused classes and methods. This rule ensures all app classes
# are retained even if ProGuard thinks they're unused.
# ============================================================================

# Keep all classes in the com.ark.llama package and subpackages
# This ensures all app code is preserved. Some classes may be loaded via
# reflection or have their methods called from native code or the framework.
-keep class com.ark.llama.** { *; }

# ============================================================================
# Keep Android Components
# ============================================================================
# Android framework components are instantiated by the system via reflection
# based on their declarations in AndroidManifest.xml. ProGuard must preserve
# these classes and their constructors.
# ============================================================================

# Keep all Activities
# Activities are declared in AndroidManifest.xml and instantiated by the
# Android system when launched. The system uses the class name as a string,
# so the class must exist with its original name.
-keep public class * extends android.app.Activity

# Keep all Services
# Services are declared in AndroidManifest.xml and started via intents.
# The system instantiates them by class name, so preservation is required.
-keep public class * extends android.app.Service

# Keep all BroadcastReceivers
# Broadcast receivers are declared in AndroidManifest.xml and registered
# either statically or dynamically. The system instantiates them by class name.
-keep public class * extends android.content.BroadcastReceiver

# Keep all Dialogs
# Dialogs may be shown via reflection or from XML layout files.
-keep public class * extends android.app.Dialog

# Keep all custom Views
# Custom views are referenced in XML layout files by their fully-qualified
# class name. The layout inflater uses reflection to instantiate them.
-keep public class * extends android.view.View

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
# When inflating custom views from XML, the Android framework looks for specific
# constructors based on the attributes provided. All three standard constructors
# must be preserved for proper XML inflation.
# ============================================================================

# Keep the three standard View constructors
# - Context only: Used when programmatically creating the view
# - Context + AttributeSet: Used when inflating from XML with attributes
# - Context + AttributeSet + int: Used for styleable attributes
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization (Song class saved to SharedPreferences)
# ============================================================================
# The Song class implements Serializable and is saved to SharedPreferences.
# ProGuard must preserve the serialization mechanism to prevent corruption
# of saved data when the app is updated.
# ============================================================================

# Keep serialization-related fields and methods
# Java serialization uses reflection to read and write objects. The
# serialVersionUID, serialPersistentFields, and special methods like
# writeObject/readObject must be preserved for correct serialization.
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Keep the Song class entirely
# The Song class is stored in SharedPreferences and may be serialized.
# All fields must be preserved to avoid data loss on app update.
-keep class com.ark.llama.Song { *; }

# ============================================================================
# Keep Enums
# ============================================================================
# Enums in Java have special methods like values() and valueOf() that are
# generated by the compiler. These methods are called by the framework and
# must be preserved.
# ============================================================================

# Keep enum methods
# The values() method is called to iterate over enum constants.
# The valueOf() method is called to convert strings back to enum constants.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Keep Parcelable
# ============================================================================
# Parcelable is used for cross-process communication (e.g., passing Song
# objects between activities via Intent extras). The CREATOR field is accessed
# via reflection by the Android framework.
# ============================================================================

# Keep the CREATOR field in Parcelable classes
# The framework uses reflection to find the CREATOR field and call its
# createFromParcel method. Without this, Parcelable objects cannot be
# deserialized from Intents.
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Reflection Targets
# ============================================================================
# Some parts of the app use reflection to access private framework APIs.
# These reflection targets must be preserved with their exact names.
# ============================================================================

# Keep TextView internals (used by ThemeHelper for cursor color)
# The ThemeHelper class uses reflection to change the cursor color in TextViews.
# This is not a public API but is necessary for theme customization.
-keep class android.widget.TextView { *; }
-keep class android.widget.Editor { *; }

# Keep ThemeHelper class
# This class contains reflection code that accesses framework internals.
-keep class com.ark.llama.ThemeHelper { *; }

# ============================================================================
# Keep all adapters, dialogs, receivers
# ============================================================================
# These classes are often referenced by name from XML layouts or registered
# dynamically. Preserving them prevents ClassNotFoundException at runtime.
# ============================================================================

# Keep all adapter classes and their inner classes
-keep class com.ark.llama.*Adapter { *; }
-keep class com.ark.llama.*Adapter$* { *; }

# Keep all dialog classes and their inner classes
-keep class com.ark.llama.*Dialog { *; }
-keep class com.ark.llama.*Dialog$* { *; }

# Keep all receiver classes and their inner classes
-keep class com.ark.llama.*Receiver { *; }
-keep class com.ark.llama.*Receiver$* { *; }

# ============================================================================
# Keep managers and services
# ============================================================================
# These classes are the core components of the app. Many are accessed via
# static methods or registered with the system.
# ============================================================================

-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.PlaylistService { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.SongDatabase { *; }

# ============================================================================
# Keep Media3 builder classes
# ============================================================================
# Media3 uses the builder pattern for constructing complex objects.
# These builder classes are accessed via the public API and must be preserved
# to allow proper initialization.
# ============================================================================

-keep class androidx.media3.exoplayer.ExoPlayer$Builder { *; }
-keep class androidx.media3.exoplayer.audio.DefaultAudioSink$Builder { *; }
-keep class androidx.media3.exoplayer.trackselection.DefaultTrackSelector$Builder { *; }
-keep class androidx.media3.datasource.DefaultDataSource$Factory { *; }
-keep class androidx.media3.exoplayer.source.ProgressiveMediaSource$Factory { *; }

# ============================================================================
# Third-party Libraries
# ============================================================================
# These libraries have their own reflection patterns that ProGuard must respect.
# ============================================================================

# Jaudiotagger - uses reflection for ID3 tag parsing
# This library uses reflection to instantiate tag readers and writers based on
# file type and tag format. All classes must be preserved.
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# AndroidX - keep everything
# AndroidX libraries use reflection internally and for compatibility features.
# Keeping all classes prevents runtime crashes due to missing classes.
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Android Media framework
# The media framework classes are used by Media3 and by our own code.
-keep class android.media.** { *; }
-dontwarn android.media.**

# Suppress Kotlin warnings
# Media3 and some AndroidX libraries are written in Kotlin and may include
# Kotlin-specific metadata that ProGuard doesn't understand.
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ============================================================================
# Performance: Remove verbose logging in release
# ============================================================================
# Removing debug and verbose log calls reduces the number of instructions
# executed, improves performance, and slightly reduces APK size.
# ============================================================================

# Remove all debug (Log.d) and verbose (Log.v) logging calls
# These log levels are used during development but add runtime overhead in
# production. Removing them saves CPU cycles and reduces string allocations.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

# Optional: Keep warnings and errors for crash reporting
# These rules are commented out because we want to keep error logging for
# diagnosing production issues. Uncomment to also remove these log levels.
# -assumenosideeffects class android.util.Log {
#     public static *** w(...);
#     public static *** e(...);
#     public static *** i(...);
# }

# ============================================================================
# Keep annotations
# ============================================================================
# Annotations are used by the framework and by libraries for runtime behavior.
# Preserving them ensures features like @NonNull validation continue to work.
# ============================================================================

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# ============================================================================
# Keep application entry point
# ============================================================================
# The main Activity is the entry point of the app. It must be preserved
# exactly as declared in AndroidManifest.xml.
# ============================================================================

-keep class com.ark.llama.MusicPlayer { *; }

# ============================================================================
# Additional performance optimizations
# ============================================================================
# These settings enable additional optimizations that improve runtime
# performance and reduce APK size.
# ============================================================================

# Flatten package hierarchy
# This was set earlier but repeated here for clarity.
-repackageclasses ''

# Allow access modification
# This was set earlier but repeated here for clarity.
-allowaccessmodification