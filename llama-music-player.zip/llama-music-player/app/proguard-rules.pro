#
# Llama Music Player - ProGuard Rules
# ============================================================================
# These ProGuard rules optimize and obfuscate the application while preserving
# ALL necessary classes and methods for proper functionality.
#
# When minifyEnabled is set to true in build.gradle, ProGuard will:
# - Remove unused code (shrinking)
# - Obfuscate class and method names
# - Optimize bytecode for performance
#
# These rules prevent ProGuard from removing or renaming classes that are
# accessed dynamically (e.g., via reflection, JNI, or by the Android system).
#
# File Location: /app/proguard-rules.pro
#
# @author Richard Korbla Adzido
# @version 1.0.1
# @since 1.0
# ============================================================================

# ============================================================================
# Jaudiotagger Library Rules
# ============================================================================
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

# ============================================================================
# Native Method Rules (SoundTouch JNI)
# ============================================================================
-keep class com.ark.llama.PitchShifter { *; }
-keepclassmembers class com.ark.llama.PitchShifter {
    native <methods>;
}
-keep class com.ark.llama.SoundTouchPlayer { *; }
-keep class com.ark.llama.AudioProcessor { *; }

# Keep all native method names across all classes
-keepclasseswithmembernames class * {
    native <methods>;
}

# ============================================================================
# SoundTouchPlayer Inner Classes and Listeners
# ============================================================================
-keep class com.ark.llama.SoundTouchPlayer$* { *; }

# ============================================================================
# ALL Activities (8 classes)
# ============================================================================
-keep class com.ark.llama.MusicPlayer { *; }
-keep class com.ark.llama.PlaylistActivity { *; }
-keep class com.ark.llama.FolderManager { *; }
-keep class com.ark.llama.EqualizerActivity { *; }
-keep class com.ark.llama.MetadataEditor { *; }

# ============================================================================
# ALL Dialogs (3 classes)
# ============================================================================
-keep class com.ark.llama.CreditsDialog { *; }
-keep class com.ark.llama.PresetDialog { *; }
-keep class com.ark.llama.ThemeDialog { *; }

# PresetDialog and ThemeDialog inner classes/listeners
-keep class com.ark.llama.PresetDialog$* { *; }
-keep class com.ark.llama.ThemeDialog$* { *; }

# ============================================================================
# ALL Services & Receivers (3 classes)
# ============================================================================
-keep class com.ark.llama.MusicService { *; }
-keep class com.ark.llama.NotificationService { *; }
-keep class com.ark.llama.BluetoothReceiver { *; }

# ServiceConnection anonymous classes
-keep class * implements android.content.ServiceConnection { *; }

# MediaSession callback
-keep class android.media.session.MediaSession$Callback { *; }

# ============================================================================
# ALL Adapters (2 classes)
# ============================================================================
-keep class com.ark.llama.PlaylistAdapter { *; }
-keep class com.ark.llama.FolderAdapter { *; }

# Adapter inner classes and listeners
-keep class com.ark.llama.PlaylistAdapter$* { *; }
-keep class com.ark.llama.FolderAdapter$* { *; }

# ============================================================================
# ALL Managers (5 classes)
# ============================================================================
-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }
-keep class com.ark.llama.ToastManager { *; }
-keep class com.ark.llama.NavigationController { *; }
-keep class com.ark.llama.NavigationController$* { *; }

# EqualizerManager inner classes and listeners (used via reflection)
-keep class com.ark.llama.EqualizerManager$* { *; }

# ============================================================================
# ALL Metadata Classes (3 classes)
# ============================================================================
-keep class com.ark.llama.MetadataReader { *; }
-keep class com.ark.llama.MetadataWriter { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }

# ============================================================================
# ALL Database & Model Classes (4 classes)
# ============================================================================
-keep class com.ark.llama.Song { *; }
-keep class com.ark.llama.SongDatabase { *; }
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.PlaylistService { *; }

# ============================================================================
# ALL Utility Classes (4 classes)
# ============================================================================
-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.FontAwesome { *; }
-keep class com.ark.llama.StorageObserver { *; }
-keep class com.ark.llama.StorageAccessHelper { *; }

# ============================================================================
# Keep entire app package to prevent crashes
# ============================================================================
-keep class com.ark.llama.** { *; }
-keepclassmembers class com.ark.llama.** { *; }

# ============================================================================
# AndroidX Rules
# ============================================================================
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# ============================================================================
# Media Framework
# ============================================================================
-keep class android.media.** { *; }
-dontwarn android.media.**

# ============================================================================
# General Android Rules
# ============================================================================
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keepattributes Exceptions,InnerClasses,Signature,Deprecated

-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog

-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Enum Rules
# ============================================================================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# Parcelable Rules
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}

# ============================================================================
# Serializable Rules (for Song class)
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Remove Logging in Release Builds
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ============================================================================
# Optimization Flags
# ============================================================================
-optimizationpasses 5
-dontpreverify
-allowaccessmodification
-repackageclasses ''
-renamesourcefileattribute SourceFile