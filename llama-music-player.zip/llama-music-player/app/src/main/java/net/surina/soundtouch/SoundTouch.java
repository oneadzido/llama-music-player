package net.surina.soundtouch;

public final class SoundTouch {
    private static native long newInstance();
    private native void deleteInstance(long handle);
    private native void setSampleRate(long handle, int sampleRate);
    private native void setChannels(long handle, int channels);
    private native void setTempo(long handle, float tempo);
    private native void setPitchSemiTones(long handle, float pitch);
    private native void setRate(long handle, float rate);
    private native void putSamples(long handle, short[] samples, int numSamples);
    private native int receiveSamples(long handle, short[] buffer, int maxSamples);
    private native int numSamples(long handle);
    private native void clear(long handle);
    private native void flush(long handle);
    public static native String getVersionString();
    public static native String getErrorString();

    static { System.loadLibrary("soundtouch"); }

    private long handle = 0;
    private int mSampleRate = 0;
    private int mChannels = 0;
    private boolean mIsClosed = false;

    public SoundTouch() {
        handle = newInstance();
        if (handle == 0) throw new RuntimeException("Failed to create SoundTouch instance");
    }

    public void setSampleRate(int sampleRate) { if (!mIsClosed) { mSampleRate = sampleRate; setSampleRate(handle, sampleRate); } }
    public void setChannels(int channels) { if (!mIsClosed) { mChannels = channels; setChannels(handle, channels); } }
    public void setTempo(float tempo) { if (!mIsClosed) setTempo(handle, tempo); }
    public void setPitchSemiTones(float pitch) { if (!mIsClosed) setPitchSemiTones(handle, pitch); }
    public void setRate(float rate) { if (!mIsClosed) setRate(handle, rate); }
    public void putSamples(short[] samples, int numSamples) { if (!mIsClosed) putSamples(handle, samples, numSamples); }
    public int receiveSamples(short[] buffer, int maxSamples) { return mIsClosed ? 0 : receiveSamples(handle, buffer, maxSamples); }
    public int numSamples() { return mIsClosed ? 0 : numSamples(handle); }
    public void clear() { if (!mIsClosed) clear(handle); }
    public void flush() { if (!mIsClosed) flush(handle); }
    public int getSampleRate() { return mSampleRate; }
    public int getChannels() { return mChannels; }
    public void close() { if (!mIsClosed && handle != 0) { deleteInstance(handle); handle = 0; mIsClosed = true; } }
    public static boolean isAvailable() { try { return getVersionString() != null; } catch (UnsatisfiedLinkError e) { return false; } }
}
