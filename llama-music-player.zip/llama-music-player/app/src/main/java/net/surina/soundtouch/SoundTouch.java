package net.surina.soundtouch;

/**
 * SoundTouch - Java wrapper for the SoundTouch native audio processing library
 * ============================================================================
 * 
 * <p>This class provides a complete JNI interface to the SoundTouch native library
 * for real-time pitch and tempo shifting of 16-bit PCM audio. The SoundTouch
 * library uses the WSOLA (Waveform Similarity Overlap-Add) algorithm for
 * high-quality time stretching without affecting pitch.</p>
 * 
 * <p>The native library (libsoundtouch.so) is LGPL licensed. This Java wrapper
 * is original code written to interface with that library.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time streaming processing with low latency</li>
 *   <li>Support for both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>File-to-file batch processing mode</li>
 * </ul>
 * 
 * <h3>Audio Format Requirements</h3>
 * <p>The native library expects 16-bit PCM samples in interleaved format.
 * For stereo audio, the sample order is L, R, L, R, etc. The sample rate
 * must be set before processing any audio.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All methods should be called from the same
 * thread, or external synchronization should be used when calling from multiple
 * threads. The native library maintains internal state that is not thread-safe.</p>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #close()} when the processor is no longer needed to
 * free native resources and prevent memory leaks. The processor cannot be used
 * after close() is called.</p>
 * 
 * <h3>Usage Example (Streaming)</h3>
 * <pre>
 * // Create processor and configure
 * SoundTouch processor = new SoundTouch();
 * processor.setSampleRate(44100);
 * processor.setChannels(2);
 * processor.setTempo(1.25f);      // Speed up by 25%
 * processor.setPitchSemiTones(2.0f); // Raise pitch by 2 semitones
 * 
 * // Process audio in real-time
 * short[] input = new short[8192];
 * short[] output = new short[8192];
 * 
 * // Feed input samples
 * processor.putSamples(input, input.length);
 * 
 * // Retrieve processed samples
 * int available = processor.numSamples();
 * int received = processor.receiveSamples(output, available);
 * 
 * // Clean up
 * processor.close();
 * </pre>
 * 
 * <h3>Usage Example (File Processing)</h3>
 * <pre>
 * SoundTouch processor = new SoundTouch();
 * processor.setTempo(1.25f);
 * processor.setPitchSemiTones(2.0f);
 * int result = processor.processFile("/sdcard/input.mp3", "/sdcard/output.mp3");
 * processor.close();
 * </pre>
 * 
 * @author Richard Korbla Adzido (Java wrapper)
 * @author Olli Parviainen (SoundTouch native library)
 * @version 1.0.1
 * @since 1.0
 * @see <a href="https://www.surina.net/soundtouch/">SoundTouch Website</a>
 */
public final class SoundTouch {

    // ========================================================================
    // Native Method Declarations
    // ========================================================================
    
    /**
     * Creates a new SoundTouch processor instance in native memory.
     * 
     * <p>This method allocates a SoundTouch object in native memory and returns
     * its pointer as a long value. The pointer must be passed to all other
     * native methods to identify which instance to operate on.</p>
     *
     * @return Native handle pointer (0 if creation fails)
     */
    private static native long newInstance();
    
    /**
     * Destroys a SoundTouch processor instance and frees native memory.
     *
     * @param handle Native handle pointer returned by newInstance()
     */
    private native void deleteInstance(long handle);
    
    /**
     * Sets the audio sample rate for processing.
     * 
     * <p>This must be called before processing any audio. The sample rate
     * is used internally by the time-stretching algorithm to calculate
     * proper buffer sizes and processing parameters.</p>
     *
     * @param handle Native handle pointer
     * @param sampleRate Sample rate in Hz (8000 to 192000)
     */
    private native void setSampleRate(long handle, int sampleRate);
    
    /**
     * Sets the number of audio channels.
     * 
     * <p>This must be called before processing any audio. The channel count
     * determines how samples are interleaved in the input and output buffers.</p>
     *
     * @param handle Native handle pointer
     * @param channels Number of channels (1 for mono, 2 for stereo)
     */
    private native void setChannels(long handle, int channels);
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The tempo change is independent of pitch, meaning the
     * audio key remains unchanged while the speed changes.</p>
     *
     * @param handle Native handle pointer
     * @param tempo Tempo multiplier (0.5 to 1.5 recommended)
     */
    private native void setTempo(long handle, float tempo);
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch (higher key), negative values lower
     * it (lower key). The pitch change is independent of tempo, meaning the
     * playback speed remains unchanged while the key changes.</p>
     *
     * @param handle Native handle pointer
     * @param pitch Pitch shift amount in semitones (-6 to +6 recommended)
     */
    private native void setPitchSemiTones(long handle, float pitch);
    
    /**
     * Sets the playback rate (affects both tempo and pitch).
     * 
     * <p>Unlike setTempo() and setPitchSemiTones(), setRate() changes both
     * speed and pitch simultaneously, similar to changing the playback speed
     * on a tape recorder.</p>
     *
     * @param handle Native handle pointer
     * @param rate Playback rate multiplier
     */
    private native void setRate(long handle, float rate);
    
    /**
     * Feeds PCM samples into the processor.
     * 
     * <p>The samples are processed by the SoundTouch algorithm. Processed
     * samples can be retrieved using {@link #receiveSamples(short[], int)}.
     * The number of output samples may differ from the number of input samples
     * depending on the tempo setting.</p>
     *
     * @param handle Native handle pointer
     * @param samples Array of 16-bit PCM samples (interleaved for stereo)
     * @param numSamples Number of samples to process
     */
    private native void putSamples(long handle, short[] samples, int numSamples);
    
    /**
     * Retrieves processed samples from the processor.
     * 
     * <p>Call {@link #numSamples()} first to check how many samples are available
     * before calling this method. The retrieved samples are in the same format
     * as the input (16-bit PCM, interleaved for stereo).</p>
     *
     * @param handle Native handle pointer
     * @param buffer Array to receive the processed samples
     * @param maxSamples Maximum number of samples to retrieve
     * @return Number of samples actually retrieved
     */
    private native int receiveSamples(long handle, short[] buffer, int maxSamples);
    
    /**
     * Returns the number of samples currently available in the output buffer.
     * 
     * <p>Use this method to check how much processed data is ready before
     * calling {@link #receiveSamples(short[], int)}. This prevents buffer
     * underruns when reading processed audio.</p>
     *
     * @param handle Native handle pointer
     * @return Number of available samples
     */
    private native int numSamples(long handle);
    
    /**
     * Clears all internal buffers and resets the processor state.
     * 
     * <p>Use this method when seeking to a new position in the audio stream
     * or when starting a new song. It discards any pending input and output
     * data, ensuring a clean state for the next audio segment.</p>
     *
     * @param handle Native handle pointer
     */
    private native void clear(long handle);
    
    /**
     * Flushes any remaining samples from the processor.
     * 
     * <p>Call this method after feeding all input samples to retrieve the
     * last processed samples from the pipeline. After flushing, no more
     * output will be available.</p>
     *
     * @param handle Native handle pointer
     */
    private native void flush(long handle);
    
    /**
     * Processes an entire audio file (offline batch mode).
     * 
     * <p>This method reads an input audio file, applies the configured
     * tempo and pitch changes, and writes the result to an output file.
     * It is suitable for batch processing but not for real-time playback.</p>
     *
     * @param handle Native handle pointer
     * @param inputFile Path to the input audio file
     * @param outputFile Path to the output audio file
     * @return 0 on success, non-zero on error
     */
    private native int processFile(long handle, String inputFile, String outputFile);
    
    /**
     * Returns the version string of the native SoundTouch library.
     * 
     * <p>This method can be called before creating a SoundTouch instance
     * to verify that the native library is available and loaded correctly.</p>
     *
     * @return Version string (e.g., "SoundTouch 2.1.0")
     */
    public static native String getVersionString();
    
    /**
     * Returns the last error message from the native library.
     * 
     * <p>If an operation fails, this method can be called to get a
     * human-readable error description for debugging.</p>
     *
     * @return Error message string, or null if no error
     */
    public static native String getErrorString();
    
    // ========================================================================
    // Static Initializer
    // ========================================================================
    
    /**
     * Static initializer that loads the native SoundTouch library.
     * 
     * <p>The library is expected to be named "soundtouch" and located in the
     * jniLibs directory with the appropriate ABI subfolder (armeabi-v7a,
     * arm64-v8a, x86, or x86_64). If the library cannot be loaded, an
     * UnsatisfiedLinkError will be thrown when native methods are called.</p>
     */
    static {
        System.loadLibrary("soundtouch");
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Native handle pointer to the SoundTouch instance. */
    private long handle = 0;
    
    /** Cached sample rate value set by the user. */
    private int mSampleRate = 0;
    
    /** Cached channel count value set by the user. */
    private int mChannels = 0;
    
    /** Flag indicating whether the processor has been closed. */
    private boolean mIsClosed = false;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouch processor instance.
     * 
     * <p>The constructor creates a native SoundTouch object in memory.
     * If the native library cannot be loaded or the instance cannot be created,
     * a RuntimeException is thrown.</p>
     * 
     * <p>After construction, you must call {@link #setSampleRate(int)} and
     * {@link #setChannels(int)} before processing any audio. Tempo and pitch
     * settings can be changed at any time, even during playback.</p>
     * 
     * @throws RuntimeException if the native instance cannot be created
     * @throws UnsatisfiedLinkError if the native library cannot be loaded
     */
    public SoundTouch() {
        handle = newInstance();
        if (handle == 0) {
            throw new RuntimeException("Failed to create SoundTouch instance");
        }
    }
    
    // ========================================================================
    // Configuration Methods
    // ========================================================================
    
    /**
     * Sets the audio sample rate.
     * 
     * <p>This method must be called before processing any audio. The sample
     * rate is used by the time-stretching algorithm to calculate proper
     * processing parameters. Common values are 44100 Hz (CD quality) and
     * 48000 Hz (DVD quality).</p>
     * 
     * <p>Valid sample rates range from 8000 Hz to 192000 Hz. Values outside
     * this range may cause undefined behavior.</p>
     *
     * @param sampleRate Sample rate in Hz (8000 to 192000)
     * @throws IllegalStateException if the processor has been closed
     */
    public void setSampleRate(int sampleRate) {
        if (mIsClosed) return;
        mSampleRate = sampleRate;
        setSampleRate(handle, sampleRate);
    }
    
    /**
     * Sets the number of audio channels.
     * 
     * <p>This method must be called before processing any audio. The channel
     * count determines how samples are interleaved in the input and output
     * buffers. Use 1 for mono audio, 2 for stereo audio.</p>
     *
     * @param channels Number of channels (1 for mono, 2 for stereo)
     * @throws IllegalStateException if the processor has been closed
     */
    public void setChannels(int channels) {
        if (mIsClosed) return;
        mChannels = channels;
        setChannels(handle, channels);
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio (e.g., 0.5 = half speed),
     * values greater than 1.0 speed it up (e.g., 1.5 = 1.5x speed). The tempo
     * change is independent of pitch, meaning the audio key remains unchanged
     * while the speed changes.</p>
     * 
     * <p>The change takes effect immediately on subsequent audio frames.
     * There is no audible transition or gap when changing tempo during playback.</p>
     *
     * @param tempo Tempo multiplier (0.5 to 1.5 recommended)
     * @throws IllegalStateException if the processor has been closed
     */
    public void setTempo(float tempo) {
        if (mIsClosed) return;
        setTempo(handle, tempo);
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch (higher key), negative values lower
     * it (lower key). Each semitone corresponds to one half-step on the
     * chromatic scale. For example, +2 semitones raises the pitch by one
     * whole step.</p>
     * 
     * <p>The change takes effect immediately on subsequent audio frames.
     * There is no audible transition or gap when changing pitch during playback.</p>
     *
     * @param pitch Pitch shift amount in semitones (-6 to +6 recommended)
     * @throws IllegalStateException if the processor has been closed
     */
    public void setPitchSemiTones(float pitch) {
        if (mIsClosed) return;
        setPitchSemiTones(handle, pitch);
    }
    
    /**
     * Sets the playback rate (affects both tempo and pitch).
     * 
     * <p>Unlike {@link #setTempo(float)} and {@link #setPitchSemiTones(float)},
     * this method changes both speed and pitch simultaneously, similar to
     * changing the playback speed on a tape recorder. A rate of 2.0 doubles
     * both the speed and the pitch (one octave higher).</p>
     *
     * @param rate Playback rate multiplier
     * @throws IllegalStateException if the processor has been closed
     */
    public void setRate(float rate) {
        if (mIsClosed) return;
        setRate(handle, rate);
    }
    
    // ========================================================================
    // Streaming Processing Methods
    // ========================================================================
    
    /**
     * Feeds PCM samples into the processor for real-time processing.
     * 
     * <p>The samples must be 16-bit integer PCM in interleaved format.
     * For stereo audio, the sample order is left, right, left, right, etc.
     * The number of samples must be a multiple of the channel count.</p>
     * 
     * <p>Processed samples can be retrieved using {@link #receiveSamples(short[], int)}.
     * The number of output samples may differ from the number of input samples
     * depending on the tempo setting. For example, a tempo of 2.0 will produce
     * approximately half as many output samples as input samples.</p>
     *
     * @param samples Array of 16-bit PCM samples
     * @param numSamples Number of samples to process (must be <= samples.length)
     * @throws IllegalStateException if the processor has been closed
     * @throws NullPointerException if samples is null
     */
    public void putSamples(short[] samples, int numSamples) {
        if (mIsClosed) return;
        putSamples(handle, samples, numSamples);
    }
    
    /**
     * Retrieves processed samples from the processor.
     * 
     * <p>Call {@link #numSamples()} first to check how many samples are available
     * before calling this method. This prevents buffer overruns and ensures
     * you allocate a sufficiently large buffer.</p>
     * 
     * <p>The retrieved samples are in the same format as the input
     * (16-bit PCM, interleaved for stereo). The number of samples actually
     * retrieved may be less than maxSamples if the output buffer is not full.</p>
     *
     * @param buffer Array to receive the processed samples
     * @param maxSamples Maximum number of samples to retrieve
     * @return Number of samples actually retrieved (0 if none available)
     * @throws IllegalStateException if the processor has been closed
     * @throws NullPointerException if buffer is null
     */
    public int receiveSamples(short[] buffer, int maxSamples) {
        if (mIsClosed) return 0;
        return receiveSamples(handle, buffer, maxSamples);
    }
    
    /**
     * Returns the number of samples currently available in the output buffer.
     * 
     * <p>Use this method to check how much processed data is ready before
     * calling {@link #receiveSamples(short[], int)}. This prevents blocking
     * or buffer underruns when reading processed audio.</p>
     * 
     * <p>The number of available samples changes dynamically as more input
     * is fed and more output is retrieved.</p>
     *
     * @return Number of available samples (0 if none available or processor closed)
     */
    public int numSamples() {
        if (mIsClosed) return 0;
        return numSamples(handle);
    }
    
    /**
     * Clears all internal buffers and resets the processor state.
     * 
     * <p>Use this method when seeking to a new position in the audio stream,
     * starting a new song, or when you need to reset the processor to a clean
     * state. It discards any pending input and output data.</p>
     * 
     * <p>After calling clear(), you must feed new input samples using
     * {@link #putSamples(short[], int)} before retrieving output.</p>
     *
     * @throws IllegalStateException if the processor has been closed
     */
    public void clear() {
        if (mIsClosed) return;
        clear(handle);
    }
    
    /**
     * Flushes any remaining samples from the processor.
     * 
     * <p>Call this method after feeding all input samples to retrieve the
     * last processed samples from the pipeline. After flushing, no more
     * output will be available, and the processor will be in a clean state.</p>
     * 
     * <p>This method is typically called at the end of a song or audio stream
     * to ensure all processed audio is retrieved.</p>
     *
     * @throws IllegalStateException if the processor has been closed
     */
    public void flush() {
        if (mIsClosed) return;
        flush(handle);
    }
    
    // ========================================================================
    // File Processing Method
    // ========================================================================
    
    /**
     * Processes an entire audio file (offline batch mode).
     * 
     * <p>This method reads an input audio file, applies the configured
     * tempo and pitch changes, and writes the result to an output file.
     * It is suitable for batch processing applications but not for
     * real-time playback.</p>
     * 
     * <p>Supported input formats depend on the underlying platform, but
     * typically include WAV, MP3, OGG, and other common formats through
     * the libsndfile or other decoders.</p>
     *
     * @param inputFile Path to the input audio file
     * @param outputFile Path to the output audio file
     * @return 0 on success, non-zero on error (use {@link #getErrorString()}
     *         to get error details)
     * @throws IllegalStateException if the processor has been closed
     * @throws NullPointerException if inputFile or outputFile is null
     */
    public int processFile(String inputFile, String outputFile) {
        if (mIsClosed) return -1;
        return processFile(handle, inputFile, outputFile);
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the sample rate currently configured for this processor.
     *
     * @return Sample rate in Hz, or 0 if not set
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the channel count currently configured for this processor.
     *
     * @return Number of channels (1 for mono, 2 for stereo), or 0 if not set
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Checks whether the processor has been closed.
     * 
     * <p>A closed processor cannot be used for any operations. If you need
     * to process more audio after closing, you must create a new instance.</p>
     *
     * @return true if the processor is closed, false otherwise
     */
    public boolean isClosed() {
        return mIsClosed;
    }
    
    /**
     * Checks if the native library is available for use.
     * 
     * <p>This static method can be called before creating a SoundTouch instance
     * to verify that the native library was loaded successfully. It attempts
     * to retrieve the version string and catches any UnsatisfiedLinkError.</p>
     *
     * @return true if the native library is available, false otherwise
     */
    public static boolean isAvailable() {
        try {
            String version = getVersionString();
            return version != null && !version.isEmpty();
        } catch (UnsatisfiedLinkError e) {
            return false;
        }
    }
    
    // ========================================================================
    // Resource Management
    // ========================================================================
    
    /**
     * Releases the native SoundTouch processor and frees all resources.
     * 
     * <p>Always call this method when the processor is no longer needed to
     * prevent memory leaks. After calling close(), this instance cannot be
     * used for any further operations. Any subsequent method calls will
     * have no effect (they will silently return without processing).</p>
     * 
     * <p>It is safe to call close() multiple times; subsequent calls have
     * no effect. The recommended pattern is to call close() in a finally
     * block or use try-with-resources with an AutoCloseable wrapper.</p>
     * 
     * <p>Example usage:</p>
     * <pre>
     * SoundTouch processor = null;
     * try {
     *     processor = new SoundTouch();
     *     // use processor
     * } finally {
     *     if (processor != null) {
     *         processor.close();
     *     }
     * }
     * </pre>
     */
    public void close() {
        if (!mIsClosed && handle != 0) {
            deleteInstance(handle);
            handle = 0;
            mIsClosed = true;
        }
    }
    
    // ========================================================================
    // Finalization
    // ========================================================================
    
    /**
     * Finalizes the SoundTouch processor instance.
     * 
     * <p>This method is called by the garbage collector and ensures that
     * native resources are freed if {@link #close()} was not called explicitly.
     * It is strongly recommended to call close() explicitly rather than relying
     * on finalization, as finalization is not guaranteed to happen in a timely
     * manner.</p>
     *
     * @throws Throwable if an error occurs during finalization
     */
    @Override
    protected void finalize() throws Throwable {
        try {
            if (!mIsClosed && handle != 0) {
                deleteInstance(handle);
                handle = 0;
            }
        } finally {
            super.finalize();
        }
    }
}