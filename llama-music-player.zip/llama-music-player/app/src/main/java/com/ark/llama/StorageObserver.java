package com.ark.llama;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * ContentObserver for monitoring storage changes and triggering automatic playlist updates.
 * 
 * <p>This class listens for changes in the device's media storage (new audio files added,
 * files modified, or files deleted) and automatically triggers a playlist synchronization
 * to keep the app's playlist in sync with the device's file system.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li><b>Event-Driven Sync</b> - Reacts to Android MediaStore change notifications</li>
 *   <li><b>Debouncing (Quiet Period)</b> - Waits 5 seconds after last change before syncing</li>
 *   <li><b>Rate Limiting (Cooldown)</b> - Ensures syncs occur at most once per minute</li>
 *   <li><b>Non-Intrusive Updates</b> - Uses SOFT_UPDATE_PLAYLIST broadcast to preserve current playback</li>
 *   <li><b>State Management</b> - Tracks sync state to prevent overlapping updates</li>
 *   <li><b>NavigationController Integration</b> - Disables buttons during auto-sync</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All delays use Handler.postDelayed().
 * The content observer callbacks run on the main thread, and all operations
 * are properly synchronized.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class StorageObserver extends ContentObserver {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "StorageObserver";
    
    /** Cooldown period between syncs (60 seconds) - prevents CPU thrashing. */
    private static final long SYNC_COOLDOWN_MS = 60000;
    
    /** Quiet period delay after last change (5 seconds) - batches multiple file operations. */
    private static final long QUIET_PERIOD_MS = 5000;
    
    /** Delay before ending operation after sync (milliseconds). */
    private static final long OPERATION_END_DELAY_MS = 500;
    
    /** Broadcast action for soft updating the playlist (preserves current playback). */
    private static final String ACTION_SOFT_UPDATE_PLAYLIST = "SOFT_UPDATE_PLAYLIST";
    
    /** Broadcast action for displaying the playlist. */
    private static final String ACTION_DISPLAY_PLAYLIST = "DISPLAY_PLAYLIST";
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Activity context for showing toasts. */
    @Nullable
    private Activity mActivity;
    
    /** Application context for accessing content resolver and sending broadcasts. */
    @NonNull
    private final Context mContext;
    
    /** Flag indicating whether the observer is currently active. */
    private boolean mIsObserving = false;
    
    /** Timestamp of the last completed sync for rate limiting. */
    private long mLastSyncTime = 0;
    
    /** Service for performing the actual playlist update. */
    @NonNull
    private final PlaylistService mPlaylistService;
    
    /** Flag indicating whether a playlist update is currently in progress. */
    private volatile boolean mIsUpdating = false;
    
    /** Main thread handler for delayed operations. */
    @NonNull
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for the pending storage update (used for debouncing). */
    @Nullable
    private Runnable mPendingUpdateRunnable = null;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new StorageObserver.
     *
     * @param activity The activity context (for showing toasts)
     */
    public StorageObserver(@NonNull Activity activity) {
        super(new Handler(Looper.getMainLooper()));
        mActivity = activity;
        mContext = activity.getApplicationContext();
        mPlaylistService = PlaylistService.getInstance(mContext);
    }
    
    /**
     * Updates the activity reference (called when activity is recreated).
     * Should be called in onResume() of MusicPlayer to ensure toast works.
     *
     * @param activity The current activity
     */
    public void setActivity(@NonNull Activity activity) {
        mActivity = activity;
    }
    
    // ========================================================================
    // ContentObserver Callback Methods
    // ========================================================================
    
    /**
     * Called when a change occurs in the content that this observer is monitoring.
     *
     * @param selfChange True if this is a self-change (caused by the app itself)
     * @param uri The URI of the changed content
     */
    @Override
    public void onChange(boolean selfChange, @Nullable Uri uri) {
        super.onChange(selfChange, uri);
        handleChange(uri);
    }
    
    /**
     * Called when a change occurs (legacy method without URI parameter).
     *
     * @param selfChange True if this is a self-change
     */
    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        handleChange(null);
    }
    
    // ========================================================================
    // Change Handling
    // ========================================================================
    
    /**
     * Handles storage change events using a 2-tier smart sync strategy:
     * <ol>
     *   <li><b>Cooldown Check</b> - Ensures syncs occur at most once per minute</li>
     *   <li><b>Quiet Period (Debounce)</b> - Waits 5 seconds after last change before syncing</li>
     * </ol>
     * <p>All delays use Handler.postDelayed().</p>
     *
     * @param uri The URI of the changed content (can be null)
     */
    private void handleChange(@Nullable Uri uri) {
        if (uri == null) {
            return;
        }
        
        String uriString = uri.toString();
        Log.d(TAG, "MediaStore changed: " + uriString);
        
        // Only respond to audio or external storage changes
        if (uriString.contains("audio") || uriString.contains("external")) {
            long now = SystemClock.elapsedRealtime();
            
            // TIER 1: COOLDOWN CHECK - Rate limiting (max once per minute)
            if (now - mLastSyncTime < SYNC_COOLDOWN_MS && mLastSyncTime > 0) {
                Log.d(TAG, "Cooldown active - last sync was " + (now - mLastSyncTime) + "ms ago, skipping");
                return;
            }
            
            // Don't trigger if an update is already in progress
            if (mIsUpdating) {
                Log.d(TAG, "Already updating, skipping");
                return;
            }
            
            // TIER 2: QUIET PERIOD (Debounce) - Cancel previous pending update
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                Log.d(TAG, "Cancelled previous pending update, resetting quiet period");
            }
            
            // Schedule the update after quiet period to wait for file operations to complete
            mPendingUpdateRunnable = new Runnable() {
                @Override
                public void run() {
                    mPendingUpdateRunnable = null;
                    performStorageUpdate();
                }
            };
            mMainHandler.postDelayed(mPendingUpdateRunnable, QUIET_PERIOD_MS);
            
            Log.d(TAG, "Quiet period started - sync scheduled in " + QUIET_PERIOD_MS + "ms");
        }
    }
    
    /**
     * Performs the actual playlist update triggered by storage changes.
     * 
     * <p>This method uses SOFT_UPDATE_PLAYLIST broadcast which updates the playlist
     * structure while preserving the currently playing song and playback state.
     * This ensures automatic library updates do not interrupt the user's listening experience.</p>
     * 
     * <p>Uses Handler.postDelayed() for the operation end delay.</p>
     */
    private void performStorageUpdate() {
        if (mIsUpdating) {
            Log.d(TAG, "Already updating, skipping");
            return;
        }
        
        Log.d(TAG, "Quiet period ended - triggering playlist update...");
        
        mIsUpdating = true;
        
        // Notify NavigationController to disable relevant buttons
        NavigationController.getInstance().beginPlaylistSync();
        
        // Tell MusicService sync is starting (suppresses notification updates)
        Intent syncStartIntent = new Intent("SYNC_STARTING");
        mContext.sendBroadcast(syncStartIntent);
        
        // Perform the actual playlist update silently (no progress UI)
        mPlaylistService.updatePlaylistSilent();
        
        // Record sync time for cooldown
        mLastSyncTime = SystemClock.elapsedRealtime();
        
        // End the operation after a delay to ensure sync completes
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                NavigationController.getInstance().endPlaylistSync();
                mIsUpdating = false;
                Log.d(TAG, "Auto-update completed");
                
                // Send soft update broadcast to refresh playlist while preserving playback
                Intent softUpdateIntent = new Intent(ACTION_SOFT_UPDATE_PLAYLIST);
                mContext.sendBroadcast(softUpdateIntent);
                
                // Refresh playlist display for any open playlist views
                Intent displayIntent = new Intent(ACTION_DISPLAY_PLAYLIST);
                mContext.sendBroadcast(displayIntent);
                
                // Tell MusicService sync has ended
                Intent syncEndIntent = new Intent("SYNC_ENDING");
                mContext.sendBroadcast(syncEndIntent);
            }
        }, OPERATION_END_DELAY_MS);
    }
    
    // ========================================================================
    // Lifecycle Management
    // ========================================================================
    
    /**
     * Starts observing storage changes.
     * Registers content observers for MediaStore audio and external files.
     * Should be called when the app starts or when observing is needed.
     */
    public void startObserving() {
        if (mIsObserving) {
            return;
        }
        
        try {
            ContentResolver resolver = mContext.getContentResolver();
            
            // Observe changes to audio media
            resolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true,
                this
            );
            
            // Observe changes to external files
            resolver.registerContentObserver(
                MediaStore.Files.getContentUri("external"),
                true,
                this
            );
            
            mIsObserving = true;
            Log.d(TAG, "Started observing storage changes");
            
        } catch (SecurityException e) {
            Log.e(TAG, "Permission denied for storage observer", e);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register observer", e);
        }
    }
    
    /**
     * Stops observing storage changes.
     * Should be called when the app is destroyed to prevent memory leaks.
     */
    public void stopObserving() {
        if (!mIsObserving) {
            return;
        }
        
        try {
            // Cancel any pending update
            if (mPendingUpdateRunnable != null) {
                mMainHandler.removeCallbacks(mPendingUpdateRunnable);
                mPendingUpdateRunnable = null;
                Log.d(TAG, "Cancelled pending update on stop");
            }
            
            // Unregister the observer
            mContext.getContentResolver().unregisterContentObserver(this);
            mIsObserving = false;
            Log.d(TAG, "Stopped observing storage changes");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister observer", e);
        }
    }
    
    /**
     * Checks if a playlist update is currently in progress.
     *
     * @return True if updating
     */
    public boolean isUpdating() {
        return mIsUpdating;
    }
    
    /**
     * Forces an immediate playlist update, bypassing cooldown and quiet period.
     * Useful when the app needs to sync immediately (e.g., after user folder changes).
     * Uses Handler to ensure proper execution order.
     */
    public void forceUpdate() {
        // Cancel any pending debounced update
        if (mPendingUpdateRunnable != null) {
            mMainHandler.removeCallbacks(mPendingUpdateRunnable);
            mPendingUpdateRunnable = null;
            Log.d(TAG, "Cancelled pending update for force update");
        }
        
        // Reset cooldown to allow immediate sync
        mLastSyncTime = 0;
        
        // Post to ensure we're not blocking the current thread
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!mIsUpdating) {
                    Log.d(TAG, "Force update triggered");
                    performStorageUpdate();
                } else {
                    Log.d(TAG, "Force update requested but update already in progress");
                }
            }
        });
    }
}