package com.ark.llama;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * AudioPlayerBridge - Orchestrates dual-player architecture with seamless transition.
 * 
 * <p>This class manages two audio players:</p>
 * <ul>
 *   <li><b>NativeMediaPlayer (Primary at start)</b> - Reliable playback using Android's
 *       native MediaPlayer. Provides immediate playback with no delay.</li>
 *   <li><b>LlamaPlayer (Enhanced after init)</b> - Advanced player with SoundTouch
 *       processing for pitch and tempo control. Takes over seamlessly when ready.</li>
 * </ul>
 * 
 * <h3>Initialization Strategy</h3>
 * <p><b>Phase 1 (Immediate):</b> NativeMediaPlayer initializes instantly when the first
 * song is loaded. Playback can start immediately with no delay.</p>
 * 
 * <p><b>Phase 2 (Background):</b> LlamaPlayer initializes in the background while
 * NativeMediaPlayer continues playing. SoundTouch library loading and decoder
 * initialization happen without user-visible delay.</p>
 * 
 * <p><b>Phase 3 (Transition):</b> When LlamaPlayer is ready, the bridge performs a
 * seamless transition: captures current position, pauses NativeMediaPlayer briefly,
 * starts LlamaPlayer at the same position, and hands over playback. The transition
 * is typically under 100ms and barely noticeable to the user.</p>
 * 
 * <p><b>Phase 4 (Steady State):</b> LlamaPlayer becomes the primary player for all
 * future playback. NativeMediaPlayer remains as a fallback if LlamaPlayer ever fails.</p>
 * 
 * <h3>State Management</h3>
 * <p>The bridge maintains a single source of truth for playback state. MusicService
 * interacts only with this bridge, which internally manages both players.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. State changes are synchronized and
 * protected against race conditions. Callbacks are delivered on the main UI thread.</p>
 * 
 * @see NativeMediaPlayer
 * @see LlamaPlayer
 * @see DecoderManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class AudioPlayerBridge {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "AudioPlayerBridge";
    
    /** Delay before starting LlamaPlayer background initialization (ms). */
    private static final int LLAMA_INIT_DELAY_MS = 500;
    
    /** Max time to wait for LlamaPlayer transition (ms). */
    private static final int TRANSITION_TIMEOUT_MS = 3000;
    
    /** Check interval for LlamaPlayer readiness (ms). */
    private static final int READY_CHECK_INTERVAL_MS = 200;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Current active player.
     */
    public enum ActivePlayer {
        /** NativeMediaPlayer is active (fallback/default). */
        NATIVE,
        
        /** LlamaPlayer is active (enhanced). */
        LLAMA,
        
        /** Transition in progress between players. */
        TRANSITIONING
    }
    
    /**
     * Transition state for seamless handover.
     */
    private enum TransitionState {
        IDLE,
        PREPARING_LLAMA,
        READY_TO_TRANSITION,
        TRANSITIONING,
        COMPLETED,
        FAILED
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    @NonNull private final Context mContext;
    
    /** NativeMediaPlayer (always reliable, starts first). */
    @NonNull private final NativeMediaPlayer mNativePlayer;
    
    /** LlamaPlayer (enhanced, takes over when ready). */
    @Nullable private LlamaPlayer mLlamaPlayer;
    
    /** DecoderManager for LlamaPlayer (prefill and format info). */
    @Nullable private volatile DecoderManager mDecoderManager;
    
    /** Currently active player. */
    @NonNull private volatile ActivePlayer mActivePlayer = ActivePlayer.NATIVE;
    
    /** Transition state machine. */
    @NonNull private final AtomicBoolean mTransitionInProgress = new AtomicBoolean(false);
    
    /** Flag indicating if LlamaPlayer initialization has started. */
    private volatile boolean mLlamaInitStarted = false;
    
    /** Flag indicating if LlamaPlayer is ready for transition. */
    private volatile boolean mLlamaReady = false;
    
    /** Current song file path (cached for LlamaPlayer initialization). */
    @Nullable private String mCurrentFilePath = null;
    
    /** Current playback position (cached for seamless transition). */
    private volatile int mCurrentPosition = 0;
    
    /** Flag indicating if playback was playing before transition. */
    private volatile boolean mWasPlayingBeforeTransition = false;
    
    /** Current sample rate (from decoder, for LlamaPlayer). */
    private volatile int mSampleRate = 44100;
    
    /** Current channel count (from decoder, for LlamaPlayer). */
    private volatile int mChannels = 2;
    
    /** Main thread handler. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Listener for playback events. */
    @Nullable private AudioPlayerListener mListener;
    
    /** Lock for transition operations. */
    @NonNull private final Object mTransitionLock = new Object();
    
    /** Current pitch value (for LlamaPlayer). */
    private float mCurrentPitch = 0f;
    
    /** Current tempo value (for LlamaPlayer). */
    private float mCurrentTempo = 1.0f;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Unified listener for audio player events.
     * All callbacks are delivered on the main UI thread.
     */
    public interface AudioPlayerListener {
        /**
         * Called when the player is prepared and ready.
         */
        void onPrepared();
        
        /**
         * Called when a song completes naturally.
         */
        void onCompletion();
        
        /**
         * Called with periodic position updates.
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs.
         * @param error Human-readable error description
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the audio session ID is available.
         * @param sessionId The audio session ID
         */
        void onAudioSessionAvailable(int sessionId);
        
        /**
         * Called when the player state changes.
         * @param isPlaying True if playing
         * @param isPrepared True if prepared
         */
        void onStateChanged(boolean isPlaying, boolean isPrepared);
        
        /**
         * Called when LlamaPlayer becomes available (pitch/tempo controls enabled).
         */
        void onLlamaPlayerAvailable();
        
        /**
         * Called during transition to report progress.
         * @param progress 0-100 indicating transition progress
         */
        void onTransitionProgress(int progress);
        
        /**
         * Called when transition to LlamaPlayer completes.
         */
        void onTransitionComplete();
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new AudioPlayerBridge.
     * 
     * <p>NativeMediaPlayer is created immediately and ready for playback.
     * LlamaPlayer initialization starts in the background after a short delay.</p>
     *
     * @param context Application context
     */
    public AudioPlayerBridge(@NonNull Context context) {
        mContext = context.getApplicationContext();
        
        // Create NativeMediaPlayer immediately (Phase 1)
        mNativePlayer = new NativeMediaPlayer(mContext);
        mNativePlayer.setListener(new NativeMediaPlayerListener());
        
        Log.d(TAG, "AudioPlayerBridge created - NativeMediaPlayer ready");
    }
    
    /**
     * Sets the unified listener for playback events.
     *
     * @param listener The listener to receive callbacks
     */
    public void setListener(@Nullable AudioPlayerListener listener) {
        mListener = listener;
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Initializes the bridge with a song file.
     * 
     * <p>NativeMediaPlayer starts loading immediately for instant playback.
     * LlamaPlayer initialization begins in the background.</p>
     *
     * @param filePath Absolute path to the audio file
     */
    public void initialize(@NonNull String filePath) {
        mCurrentFilePath = filePath;
        mNativePlayer.initialize(filePath);
        
        // Start background LlamaPlayer initialization (Phase 2)
        startLlamaPlayerBackgroundInit(filePath);
        
        Log.d(TAG, "initialize: " + filePath + " - NativePlayer loading, LlamaPlayer background init scheduled");
    }
    
    /**
     * Prepares the active player asynchronously.
     *
     * @param autoStart True to automatically start playback when prepared
     */
    public void prepare(boolean autoStart) {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.prepare(autoStart);
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            mLlamaPlayer.prepareAsync();
            if (autoStart) {
                // Note: LlamaPlayer will auto-start via its own prepareAsync with autoStart
            }
        }
    }
    
    /**
     * Starts or resumes playback.
     */
    public void start() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.start();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            mLlamaPlayer.start();
        }
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        mCurrentPosition = getCurrentPosition();
        
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.pause();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            mLlamaPlayer.pause();
        }
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param positionMs Target position in milliseconds
     */
    public void seekTo(int positionMs) {
        mCurrentPosition = positionMs;
        
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.seekTo(positionMs);
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            mLlamaPlayer.seekTo(positionMs);
        }
    }
    
    /**
     * Gets the current playback position.
     *
     * @return Current position in milliseconds
     */
    public int getCurrentPosition() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            return mNativePlayer.getCurrentPosition();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            return (int) mLlamaPlayer.getCurrentPosition();
        }
        return mCurrentPosition;
    }
    
    /**
     * Gets the duration of the current song.
     *
     * @return Duration in milliseconds
     */
    public int getDuration() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            return mNativePlayer.getDuration();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            return (int) mLlamaPlayer.getDuration();
        }
        return 0;
    }
    
    /**
     * Checks if playback is active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            return mNativePlayer.isPlaying();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            return mLlamaPlayer.isPlaying();
        }
        return false;
    }
    
    /**
     * Checks if the player is prepared.
     *
     * @return True if prepared
     */
    public boolean isPrepared() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            return mNativePlayer.isPrepared();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            return mLlamaPlayer.isPrepared();
        }
        return false;
    }
    
    /**
     * Gets the audio session ID.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            return mNativePlayer.getAudioSessionId();
        } else if (mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null) {
            return mLlamaPlayer.getAudioSessionId();
        }
        return 0;
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * Only effective when LlamaPlayer is active.
     *
     * @param semitones The pitch shift amount
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.setPitch(semitones);
        }
    }
    
    /**
     * Sets the tempo multiplier.
     * Only effective when LlamaPlayer is active.
     *
     * @param tempo The tempo multiplier (0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.setTempo(tempo);
        }
    }
    
    /**
     * Updates playback parameters from EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(mContext);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        setPitch(semitones);
        setTempo(tempo);
    }
    
    /**
     * Sets the volume level for ducking.
     *
     * @param volume Volume level (0.0 to 1.0)
     */
    public void setVolume(float volume) {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.setVolume(volume);
        } else if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.setVolume(volume);
        }
    }
    
    /**
     * Ducks volume to 30% for transient audio focus loss.
     */
    public void duck() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.duck();
        } else if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.duck();
        }
    }
    
    /**
     * Restores volume to normal after ducking.
     */
    public void unduck() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.unduck();
        } else if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.unduck();
        }
    }
    
    /**
     * Checks if LlamaPlayer is available (pitch/tempo controls enabled).
     *
     * @return True if LlamaPlayer is active and ready
     */
    public boolean isLlamaPlayerAvailable() {
        return mActivePlayer == ActivePlayer.LLAMA && mLlamaPlayer != null && mLlamaPlayer.isPrepared();
    }
    
    /**
     * Gets the currently active player type.
     *
     * @return The active player (NATIVE or LLAMA)
     */
    @NonNull
    public ActivePlayer getActivePlayer() {
        return mActivePlayer;
    }
    
    /**
     * Stops playback and resets the bridge.
     */
    public void stop() {
        if (mActivePlayer == ActivePlayer.NATIVE) {
            mNativePlayer.stop();
        } else if (mLlamaPlayer != null && mActivePlayer == ActivePlayer.LLAMA) {
            mLlamaPlayer.stop();
        }
    }
    
    /**
     * Releases all resources.
     */
    public void release() {
        mNativePlayer.release();
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.release();
            mLlamaPlayer = null;
        }
        
        if (mDecoderManager != null) {
            mDecoderManager.release();
            mDecoderManager = null;
        }
        
        mListener = null;
        Log.d(TAG, "AudioPlayerBridge released");
    }
    
    // ========================================================================
    // LlamaPlayer Background Initialization (Phase 2)
    // ========================================================================
    
    /**
     * Starts background initialization of LlamaPlayer.
     * This runs without blocking the UI or NativeMediaPlayer playback.
     *
     * @param filePath The current song file path
     */
    private void startLlamaPlayerBackgroundInit(@NonNull String filePath) {
        if (mLlamaInitStarted) {
            Log.d(TAG, "LlamaPlayer init already started, skipping");
            return;
        }
        
        if (!SoundTouch.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available, LlamaPlayer will not be initialized");
            notifyLlamaUnavailable();
            return;
        }
        
        mLlamaInitStarted = true;
        
        // Delay initialization slightly to let NativeMediaPlayer start first
        mMainHandler.postDelayed(() -> {
            Log.d(TAG, "Starting background LlamaPlayer initialization for: " + filePath);
            initializeLlamaPlayerInBackground(filePath);
        }, LLAMA_INIT_DELAY_MS);
    }
    
    /**
     * Initializes LlamaPlayer on a background thread.
     */
    private void initializeLlamaPlayerInBackground(@NonNull String filePath) {
        new Thread(() -> {
            try {
                Log.d(TAG, "Background thread: Creating LlamaPlayer");
                
                // Create LlamaPlayer
                LlamaPlayer llamaPlayer = new LlamaPlayer(mContext);
                DecoderManager decoderManager = new DecoderManager();
                
                // Initialize decoder manager to get format info
                if (!decoderManager.initialize(filePath, 0, 0)) {
                    Log.e(TAG, "Failed to initialize DecoderManager for LlamaPlayer");
                    notifyLlamaUnavailable();
                    return;
                }
                
                // Wait for decoder to provide format info
                int retryCount = 0;
                short[] tempBuffer = new short[8192];
                while (decoderManager.getSampleRate() <= 0 && retryCount < 20) {
                    int frames = decoderManager.read(tempBuffer, 4096);
                    if (frames > 0) break;
                    try { Thread.sleep(100); } catch (InterruptedException e) { break; }
                    retryCount++;
                }
                
                if (decoderManager.getSampleRate() <= 0) {
                    Log.e(TAG, "Failed to get audio format for LlamaPlayer");
                    decoderManager.release();
                    notifyLlamaUnavailable();
                    return;
                }
                
                mSampleRate = decoderManager.getSampleRate();
                mChannels = decoderManager.getChannels();
                
                // Set up LlamaPlayer listener
                llamaPlayer.setListener(new LlamaPlayerListener());
                
                // Set pitch and tempo if already set
                llamaPlayer.setPitch(mCurrentPitch);
                llamaPlayer.setTempo(mCurrentTempo);
                
                // Store references
                synchronized (mTransitionLock) {
                    mLlamaPlayer = llamaPlayer;
                    mDecoderManager = decoderManager;
                }
                
                // Load the song in LlamaPlayer (prepares in background)
                llamaPlayer.reset();
                llamaPlayer.setDataSource(filePath);
                llamaPlayer.prepareAsync();
                
                Log.d(TAG, "LlamaPlayer background initialization started, waiting for onPrepared");
                
            } catch (Exception e) {
                Log.e(TAG, "Failed to initialize LlamaPlayer in background", e);
                notifyLlamaUnavailable();
            }
        }, "LlamaPlayer-BgInit").start();
    }
    
    /**
     * Notifies listener that LlamaPlayer is unavailable.
     */
    private void notifyLlamaUnavailable() {
        mMainHandler.post(() -> {
            if (mListener != null) {
                // LlamaPlayer unavailable, but NativeMediaPlayer continues to work
                Log.d(TAG, "LlamaPlayer unavailable, continuing with NativeMediaPlayer only");
            }
        });
    }
    
    // ========================================================================
    // Seamless Transition (Phase 3)
    // ========================================================================
    
    /**
     * Initiates seamless transition from NativeMediaPlayer to LlamaPlayer.
     * Called when LlamaPlayer is fully prepared and ready.
     */
    private void initiateSeamlessTransition() {
        if (!mTransitionInProgress.compareAndSet(false, true)) {
            Log.d(TAG, "Transition already in progress, skipping");
            return;
        }
        
        Log.d(TAG, "===== INITIATING SEAMLESS TRANSITION to LlamaPlayer =====");
        
        mMainHandler.post(() -> {
            if (mListener != null) {
                mListener.onTransitionProgress(10);
            }
        });
        
        synchronized (mTransitionLock) {
            if (mLlamaPlayer == null || !mLlamaPlayer.isPrepared()) {
                Log.w(TAG, "LlamaPlayer not ready for transition");
                mTransitionInProgress.set(false);
                return;
            }
            
            // Capture current playback state from NativeMediaPlayer
            mWasPlayingBeforeTransition = mNativePlayer.isPlaying();
            mCurrentPosition = mNativePlayer.getCurrentPosition();
            
            Log.d(TAG, "Transition: capturing state - playing=" + mWasPlayingBeforeTransition + 
                  ", position=" + mCurrentPosition + "ms");
            
            mMainHandler.post(() -> {
                if (mListener != null) {
                    mListener.onTransitionProgress(30);
                }
            });
            
            // Step 1: Pause NativeMediaPlayer (but don't release)
            if (mWasPlayingBeforeTransition) {
                mNativePlayer.pause();
            }
            
            mMainHandler.post(() -> {
                if (mListener != null) {
                    mListener.onTransitionProgress(50);
                }
            });
            
            // Step 2: Seek LlamaPlayer to the same position
            if (mCurrentPosition > 0 && mCurrentPosition < getDuration()) {
                // Use DecoderManager prefill for gap-free seek
                if (mDecoderManager != null && mDecoderManager.isReady()) {
                    final int seekPosition = mCurrentPosition;
                    final boolean wasPlaying = mWasPlayingBeforeTransition;
                    
                    mDecoderManager.startPrefill(seekPosition, new DecoderManager.PrefillCallback() {
                        @Override
                        public void onPrefillReady(@NonNull short[] buffer, int frames, int sequence) {
                            if (mLlamaPlayer != null) {
                                mLlamaPlayer.seekTo(seekPosition, buffer, frames);
                                completeTransition(wasPlaying);
                            } else {
                                completeTransition(wasPlaying);
                            }
                        }
                    });
                } else {
                    mLlamaPlayer.seekTo(mCurrentPosition);
                    completeTransition(mWasPlayingBeforeTransition);
                }
            } else {
                completeTransition(mWasPlayingBeforeTransition);
            }
            
            mMainHandler.post(() -> {
                if (mListener != null) {
                    mListener.onTransitionProgress(70);
                }
            });
        }
    }
    
    /**
     * Completes the transition to LlamaPlayer.
     *
     * @param shouldPlay True if playback should resume
     */
    private void completeTransition(boolean shouldPlay) {
        synchronized (mTransitionLock) {
            mActivePlayer = ActivePlayer.LLAMA;
            
            if (shouldPlay && mLlamaPlayer != null) {
                mLlamaPlayer.start();
                Log.d(TAG, "Transition: playback resumed on LlamaPlayer");
            }
            
            // Notify listeners
            if (mListener != null) {
                mMainHandler.post(() -> {
                    mListener.onLlamaPlayerAvailable();
                    mListener.onTransitionProgress(100);
                    mListener.onTransitionComplete();
                    mListener.onStateChanged(shouldPlay, true);
                    
                    // Send audio session for equalizer
                    if (mLlamaPlayer != null) {
                        mListener.onAudioSessionAvailable(mLlamaPlayer.getAudioSessionId());
                    }
                });
            }
            
            mTransitionInProgress.set(false);
            
            Log.d(TAG, "===== TRANSITION COMPLETE - LlamaPlayer now active =====");
        }
    }
    
    // ========================================================================
    // NativeMediaPlayer Listener
    // ========================================================================
    
    /**
     * Listener for NativeMediaPlayer events.
     * Forwards events to the unified listener while tracking state for transition.
     */
    private class NativeMediaPlayerListener implements NativeMediaPlayer.Listener {
        
        @Override
        public void onPrepared() {
            Log.d(TAG, "NativeMediaPlayer: onPrepared");
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onPrepared());
            }
            
            // Notify audio session
            int sessionId = mNativePlayer.getAudioSessionId();
            if (sessionId > 0 && mListener != null) {
                mMainHandler.post(() -> mListener.onAudioSessionAvailable(sessionId));
            }
        }
        
        @Override
        public void onCompletion() {
            Log.d(TAG, "NativeMediaPlayer: onCompletion");
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onCompletion());
            }
        }
        
        @Override
        public void onPositionUpdate(long positionMs) {
            mCurrentPosition = (int) positionMs;
            if (mListener != null && mActivePlayer == ActivePlayer.NATIVE) {
                mMainHandler.post(() -> mListener.onPositionUpdate(positionMs));
            }
        }
        
        @Override
        public void onError(String error) {
            Log.e(TAG, "NativeMediaPlayer error: " + error);
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onError(error));
            }
        }
        
        @Override
        public void onAudioSessionAvailable(int sessionId) {
            // Handled in onPrepared
        }
        
        @Override
        public void onStateChanged(NativeMediaPlayer.State newState, NativeMediaPlayer.State oldState) {
            if (mListener != null && mActivePlayer == ActivePlayer.NATIVE) {
                boolean isPlaying = (newState == NativeMediaPlayer.State.STARTED);
                boolean isPrepared = (newState == NativeMediaPlayer.State.PREPARED || 
                                      newState == NativeMediaPlayer.State.STARTED ||
                                      newState == NativeMediaPlayer.State.PAUSED);
                mMainHandler.post(() -> mListener.onStateChanged(isPlaying, isPrepared));
            }
        }
    }
    
    // ========================================================================
    // LlamaPlayer Listener
    // ========================================================================
    
    /**
     * Listener for LlamaPlayer events.
     * When LlamaPlayer is prepared, initiates seamless transition.
     */
    private class LlamaPlayerListener implements LlamaPlayer.PlaybackListener {
        
        private boolean mHasTransitioned = false;
        
        @Override
        public void onStateChanged(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
            Log.d(TAG, "LlamaPlayer state: " + oldState + " -> " + newState);
            
            if (newState == LlamaPlayer.State.PREPARED && !mHasTransitioned) {
                // LlamaPlayer is ready! Initiate seamless transition
                mHasTransitioned = true;
                initiateSeamlessTransition();
            }
            
            if (mActivePlayer == ActivePlayer.LLAMA && mListener != null) {
                boolean isPlaying = (newState == LlamaPlayer.State.STARTED);
                boolean isPrepared = (newState == LlamaPlayer.State.PREPARED || 
                                      newState == LlamaPlayer.State.STARTED ||
                                      newState == LlamaPlayer.State.PAUSED);
                mMainHandler.post(() -> mListener.onStateChanged(isPlaying, isPrepared));
            }
        }
        
        @Override
        public void onPrepared() {
            // Handled in onStateChanged
        }
        
        @Override
        public void onCompletion() {
            if (mActivePlayer == ActivePlayer.LLAMA && mListener != null) {
                mMainHandler.post(() -> mListener.onCompletion());
            }
        }
        
        @Override
        public void onPositionUpdate(long positionMs) {
            mCurrentPosition = (int) positionMs;
            if (mActivePlayer == ActivePlayer.LLAMA && mListener != null) {
                mMainHandler.post(() -> mListener.onPositionUpdate(positionMs));
            }
        }
        
        @Override
        public void onError(String error) {
            Log.e(TAG, "LlamaPlayer error: " + error);
            
            // If LlamaPlayer fails after transition, fall back to NativeMediaPlayer
            if (mActivePlayer == ActivePlayer.LLAMA) {
                Log.w(TAG, "LlamaPlayer failed, falling back to NativeMediaPlayer");
                fallbackToNative();
            }
            
            if (mListener != null) {
                mMainHandler.post(() -> mListener.onError(error));
            }
        }
        
        /**
         * Fall back to NativeMediaPlayer if LlamaPlayer fails.
         */
        private void fallbackToNative() {
            synchronized (mTransitionLock) {
                int savedPosition = mCurrentPosition;
                boolean wasPlaying = (mActivePlayer == ActivePlayer.LLAMA && 
                                     mLlamaPlayer != null && mLlamaPlayer.isPlaying());
                
                mActivePlayer = ActivePlayer.NATIVE;
                
                if (wasPlaying && savedPosition > 0) {
                    mNativePlayer.seekTo(savedPosition);
                    mNativePlayer.start();
                }
                
                Log.d(TAG, "Fell back to NativeMediaPlayer at position " + savedPosition);
            }
        }
    }
}