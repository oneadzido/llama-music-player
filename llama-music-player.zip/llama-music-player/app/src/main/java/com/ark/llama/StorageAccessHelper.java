package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Centralized helper for Storage Access Framework (SAF) operations.
 * 
 * <p>This class provides a complete solution for managing document URIs,
 * persisting folder permissions, and resolving file paths to URIs for
 * scoped storage access on Android 10+.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Persistent storage of folder permissions across app restarts</li>
 *   <li>Path-to-URI resolution for files in imported folders</li>
 *   <li>Permission reacquisition for existing URIs</li>
 *   <li>Validation of write permissions for URIs</li>
 *   <li>Folder path extraction from URIs</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class StorageAccessHelper {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "StorageAccessHelper";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key prefix for storing folder URI to path mappings. */
    private static final String KEY_FOLDER_URI_PREFIX = "folder_uri_";
    
    /** Key prefix for storing path to URI mappings. */
    private static final String KEY_PATH_URI_PREFIX = "path_uri_";
    
    /** Set of known folder URI strings. */
    private static final String KEY_KNOWN_FOLDER_URIS = "known_folder_uris";
    
    /** Intent flags for taking URI permissions. */
    private static final int URI_PERMISSION_FLAGS = 
        Intent.FLAG_GRANT_READ_URI_PERMISSION | 
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static StorageAccessHelper sInstance;
    
    /** Application context. */
    @NonNull
    private final Context mContext;
    
    /** SharedPreferences for persistent storage. */
    @NonNull
    private final SharedPreferences mPrefs;
    
    /**
     * Private constructor for singleton pattern.
     *
     * @param context Application context
     */
    private StorageAccessHelper(@NonNull Context context) {
        mContext = context.getApplicationContext();
        mPrefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    /**
     * Returns the singleton instance of StorageAccessHelper.
     *
     * @param context Application context
     * @return The singleton instance
     */
    @NonNull
    public static synchronized StorageAccessHelper getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new StorageAccessHelper(context);
        }
        return sInstance;
    }
    
    // ========================================================================
    // Folder Permission Management
    // ========================================================================
    
    /**
     * Stores a folder URI permission and maps it to its file path.
     *
     * @param folderUri The folder URI from SAF
     * @param folderPath The absolute file path of the folder
     * @return True if the permission was stored successfully
     */
    public boolean storeFolderPermission(@NonNull final Uri folderUri, 
                                          @Nullable final String folderPath) {
        final String uriString = folderUri.toString();
        
        try {
            // Take persistable URI permission
            mContext.getContentResolver().takePersistableUriPermission(
                folderUri, URI_PERMISSION_FLAGS);
            
            // Store URI to path mapping
            final SharedPreferences.Editor editor = mPrefs.edit();
            editor.putString(KEY_FOLDER_URI_PREFIX + uriString, folderPath);
            
            // Store path to URI mapping if path is available
            if (folderPath != null) {
                editor.putString(KEY_PATH_URI_PREFIX + folderPath, uriString);
            }
            
            // Add to known folder URIs set
            final Set<String> knownUris = getKnownFolderUris();
            knownUris.add(uriString);
            editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
            editor.apply();
            
            Log.d(TAG, "Stored folder permission for: " + folderPath);
            return true;
            
        } catch (SecurityException e) {
            Log.e(TAG, "Failed to take persistable URI permission", e);
            return false;
        }
    }
    
    /**
     * Removes a folder permission mapping.
     *
     * @param folderUri The folder URI to remove
     */
    public void removeFolderPermission(@NonNull final Uri folderUri) {
        final String uriString = folderUri.toString();
        final String folderPath = getFolderPathFromUri(folderUri);
        
        // Remove mappings
        final SharedPreferences.Editor editor = mPrefs.edit();
        editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
        if (folderPath != null) {
            editor.remove(KEY_PATH_URI_PREFIX + folderPath);
        }
        
        // Remove from known URIs set
        final Set<String> knownUris = getKnownFolderUris();
        knownUris.remove(uriString);
        editor.putStringSet(KEY_KNOWN_FOLDER_URIS, knownUris);
        editor.apply();
        
        Log.d(TAG, "Removed folder permission for: " + folderPath);
    }
    
    /**
     * Removes all stored folder permissions.
     */
    public void clearAll() {
        final SharedPreferences.Editor editor = mPrefs.edit();
        final Set<String> knownUris = getKnownFolderUris();
        
        for (String uriString : knownUris) {
            editor.remove(KEY_FOLDER_URI_PREFIX + uriString);
            final String folderPath = getFolderPathFromUri(Uri.parse(uriString));
            if (folderPath != null) {
                editor.remove(KEY_PATH_URI_PREFIX + folderPath);
            }
        }
        
        editor.remove(KEY_KNOWN_FOLDER_URIS);
        editor.apply();
        Log.d(TAG, "Cleared all folder permissions");
    }
    
    /**
     * Gets the set of known folder URIs.
     *
     * @return Set of folder URI strings
     */
    @NonNull
    private Set<String> getKnownFolderUris() {
        final Set<String> saved = mPrefs.getStringSet(KEY_KNOWN_FOLDER_URIS, null);
        final Set<String> result = new HashSet<String>();
        if (saved != null) {
            result.addAll(saved);
        }
        return result;
    }
    
    /**
     * Gets the folder URI for a given file path.
     *
     * @param filePath The absolute file path
     * @return The folder URI, or null if not found
     */
    @Nullable
    public Uri getFolderUri(@NonNull final String filePath) {
        // Find the longest matching parent folder
        String bestMatch = null;
        String bestUri = null;
        
        final Map<String, ?> allEntries = mPrefs.getAll();
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            final String key = entry.getKey();
            if (key.startsWith(KEY_PATH_URI_PREFIX) && entry.getValue() instanceof String) {
                final String storedPath = key.substring(KEY_PATH_URI_PREFIX.length());
                if (filePath.startsWith(storedPath) && (bestMatch == null || storedPath.length() > bestMatch.length())) {
                    bestMatch = storedPath;
                    bestUri = (String) entry.getValue();
                }
            }
        }
        
        return bestUri != null ? Uri.parse(bestUri) : null;
    }
    
    /**
     * Gets a writeable URI for a file.
     *
     * @param filePath The absolute file path
     * @return The document URI, or null if not found
     */
    @Nullable
    public Uri getWriteableUriForFile(@NonNull final String filePath) {
        final Uri folderUri = getFolderUri(filePath);
        if (folderUri == null) {
            Log.d(TAG, "No folder URI found for: " + filePath);
            return null;
        }
        
        // Get the relative path within the folder
        final String folderPath = getFolderPathFromUri(folderUri);
        if (folderPath == null) {
            return null;
        }
        
        final String relativePath = filePath.substring(folderPath.length() + 1);
        return getDocumentUriForFile(folderUri, relativePath);
    }
    
    /**
     * Gets a document URI for a file within a folder.
     *
     * @param folderUri The parent folder URI
     * @param relativePath The relative path from the folder
     * @return The document URI for the file
     */
    @Nullable
    private Uri getDocumentUriForFile(@NonNull final Uri folderUri, 
                                      @NonNull final String relativePath) {
        try {
            DocumentFile current = DocumentFile.fromTreeUri(mContext, folderUri);
            if (current == null || !current.canRead()) {
                return null;
            }
            
            final String[] parts = relativePath.split("/");
            for (String part : parts) {
                final DocumentFile child = current.findFile(part);
                if (child == null) {
                    return null;
                }
                current = child;
            }
            
            return current.getUri();
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to get document URI", e);
            return null;
        }
    }
    
    /**
     * Takes persistable permission for a file URI.
     *
     * @param fileUri The file URI
     * @return True if permission was taken
     */
    public boolean takeFilePermission(@NonNull final Uri fileUri) {
        try {
            mContext.getContentResolver().takePersistableUriPermission(fileUri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Took persistable permission for: " + fileUri);
            return true;
        } catch (SecurityException e) {
            Log.e(TAG, "Failed to take persistable permission", e);
            return false;
        }
    }
    
    /**
     * Reacquires permission for a URI.
     *
     * @param uri The URI to reacquire permission for
     * @return True if permission was reacquired
     */
    public boolean reacquirePermission(@NonNull final Uri uri) {
        try {
            // Check if we already have permission
            try {
                final DocumentFile doc = DocumentFile.fromSingleUri(mContext, uri);
                if (doc != null && doc.canWrite()) {
                    Log.d(TAG, "Already have write permission for: " + uri);
                    return true;
                }
            } catch (Exception e) {
                Log.w(TAG, "Permission check failed, attempting to reacquire", e);
            }
            
            // Try to reacquire
            mContext.getContentResolver().takePersistableUriPermission(uri, URI_PERMISSION_FLAGS);
            Log.d(TAG, "Reacquired permission for: " + uri);
            return true;
            
        } catch (SecurityException e) {
            Log.e(TAG, "Failed to reacquire permission", e);
            return false;
        }
    }
    
    /**
     * Validates that we have write permission for a URI.
     *
     * @param uri The URI to validate
     * @return True if we have write permission
     */
    public boolean validatePermission(@NonNull final Uri uri) {
        try {
            final DocumentFile doc = DocumentFile.fromSingleUri(mContext, uri);
            return doc != null && doc.canWrite();
        } catch (Exception e) {
            Log.w(TAG, "Permission validation failed", e);
            return false;
        }
    }
    
    // ========================================================================
    // URI Path Extraction Methods
    // ========================================================================
    
    /**
     * Extracts the file system path from a folder URI.
     *
     * @param uri The folder URI (can be null)
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    public String getFolderPathFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }
        
        // First check stored mapping
        final String storedPath = mPrefs.getString(KEY_FOLDER_URI_PREFIX + uri.toString(), null);
        if (storedPath != null) {
            return storedPath;
        }
        
        // Fall back to parsing the URI
        final String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int start = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(start);
                if (subPath.contains("%2F")) {
                    subPath = subPath.replace("%2F", "/");
                }
                if (subPath.contains("/tree/")) {
                    subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                }
                if (subPath.contains("/document/")) {
                    subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                }
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) {
                    path = path.substring(0, path.length() - 1);
                }
                return path;
            } catch (Exception e) {
                Log.e(TAG, "Failed to extract folder path", e);
                return null;
            }
        }
        return null;
    }
    
    /**
     * Gets the display name of a folder from its URI.
     *
     * @param uri The folder URI (can be null)
     * @return The folder name, or null if extraction fails
     */
    @Nullable
    public String getFolderNameFromUri(@Nullable final Uri uri) {
        if (uri == null) {
            return null;
        }
        
        String name = null;
        Cursor cursor = null;
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx != -1) {
                    name = cursor.getString(idx);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getFolderName error", e);
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.w(TAG, "Failed to close folder name cursor", e);
                }
            }
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) {
                name = name.substring(name.indexOf(":") + 1);
            }
        }
        
        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
    
    /**
     * Gets the storage type indicator for a folder URI.
     *
     * @param uriString The folder URI string
     * @return "[Internal]" for internal storage, "[SD Card]" for external storage, or empty string
     */
    @NonNull
    public String getStorageType(@NonNull final String uriString) {
        final String uriLower = uriString.toLowerCase();
        
        if (uriLower.contains("primary") || uriLower.contains("emulated")) {
            return " [Internal]";
        } else if (uriLower.contains("external") || uriLower.contains("sdcard") || 
                   uriLower.contains("extsdcard") || uriLower.contains("extsd") || 
                   uriLower.matches(".*[0-9a-f]{4}-[0-9a-f]{4}.*")) {
            return " [SD Card]";
        }
        
        return "";
    }
    
    // ========================================================================
    // Scanning Methods
    // ========================================================================
    
    /**
     * Scans a folder for audio files using DocumentFile.
     *
     * @param folderUri The folder URI to scan
     * @return List of DocumentFile objects representing audio files
     */
    @NonNull
    public List<DocumentFile> scanFolderForAudioFiles(@NonNull final Uri folderUri) {
        final List<DocumentFile> audioFiles = new ArrayList<DocumentFile>();
        
        try {
            final DocumentFile folder = DocumentFile.fromTreeUri(mContext, folderUri);
            if (folder == null || !folder.exists() || !folder.canRead()) {
                Log.w(TAG, "Cannot read folder: " + folderUri);
                return audioFiles;
            }
            
            scanDocumentFileForAudioFiles(folder, audioFiles);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to scan folder", e);
        }
        
        return audioFiles;
    }
    
    /**
     * Recursively scans a DocumentFile for audio files.
     *
     * @param document The DocumentFile to scan
     * @param results The list to add audio files to
     */
    private void scanDocumentFileForAudioFiles(@NonNull final DocumentFile document, 
                                               @NonNull final List<DocumentFile> results) {
        if (document.isFile() && isAudioFile(document.getName())) {
            results.add(document);
        } else if (document.isDirectory()) {
            final DocumentFile[] children = document.listFiles();
            for (DocumentFile child : children) {
                if (child != null) {
                    scanDocumentFileForAudioFiles(child, results);
                }
            }
        }
    }
    
    /**
     * Checks if a filename indicates an audio file.
     *
     * @param name The filename (can be null)
     * @return True if the file is an audio file
     */
    private boolean isAudioFile(@Nullable final String name) {
        if (name == null) {
            return false;
        }
        final String lower = name.toLowerCase();
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || 
               lower.endsWith(".ogg") || lower.endsWith(".m4a") || 
               lower.endsWith(".mp4") || lower.endsWith(".wav");
    }
}