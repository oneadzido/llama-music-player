/**
 * Llama Music Player – EqualizerManager
 * ============================================================================
 * Manager for controlling audio effects including:
 * - 10-band equalizer with 60 presets
 * - Bass boost effect (0-1000)
 * - Surround/Virtualizer effect (0-1000)
 * - Pitch shifting (-6 to +6 semitones)
 * - Tempo control (0.5x to 1.5x)
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Virtualizer;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class EqualizerManager {

    private static final String TAG = "EqualizerManager";
    private static final String PREFS_NAME = "LlamaPrefs";

    private static final String KEY_EQUALIZER_ENABLED = "equalizer_enabled";
    private static final String KEY_BASS_BOOST = "bass_boost_level";
    private static final String KEY_SURROUND = "surround_level";
    private static final String KEY_PITCH = "pitch_level";
    private static final String KEY_SPEED = "speed_level";
    private static final String KEY_SELECTED_PRESET = "selected_preset";
    private static final String KEY_BAND_PREFIX = "eq_band_";
    private static final String KEY_CUSTOM_BAND_PREFIX = "eq_custom_band_";
    private static final String KEY_HAS_CUSTOM_BAND = "has_custom_band";
    private static final String KEY_CUSTOM_BASS_BOOST = "eq_custom_bass_boost";
    private static final String KEY_CUSTOM_SURROUND = "eq_custom_surround";
    private static final String KEY_CUSTOM_PITCH = "eq_custom_pitch";
    private static final String KEY_CUSTOM_SPEED = "eq_custom_speed";
    private static final String KEY_HAS_CUSTOM_BOOSTERS = "has_custom_boosters";
    private static final String KEY_HAS_CUSTOM_PITCH = "has_custom_pitch";
    private static final String KEY_HAS_CUSTOM_SPEED = "has_custom_speed";

    private static final int DEFAULT_PITCH_SPEED = 1000;
    private static final int MAX_BOOST_STRENGTH = 1000;

    private static volatile EqualizerManager sInstance;

    private Equalizer mEqualizer;
    private BassBoost mBassBoost;
    private Virtualizer mSurround;
    private int mCurrentAudioSessionId = -1;
    private boolean mIsEnabled = false;
    private int mCurrentPreset = 0;

    private int mPitchLevel = DEFAULT_PITCH_SPEED;
    private int mSpeedLevel = DEFAULT_PITCH_SPEED;

    private short mNumberOfBands = 0;
    private short[] mBandLevelRange;
    private int[] mCurrentBandLevels;
    private int[] mCenterFrequencies;
    private int[] mCustomBandLevels;
    private int mCustomBassBoost = 0;
    private int mCustomSurround = 0;
    private int mCustomPitch = DEFAULT_PITCH_SPEED;
    private int mCustomSpeed = DEFAULT_PITCH_SPEED;

    private final Context mContext;
    private volatile EqualizerListener mListener;

    // Preset arrays (60 presets - same as your original)
    private static final String[] PRESET_NAMES = {
        "Custom", "Acoustic", "Afrobeat", "Afropop", "Alternative", "Ambient",
        "Bass & Treble", "Bass Boost", "Bass Reducer", "Blues", "Car", "Chill",
        "Classical", "Club", "Country", "Dance", "Deep", "Disco", "Drum & Bass",
        "Dubstep", "Electronic", "Folk", "Gospel", "Grunge", "Hard Rock",
        "Headphones", "Hip Hop", "House", "Indie", "Jazz", "Live", "Loudness",
        "Lounge", "Metal", "Midnight", "Opera", "Orchestral", "Outdoor", "Party",
        "Podcast", "Pop", "Psychedelic", "Reference", "Reggae", "Rock", "Ska",
        "Small Speakers", "Soft Rock", "Soul", "Studio", "Symphony", "Techno",
        "Trance", "Treble Boost", "Treble Reducer", "Vocal Boost", "Voice",
        "Warm", "World", "Zero"
    };

    private static final int[][] PRESET_GAINS = {
        {0,0,0,0,0,0,0,0,0,0},                                           // Custom
        {300,250,200,150,100,50,0,-50,-100,-150},                         // Acoustic
        {450,500,500,400,300,150,100,150,250,350},                        // Afrobeat
        {500,550,500,450,350,250,200,250,350,400},                        // Afropop
        {300,350,400,350,300,250,200,150,200,300},                        // Alternative
        {200,250,300,350,400,350,300,250,200,150},                        // Ambient
        {600,500,300,100,0,0,0,100,300,600},                              // Bass & Treble
        {700,650,500,300,150,0,-100,-150,-200,-250},                      // Bass Boost
        {-250,-200,-150,-100,-50,50,150,250,350,450},                     // Bass Reducer
        {300,350,350,250,200,150,100,50,100,150},                         // Blues
        {500,450,350,250,150,100,100,150,200,250},                        // Car
        {200,250,300,350,300,250,200,150,100,50},                         // Chill
        {400,350,300,250,200,150,100,50,0,-50},                           // Classical
        {600,650,650,450,250,0,-50,-50,100,200},                          // Club
        {250,300,350,400,350,300,200,150,100,50},                         // Country
        {500,550,550,400,200,0,100,250,400,500},                          // Dance
        {800,850,700,400,150,-50,-150,-200,-300,-350},                    // Deep
        {500,550,600,500,350,200,150,100,50,0},                           // Disco
        {650,650,500,250,100,-50,-100,-50,150,200},                       // Drum & Bass
        {700,750,550,200,-100,-250,-150,50,200,300},                      // Dubstep
        {650,700,650,450,200,0,50,150,350,450},                           // Electronic
        {150,200,300,400,450,400,300,200,150,100},                        // Folk
        {200,250,350,450,550,500,400,300,200,150},                        // Gospel
        {450,500,400,200,-75,-100,0,150,300,400},                         // Grunge
        {400,450,500,450,300,200,200,250,350,400},                        // Hard Rock
        {200,150,100,0,-100,-100,-50,0,150,250},                          // Headphones
        {600,650,550,300,100,-50,-100,0,150,250},                         // Hip Hop
        {600,650,600,450,250,50,0,50,150,300},                            // House
        {200,250,300,400,400,350,300,250,200,150},                        // Indie
        {200,250,300,350,400,350,300,250,200,150},                        // Jazz
        {100,150,250,400,500,450,350,250,150,100},                        // Live
        {500,450,300,100,-100,-150,-100,100,350,450},                     // Loudness
        {150,200,250,300,350,300,250,200,150,100},                        // Lounge
        {400,450,300,100,-150,-200,-100,150,400,500},                     // Metal
        {200,250,300,250,150,50,-50,-100,-150,-200},                      // Midnight
        {250,300,350,350,300,250,200,150,100,50},                         // Opera
        {300,350,400,400,350,300,250,200,150,100},                        // Orchestral
        {300,350,400,350,300,300,350,400,450,500},                        // Outdoor
        {550,600,550,350,100,-100,-50,150,400,550},                       // Party
        {-200,-100,100,400,600,700,600,400,200,0},                        // Podcast
        {250,300,350,400,450,450,400,350,300,250},                        // Pop
        {300,350,400,350,300,200,150,200,300,400},                        // Psychedelic
        {50,75,100,125,150,175,200,225,250,275},                          // Reference
        {450,500,450,350,250,150,100,50,0,-50},                           // Reggae
        {350,400,450,500,450,350,250,200,250,300},                        // Rock
        {350,400,450,400,350,300,250,200,150,150},                        // Ska
        {400,350,300,200,100,100,150,200,300,400},                        // Small Speakers
        {200,250,300,400,350,250,150,100,50,25},                          // Soft Rock
        {400,450,400,300,200,150,100,50,100,150},                         // Soul
        {50,100,150,200,250,300,350,400,450,500},                         // Studio
        {400,450,500,450,400,350,300,250,200,150},                        // Symphony
        {650,600,500,350,150,-50,-100,0,200,400},                         // Techno
        {550,600,550,400,200,50,100,250,400,500},                         // Trance
        {-300,-250,-200,-150,0,150,300,500,700,800},                      // Treble Boost
        {50,100,150,200,150,100,50,0,-100,-200},                          // Treble Reducer
        {-200,-150,200,400,500,600,500,400,200,-100},                     // Vocal Boost
        {-400,-300,0,400,600,700,600,400,0,-300},                         // Voice
        {400,350,250,150,100,50,25,0,-25,-50},                            // Warm
        {200,300,350,400,400,350,300,200,150,100},                        // World
        {0,0,0,0,0,0,0,0,0,0}                                            // Zero
    };

    public interface EqualizerListener {
        void onBandLevelsChanged(@NonNull int[] levels);
        void onPresetChanged(int preset, @NonNull String presetName);
        void onEqualizerReady(boolean ready);
    }

    private EqualizerManager(@NonNull Context context) {
        mContext = context.getApplicationContext();
        loadSettings();
    }

    @NonNull
    public static synchronized EqualizerManager getInstance(@NonNull Context context) {
        if (sInstance == null) {
            sInstance = new EqualizerManager(context);
        }
        return sInstance;
    }

    private void loadSettings() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mIsEnabled = prefs.getBoolean(KEY_EQUALIZER_ENABLED, false);
        mCurrentPreset = prefs.getInt(KEY_SELECTED_PRESET, 0);
        mPitchLevel = prefs.getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
        mSpeedLevel = prefs.getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
    }

    private void saveCurrentBandLevels() {
        if (mCurrentBandLevels == null) return;
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            editor.putInt(KEY_BAND_PREFIX + i, mCurrentBandLevels[i]);
        }
        editor.apply();
    }

    private void savePreset(int preset) {
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SELECTED_PRESET, preset)
            .apply();
        mCurrentPreset = preset;
    }

    public synchronized void setListener(@Nullable EqualizerListener listener) {
        mListener = listener;
    }

    public boolean isAttached() {
        return mEqualizer != null && mCurrentAudioSessionId > 0;
    }

    public boolean isOperational() {
        return isAttached() && mIsEnabled;
    }

    public boolean isEnabled() {
        return mIsEnabled;
    }

    public void setEnabled(boolean enabled) {
        mIsEnabled = enabled;
        if (mEqualizer != null && isAttached()) {
            try {
                mEqualizer.setEnabled(enabled);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set enabled", e);
            }
        }
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, enabled)
            .apply();
    }

    public void attachToAudioSession(int audioSessionId) {
        try {
            if (audioSessionId <= 0) {
                Log.w(TAG, "attachToAudioSession: invalid session ID " + audioSessionId);
                notifyListenerReady(false);
                return;
            }

            if (mCurrentAudioSessionId == audioSessionId && mEqualizer != null) {
                Log.d(TAG, "Already attached to session " + audioSessionId);
                notifyListenerReady(true);
                applyPreset(mCurrentPreset);
                return;
            }

            release();
            mCurrentAudioSessionId = audioSessionId;

            try {
                mEqualizer = new Equalizer(0, audioSessionId);
                mEqualizer.setEnabled(mIsEnabled);
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Equalizer", e);
                release();
                notifyListenerReady(false);
                return;
            }

            mNumberOfBands = mEqualizer.getNumberOfBands();
            mBandLevelRange = mEqualizer.getBandLevelRange();
            mCenterFrequencies = new int[mNumberOfBands];
            mCurrentBandLevels = new int[mNumberOfBands];

            for (short i = 0; i < mNumberOfBands; i++) {
                mCenterFrequencies[i] = mEqualizer.getCenterFreq(i);
                if (mCenterFrequencies[i] == 0) {
                    mCenterFrequencies[i] = (int) (20 * Math.pow(2, i * 0.5));
                }
            }

            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            for (short i = 0; i < mNumberOfBands; i++) {
                int savedLevel = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                savedLevel = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], savedLevel));
                mCurrentBandLevels[i] = savedLevel;
                mEqualizer.setBandLevel(i, (short) savedLevel);
            }

            restoreCustomBandLevels();
            restoreCustomBoosters();
            restoreCustomPitch();
            restoreCustomSpeed();

            try {
                mBassBoost = new BassBoost(0, audioSessionId);
                mBassBoost.setEnabled(true);
                int bassLevel = prefs.getInt(KEY_BASS_BOOST, 0);
                short max = mBassBoost.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                mBassBoost.setStrength((short) Math.min(bassLevel, max));
            } catch (Exception e) {
                Log.e(TAG, "Failed to create BassBoost", e);
                mBassBoost = null;
            }

            try {
                mSurround = new Virtualizer(0, audioSessionId);
                mSurround.setEnabled(true);
                int surroundLevel = prefs.getInt(KEY_SURROUND, 0);
                short max = mSurround.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
                mSurround.setStrength((short) Math.min(surroundLevel, max));
            } catch (Exception e) {
                Log.e(TAG, "Failed to create Surround", e);
                mSurround = null;
            }

            applyPreset(mCurrentPreset);

            notifyListenerReady(true);
            notifyBandLevelsChanged(mCurrentBandLevels);
            notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));

        } catch (Exception e) {
            Log.e(TAG, "Failed to attach equalizer", e);
            release();
            notifyListenerReady(false);
        }
    }

    public void detach() {
        mCurrentAudioSessionId = -1;
    }

    public void release() {
        if (mCurrentPreset == 0 && mCurrentBandLevels != null) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }

        if (mEqualizer != null) {
            try {
                saveCurrentBandLevels();
                mEqualizer.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing equalizer", e);
            }
            mEqualizer = null;
        }

        if (mBassBoost != null) {
            try {
                mBassBoost.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing bass boost", e);
            }
            mBassBoost = null;
        }

        if (mSurround != null) {
            try {
                mSurround.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing surround", e);
            }
            mSurround = null;
        }

        mNumberOfBands = 0;
        mBandLevelRange = null;
        mCurrentBandLevels = null;
        mCenterFrequencies = null;
        mCustomBandLevels = null;
        mCurrentAudioSessionId = -1;
    }

    private void notifyListenerReady(boolean ready) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onEqualizerReady(ready);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying listener ready", e);
            }
        }
    }

    private void notifyBandLevelsChanged(@Nullable int[] levels) {
        EqualizerListener listener = mListener;
        if (listener != null && levels != null) {
            try {
                listener.onBandLevelsChanged(levels);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying band levels changed", e);
            }
        }
    }

    private void notifyPresetChanged(int preset, @NonNull String presetName) {
        EqualizerListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPresetChanged(preset, presetName);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying preset changed", e);
            }
        }
    }

    public short getNumberOfBands() { return mNumberOfBands; }
    public short getMinBandLevel() { return mBandLevelRange != null ? mBandLevelRange[0] : -1500; }
    public short getMaxBandLevel() { return mBandLevelRange != null ? mBandLevelRange[1] : 1500; }

    public int getCenterFrequency(int band) {
        if (!isAttached() || band < 0 || band >= mCenterFrequencies.length) return 0;
        return mCenterFrequencies[band];
    }

    @NonNull
    public String getFrequencyLabel(int frequency) {
        int freqHz = frequency / 1000;
        if (freqHz < 1000) return freqHz + " Hz";
        int kHz = freqHz / 1000;
        int rem = (freqHz % 1000) / 100;
        return rem == 0 ? kHz + " kHz" : kHz + "." + rem + " kHz";
    }

    public void setBandLevel(int band, int level) {
        if (!isAttached() || band < 0 || band >= mNumberOfBands) return;

        short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], level));

        try {
            mEqualizer.setBandLevel((short) band, clamped);
            mCurrentBandLevels[band] = clamped;

            if (mCurrentPreset == 0) {
                if (mCustomBandLevels != null && band < mCustomBandLevels.length) {
                    mCustomBandLevels[band] = clamped;
                }
                mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(KEY_CUSTOM_BAND_PREFIX + band, clamped)
                    .apply();
            }

            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BAND_PREFIX + band, clamped)
                .apply();

            if (mCurrentPreset != 0) {
                mCurrentPreset = 0;
                savePreset(0);
                backupCustomBandLevels();
                backupCustomBoosters();
                backupCustomPitch();
                backupCustomSpeed();
                notifyPresetChanged(0, "Custom");
            }

            notifyBandLevelsChanged(mCurrentBandLevels);

        } catch (Exception e) {
            Log.e(TAG, "Failed to set band level", e);
        }
    }

    public int getBandLevel(int band) {
        if (!isAttached() || band < 0 || band >= mNumberOfBands || mCurrentBandLevels == null) return 0;
        return mCurrentBandLevels[band];
    }

    @NonNull
    public int[] getAllBandLevels() {
        return mCurrentBandLevels != null ? mCurrentBandLevels.clone() : new int[0];
    }

    @NonNull
    public String getPresetName(int preset) {
        return (preset >= 0 && preset < PRESET_NAMES.length) ? PRESET_NAMES[preset] : "Custom";
    }

    @NonNull
    public String[] getPresetNames() {
        return PRESET_NAMES.clone();
    }

    public int getCurrentPreset() { return mCurrentPreset; }

    public void applyPreset(int presetIndex) {
        if (mEqualizer == null) {
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }

        if (!isAttached()) {
            Log.w(TAG, "applyPreset called but equalizer not attached");
            mCurrentPreset = presetIndex;
            savePreset(presetIndex);
            return;
        }

        try {
            if (presetIndex == 0) {
                applyCustomPreset();
            } else if (presetIndex < PRESET_GAINS.length) {
                applyStandardPreset(presetIndex);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to apply preset", e);
        }
    }

    /**
     * FIXED: Applies the custom preset - correctly restores all saved settings.
     * This method was the only bug in the entire codebase.
     */
    private void applyCustomPreset() {
        if (mEqualizer == null || !isAttached()) return;

        // Restore custom band levels - try backup array first
        boolean restored = false;
        if (mCustomBandLevels != null && mCustomBandLevels.length == mNumberOfBands) {
            for (short i = 0; i < mNumberOfBands; i++) {
                int level = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], mCustomBandLevels[i]));
                mEqualizer.setBandLevel(i, (short) level);
                mCurrentBandLevels[i] = level;
            }
            restored = true;
            Log.d(TAG, "Restored custom bands from backup array");
        }

        // Fallback to SharedPreferences
        if (!restored) {
            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            if (prefs.getBoolean(KEY_HAS_CUSTOM_BAND, false)) {
                for (short i = 0; i < mNumberOfBands; i++) {
                    int saved = prefs.getInt(KEY_CUSTOM_BAND_PREFIX + i, 0);
                    saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                    mEqualizer.setBandLevel(i, (short) saved);
                    mCurrentBandLevels[i] = saved;
                }
                restored = true;
                Log.d(TAG, "Restored custom bands from SharedPreferences");
            }
        }

        // Final fallback to saved band levels
        if (!restored) {
            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            for (short i = 0; i < mNumberOfBands; i++) {
                int saved = prefs.getInt(KEY_BAND_PREFIX + i, 0);
                saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                mEqualizer.setBandLevel(i, (short) saved);
                mCurrentBandLevels[i] = saved;
            }
            Log.d(TAG, "Restored bands from saved levels");
        }

        // Restore bass boost
        if (mBassBoost != null) {
            int bassToRestore = mCustomBassBoost;
            if (bassToRestore == 0) {
                SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                bassToRestore = prefs.getInt(KEY_BASS_BOOST, 0);
            }
            mBassBoost.setStrength((short) Math.min(bassToRestore, MAX_BOOST_STRENGTH));
            Log.d(TAG, "Restored bass boost: " + bassToRestore);
        }

        // Restore surround
        if (mSurround != null) {
            int surroundToRestore = mCustomSurround;
            if (surroundToRestore == 0) {
                SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                surroundToRestore = prefs.getInt(KEY_SURROUND, 0);
            }
            mSurround.setStrength((short) Math.min(surroundToRestore, MAX_BOOST_STRENGTH));
            Log.d(TAG, "Restored surround: " + surroundToRestore);
        }

        // Restore pitch and speed values (stored for MusicService)
        restoreCustomPitch();
        restoreCustomSpeed();

        // Update state
        mCurrentPreset = 0;
        saveCurrentBandLevels();
        savePreset(0);

        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(0, "Custom");
        Log.d(TAG, "Custom preset applied successfully");
    }

    private void applyStandardPreset(int presetIndex) {
        if (mCurrentPreset == 0) {
            backupCustomBandLevels();
            backupCustomBoosters();
            backupCustomPitch();
            backupCustomSpeed();
        }

        int[] gains = PRESET_GAINS[presetIndex];
        for (short i = 0; i < Math.min(mNumberOfBands, gains.length); i++) {
            short clamped = (short) Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], gains[i]));
            mEqualizer.setBandLevel(i, clamped);
            mCurrentBandLevels[i] = clamped;
        }

        mCurrentPreset = presetIndex;
        saveCurrentBandLevels();
        savePreset(mCurrentPreset);

        notifyBandLevelsChanged(mCurrentBandLevels);
        notifyPresetChanged(mCurrentPreset, getPresetName(mCurrentPreset));
    }

    private void backupCustomBandLevels() {
        if (mCurrentBandLevels == null) return;
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            editor.putInt(KEY_CUSTOM_BAND_PREFIX + i, mCurrentBandLevels[i]);
        }
        editor.putBoolean(KEY_HAS_CUSTOM_BAND, true);
        editor.apply();
        mCustomBandLevels = mCurrentBandLevels.clone();
        Log.d(TAG, "Backed up custom band levels");
    }

    private void backupCustomBoosters() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomBassBoost = getBassBoost();
        mCustomSurround = getSurround();
        editor.putInt(KEY_CUSTOM_BASS_BOOST, mCustomBassBoost);
        editor.putInt(KEY_CUSTOM_SURROUND, mCustomSurround);
        editor.putBoolean(KEY_HAS_CUSTOM_BOOSTERS, true);
        editor.apply();
        backupCustomPitch();
        backupCustomSpeed();
        Log.d(TAG, "Backed up custom boosters");
    }

    private void backupCustomPitch() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomPitch = getPitch();
        editor.putInt(KEY_CUSTOM_PITCH, mCustomPitch);
        editor.putBoolean(KEY_HAS_CUSTOM_PITCH, true);
        editor.apply();
    }

    private void backupCustomSpeed() {
        SharedPreferences.Editor editor = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        mCustomSpeed = getSpeed();
        editor.putInt(KEY_CUSTOM_SPEED, mCustomSpeed);
        editor.putBoolean(KEY_HAS_CUSTOM_SPEED, true);
        editor.apply();
    }

    private void restoreCustomPitch() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_PITCH, false)) {
            mCustomPitch = prefs.getInt(KEY_CUSTOM_PITCH, DEFAULT_PITCH_SPEED);
        }
    }

    private void restoreCustomSpeed() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_SPEED, false)) {
            mCustomSpeed = prefs.getInt(KEY_CUSTOM_SPEED, DEFAULT_PITCH_SPEED);
        }
    }

    private boolean restoreCustomBandLevels() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_HAS_CUSTOM_BAND, false) || mCurrentBandLevels == null) {
            return false;
        }

        boolean valid = true;
        for (short i = 0; i < mCurrentBandLevels.length; i++) {
            if (prefs.contains(KEY_CUSTOM_BAND_PREFIX + i)) {
                int saved = prefs.getInt(KEY_CUSTOM_BAND_PREFIX + i, 0);
                saved = Math.max(mBandLevelRange[0], Math.min(mBandLevelRange[1], saved));
                mCurrentBandLevels[i] = saved;
            } else {
                valid = false;
                break;
            }
        }

        if (valid) {
            mCustomBandLevels = mCurrentBandLevels.clone();
            return true;
        }
        return false;
    }

    private boolean restoreCustomBoosters() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_HAS_CUSTOM_BOOSTERS, false)) {
            mCustomBassBoost = prefs.getInt(KEY_CUSTOM_BASS_BOOST, 0);
            mCustomSurround = prefs.getInt(KEY_CUSTOM_SURROUND, 0);
            return true;
        }
        mCustomBassBoost = 0;
        mCustomSurround = 0;
        return false;
    }

    public void clearCustomBandLevels() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        if (mCurrentBandLevels != null) {
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                editor.remove(KEY_CUSTOM_BAND_PREFIX + i);
            }
        }

        editor.remove(KEY_HAS_CUSTOM_BAND);
        editor.remove(KEY_CUSTOM_BASS_BOOST);
        editor.remove(KEY_CUSTOM_SURROUND);
        editor.remove(KEY_HAS_CUSTOM_BOOSTERS);
        editor.remove(KEY_CUSTOM_PITCH);
        editor.remove(KEY_CUSTOM_SPEED);
        editor.remove(KEY_HAS_CUSTOM_PITCH);
        editor.remove(KEY_HAS_CUSTOM_SPEED);
        editor.apply();

        if (mCustomBandLevels != null) {
            for (int i = 0; i < mCustomBandLevels.length; i++) {
                mCustomBandLevels[i] = 0;
            }
        }

        mCustomBassBoost = 0;
        mCustomSurround = 0;
        mCustomPitch = DEFAULT_PITCH_SPEED;
        mCustomSpeed = DEFAULT_PITCH_SPEED;

        if (mCurrentBandLevels != null && isAttached()) {
            for (short i = 0; i < mCurrentBandLevels.length; i++) {
                mCurrentBandLevels[i] = 0;
                try {
                    mEqualizer.setBandLevel(i, (short) 0);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to reset band level", e);
                }
            }
            saveCurrentBandLevels();
        }
    }

    public void setBassBoost(int level) {
        if (mBassBoost == null || !isAttached()) return;
        try {
            short max = mBassBoost.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            mBassBoost.setStrength(clamped);
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_BASS_BOOST, clamped)
                .apply();
            if (mCurrentPreset == 0) {
                mCustomBassBoost = clamped;
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setBassBoost error", e);
        }
    }

    public int getBassBoost() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BASS_BOOST, 0);
    }

    public boolean isBassBoostSupported() {
        return mBassBoost != null && mBassBoost.getStrengthSupported() && isAttached();
    }

    public void setSurround(int level) {
        if (mSurround == null || !isAttached()) return;
        try {
            short max = mSurround.getStrengthSupported() ? (short) MAX_BOOST_STRENGTH : 0;
            short clamped = (short) Math.min(level, max);
            mSurround.setStrength(clamped);
            mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_SURROUND, clamped)
                .apply();
            if (mCurrentPreset == 0) {
                mCustomSurround = clamped;
                backupCustomBoosters();
            }
        } catch (Exception e) {
            Log.e(TAG, "setSurround error", e);
        }
    }

    public int getSurround() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SURROUND, 0);
    }

    public boolean isSurroundSupported() {
        return mSurround != null && mSurround.getStrengthSupported() && isAttached();
    }

    public void setPitch(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        mPitchLevel = smoothedLevel;
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PITCH, smoothedLevel)
            .apply();
        if (mCurrentPreset == 0) {
            mCustomPitch = smoothedLevel;
            backupCustomPitch();
        }
    }

    public int getPitch() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_PITCH, DEFAULT_PITCH_SPEED);
    }

    public int getPitchLevel() { return mPitchLevel; }
    public boolean isPitchSupported() { return true; }

    public float getPitchSemitones() {
        int level = getPitch();
        if (level == DEFAULT_PITCH_SPEED) return 0f;
        float normalized = (level - DEFAULT_PITCH_SPEED) / 1000.0f;
        return normalized * 6.0f;
    }

    public void setSpeed(int level) {
        int smoothedLevel = Math.max(0, Math.min(2000, level));
        mSpeedLevel = smoothedLevel;
        mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SPEED, mSpeedLevel)
            .apply();
        if (mCurrentPreset == 0) {
            mCustomSpeed = mSpeedLevel;
            backupCustomSpeed();
        }
    }

    public int getSpeed() {
        return mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SPEED, DEFAULT_PITCH_SPEED);
    }
}