package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Activity for displaying and managing the current playlist.
 * 
 * <p>This activity provides a comprehensive playlist management interface that allows
 * users to view, search, sort, and interact with their music library. The activity stays
 * alive in the background to continue receiving playlist updates and playback
 * indicator changes, ensuring the UI stays in sync with the playback state.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>Playlist Display</b> - Scrollable list of songs in the current playlist with
 *       efficient RecyclerView implementation</li>
 *   <li><b>Sort Functionality</b> - Sort by title, artist, album, genre, or date with
 *       ascending/descending order. Click the SORT button in the header to cycle through
 *       all 10 sort modes. The current sort mode is displayed in the header (e.g.,
 *       "SORT MODE [A-Z]") and persisted across app restarts. Changes are broadcast to
 *       MusicService so playback respects the sort order.</li>
 *   <li><b>Search Functionality</b> - Filter songs by title, artist, or album with
 *       real-time search results that maintain the current sort order</li>
 *   <li><b>Playback Indicator</b> - Visual highlighting of the currently playing song
 *       with theme-colored text and dark background</li>
 *   <li><b>Auto-scroll</b> - Automatic scrolling to the currently playing song when
 *       it's not visible in the viewport</li>
 *   <li><b>Theme Support</b> - Consistent visual styling with theme color integration
 *       across all UI components including the SORT button</li>
 *   <li><b>Empty State Handling</b> - User-friendly message when no songs are available,
 *       with instructions on how to import music</li>
 *   <li><b>Real-time Updates</b> - Listens to broadcasts for playlist changes and
 *       playback state updates from MusicService</li>
 *   <li><b>Async Genre Loading</b> - Receives genre updates from PlaylistService
 *       during background ID3 tag reading, updating the UI progressively</li>
 *   <li><b>Force Refresh</b> - Reloads playlist from database after genre loading
 *       to ensure genres persist across activity recreation</li>
 * </ul>
 * 
 * <h3>Button Behaviors</h3>
 * <p>
 * <ul>
 *   <li><b>CANCEL button (top bar)</b> - If search is visible, hides search bar; otherwise returns to MusicPlayer</li>
 *   <li><b>Back button</b> - Same behavior as CANCEL button</li>
 *   <li><b>✕ button (inside search bar)</b> - Clears search input text only (stays in search mode)</li>
 *   <li><b>SEARCH button (top bar)</b> - Shows search bar and focuses search input</li>
 * </ul>
 * </p>
 * 
 * <h3>Sort Modes (Cyclic Order)</h3>
 * <p>Clicking the SORT button cycles through these 10 modes in order.
 * All sorts use secondary sorting by Title (A-Z) when primary keys match
 * to ensure consistent, predictable ordering.</p>
 * <ol>
 *   <li><b>TITLE [A-Z]</b> - Sort by song title alphabetically (default)</li>
 *   <li><b>TITLE [Z-A]</b> - Sort by song title reverse alphabetically</li>
 *   <li><b>ARTIST [A-Z]</b> - Sort by artist name alphabetically, then by title</li>
 *   <li><b>ARTIST [Z-A]</b> - Sort by artist name reverse alphabetically, then by title</li>
 *   <li><b>ALBUM [A-Z]</b> - Sort by album name alphabetically, then by title</li>
 *   <li><b>ALBUM [Z-A]</b> - Sort by album name reverse alphabetically, then by title</li>
 *   <li><b>GENRE [A-Z]</b> - Sort by music genre alphabetically, then by title</li>
 *   <li><b>GENRE [Z-A]</b> - Sort by music genre reverse alphabetically, then by title</li>
 *   <li><b>[OLDEST]</b> - Sort by file date (oldest first), then by title</li>
 *   <li><b>[NEWEST]</b> - Sort by file date (newest first), then by title</li>
 * </ol>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistActivity extends Activity {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaylistActivity";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index in SharedPreferences. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last played song path in SharedPreferences. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Broadcast action for forcing playlist refresh after genre loading. */
    private static final String ACTION_FORCE_PLAYLIST_REFRESH = "FORCE_PLAYLIST_REFRESH";
    
    /** Broadcast action for updating sort mode in MusicService. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Debounce delay for button clicks in milliseconds. Prevents rapid multiple clicks. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay in milliseconds before scrolling to the currently playing song. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons after animation completes. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Maximum length for search query input in characters. */
    private static final int MAX_SEARCH_LENGTH = 128;
    
    /** Corner radius for search bar in density-independent pixels. */
    private static final int SEARCH_BAR_CORNER_RADIUS_DP = 10;
    
    /** Corner radius for search input field in density-independent pixels. */
    private static final int SEARCH_INPUT_CORNER_RADIUS_DP = 8;
    
    /** Stroke width for search bar border in density-independent pixels. */
    private static final int SEARCH_BAR_STROKE_WIDTH_DP = 1;
    
    /** Padding for empty container in density-independent pixels. */
    private static final int EMPTY_CONTAINER_PADDING_DP = 32;
    
    // ========================================================================
    // Sort Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). This is the default. */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    /** Total number of available sort modes (10). Used for cyclic navigation. */
    private static final int SORT_MODE_COUNT = 10;
    
    /** Preference key for storing the user's selected sort mode in SharedPreferences. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /**
     * Display names for each sort mode shown in the header.
     * Index matches the sort mode constants.
     */
    private static final String[] SORT_DISPLAY_NAMES = {
        "[TITLE A-Z]",    // SORT_TITLE_AZ
        "[TITLE Z-A]",    // SORT_TITLE_ZA
        "[ARTIST A-Z]",    // SORT_ARTIST_AZ
        "[ARTIST Z-A]",    // SORT_ARTIST_ZA
        "[ALBUM A-Z]",    // SORT_ALBUM_AZ
        "[ALBUM Z-A]",    // SORT_ALBUM_ZA
        "[GENRE A-Z]",    // SORT_GENRE_AZ
        "[GENRE Z-A]",    // SORT_GENRE_ZA
        "[OLDEST]",        // SORT_OLDEST
        "[NEWEST]"       // SORT_NEWEST
    };
    
    /**
     * Toast messages for each sort mode shown when user cycles sort.
     * Index matches the sort mode constants.
     */
    private static final String[] SORT_TOAST_MESSAGES = {
        "SORT MODE: TITLE [A-Z]",
        "SORT MODE: TITLE [Z-A]",
        "SORT MODE: ARTIST [A-Z]",
        "SORT MODE: ARTIST [Z-A]",
        "SORT MODE: ALBUM [A-Z]",
        "SORT MODE: ALBUM [Z-A]",
        "SORT MODE: GENRE [A-Z]",
        "SORT MODE: GENRE [Z-A]",
        "SORT MODE: OLDEST",
        "SORT MODE: NEWEST"
    };
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** RecyclerView for displaying the playlist items with efficient recycling. */
    private RecyclerView mPlaylistRecyclerView;
    
    /** Adapter for the playlist RecyclerView that handles view binding. */
    private PlaylistAdapter mAdapter;
    
    /** TextView displaying the playlist title (shows "SORT MODE [current]"). */
    private TextView mPlaylistTitle;
    
    /** TextView displaying the song count (e.g., "5 songs" or "5 / 120 songs"). */
    private TextView mSongCountText;
    
    /** EditText for search input with real-time filtering. */
    private EditText mSearchEditText;
    
    /** Button to toggle search mode visibility. */
    private Button mSearchButton;
    
    /** Button to clear the search query (stays in search mode). */
    private Button mClearSearchButton;
    
    /** Container layout for the search bar (initially hidden). */
    private LinearLayout mSearchBar;
    
    /** Button to cancel/hide search or return to music player. */
    private Button mCancelButton;
    
    /** Container for empty state UI when no songs exist in the playlist. */
    private LinearLayout mEmptyContainer;
    
    /** Root container frame layout that holds all content. */
    private FrameLayout mRootContainer;
    
    /** Clickable SORT text view in the header bar. */
    private TextView mSortButton;
    
    // ========================================================================
    // Data Components
    // ========================================================================
    
    /** List of songs currently displayed (filtered by search and sorted). */
    private ArrayList<Song> mCurrentDisplayList;
    
    /** Manages music library operations including database caching and folder management. */
    private MusicLibrary mMusicLibrary;
    
    /** Index of the currently playing song (-1 if no song is playing). */
    private int mCurrentPlayingIndex = -1;
    
    /** Flag indicating whether the search bar is currently visible. */
    private boolean mIsSearchVisible = false;
    
    /** Input method manager for controlling the soft keyboard. */
    private InputMethodManager mInputMethodManager;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Manager for theme color operations and persistence. */
    private ThemeManager mThemeManager;
    
    /** Helper for applying theme colors to UI components (buttons, text, etc.). */
    private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme color change events from ThemeManager. */
    private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Sort Components
    // ========================================================================
    
    /** Current sort mode (default is SORT_TITLE_AZ to match original behavior). */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    /** Last sort button click timestamp for debouncing rapid clicks. */
    private long mLastSortClickTime = 0;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Timestamp of the last search button click for debouncing. */
    private long mLastSearchClickTime = 0;
    
    /** Timestamp of the last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;
    
    /**
     * Flag indicating if a user interaction (like song click) is in progress.
     * Used to prevent auto-scrolling during user interactions.
     */
    private volatile boolean mUserInteractionInProgress = false;
    
    /** Main thread handler for delayed operations (auto-scroll, focus, etc.). */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for playback state updates from MusicService. */
    private BroadcastReceiver mUpdatePlayerReceiver;
    
    /** Receiver for playlist display updates (when playlist changes). */
    private BroadcastReceiver mDisplayPlaylistReceiver;
    
    /** Receiver for forced player updates (after metadata changes). */
    private BroadcastReceiver mForceUpdatePlayerReceiver;
    
    /** Receiver for playlist load progress updates during scanning. */
    private BroadcastReceiver mPlaylistLoadProgressReceiver;
    
    /**
     * Receiver for genre update events from PlaylistService during async genre loading.
     * Handles progressive genre display as ID3 tags are read in the background.
     */
    private BroadcastReceiver mGenreUpdateReceiver;
    
    /**
     * Receiver for force refresh events from PlaylistService after genre loading.
     * Ensures the playlist reloads from database after orientation changes.
     */
    private BroadcastReceiver mForceRefreshReceiver;
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * Initializes the UI, managers, loads preferences, and registers receivers.
     *
     * @param savedInstanceState Saved instance state (not used in this activity)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_playlist);
        
        CharacterMapper.init(this);
        mMusicLibrary = new MusicLibrary(this);
        mCurrentDisplayList = new ArrayList<Song>();
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        
        loadCurrentPlayingIndex();
        loadSortMode();
        initializeViews();
        setupSearchListener();
        registerReceivers();
        registerGenreUpdateReceiver();
        registerForceRefreshReceiver();
        displayCachedSongs();
        applyThemeToUI();
        themeAllHeaders();
    }
    
    /**
     * Called when the activity resumes.
     * Reattaches persistent toast, re-registers theme receiver, refreshes UI,
     * and ensures sort button and header display are up to date.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Reattach persistent toast if it exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        // Refresh from database on resume to get persisted genres
        refreshFromDatabase();
        
        if (mAdapter != null) {
            mAdapter.setCurrentPlayingIndex(mCurrentPlayingIndex);
            if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                if (!mUserInteractionInProgress) {
                    focusCurrentSong();
                }
            }
        }
        
        // Refresh sort button color (theme may have changed)
        if (mSortButton != null && mThemeHelper != null) {
            mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        // Update header sort display
        updateSortHeaderDisplay();
        
        applyThemeToUI();
        themeAllHeaders();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity pauses.
     * Unregisters the theme receiver to prevent memory leaks.
     */
    @Override
    protected void onPause() {
        super.onPause();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     * Reattaches persistent toast if it exists.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        // Reattach persistent toast if it exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     * Cleans up resources, shuts down MusicLibrary, unregisters receivers,
     * and removes any pending handler callbacks.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mMusicLibrary != null) {
            mMusicLibrary.shutdown();
        }
        
        // Hide ToastManager persistent overlay if showing
        ToastManager.hidePersistentOverlay();
        
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister theme receiver", e);
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mDisplayPlaylistReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaylistLoadProgressReceiver);
        unregisterReceiverSafely(mGenreUpdateReceiver);
        unregisterReceiverSafely(mForceRefreshReceiver);
        
        mMainHandler.removeCallbacksAndMessages(null);
    }
    
    /**
     * Called when the window focus changes.
     * Handles immersive mode for full-screen experience and reattaches persistent toast.
     *
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            applyImmersiveMode();
        }
        
        if (hasFocus && ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Applies immersive mode for full-screen experience.
     * Uses modern API for Android 11+ and legacy for older versions.
     */
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(android.view.WindowInsets.Type.statusBars() | 
                               android.view.WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            View decor = getWindow().getDecorView();
            if (decor != null) {
                decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        }
    }
    
    /**
     * Called when the back button is pressed.
     * 
     * <p>Back button behavior:
     * <ul>
     *   <li>If search is visible: Hides the search bar and returns to normal playlist view</li>
     *   <li>If search is not visible: Returns to MusicPlayer activity</li>
     * </ul>
     * </p>
     */
    @Override
    public void onBackPressed() {
        if (mIsSearchVisible) {
            hideSearch();
            super.onBackPressed();
        } else {
            returnToMusicPlayer();
            super.onBackPressed();
        }
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Returns to MusicPlayer without destroying this activity.
     * This allows playlist updates and playback indicator to continue in the background.
     * Symmetric to MusicPlayer.openPlaylist().
     */
    private void returnToMusicPlayer() {
        Intent intent = new Intent(this, MusicPlayer.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    // ========================================================================
    // Refresh Methods
    // ========================================================================
    
    /**
     * Refreshes the playlist from the database.
     * 
     * <p>This method recreates the MusicLibrary instance to get fresh data from
     * the database and reloads the playlist display. It is called on activity
     * resume and when a force refresh broadcast is received after genre
     * loading completes.</p>
     */
    private void refreshFromDatabase() {
        // Recreate MusicLibrary to get fresh data from database
        mMusicLibrary = new MusicLibrary(this);
        displayCachedSongs();
    }
    
    // ========================================================================
    // Sort Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * Default is SORT_TITLE_AZ (Title A-Z) which matches the original code's behavior.
     * This method is called during onCreate to restore user preference.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     * Called whenever the user cycles to a new sort mode to persist preference.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    /**
     * Cycles to the next sort mode and applies it.
     * This method is called when the user clicks the SORT button in the header.
     * Cycles through all 10 sort modes in order, broadcasts the change to MusicService,
     * and shows a toast confirmation.
     */
    private void cycleSortMode() {
        // Cycle to next mode (wrap around using modulo)
        mCurrentSortMode = (mCurrentSortMode + 1) % SORT_MODE_COUNT;
        
        // Save the new preference
        saveSortMode();
        
        // Broadcast the new sort mode to MusicService so playback respects the order
        Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
        sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
        sendBroadcast(sortIntent);
        
        // Apply the sort with toast notification
        applyCurrentSort(true);
        
        // Update the header display to show the new sort mode
        updateSortHeaderDisplay();
    }
    
    /**
     * Applies the current sort mode to the displayed list.
     * This method sorts the mCurrentDisplayList in place and updates the adapter.
     * It preserves the currently playing song highlight by finding its new position.
     *
     * @param showToast True to show a toast confirmation message
     */
    private void applyCurrentSort(boolean showToast) {
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        
        // Save current playing song path to restore highlight after sorting
        String currentSongPath = findCurrentSongPath();
        
        // Apply sorting based on current mode
        Collections.sort(mCurrentDisplayList, getComparatorForSortMode(mCurrentSortMode));
        
        // Broadcast the sort mode to MusicService (only if this is a user-initiated sort)
        if (showToast) {
            Intent sortIntent = new Intent(ACTION_UPDATE_SORT_MODE);
            sortIntent.putExtra(EXTRA_SORT_MODE, mCurrentSortMode);
            sendBroadcast(sortIntent);
        }
        
        // Update the adapter with the sorted list
        if (mAdapter != null) {
            mAdapter.updateList(mCurrentDisplayList);
            
            // Restore playing indicator by finding the song in the sorted list
            if (currentSongPath != null) {
                int newPosition = findPositionByPath(currentSongPath);
                if (newPosition >= 0) {
                    mCurrentPlayingIndex = newPosition;
                    mAdapter.setCurrentPlayingIndex(newPosition);
                }
            }
        }
        
        // Update the header (song count stays the same, but title updates if in search mode)
        updateTitleAndCount();
        
        // Show toast confirmation if requested
        if (showToast) {
            ToastManager.showToast(this, SORT_TOAST_MESSAGES[mCurrentSortMode], ToastManager.LENGTH_SHORT);
        }
        
        // Auto-scroll to current song if not searching and no user interaction in progress
        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
            if (!mUserInteractionInProgress) {
                focusCurrentSong();
            }
        }
    }
    
    /**
     * Finds the position of a song in mCurrentDisplayList by its file path.
     *
     * @param path The file path of the song to find
     * @return The position index, or -1 if the song is not found
     */
    private int findPositionByPath(String path) {
        if (path == null || mCurrentDisplayList == null) {
            return -1;
        }
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && path.equals(song.getPath())) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     * All comparators use secondary sorting by Title (A-Z) when primary keys match
     * to ensure consistent, predictable display ordering.
     *
     * @param sortMode The sort mode constant (SORT_TITLE_AZ, SORT_GENRE_ZA, etc.)
     * @return A Comparator<Song> that implements the requested sorting order
     */
    private Comparator<Song> getComparatorForSortMode(final int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
                
            case SORT_TITLE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleB.compareToIgnoreCase(titleA);
                    }
                };
                
            case SORT_ARTIST_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistA.compareToIgnoreCase(artistB);
                        
                        // Secondary sort by title when artists are the same
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ARTIST_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String artistA = a.getArtist();
                        String artistB = b.getArtist();
                        if (artistA == null) artistA = "";
                        if (artistB == null) artistB = "";
                        
                        int artistCompare = artistB.compareToIgnoreCase(artistA);
                        
                        // Secondary sort by title when artists are the same
                        if (artistCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return artistCompare;
                    }
                };
                
            case SORT_ALBUM_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumA.compareToIgnoreCase(albumB);
                        
                        // Secondary sort by title when albums are the same
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_ALBUM_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String albumA = a.getAlbum();
                        String albumB = b.getAlbum();
                        if (albumA == null) albumA = "";
                        if (albumB == null) albumB = "";
                        
                        int albumCompare = albumB.compareToIgnoreCase(albumA);
                        
                        // Secondary sort by title when albums are the same
                        if (albumCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return albumCompare;
                    }
                };
                
            case SORT_GENRE_AZ:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreA.compareToIgnoreCase(genreB);
                        
                        // Secondary sort by title when genres are the same
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_GENRE_ZA:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String genreA = a.getGenre();
                        String genreB = b.getGenre();
                        if (genreA == null) genreA = "";
                        if (genreB == null) genreB = "";
                        
                        int genreCompare = genreB.compareToIgnoreCase(genreA);
                        
                        // Secondary sort by title when genres are the same
                        if (genreCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return genreCompare;
                    }
                };
                
            case SORT_OLDEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateA, dateB);
                        
                        // Secondary sort by title when dates are the same
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            case SORT_NEWEST:
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        long dateA = getSongDate(a);
                        long dateB = getSongDate(b);
                        
                        int dateCompare = Long.compare(dateB, dateA);
                        
                        // Secondary sort by title when dates are the same
                        if (dateCompare == 0) {
                            String titleA = a.getTitle();
                            String titleB = b.getTitle();
                            if (titleA == null) titleA = "";
                            if (titleB == null) titleB = "";
                            return titleA.compareToIgnoreCase(titleB);
                        }
                        return dateCompare;
                    }
                };
                
            default:
                // Fallback to Title A-Z (should never reach here)
                return new Comparator<Song>() {
                    @Override
                    public int compare(Song a, Song b) {
                        String titleA = a.getTitle();
                        String titleB = b.getTitle();
                        if (titleA == null) titleA = "";
                        if (titleB == null) titleB = "";
                        return titleA.compareToIgnoreCase(titleB);
                    }
                };
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     * This is a reliable method that works across all Android versions without
     * requiring additional permissions.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds since Unix epoch
     */
    private long getSongDate(Song song) {
        if (song == null || song.getPath() == null) {
            return 0;
        }
        
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Updates the header to show the current sort mode.
     * Example formats:
     * - "SORT MODE [A-Z]" (normal playlist view)
     * - "SEARCH RESULTS" (when search is active - no sort mode shown)
     * This method is called after sort mode changes or when the activity resumes.
     */
    private void updateSortHeaderDisplay() {
        if (mPlaylistTitle != null) {
            String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
            
            if (TextUtils.isEmpty(searchText)) {
                // Normal playlist view - show sort mode
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                // Ensure sort button is visible
                if (mSortButton != null && mSortButton.getVisibility() != View.VISIBLE) {
                    mSortButton.setVisibility(View.VISIBLE);
                }
            } else {
                // Search results view - just show "SEARCH RESULTS" without sort mode
                mPlaylistTitle.setText("SEARCH RESULTS");
                // Hide sort button during search
                if (mSortButton != null && mSortButton.getVisibility() == View.VISIBLE) {
                    mSortButton.setVisibility(View.GONE);
                }
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Sets up the clickable SORT button in the header bar.
     * The button is defined in XML layout, so we just find and configure it.
     */
    private void setupSortButton() {
        // Find the SORT button from XML layout
        mSortButton = (TextView) findViewById(R.id.sortButton);
        
        if (mSortButton == null) {
            Log.w(TAG, "Sort button not found in layout");
            return;
        }
        
        // Apply theme color
        int themeColor = mThemeHelper.getThemeColorInt();
        mSortButton.setTextColor(themeColor);
        
        // Add press animation (scale down on touch, scale up on release)
        mSortButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
        
        // Add click listener with debouncing to prevent rapid cycling
        mSortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - mLastSortClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastSortClickTime = currentTime;
                    cycleSortMode();
                }
            }
        });
    }
    
    // ========================================================================
    // Display Methods
    // ========================================================================
    
    /**
     * Displays cached songs from the music library.
     * This method loads songs from MusicLibrary, applies the current sort mode,
     * and sets up the adapter. It also handles the empty state when no songs exist.
     */
    private void displayCachedSongs() {
        ArrayList<Song> cachedSongs = mMusicLibrary.getAllSongs();
        
        if (cachedSongs != null && !cachedSongs.isEmpty()) {
            mCurrentDisplayList.clear();
            mCurrentDisplayList.addAll(cachedSongs);
            
            // Apply saved sort preference (no toast on initial load)
            applyCurrentSort(false);
            
            hideEmptyView();
        } else {
            setHeaderTexts("CURRENT PLAYLIST", "0 songs");
            mCurrentDisplayList.clear();
            showEmptyView();
        }
        
        if (mPlaylistRecyclerView != null) {
            setupAdapter();
        }
        
        updateTitleAndCount();
        
        if (!mCurrentDisplayList.isEmpty() && !mUserInteractionInProgress) {
            focusCurrentSong();
        }
    }
    
    /**
     * Shows the empty state view when no songs are available.
     * Displays instructional text and hides interactive elements.
     */
    private void showEmptyView() {
        if (mEmptyContainer == null) {
            mEmptyContainer = new LinearLayout(this);
            mEmptyContainer.setOrientation(LinearLayout.VERTICAL);
            mEmptyContainer.setGravity(Gravity.CENTER);
            mEmptyContainer.setPadding(dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP), 
                dpToPx(EMPTY_CONTAINER_PADDING_DP * 2));
            
            TextView emptyText = new TextView(this);
            emptyText.setText("No songs yet.\n\nUse MANAGER to import music folders.");
            emptyText.setTextColor(Color.parseColor("#C0C0C0"));
            emptyText.setTextSize(14);
            emptyText.setGravity(Gravity.CENTER);
            mEmptyContainer.addView(emptyText);
            
            if (mRootContainer != null) {
                mRootContainer.addView(mEmptyContainer, 
                    new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, 
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mEmptyContainer.setVisibility(View.VISIBLE);
        }
        
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.GONE);
        }
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(false);
            mSearchButton.setTextColor(Color.parseColor("#5A5A5A"));
        }
    }
    
    /**
     * Hides the empty state view and shows the playlist RecyclerView.
     */
    private void hideEmptyView() {
        if (mEmptyContainer != null) {
            mEmptyContainer.setVisibility(View.GONE);
        }
        if (mPlaylistRecyclerView != null) {
            mPlaylistRecyclerView.setVisibility(View.VISIBLE);
        }
        if (mSearchButton != null) {
            mSearchButton.setEnabled(true);
            applyThemeToUI();
        }
        if (mSearchBar != null && mIsSearchVisible) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Sets up the playlist adapter with click listener.
     * Clicking a song plays it and updates the UI with the current playing indicator.
     * 
     * Note: DividerItemDecoration has been removed. Dividers are now handled
     * inside each item layout (item_song.xml) and controlled by PlaylistAdapter
     * to hide the divider for the currently playing song, eliminating the visual gap.
     */
    private void setupAdapter() {
        mAdapter = new PlaylistAdapter(this, mCurrentDisplayList, new PlaylistAdapter.OnSongClickListener() {
            @Override
            public void onSongClick(int position, @NonNull Song song) {
                if (TextUtils.isEmpty(song.getPath())) {
                    return;
                }
                
                mUserInteractionInProgress = true;
                
                Intent intent = new Intent(PlaylistActivity.this, MusicService.class);
                intent.setAction("PLAY_SONG");
                intent.putExtra("song_path", song.getPath());
                startService(intent);
                
                final int selectedPosition = position;
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            mCurrentPlayingIndex = selectedPosition;
                            if (mAdapter != null && selectedPosition < mAdapter.getItemCount()) {
                                mAdapter.setCurrentPlayingIndex(selectedPosition);
                                focusCurrentSong();
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting playing index", e);
                        }
                        mUserInteractionInProgress = false;
                    }
                }, FOCUS_SCROLL_DELAY_MS);
            }
        });
        
        mAdapter.setCurrentPlayingIndex(mCurrentPlayingIndex);
        
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mPlaylistRecyclerView.setLayoutManager(layoutManager);
        
        // DividerItemDecoration has been removed.
        // Dividers are now part of each item layout (item_song.xml) and controlled by PlaylistAdapter.
        // The divider is hidden for the currently playing song to eliminate the visual gap.
        
        mPlaylistRecyclerView.setAdapter(mAdapter);
    }
    
    /**
     * Updates the title and song count display based on search state.
     * Shows sort mode in the header for normal view, hides it for search results.
     */
    private void updateTitleAndCount() {
        String searchText = mSearchEditText != null ? mSearchEditText.getText().toString() : "";
        
        if (TextUtils.isEmpty(searchText)) {
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " songs");
            }
        } else {
            int totalSongs = mMusicLibrary.getSongCount();
            if (mPlaylistTitle != null) {
                mPlaylistTitle.setText("SEARCH RESULTS");
                mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
            }
            if (mSongCountText != null) {
                mSongCountText.setText(mCurrentDisplayList.size() + " / " + totalSongs + " songs");
            }
        }
    }
    
    /**
     * Sets the header texts for playlist title and song count.
     * Used primarily for empty state and initial setup.
     *
     * @param title The title text
     * @param count The count text
     */
    private void setHeaderTexts(@NonNull String title, @NonNull String count) {
        if (mPlaylistTitle != null) {
            if (title.equals("CURRENT PLAYLIST") || title.equals("SEARCH RESULTS")) {
                if (title.equals("CURRENT PLAYLIST")) {
                    mPlaylistTitle.setText("SORT MODE " + SORT_DISPLAY_NAMES[mCurrentSortMode]);
                } else {
                    mPlaylistTitle.setText(title);
                }
            } else {
                mPlaylistTitle.setText(title);
            }
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setText(count);
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Loads the current playing index from SharedPreferences.
     * This allows the activity to show the correct playing indicator on startup.
     */
    private void loadCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentPlayingIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
    }
    
    /**
     * Scrolls the playlist to show the currently playing song.
     * Uses the last song path from SharedPreferences to find the correct position.
     * Only scrolls if the current song is not already visible in the viewport.
     */
    private void focusCurrentSong() {
        if (mPlaylistRecyclerView == null || mAdapter == null || mUserInteractionInProgress) {
            return;
        }
        if (mCurrentDisplayList == null || mCurrentDisplayList.isEmpty()) {
            return;
        }
        if (mAdapter.getItemCount() == 0) {
            return;
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String lastSongPath = prefs.getString(KEY_LAST_SONG_PATH, null);
        
        if (lastSongPath == null) {
            return;
        }
        
        int targetPosition = -1;
        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
            Song song = mCurrentDisplayList.get(i);
            if (song != null && lastSongPath.equals(song.getPath())) {
                targetPosition = i;
                break;
            }
        }
        
        if (targetPosition >= 0) {
            mAdapter.setCurrentPlayingIndex(targetPosition);
            
            final int finalPosition = targetPosition;
            mPlaylistRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    RecyclerView.LayoutManager layoutManager = mPlaylistRecyclerView.getLayoutManager();
                    if (layoutManager instanceof LinearLayoutManager) {
                        LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
                        int firstVisible = linearManager.findFirstCompletelyVisibleItemPosition();
                        int lastVisible = linearManager.findLastCompletelyVisibleItemPosition();
                        
                        if (finalPosition < firstVisible || finalPosition > lastVisible) {
                            linearManager.scrollToPositionWithOffset(finalPosition,
                                mPlaylistRecyclerView.getHeight() / 2);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets status bar and navigation bar colors based on Android version.
     * Uses modern API for Android 11+ and legacy for older versions.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            applyImmersiveMode();
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components and sets up click listeners.
     * This includes finding views by ID, setting up animations, and configuring the sort button.
     */
    private void initializeViews() {
        mPlaylistRecyclerView = (RecyclerView) findViewById(R.id.playlistRecyclerView);
        mPlaylistTitle = (TextView) findViewById(R.id.playlistTitle);
        mSongCountText = (TextView) findViewById(R.id.songCountText);
        mSearchEditText = (EditText) findViewById(R.id.searchEditText);
        mSearchButton = (Button) findViewById(R.id.searchButton);
        mClearSearchButton = (Button) findViewById(R.id.clearSearchButton);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        mCancelButton = (Button) findViewById(R.id.cancelButton);
        mRootContainer = (FrameLayout) findViewById(R.id.rootContainer);
        
        if (mSearchEditText != null) {
            mSearchEditText.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(MAX_SEARCH_LENGTH)
            });
        }
        
        animateButton(mCancelButton);
        animateButton(mSearchButton);
        animateButton(mClearSearchButton);
        
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
            mSearchBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });
        }
        
        if (mSearchButton != null) {
            mSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastSearchClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastSearchClickTime = currentTime;
                        showSearch();
                    }
                }
            });
        }
        
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = currentTime;
                        if (mIsSearchVisible) {
                            hideSearch();
                        } else {
                            returnToMusicPlayer();
                        }
                    }
                }
            });
        }
        
        // Set up the SORT button in the header bar
        setupSortButton();
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% of its original size when pressed,
     * then returns to normal when released.
     *
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN)
                                   .scaleY(ANIMATION_SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                   .scaleY(ANIMATION_SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Search Methods
    // ========================================================================
    
    /**
     * Sets up the search functionality with text watcher and clear button.
     * The search filters in real-time as the user types.
     * The Enter key on the keyboard dismisses the input method since
     * search is already live, so no need to re-trigger.
     */
    private void setupSearchListener() {
        if (mSearchEditText != null) {
            mSearchEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch(s.toString());
                }
                
                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            
            // Handle "Enter" key on keyboard to hide keyboard (search is already live)
            mSearchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null && mSearchEditText != null) {
                            imm.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
                        }
                        return true;
                    }
                    return false;
                }
            });
            
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
        }
        
        if (mClearSearchButton != null) {
            mClearSearchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSearchEditText != null) {
                        mSearchEditText.setText("");  // Only clear text, stay in search mode
                    }
                }
            });
        }
    }
    
    /**
     * Performs the search operation and updates the displayed list.
     * The current sort mode is maintained in the search results.
     *
     * @param query The search query string
     */
    private void performSearch(@NonNull String query) {
        if (mAdapter == null) {
            return;
        }
        
        String currentPath = findCurrentSongPath();
        ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
        
        if (allSongs == null) {
            return;
        }
        
        mCurrentDisplayList.clear();
        
        if (query.trim().isEmpty()) {
            mCurrentDisplayList.addAll(allSongs);
            // Apply current sort to full list
            applyCurrentSort(false);
        } else {
            mCurrentDisplayList.addAll(mMusicLibrary.searchSongs(query));
            // Apply current sort to search results
            applyCurrentSort(false);
        }
        
        // Update playing index in the filtered list
        if (currentPath != null) {
            int displayPosition = -1;
            for (int i = 0; i < mCurrentDisplayList.size(); i++) {
                Song song = mCurrentDisplayList.get(i);
                if (song != null && currentPath.equals(song.getPath())) {
                    displayPosition = i;
                    break;
                }
            }
            mAdapter.setCurrentPlayingIndex(displayPosition);
        } else {
            mAdapter.setCurrentPlayingIndex(-1);
        }
        
        updateTitleAndCount();
        
        if (query.trim().isEmpty() && !mUserInteractionInProgress) {
            focusCurrentSong();
        }
    }
    
    /**
     * Finds the file path of the currently playing song.
     * First checks the current playing index, then falls back to SharedPreferences.
     *
     * @return The song path, or null if not found
     */
    @Nullable
    private String findCurrentSongPath() {
        if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mCurrentDisplayList.size()) {
            Song song = mCurrentDisplayList.get(mCurrentPlayingIndex);
            if (song != null) {
                return song.getPath();
            }
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Shows the search bar and focuses the search input.
     * The keyboard automatically appears when the search bar becomes visible.
     * Sort button is hidden during search.
     */
    private void showSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.VISIBLE);
        }
        mIsSearchVisible = true;
        
        // Hide sort button when search is active
        if (mSortButton != null) {
            mSortButton.setVisibility(View.GONE);
        }
        
        if (mSearchEditText != null) {
            mSearchEditText.requestFocus();
            if (mInputMethodManager != null) {
                mInputMethodManager.showSoftInput(mSearchEditText, InputMethodManager.SHOW_IMPLICIT);
            }
        }
    }
    
    /**
     * Hides the search bar and clears the search query.
     * The keyboard is dismissed and the full playlist is restored.
     * Sort button is shown again.
     */
    private void hideSearch() {
        if (mSearchBar != null) {
            mSearchBar.setVisibility(View.GONE);
        }
        mIsSearchVisible = false;
        
        // Show sort button when search is closed
        if (mSortButton != null) {
            mSortButton.setVisibility(View.VISIBLE);
        }
        
        if (mSearchEditText != null) {
            mSearchEditText.setText("");
            if (mInputMethodManager != null) {
                mInputMethodManager.hideSoftInputFromWindow(mSearchEditText.getWindowToken(), 0);
            }
        }
        
        performSearch("");
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers the theme color change broadcast receiver.
     * This allows the activity to update its UI when the user changes the theme.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) {
            return;
        }
        
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                    themeAllHeaders();
                    ToastManager.refreshThemeColor();
                    
                    // Refresh sort button color
                    if (mSortButton != null && mThemeHelper != null) {
                        mSortButton.setTextColor(mThemeHelper.getThemeColorInt());
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the genre update broadcast receiver for async genre loading.
     * 
     * <p>This receiver listens for GENRE_UPDATE broadcasts from PlaylistService
     * during the background ID3 tag reading phase. It progressively updates the
     * UI as each song's genre becomes available.</p>
     * 
     * <p>The receiver handles three status types:
     * <ul>
     *   <li><b>START</b> - Loading phase begins (shows persistent overlay)</li>
     *   <li><b>UPDATE</b> - Single song genre loaded, refreshes that item only and updates progress</li>
     *   <li><b>COMPLETE</b> - Loading complete, hides overlay and refreshes database</li>
     * </ul>
     * </p>
     */
    private void registerGenreUpdateReceiver() {
        mGenreUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!"GENRE_UPDATE".equals(intent.getAction())) {
                    return;
                }
                
                String status = intent.getStringExtra("status");
                
                if ("START".equals(status)) {
                    int total = intent.getIntExtra("total", 0);
                    Log.d(TAG, "Genre loading started for " + total + " songs");
                    // Use ToastManager for persistent overlay
                    ToastManager.showPersistentOverlay(PlaylistActivity.this, "Loading metadata...");
                    
                } else if ("UPDATE".equals(status)) {
                    String songPath = intent.getStringExtra("song_path");
                    String genre = intent.getStringExtra("genre");
                    int current = intent.getIntExtra("current", 0);
                    int total = intent.getIntExtra("total", 0);
                    
                    // Update progress using ToastManager
                    ToastManager.updatePersistentOverlay("Loading metadata... " + current + "/" + total);
                    
                    if (mAdapter != null && songPath != null && genre != null) {
                        mAdapter.updateSongGenre(songPath, genre);
                    }
                    
                } else if ("COMPLETE".equals(status)) {
                    int loaded = intent.getIntExtra("current", 0);
                    Log.d(TAG, "Genre loading complete: " + loaded + " genres loaded");
                    // Hide overlay using ToastManager
                    ToastManager.hidePersistentOverlay();
                    // Refresh from database to ensure all genres are displayed
                    refreshFromDatabase();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GENRE_UPDATE");
        registerReceiver(mGenreUpdateReceiver, filter);
    }
    
    /**
     * Registers the force refresh broadcast receiver for genre loading completion.
     * 
     * <p>This receiver listens for FORCE_PLAYLIST_REFRESH broadcasts from PlaylistService
     * after genre loading completes. It forces the playlist to reload from the
     * database, ensuring that all genres are properly displayed even after the
     * activity has been recreated (e.g., after orientation change).</p>
     */
    private void registerForceRefreshReceiver() {
        mForceRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_PLAYLIST_REFRESH.equals(intent.getAction())) {
                    Log.d(TAG, "Force refresh received - reloading playlist from database");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshFromDatabase();
                        }
                    });
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_FORCE_PLAYLIST_REFRESH);
        registerReceiver(mForceRefreshReceiver, filter);
    }
    
    /**
     * Applies header styling to all header TextViews in the activity.
     * This method recursively traverses the view hierarchy to find and style header texts.
     */
    private void themeAllHeaders() {
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            themeHeadersRecursive((ViewGroup) rootView);
        }
    }
    
    /**
     * Recursively applies header styling to TextViews in a view hierarchy.
     * Targets TextViews that contain header-like text such as "PLAYLIST", "SORT MODE",
     * "SEARCH RESULTS", or any text containing "songs".
     *
     * @param group The ViewGroup to traverse
     */
    private void themeHeadersRecursive(@NonNull ViewGroup group) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString();
                
                if (text.equals("PLAYLIST") || text.equals("CURRENT PLAYLIST") || 
                    text.equals("SEARCH RESULTS") || text.contains("songs") ||
                    text.startsWith("SORT MODE") || text.startsWith("SEARCH RESULTS")) {
                    textView.setTextColor(Color.parseColor("#C0C0C0"));
                }
            } else if (child instanceof ViewGroup) {
                themeHeadersRecursive((ViewGroup) child);
            }
        }
    }
    
    /**
     * Applies the current theme color to all UI components.
     * This includes buttons, search bar border, edit text, and the SORT button.
     * Called when the theme changes or when the activity resumes.
     */
    private void applyThemeToUI() {
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        int themeColor = mThemeHelper.getThemeColorInt();
        
        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, mCancelButton.isEnabled());
        }
        if (mSearchButton != null) {
            mThemeHelper.updateButton(mSearchButton, mSearchButton.isEnabled());
        }
        if (mClearSearchButton != null) {
            mThemeHelper.updateButton(mClearSearchButton, mClearSearchButton.isEnabled());
        }
        
        // Update sort button text color
        if (mSortButton != null) {
            mSortButton.setTextColor(themeColor);
        }
        
        if (mSearchBar != null) {
            GradientDrawable searchBarBorder = new GradientDrawable();
            searchBarBorder.setShape(GradientDrawable.RECTANGLE);
            searchBarBorder.setCornerRadius(dpToPx(SEARCH_BAR_CORNER_RADIUS_DP));
            searchBarBorder.setStroke(dpToPx(SEARCH_BAR_STROKE_WIDTH_DP), themeColor);
            searchBarBorder.setColor(Color.TRANSPARENT);
            mSearchBar.setBackground(searchBarBorder);
        }
        
        if (mSearchEditText != null) {
            mThemeHelper.updateEditText(mSearchEditText);
            mThemeHelper.updateEditTextCursor(mSearchEditText);
            
            GradientDrawable searchBackground = new GradientDrawable();
            searchBackground.setShape(GradientDrawable.RECTANGLE);
            searchBackground.setCornerRadius(dpToPx(SEARCH_INPUT_CORNER_RADIUS_DP));
            searchBackground.setColor(Color.parseColor("#1A1A1A"));
            mSearchEditText.setBackground(searchBackground);
            
            mSearchEditText.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mPlaylistTitle != null) {
            mPlaylistTitle.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongCountText != null) {
            mSongCountText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Methods
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for playlist and playback updates.
     * This includes receivers for player updates, playlist display, force updates,
     * and playlist load progress.
     */
    private void registerReceivers() {
        // Receiver for playback state updates
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                    
                    if (currentPath != null && mAdapter != null) {
                        int displayPosition = -1;
                        for (int i = 0; i < mCurrentDisplayList.size(); i++) {
                            Song song = mCurrentDisplayList.get(i);
                            if (song != null && currentPath.equals(song.getPath())) {
                                displayPosition = i;
                                break;
                            }
                        }
                        
                        if (displayPosition >= 0) {
                            mCurrentPlayingIndex = displayPosition;
                            mAdapter.setCurrentPlayingIndex(displayPosition);
                        }
                        
                        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                            if (!mUserInteractionInProgress) {
                                focusCurrentSong();
                            }
                        }
                    }
                }
            }
        };
        
        // Receiver for playlist display updates
        mDisplayPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "DISPLAY_PLAYLIST".equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshFromDatabase();
                        }
                    });
                }
            }
        };
        
        // Receiver for forced player updates (after metadata changes)
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    if (mAdapter != null) {
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        String currentPath = prefs.getString(KEY_LAST_SONG_PATH, null);
                        
                        if (currentPath != null) {
                            int displayPosition = -1;
                            for (int i = 0; i < mCurrentDisplayList.size(); i++) {
                                Song song = mCurrentDisplayList.get(i);
                                if (song != null && currentPath.equals(song.getPath())) {
                                    displayPosition = i;
                                    break;
                                }
                            }
                            
                            if (displayPosition >= 0) {
                                mCurrentPlayingIndex = displayPosition;
                                mAdapter.setCurrentPlayingIndex(displayPosition);
                            }
                        }
                        
                        if (mSearchEditText == null || TextUtils.isEmpty(mSearchEditText.getText().toString().trim())) {
                            if (!mUserInteractionInProgress) {
                                focusCurrentSong();
                            }
                        }
                    }
                }
            }
        };
        
        // Receiver for playlist load progress updates (during scanning)
        mPlaylistLoadProgressReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS.equals(intent.getAction())) {
                    String path = intent.getStringExtra("song_path");
                    if (TextUtils.isEmpty(path)) {
                        return;
                    }
                    
                    boolean exists = false;
                    for (Song song : mCurrentDisplayList) {
                        if (song != null && path.equals(song.getPath())) {
                            exists = true;
                            break;
                        }
                    }
                    
                    if (!exists) {
                        String title = intent.getStringExtra("song_title");
                        String artist = intent.getStringExtra("song_artist");
                        String album = intent.getStringExtra("song_album");
                        String genre = intent.getStringExtra("song_genre");
                        long duration = intent.getLongExtra("song_duration", 0);
                        
                        Song newSong = new Song(
                            title != null ? title : "Unknown Title",
                            artist != null ? artist : "Unknown Artist",
                            album != null ? album : "Unknown Album",
                            genre != null ? genre : "Unknown Genre",
                            path, duration, null
                        );
                        
                        mCurrentDisplayList.add(newSong);
                        
                        if (mAdapter != null) {
                            mAdapter.updateList(mCurrentDisplayList);
                        }
                        
                        updateTitleAndCount();
                    }
                }
            }
        };
        
        // Register all receivers with appropriate IntentFilters
        IntentFilter playerFilter = new IntentFilter();
        playerFilter.addAction("UPDATE_PLAYER");
        registerReceiver(mUpdatePlayerReceiver, playerFilter);
        
        IntentFilter displayFilter = new IntentFilter();
        displayFilter.addAction("DISPLAY_PLAYLIST");
        registerReceiver(mDisplayPlaylistReceiver, displayFilter);
        
        IntentFilter forceFilter = new IntentFilter();
        forceFilter.addAction("FORCE_UPDATE_PLAYER");
        registerReceiver(mForceUpdatePlayerReceiver, forceFilter);
        
        IntentFilter progressFilter = new IntentFilter();
        progressFilter.addAction(MusicLibrary.ACTION_PLAYLIST_LOAD_PROGRESS);
        registerReceiver(mPlaylistLoadProgressReceiver, progressFilter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     * This prevents crashes if the receiver was already unregistered.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.w(TAG, "Failed to unregister receiver", e);
            }
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Converts density-independent pixels (dp) to pixels (px).
     * Uses the device's screen density to calculate the correct pixel value.
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}