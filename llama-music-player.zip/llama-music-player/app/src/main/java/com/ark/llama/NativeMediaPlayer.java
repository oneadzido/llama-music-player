package com.ark.llama;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * NativeMediaPlayer - Basic audio player using Android's native MediaPlayer.
 * 
 * <p>This player serves as the fallback when LlamaPlayer (SoundTouch) is
 * unavailable or fails. It provides reliable, basic playback without
 * pitch/tempo shifting capabilities.</p>
 * 
 * <p>This is the STANDARD implementation using Android's built-in MediaPlayer,
 * while LlamaPlayer is the ENHANCED implementation with SoundTouch processing
 * for independent pitch and tempo control.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Reliable playback using Android's native MediaPlayer</li>
 *   <li>Audio focus management integration</li>
 *   <li>Playback state callbacks on main thread</li>
 *   <li>Seek support with position tracking</li>
 *   <li>Volume control for ducking</li>
 *   <li>Thread-safe operation with atomic flags</li>
 *   <li>Automatic resource cleanup</li>
 * </ul>
 * 
 * <h3>Lifecycle</h3>
 * <pre>
 * NativeMediaPlayer STATE MACHINE
 * ================================
 * 
 * IDLE ── setDataSource() ──► INITIALIZED ── prepareAsync() ──► PREPARING
 *                                                              │
 *                                                              │ onPrepared()
 *                                                              ▼
 *                                                        PREPARED
 *                                                              │
 *                                                              │ start()
 *                                                              ▼
 *                                                         STARTED
 *                                        ┌───────┴───────┐
 *                                        │                                          │
 *                                    pause()                            completion()
 *                                        │                                          │
 *                                        ▼                                        ▼
 *                                    PAUSED                            COMPLETED
 *                                        │                                          │
 *                                        └───────┬───────┘
 *                                                              │
 *                                                   stop() / reset()
 *                                                              │
 *                                                             ▼
 *                                                  IDLE / STOPPED
 * 
 * Note: Any state can transition to ERROR (on failure) or RELEASED (when release() called)
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. State changes are synchronized and
 * protected against race conditions. Callbacks are delivered on the main
 * UI thread via Handler.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * NativeMediaPlayer player = new NativeMediaPlayer(context);
 * player.setListener(new NativeMediaPlayer.Listener() {
 *     public void onPrepared() { /* ready to play *\/ }
 *     public void onCompletion() { /* song finished *\/ }
 *     public void onPositionUpdate(long positionMs) { /* update UI *\/ }
 *     public void onError(String error) { /* handle error *\/ }
 *     public void onAudioSessionAvailable(int sessionId) { /* attach equalizer *\/ }
 * });
 * 
 * player.initialize("/sdcard/Music/song.mp3");
 * player.prepare();
 * player.start();
 * player.seekTo(30000);
 * player.pause();
 * player.release();
 * </pre>
 * 
 * @see MediaPlayer
 * @see LlamaPlayer
 * @see AudioManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NativeMediaPlayer {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "NativeMediaPlayer";
    
    /** Timeout for player preparation in milliseconds. */
    private static final int PREPARE_TIMEOUT_MS = 8000;
    
    /** Polling interval for MediaPlayer position updates in milliseconds. */
    private static final int POSITION_POLLING_INTERVAL_MS = 150;
    
    /** Seek reset delay after operation in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    /** Maximum number of recovery attempts before giving up. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Delay before recovery attempt in milliseconds. */
    private static final int RECOVERY_DELAY_MS = 500;
    
    /** Health check interval for playback stall detection in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 1500;
    
    /** Maximum stall time before triggering recovery in milliseconds. */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    // ========================================================================
    // State Enums
    // ========================================================================
    
    /**
     * Represents the current state of the player.
     * Follows MediaPlayer lifecycle pattern for consistency.
     */
    public enum State {
        /** Initial state after creation. No song loaded. */
        IDLE,
        
        /** Data source has been set via initialize(). Ready for prepare(). */
        INITIALIZED,
        
        /** Loading song asynchronously. */
        PREPARING,
        
        /** Song loaded and ready to play. Call start() to play. */
        PREPARED,
        
        /** Actively playing audio. */
        STARTED,
        
        /** Playback paused. Call start() to resume. */
        PAUSED,
        
        /** Playback stopped via stop(). Must prepare again to play. */
        STOPPED,
        
        /** Song finished normally. Can seek to 0 and start again. */
        COMPLETED,
        
        /** An error occurred. Must call release() and recreate. */
        ERROR,
        
        /** Player resources released. Cannot be used again. */
        RELEASED
    }
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for NativeMediaPlayer events.
     * All callbacks are delivered on the main UI thread.
     */
    public interface Listener {
        
        /**
         * Called when the player is prepared and ready for playback.
         * After this callback, getDuration() returns a valid value.
         */
        void onPrepared();
        
        /**
         * Called when the song completes naturally (end of file reached).
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * Use this to update UI seek bars and time displays.
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback or preparation.
         *
         * @param error Human-readable description of the error
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the audio session ID becomes available.
         * Use this to attach an equalizer to the audio session.
         *
         * @param sessionId The audio session ID
         */
        void onAudioSessionAvailable(int sessionId);
        
        /**
         * Called when the player state changes.
         *
         * @param newState The new state
         * @param oldState The previous state (may be null on first callback)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    @NonNull private final Context mContext;
    
    /** Playback event listener. */
    @Nullable private Listener mListener;
    
    /** Native MediaPlayer instance. */
    @Nullable private MediaPlayer mMediaPlayer;
    
    /** Current player state (protected by mStateLock). */
    @NonNull private State mState = State.IDLE;
    
    /** Lock object for state transitions. */
    @NonNull private final Object mStateLock = new Object();
    
    /** File path of the currently loaded/loading song. */
    @Nullable private String mCurrentFilePath = null;
    
    /** Current audio session ID (for equalizer attachment). */
    private int mAudioSessionId = 0;
    
    /** Total duration of current song in milliseconds. */
    private volatile int mDuration = 0;
    
    /** Current playback position (cached, updated by polling). */
    @NonNull private final AtomicInteger mCurrentPosition = new AtomicInteger(0);
    
    /** Flag indicating if playback is currently active. */
    @NonNull private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if player is prepared. */
    @NonNull private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if preparation is in progress. */
    @NonNull private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    
    /** Flag indicating if seek is in progress (for position reporting). */
    @NonNull private final AtomicBoolean mSeekInProgress = new AtomicBoolean(false);
    
    /** Last seek position for UI feedback during seek. */
    private volatile int mLastSeekPosition = -1;
    
    /** Preparation ID for stale operation detection. */
    @NonNull private final AtomicInteger mPrepId = new AtomicInteger(0);
    
    /** Current preparation ID. */
    private volatile int mCurrentPrepId = -1;
    
    /** Flag indicating if playback should auto-start after preparation. */
    private boolean mShouldStartAfterPrepare = false;
    
    /** Flag indicating if a pending seek exists during preparation. */
    private final AtomicInteger mPendingSeekPosition = new AtomicInteger(-1);
    
    /** Flag indicating if the player has been released. */
    @NonNull private final AtomicBoolean mIsReleased = new AtomicBoolean(false);
    
    /** Main thread handler for callbacks and delayed operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for preparation timeout. */
    @NonNull private final Handler mTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for preparation timeout. */
    @Nullable private Runnable mTimeoutRunnable = null;
    
    /** Polling handler for position updates (when MediaPlayer doesn't provide callbacks). */
    @Nullable private Handler mPollingHandler = null;
    
    /** Runnable for position polling. */
    @Nullable private Runnable mPollingRunnable = null;
    
    /** Flag indicating if polling is active. */
    private boolean mIsPollingActive = false;
    
    /** Health check handler for stall detection. */
    @Nullable private Handler mHealthHandler = null;
    
    /** Runnable for health check. */
    @Nullable private Runnable mHealthCheckRunnable = null;
    
    /** Timestamp when playback started (for stall detection). */
    private long mPlaybackStartTime = 0;
    
    /** Number of recovery attempts made. */
    private int mRecoveryAttempts = 0;
    
    /** Current volume level (for ducking). */
    private float mCurrentVolume = 1.0f;
    
    /** Normal volume before ducking (for restoration). */
    private float mNormalVolume = 1.0f;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new NativeMediaPlayer.
     * 
     * <p>The player starts in {@link State#IDLE}. Call {@link #initialize(String)}
     * to load a song, then {@link #prepare()} to prepare for playback.</p>
     *
     * @param context Application context
     * @throws NullPointerException if context is null
     */
    public NativeMediaPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "NativeMediaPlayer created (IDLE state)");
    }
    
    /**
     * Sets the event listener for playback callbacks.
     * 
     * <p>All callbacks are delivered on the main UI thread.</p>
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable Listener listener) {
        mListener = listener;
    }
    
    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the player with a song file.
     * 
     * <p>After calling this method, the player enters {@link State#INITIALIZED}.
     * Call {@link #prepare()} to start loading the song.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @throws IllegalStateException if player is in RELEASED state
     * @throws NullPointerException if filePath is null
     * @throws IllegalArgumentException if filePath is empty
     */
    public void initialize(@NonNull String filePath) {
        if (filePath.isEmpty()) {
            throw new IllegalArgumentException("filePath cannot be empty");
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("initialize called on released player");
            }
            
            // Reset if necessary
            if (mState != State.IDLE && mState != State.INITIALIZED && 
                mState != State.ERROR && mState != State.STOPPED) {
                Log.w(TAG, "initialize called in state " + mState + " - auto-resetting");
                resetInternal(false);
            }
            
            mCurrentFilePath = filePath;
            mDuration = 0;
            mCurrentPosition.set(0);
            mIsPrepared.set(false);
            mIsPlaying.set(false);
            mPendingSeekPosition.set(-1);
            mShouldStartAfterPrepare = false;
            
            transitionState(State.INITIALIZED);
            
            Log.d(TAG, "initialize: " + filePath + " (INITIALIZED state)");
        }
    }
    
    /**
     * Prepares the player asynchronously.
     * 
     * <p>After this method returns, the state becomes {@link State#PREPARING}.
     * When preparation completes successfully, {@link Listener#onPrepared()}
     * is called and the state becomes {@link State#PREPARED}.</p>
     *
     * @throws IllegalStateException if player is not in INITIALIZED state
     */
    public void prepare() {
        prepare(false);
    }
    
    /**
     * Prepares the player asynchronously with auto-start option.
     * 
     * @param autoStart True to automatically start playback when prepared
     * @throws IllegalStateException if player is not in INITIALIZED state
     */
    public void prepare(boolean autoStart) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("prepare called on released player");
            }
            if (mState != State.INITIALIZED && mState != State.STOPPED) {
                throw new IllegalStateException("prepare called in invalid state: " + mState);
            }
            
            mShouldStartAfterPrepare = autoStart;
            mCurrentPrepId = mPrepId.incrementAndGet();
            transitionState(State.PREPARING);
        }
        
        Log.d(TAG, "prepare() - starting background preparation (autoStart=" + autoStart + ")");
        performPrepareAsync();
    }
    
    /**
     * Performs asynchronous preparation on a background thread.
     */
    private void performPrepareAsync() {
        final int myPrepId = mCurrentPrepId;
        
        new Thread(() -> {
            if (myPrepId != mCurrentPrepId) {
                Log.d(TAG, "performPrepareAsync: stale preparation (aborting)");
                return;
            }
            
            try {
                // Create and configure MediaPlayer
                MediaPlayer player = getOrCreateMediaPlayer();
                if (player == null) {
                    handlePrepareError("Failed to create MediaPlayer", myPrepId);
                    return;
                }
                
                // Reset and set data source
                player.reset();
                player.setDataSource(mCurrentFilePath);
                
                // Set listeners
                setupMediaPlayerListeners(player, myPrepId);
                
                // Start asynchronous preparation
                mIsPreparing.set(true);
                setupPreparationTimeout(myPrepId);
                player.prepareAsync();
                
                Log.d(TAG, "MediaPlayer preparing: " + mCurrentFilePath);
                
            } catch (IOException e) {
                Log.e(TAG, "prepareAsync IOException", e);
                handlePrepareError(e.getMessage() != null ? e.getMessage() : "IO Error", myPrepId);
            } catch (IllegalStateException e) {
                Log.e(TAG, "prepareAsync IllegalStateException", e);
                handlePrepareError(e.getMessage() != null ? e.getMessage() : "Invalid state", myPrepId);
            } catch (Exception e) {
                Log.e(TAG, "prepareAsync unexpected error", e);
                handlePrepareError(e.getMessage() != null ? e.getMessage() : "Unknown error", myPrepId);
            }
        }, "NativeMediaPlayer-Prepare").start();
    }
    
    /**
     * Sets up MediaPlayer event listeners.
     */
    private void setupMediaPlayerListeners(@NonNull MediaPlayer player, final int myPrepId) {
        player.setOnPreparedListener(mp -> {
            if (mCurrentPrepId != myPrepId) return;
            onPrepared(mp);
        });
        
        player.setOnCompletionListener(mp -> {
            if (mCurrentPrepId != myPrepId) return;
            onCompletion();
        });
        
        player.setOnErrorListener((mp, what, extra) -> {
            Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
            if (mCurrentPrepId == myPrepId) {
                handlePlaybackError("MediaPlayer error: " + what);
            }
            return true;
        });
    }
    
    /**
     * Called when MediaPlayer preparation completes.
     */
    private void onPrepared(@NonNull MediaPlayer player) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || mState == State.ERROR) {
                return;
            }
            
            cancelTimeout();
            mIsPreparing.set(false);
            
            // Get duration and audio session
            try {
                mDuration = player.getDuration();
                mAudioSessionId = player.getAudioSessionId();
            } catch (Exception e) {
                Log.w(TAG, "Failed to get duration/session", e);
                mDuration = 0;
                mAudioSessionId = 0;
            }
            
            // Handle pending seek
            int pendingPos = mPendingSeekPosition.getAndSet(-1);
            if (pendingPos > 0 && pendingPos < mDuration) {
                player.seekTo(pendingPos);
                mCurrentPosition.set(pendingPos);
            }
            
            mIsPrepared.set(true);
            transitionState(State.PREPARED);
            
            // Notify listeners
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> {
                    listener.onAudioSessionAvailable(mAudioSessionId);
                    listener.onPrepared();
                    listener.onStateChanged(State.PREPARED, State.PREPARING);
                });
            }
            
            // Auto-start if requested
            if (mShouldStartAfterPrepare) {
                start();
            }
            
            Log.d(TAG, "onPrepared: duration=" + mDuration + "ms, session=" + mAudioSessionId);
        }
    }
    
    /**
     * Called when song completes naturally.
     */
    private void onCompletion() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            stopPolling();
            stopHealthCheck();
            mIsPlaying.set(false);
            mCurrentPosition.set(mDuration);
            transitionState(State.COMPLETED);
            
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> {
                    listener.onCompletion();
                    listener.onStateChanged(State.COMPLETED, State.STARTED);
                    listener.onPositionUpdate(mDuration);
                });
            }
            
            Log.d(TAG, "onCompletion: song finished");
        }
    }
    
    /**
     * Handles preparation errors.
     */
    private void handlePrepareError(String error, int myPrepId) {
        if (myPrepId != mCurrentPrepId) return;
        
        synchronized (mStateLock) {
            cancelTimeout();
            mIsPreparing.set(false);
            transitionState(State.ERROR);
        }
        
        final Listener listener = mListener;
        if (listener != null) {
            mMainHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, State.PREPARING);
            });
        }
        
        Log.e(TAG, "Preparation failed: " + error);
    }
    
    /**
     * Handles playback errors after preparation.
     */
    private void handlePlaybackError(String error) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            stopPolling();
            stopHealthCheck();
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            transitionState(State.ERROR);
        }
        
        final Listener listener = mListener;
        if (listener != null) {
            mMainHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, State.STARTED);
            });
        }
        
        Log.e(TAG, "Playback error: " + error);
    }
    
    /**
     * Sets up a timeout for preparation.
     */
    private void setupPreparationTimeout(final int myPrepId) {
        cancelTimeout();
        mTimeoutRunnable = () -> {
            if (myPrepId == mCurrentPrepId && mIsPreparing.get()) {
                Log.e(TAG, "Preparation timeout after " + PREPARE_TIMEOUT_MS + "ms");
                handlePrepareError("Preparation timeout", myPrepId);
            }
        };
        mTimeoutHandler.postDelayed(mTimeoutRunnable, PREPARE_TIMEOUT_MS);
    }
    
    /**
     * Cancels the preparation timeout.
     */
    private void cancelTimeout() {
        if (mTimeoutRunnable != null) {
            mTimeoutHandler.removeCallbacks(mTimeoutRunnable);
            mTimeoutRunnable = null;
        }
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Starts or resumes playback.
     * 
     * <p>Valid states: {@link State#PREPARED}, {@link State#PAUSED},
     * {@link State#COMPLETED} (seeks to 0 then starts).</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void start() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("start called on released player");
            }
            
            switch (mState) {
                case PREPARED:
                    Log.d(TAG, "start() - from PREPARED");
                    performStart();
                    break;
                    
                case PAUSED:
                    Log.d(TAG, "start() - from PAUSED, resuming");
                    performResume();
                    break;
                    
                case COMPLETED:
                    Log.d(TAG, "start() - from COMPLETED, seeking to 0");
                    performSeek(0);
                    performStart();
                    break;
                    
                case STARTED:
                    Log.d(TAG, "start() - already STARTED, ignoring");
                    break;
                    
                default:
                    throw new IllegalStateException("start called in invalid state: " + mState);
            }
        }
    }
    
    /**
     * Performs the actual start operation.
     */
    private void performStart() {
        MediaPlayer player = getMediaPlayer();
        if (player == null) {
            handlePlaybackError("MediaPlayer is null");
            return;
        }
        
        try {
            player.start();
            mIsPlaying.set(true);
            transitionState(State.STARTED);
            startPolling();
            startHealthCheck();
            mPlaybackStartTime = SystemClock.elapsedRealtime();
            mRecoveryAttempts = 0;
            
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> listener.onStateChanged(State.STARTED, State.PREPARED));
            }
            
            Log.d(TAG, "Playback started");
        } catch (IllegalStateException e) {
            Log.e(TAG, "start() error", e);
            handlePlaybackError(e.getMessage());
        }
    }
    
    /**
     * Performs the actual resume operation.
     */
    private void performResume() {
        MediaPlayer player = getMediaPlayer();
        if (player == null) {
            handlePlaybackError("MediaPlayer is null");
            return;
        }
        
        try {
            player.start();
            mIsPlaying.set(true);
            transitionState(State.STARTED);
            startPolling();
            startHealthCheck();
            
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> listener.onStateChanged(State.STARTED, State.PAUSED));
            }
            
            Log.d(TAG, "Playback resumed");
        } catch (IllegalStateException e) {
            Log.e(TAG, "resume() error", e);
            handlePlaybackError(e.getMessage());
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>Valid state: {@link State#STARTED}.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("pause called on released player");
            }
            
            if (mState != State.STARTED) {
                Log.w(TAG, "pause() called in state: " + mState + " (ignoring)");
                return;
            }
            
            MediaPlayer player = getMediaPlayer();
            if (player == null) {
                Log.w(TAG, "pause() - MediaPlayer is null");
                return;
            }
            
            try {
                player.pause();
                mIsPlaying.set(false);
                transitionState(State.PAUSED);
                stopPolling();
                stopHealthCheck();
                
                // Capture final position for UI
                int position = getCurrentPosition();
                mCurrentPosition.set(position);
                
                final Listener listener = mListener;
                if (listener != null) {
                    mMainHandler.post(() -> {
                        listener.onStateChanged(State.PAUSED, State.STARTED);
                        listener.onPositionUpdate(position);
                    });
                }
                
                Log.d(TAG, "Playback paused at " + position + "ms");
            } catch (IllegalStateException e) {
                Log.e(TAG, "pause() error", e);
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>After calling stop(), the player enters {@link State#STOPPED}.
     * Call {@link #prepare()} again to play another song.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("stop called on released player");
            }
            
            if (mState != State.PREPARED && mState != State.STARTED && 
                mState != State.PAUSED && mState != State.COMPLETED) {
                Log.w(TAG, "stop() called in state: " + mState + " (ignoring)");
                return;
            }
            
            Log.d(TAG, "stop() - stopping playback");
            
            stopPolling();
            stopHealthCheck();
            
            MediaPlayer player = getMediaPlayer();
            if (player != null) {
                try {
                    if (mIsPlaying.get()) {
                        player.pause();
                    }
                    player.seekTo(0);
                } catch (Exception e) {
                    Log.e(TAG, "stop() error", e);
                }
            }
            
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            mCurrentPosition.set(0);
            transitionState(State.STOPPED);
            
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> listener.onStateChanged(State.STOPPED, State.STARTED));
            }
        }
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param positionMs Target position in milliseconds
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("seekTo called on released player");
            }
            
            int clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            Log.d(TAG, "seekTo: " + positionMs + "ms -> clamped: " + clampedPosition + "ms");
            
            mSeekInProgress.set(true);
            mLastSeekPosition = clampedPosition;
            mCurrentPosition.set(clampedPosition);
            
            // Immediate UI feedback
            final Listener listener = mListener;
            if (listener != null) {
                mMainHandler.post(() -> listener.onPositionUpdate(clampedPosition));
            }
            
            // If not prepared yet, store pending seek
            if (!mIsPrepared.get() || mIsPreparing.get()) {
                mPendingSeekPosition.set(clampedPosition);
                mMainHandler.postDelayed(() -> {
                    mSeekInProgress.set(false);
                    mLastSeekPosition = -1;
                }, SEEK_RESET_DELAY_MS);
                return;
            }
            
            // Perform seek
            performSeek(clampedPosition);
        }
    }
    
    /**
     * Performs the actual seek operation.
     */
    private void performSeek(int positionMs) {
        MediaPlayer player = getMediaPlayer();
        if (player == null) {
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
            return;
        }
        
        try {
            player.seekTo(positionMs);
            mCurrentPosition.set(positionMs);
            
            mMainHandler.postDelayed(() -> {
                mSeekInProgress.set(false);
                mLastSeekPosition = -1;
            }, SEEK_RESET_DELAY_MS);
            
            Log.d(TAG, "Seek completed to " + positionMs + "ms");
        } catch (IllegalStateException e) {
            Log.e(TAG, "seekTo() error", e);
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
        }
    }
    
    // ========================================================================
    // Position Polling Methods
    // ========================================================================
    
    /**
     * Starts polling for position updates.
     * MediaPlayer doesn't provide continuous position callbacks, so polling is necessary.
     */
    private void startPolling() {
        if (mIsPollingActive) return;
        
        if (mPollingHandler == null) {
            mPollingHandler = new Handler(Looper.getMainLooper());
        }
        
        stopPolling();
        
        mPollingRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mIsPlaying.get() || mSeekInProgress.get()) {
                    if (mIsPlaying.get() && mPollingHandler != null) {
                        mPollingHandler.postDelayed(this, POSITION_POLLING_INTERVAL_MS);
                    } else {
                        mIsPollingActive = false;
                    }
                    return;
                }
                
                int position = getRawPosition();
                if (position >= 0) {
                    mCurrentPosition.set(position);
                    final Listener listener = mListener;
                    if (listener != null) {
                        mMainHandler.post(() -> listener.onPositionUpdate(position));
                    }
                }
                
                if (mPollingHandler != null && mIsPlaying.get()) {
                    mPollingHandler.postDelayed(this, POSITION_POLLING_INTERVAL_MS);
                } else {
                    mIsPollingActive = false;
                }
            }
        };
        
        mIsPollingActive = true;
        mPollingHandler.post(mPollingRunnable);
        Log.d(TAG, "Position polling started");
    }
    
    /**
     * Stops position polling.
     */
    private void stopPolling() {
        if (mPollingHandler != null && mPollingRunnable != null) {
            mPollingHandler.removeCallbacks(mPollingRunnable);
        }
        mIsPollingActive = false;
        Log.d(TAG, "Position polling stopped");
    }
    
    /**
     * Gets raw position from MediaPlayer.
     */
    private int getRawPosition() {
        MediaPlayer player = getMediaPlayer();
        if (player == null) return -1;
        
        try {
            return player.getCurrentPosition();
        } catch (IllegalStateException e) {
            return -1;
        }
    }
    
    // ========================================================================
    // Health Check Methods (Stall Detection and Recovery)
    // ========================================================================
    
    /**
     * Starts health monitoring for playback stall detection.
     */
    private void startHealthCheck() {
        if (mHealthHandler == null) {
            mHealthHandler = new Handler(Looper.getMainLooper());
        }
        
        stopHealthCheck();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = SystemClock.elapsedRealtime();
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying.get() && mHealthHandler != null) {
                    mHealthHandler.postDelayed(this, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health check started");
    }
    
    /**
     * Stops health monitoring.
     */
    private void stopHealthCheck() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
        Log.d(TAG, "Health check stopped");
    }
    
    /**
     * Checks playback health and triggers recovery if stalled.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying.get()) return;
        
        try {
            int currentPosition = getCurrentPosition();
            
            // Check if position hasn't advanced
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = SystemClock.elapsedRealtime() - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected - attempting recovery");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                // Progress made, reset start time
                mPlaybackStartTime = SystemClock.elapsedRealtime();
            }
        } catch (Exception e) {
            Log.w(TAG, "Health check error", e);
            recoverFromStall();
        }
    }
    
    /**
     * Recovers from a playback stall.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, giving up");
            mRecoveryAttempts = 0;
            handlePlaybackError("Playback stalled - max recovery attempts reached");
            return;
        }
        
        mRecoveryAttempts++;
        Log.d(TAG, "Recovery attempt " + mRecoveryAttempts + " of " + MAX_RECOVERY_ATTEMPTS);
        
        final String currentPath = mCurrentFilePath;
        final int currentPosition = getCurrentPosition();
        final boolean wasPlaying = mIsPlaying.get();
        
        // Stop current playback
        stopPolling();
        stopHealthCheck();
        
        if (mMediaPlayer != null) {
            try {
                if (wasPlaying) {
                    mMediaPlayer.pause();
                }
            } catch (Exception ignored) {}
        }
        
        // Re-prepare after delay
        mMainHandler.postDelayed(() -> {
            if (currentPath != null && !mIsReleased.get()) {
                Log.d(TAG, "Attempting recovery for: " + currentPath);
                initialize(currentPath);
                prepare(true);
                if (currentPosition > 0) {
                    mMainHandler.postDelayed(() -> seekTo(currentPosition), 200);
                }
            }
        }, RECOVERY_DELAY_MS);
    }
    
    // ========================================================================
    // Volume Control Methods
    // ========================================================================
    
    /**
     * Sets the volume level.
     * 
     * <p>Range: 0.0 (silent) to 1.0 (full volume).</p>
     *
     * @param volume Volume level (clamped to 0.0-1.0)
     */
    public void setVolume(float volume) {
        mCurrentVolume = Math.max(0.0f, Math.min(1.0f, volume));
        
        MediaPlayer player = getMediaPlayer();
        if (player != null && isPrepared()) {
            try {
                player.setVolume(mCurrentVolume, mCurrentVolume);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set volume", e);
            }
        }
    }
    
    /**
     * Gets the current volume level.
     *
     * @return Current volume (0.0 to 1.0)
     */
    public float getVolume() {
        return mCurrentVolume;
    }
    
    /**
     * Ducks volume to 30% for transient audio focus loss.
     * Saves current volume for later restoration.
     */
    public void duck() {
        mNormalVolume = mCurrentVolume;
        setVolume(0.3f);
        Log.d(TAG, "Volume ducked to 30% (was " + mNormalVolume + ")");
    }
    
    /**
     * Restores volume to normal level after ducking.
     */
    public void unduck() {
        setVolume(mNormalVolume);
        Log.d(TAG, "Volume unducked to " + mNormalVolume);
    }
    
    // ========================================================================
    // State Query Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * During seek operations, returns the seek target for instant UI feedback.
     *
     * @return Current position in milliseconds
     */
    public int getCurrentPosition() {
        if (mSeekInProgress.get() && mLastSeekPosition >= 0) {
            return mLastSeekPosition;
        }
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if not available
     */
    public int getDuration() {
        return mDuration;
    }
    
    /**
     * Checks if the player is currently playing audio.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && mState == State.STARTED;
    }
    
    /**
     * Checks if the player is prepared (song loaded and ready to play).
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mIsPrepared.get() && (mState == State.PREPARED || mState == State.STARTED || 
               mState == State.PAUSED || mState == State.COMPLETED);
    }
    
    /**
     * Returns the current player state.
     *
     * @return Current state (never null)
     */
    @NonNull
    public State getState() {
        return mState;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current file path.
     *
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentFilePath() {
        return mCurrentFilePath;
    }
    
    // ========================================================================
    // MediaPlayer Management
    // ========================================================================
    
    /**
     * Gets or creates the MediaPlayer instance.
     */
    @Nullable
    private MediaPlayer getOrCreateMediaPlayer() {
        if (mMediaPlayer == null) {
            try {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                Log.d(TAG, "MediaPlayer created");
            } catch (Exception e) {
                Log.e(TAG, "Failed to create MediaPlayer", e);
                return null;
            }
        }
        return mMediaPlayer;
    }
    
    /**
     * Gets the current MediaPlayer instance (may be null).
     */
    @Nullable
    private MediaPlayer getMediaPlayer() {
        return mMediaPlayer;
    }
    
    /**
     * Releases the MediaPlayer and frees resources.
     */
    private void releaseMediaPlayer() {
        stopPolling();
        stopHealthCheck();
        
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying.get()) {
                    mMediaPlayer.stop();
                }
                mMediaPlayer.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing MediaPlayer", e);
            }
            mMediaPlayer = null;
        }
        
        mAudioSessionId = 0;
    }
    
    // ========================================================================
    // Reset Methods
    // ========================================================================
    
    /**
     * Resets the player to IDLE state.
     * 
     * <p>After reset, call {@link #initialize(String)} and {@link #prepare()}
     * again to play a song.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void reset() {
        resetInternal(true);
    }
    
    /**
     * Internal reset implementation.
     *
     * @param notifyListener Whether to notify listener of state change
     */
    private void resetInternal(boolean notifyListener) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("reset called on released player");
            }
            
            final State oldState = mState;
            Log.d(TAG, "reset() from state: " + oldState);
            
            stopPolling();
            stopHealthCheck();
            cancelTimeout();
            
            releaseMediaPlayer();
            
            mIsPreparing.set(false);
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
            mCurrentPosition.set(0);
            mPendingSeekPosition.set(-1);
            mAudioSessionId = 0;
            mDuration = 0;
            mCurrentFilePath = null;
            mRecoveryAttempts = 0;
            mShouldStartAfterPrepare = false;
            
            mPrepId.incrementAndGet();
            
            transitionState(State.IDLE);
            
            if (notifyListener) {
                final Listener listener = mListener;
                if (listener != null) {
                    mMainHandler.post(() -> listener.onStateChanged(State.IDLE, oldState));
                }
            }
            
            Log.d(TAG, "reset() - IDLE state");
        }
    }
    
    // ========================================================================
    // Resource Release
    // ========================================================================
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>After calling this method, the player enters {@link State#RELEASED}
     * and cannot be used again. Always call release() when the player is
     * no longer needed to prevent memory leaks.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release() - releasing all resources");
            
            stopPolling();
            stopHealthCheck();
            cancelTimeout();
            
            releaseMediaPlayer();
            
            mIsPreparing.set(false);
            mIsPlaying.set(false);
            mIsPrepared.set(false);
            mSeekInProgress.set(false);
            mCurrentPosition.set(0);
            mPendingSeekPosition.set(-1);
            mAudioSessionId = 0;
            mDuration = 0;
            mCurrentFilePath = null;
            mIsReleased.set(true);
            
            transitionState(State.RELEASED);
            
            // Clear handler callbacks
            mMainHandler.removeCallbacksAndMessages(null);
            mTimeoutHandler.removeCallbacksAndMessages(null);
            if (mPollingHandler != null) {
                mPollingHandler.removeCallbacksAndMessages(null);
            }
            if (mHealthHandler != null) {
                mHealthHandler.removeCallbacksAndMessages(null);
            }
            
            Log.d(TAG, "release() - RELEASED state");
        }
    }
    
    // ========================================================================
    // State Management Helpers
    // ========================================================================
    
    /**
     * Transitions the player to a new state with thread-safe logging.
     */
    private void transitionState(State newState) {
        final State oldState = mState;
        mState = newState;
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
    }
}