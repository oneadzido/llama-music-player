package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe manager for audio decoding operations including main decoder and prefill for seeks.
 * 
 * <p>This class provides two types of decoders:</p>
 * <ul>
 *   <li><b>Main Decoder:</b> Persistent decoder for continuous playback</li>
 *   <li><b>Prefill Decoder:</b> Temporary decoder for seek prefill (eliminates stall)</li>
 * </ul>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All public methods are thread-safe</li>
 *   <li>Main decoder operations are protected by a ReentrantLock</li>
 *   <li>Prefill operations use AtomicBoolean for state tracking</li>
 *   <li>Callback is delivered on main thread via Handler</li>
 *   <li>No two decoders access the same file simultaneously</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * DecoderManager decoderManager = new DecoderManager();
 * decoderManager.initialize(filePath, sampleRate, channels);
 * 
 * // For seamless seek
 * decoderManager.startPrefill(targetPosition, new PrefillCallback() {
 *     void onPrefillReady(short[] buffer, int frames, int sequence) {
 *         player.seekTo(targetPosition, buffer, frames);
 *     }
 * });
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class DecoderManager {
    
    private static final String TAG = "DecoderManager";
    
    /** Number of frames to prefill (~93ms at 44.1kHz stereo). */
    private static final int PREFILL_FRAMES = 4096;
    
    // ========================================================================
    // Thread-Safe State Variables
    // ========================================================================
    
    /** Lock for main decoder operations. */
    private final ReentrantLock mMainDecoderLock = new ReentrantLock();
    
    /** Main decoder for continuous playback. */
    @Nullable
    private volatile AudioDecoder mMainDecoder;
    
    /** Current file path (immutable after initialize). */
    @Nullable
    private volatile String mCurrentFilePath;
    
    /** Current sample rate (immutable after initialize). */
    private volatile int mSampleRate = 44100;
    
    /** Current channel count (immutable after initialize). */
    private volatile int mChannels = 2;
    
    /** Main thread handler for callbacks. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if prefill is in progress (atomic). */
    private final AtomicBoolean mIsPrefilling = new AtomicBoolean(false);
    
    /** Flag indicating if prefill was cancelled (atomic). */
    private final AtomicBoolean mIsPrefillCancelled = new AtomicBoolean(false);
    
    /** Current prefill sequence ID (increments on each prefill start). */
    private final AtomicInteger mPrefillSequence = new AtomicInteger(0);
    
    /** Callback for prefill completion (volatile for cross-thread visibility). */
    @Nullable
    private volatile PrefillCallback mPendingCallback = null;
    
    /** Thread reference for current prefill operation (for interruption). */
    @Nullable
    private volatile Thread mCurrentPrefillThread = null;
    
    // ========================================================================
    // Callback Interface
    // ========================================================================
    
    /**
     * Callback for prefill completion.
     * Called on the main thread.
     */
    public interface PrefillCallback {
        /**
         * Called when prefill buffer is ready.
         * 
         * @param buffer Prefilled audio data (16-bit PCM, interleaved)
         * @param frames Number of frames in buffer
         * @param sequence The sequence ID of this prefill (for stale detection)
         */
        void onPrefillReady(@NonNull short[] buffer, int frames, int sequence);
    }
    
    // ========================================================================
    // Initialization and Main Decoder Operations
    // ========================================================================
    
    /**
     * Initializes the decoder manager with a file.
     * Thread-safe: uses ReentrantLock to protect main decoder creation.
     * 
     * @param filePath Absolute path to the audio file
     * @param sampleRate Sample rate in Hz
     * @param channels Number of audio channels (1 or 2)
     * @return true if initialization successful
     */
    public boolean initialize(@NonNull String filePath, int sampleRate, int channels) {
        // Cancel any ongoing prefill before reinitializing
        cancelPrefill();
        
        mMainDecoderLock.lock();
        try {
            releaseMainDecoderLocked();
            
            AudioDecoder newDecoder = new AudioDecoder();
            if (!newDecoder.open(filePath)) {
                Log.e(TAG, "Failed to open main decoder: " + filePath);
                return false;
            }
            
            mMainDecoder = newDecoder;
            mCurrentFilePath = filePath;
            mSampleRate = sampleRate;
            mChannels = channels;
            
            Log.d(TAG, "DecoderManager initialized: " + filePath + ", " + sampleRate + "Hz, " + channels + "ch");
            return true;
            
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Reads PCM data from the main decoder.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * @param buffer Destination buffer for PCM samples
     * @param frames Number of frames to read
     * @return Number of frames actually read, or -1 on error
     */
    public int read(@NonNull short[] buffer, int frames) {
        mMainDecoderLock.lock();
        try {
            if (mMainDecoder == null) {
                return -1;
            }
            return mMainDecoder.read(buffer, frames);
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Seeks the main decoder to the specified position.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * @param positionMs Position in milliseconds
     */
    public void seekMainDecoder(int positionMs) {
        mMainDecoderLock.lock();
        try {
            if (mMainDecoder != null) {
                mMainDecoder.seekTo(positionMs);
                Log.d(TAG, "Main decoder seeked to: " + positionMs + "ms");
            }
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Checks if the main decoder has reached end of stream.
     * Thread-safe: uses ReentrantLock to protect main decoder access.
     * 
     * @return true if EOS reached
     */
    public boolean isEOS() {
        mMainDecoderLock.lock();
        try {
            return mMainDecoder != null && mMainDecoder.isEOS();
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    /**
     * Gets the current sample rate.
     * Thread-safe: volatile read.
     * 
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Gets the current channel count.
     * Thread-safe: volatile read.
     * 
     * @return Number of channels (1 or 2)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Gets the current file path.
     * Thread-safe: volatile read.
     * 
     * @return File path, or null if not initialized
     */
    @Nullable
    public String getCurrentFilePath() {
        return mCurrentFilePath;
    }
    
    /**
     * Checks if the decoder manager is initialized and ready.
     * Thread-safe: volatile read of mMainDecoder with lock for safety.
     * 
     * @return true if main decoder is available
     */
    public boolean isReady() {
        mMainDecoderLock.lock();
        try {
            return mMainDecoder != null;
        } finally {
            mMainDecoderLock.unlock();
        }
    }
    
    // ========================================================================
    // Prefill Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Starts asynchronous prefill at the specified position.
     * Thread-safe: uses AtomicBoolean for state, sequence ID for stale detection.
     * 
     * <p>If a prefill is already in progress, it is cancelled and replaced.</p>
     * 
     * @param targetPositionMs Target seek position in milliseconds
     * @param callback Callback when prefill is ready (on UI thread)
     */
    public void startPrefill(int targetPositionMs, @NonNull PrefillCallback callback) {
        // Cancel any existing prefill
        cancelPrefill();
        
        if (mCurrentFilePath == null) {
            Log.e(TAG, "Cannot prefill: no file loaded");
            mMainHandler.post(() -> callback.onPrefillReady(new short[0], 0, -1));
            return;
        }
        
        // Atomically set prefill state
        if (!mIsPrefilling.compareAndSet(false, true)) {
            Log.w(TAG, "Prefill already in progress (CAS failed)");
            return;
        }
        
        mIsPrefillCancelled.set(false);
        
        final int currentSequence = mPrefillSequence.incrementAndGet();
        mPendingCallback = callback;
        
        final String filePath = mCurrentFilePath;
        final int channels = mChannels;
        final int targetPos = targetPositionMs;
        
        // Start background thread
        final Thread prefillThread = new Thread(() -> {
            mCurrentPrefillThread = Thread.currentThread();
            
            try {
                // Check cancellation before starting
                if (mIsPrefillCancelled.get()) {
                    finishPrefill(new short[0], 0, currentSequence);
                    return;
                }
                
                AudioDecoder prefillDecoder = null;
                try {
                    // Create temporary decoder for prefill only
                    prefillDecoder = new AudioDecoder();
                    
                    if (!prefillDecoder.open(filePath)) {
                        Log.e(TAG, "Failed to open prefill decoder");
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Check cancellation after open
                    if (mIsPrefillCancelled.get()) {
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Seek to target position
                    prefillDecoder.seekTo(targetPos);
                    
                    // Check cancellation after seek
                    if (mIsPrefillCancelled.get()) {
                        finishPrefill(new short[0], 0, currentSequence);
                        return;
                    }
                    
                    // Read small buffer
                    short[] buffer = new short[PREFILL_FRAMES * channels];
                    int framesRead = prefillDecoder.read(buffer, PREFILL_FRAMES);
                    
                    if (framesRead > 0 && !mIsPrefillCancelled.get()) {
                        Log.d(TAG, "Prefill complete: " + framesRead + " frames at " + targetPos + "ms (seq=" + currentSequence + ")");
                        
                        // Trim buffer to actual frames read
                        short[] trimmedBuffer = new short[framesRead * channels];
                        System.arraycopy(buffer, 0, trimmedBuffer, 0, trimmedBuffer.length);
                        
                        finishPrefill(trimmedBuffer, framesRead, currentSequence);
                    } else {
                        Log.w(TAG, "Prefill read " + framesRead + " frames");
                        finishPrefill(new short[0], 0, currentSequence);
                    }
                    
                } catch (Exception e) {
                    Log.e(TAG, "Prefill failed", e);
                    finishPrefill(new short[0], 0, currentSequence);
                } finally {
                    if (prefillDecoder != null) {
                        try {
                            prefillDecoder.release();
                        } catch (Exception e) {
                            Log.w(TAG, "Error releasing prefill decoder", e);
                        }
                    }
                }
            } finally {
                mCurrentPrefillThread = null;
            }
        }, "DecoderManager-Prefill");
        
        prefillThread.start();
    }
    
    /**
     * Cancels any ongoing prefill operation.
     * Thread-safe: uses AtomicBoolean flags and thread interruption.
     */
    public void cancelPrefill() {
        // Set cancellation flag first (prevents new operations)
        mIsPrefillCancelled.set(true);
        
        // Interrupt the prefill thread if it's running
        Thread prefillThread = mCurrentPrefillThread;
        if (prefillThread != null && prefillThread.isAlive()) {
            prefillThread.interrupt();
        }
        
        // Clear the prefill state
        mIsPrefilling.set(false);
        mPendingCallback = null;
        
        Log.d(TAG, "Prefill cancelled");
    }
    
    /**
     * Checks if prefill is currently in progress.
     * Thread-safe: AtomicBoolean get.
     * 
     * @return true if prefill is active
     */
    public boolean isPrefilling() {
        return mIsPrefilling.get();
    }
    
    /**
     * Completes prefill and delivers callback on main thread.
     * Thread-safe: checks sequence ID to prevent stale callbacks.
     * 
     * @param buffer The prefill buffer
     * @param frames Number of frames
     * @param sequence The sequence ID of this prefill
     */
    private void finishPrefill(@NonNull short[] buffer, int frames, int sequence) {
        // Reset prefill state
        mIsPrefilling.set(false);
        
        // Get the callback (volatile read)
        final PrefillCallback callback = mPendingCallback;
        
        // Only deliver if this callback is still valid (not cancelled by a newer prefill)
        if (callback != null && sequence == mPrefillSequence.get()) {
            mMainHandler.post(() -> {
                // Double-check we're not delivering a stale callback
                if (sequence == mPrefillSequence.get()) {
                    callback.onPrefillReady(buffer, frames, sequence);
                }
            });
        }
        
        // Clear callback reference to allow GC
        if (sequence == mPrefillSequence.get()) {
            mPendingCallback = null;
        }
        
        Log.d(TAG, "Prefill finished: " + frames + " frames, seq=" + sequence);
    }
    
    // ========================================================================
    // Lifecycle Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Releases main decoder resources (must be called with lock held).
     */
    private void releaseMainDecoderLocked() {
        if (mMainDecoder != null) {
            try {
                mMainDecoder.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing main decoder", e);
            }
            mMainDecoder = null;
        }
    }
    
    /**
     * Releases all decoder resources.
     * Thread-safe: acquires lock and cancels prefill.
     */
    public void release() {
        // Cancel any ongoing prefill first
        cancelPrefill();
        
        mMainDecoderLock.lock();
        try {
            releaseMainDecoderLocked();
            mCurrentFilePath = null;
            Log.d(TAG, "DecoderManager released");
        } finally {
            mMainDecoderLock.unlock();
        }
    }
}