package com.ark.llama;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * DisplayManager - Manages all UI display components for the music player.
 * 
 * <p>This class handles:
 * <ul>
 *   <li>Album art loading and caching with LRU cache</li>
 *   <li>Placeholder bitmap generation with theme coloring</li>
 *   <li>UI updates for song title, artist, seekbar, and time displays</li>
 *   <li>Button state management (enabled/disabled, themed styling)</li>
 *   <li>Loading overlay management</li>
 *   <li>Album art clipping and animation</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All UI updates are posted to the main thread.
 * Album art loading uses ExecutorService with proper cancellation.
 * The album art cache reference is volatile for thread-safe publication.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class DisplayManager {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "DisplayManager";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum album art dimension in pixels for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Duration of album art fade animation in milliseconds. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Alpha value for dim overlay background (180 = 70% opacity). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in density-independent pixels. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art container in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Maximum length for song title display before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum length for artist name display before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Light gray text color for secondary text. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Darker text color for subtitles. */
    private static final String TEXT_COLOR_DARK = "#808080";
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Container for album art with rounded corners. */
    @Nullable private View mAlbumArtContainer;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    /** 
     * LRU cache for album art bitmaps (50MB max).
     * Volatile for thread-safe publication to background threads.
     */
    @Nullable private volatile android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Executor for asynchronous album art loading. */
    @Nullable private ExecutorService mAlbumArtExecutor = null;
    
    /** Future for the current album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    
    /** Path of the album art currently being loaded. */
    @Nullable private volatile String mCurrentLoadingArtPath = null;
    
    /** Path of the currently displayed album art. */
    @Nullable private volatile String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    /** Placeholder bitmap for when album art is unavailable. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap before theme color applied. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Executor for placeholder bitmap generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Future for the current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock for placeholder bitmap operations. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components
    // ========================================================================
    
    /** Dim overlay view for loading states. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner shown during long operations. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Flag indicating if user is actively seeking (dragging seek bar). */
    private volatile boolean mIsUserSeeking = false;
    
    /** Current activity context. */
    @NonNull private final Context mContext;
    
    /** Main thread handler. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if the display manager has been destroyed. */
    private final AtomicBoolean mIsDestroyed = new AtomicBoolean(false);
    
    /** Listener for display events. */
    @Nullable private DisplayListener mListener;

    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener for display events that need to be communicated back to the parent.
     */
    public interface DisplayListener {
        /**
         * Called when the user seeks to a new position.
         * @param position The position in milliseconds
         */
        void onSeekRequested(int position);
        
        /**
         * Called when the seek operation starts (user begins dragging).
         */
        void onSeekStart();
        
        /**
         * Called when the seek operation stops (user releases drag).
         */
        void onSeekStop();
        
        /**
         * Called when album art needs to be updated in the notification.
         * @param art The album art bitmap
         * @param placeholder The placeholder bitmap
         * @param artPath The file path for the art
         */
        void onNotificationAlbumArtUpdate(@Nullable Bitmap art, @Nullable Bitmap placeholder, @Nullable String artPath);
    }

    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new DisplayManager.
     *
     * @param context The activity context
     * @param listener The listener for display events
     */
    public DisplayManager(@NonNull Context context, @Nullable DisplayListener listener) {
        mContext = context;
        mListener = listener;
        mThemeManager = ThemeManager.getInstance(context);
        mThemeHelper = ThemeHelper.getInstance(context);
        
        initializeCache();
        initializeExecutors();
    }
    
    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the album art LRU cache.
     * Called from constructor, safe as no background threads are running yet.
     */
    private void initializeCache() {
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
    }
    
    /**
     * Initializes the executor services for background operations.
     */
    private void initializeExecutors() {
        mAlbumArtExecutor = Executors.newSingleThreadExecutor();
    }
    
    // ========================================================================
    // UI Initialization and Binding
    // ========================================================================
    
    /**
     * Binds UI components from the activity.
     * Called after the activity's views are created.
     *
     * @param songTitle TextView for song title
     * @param songArtist TextView for artist name
     * @param seekTime TextView for elapsed time
     * @param totalTime TextView for total duration
     * @param seekBar SeekBar for position control
     * @param albumArtView ImageView for album art
     * @param albumArtContainer Container for album art clipping
     */
    public void bindViews(@Nullable TextView songTitle, @Nullable TextView songArtist,
                          @Nullable TextView seekTime, @Nullable TextView totalTime,
                          @Nullable SeekBar seekBar, @Nullable ImageView albumArtView,
                          @Nullable View albumArtContainer) {
        mSongTitle = songTitle;
        mSongArtist = songArtist;
        mSeekTime = seekTime;
        mTotalTime = totalTime;
        mSeekBar = seekBar;
        mAlbumArtView = albumArtView;
        mAlbumArtContainer = albumArtContainer;
        
        setupSeekBarListener();
        applyAlbumArtClipping();
    }
    
    /**
     * Sets up the SeekBar listener for position tracking and seeking.
     */
    private void setupSeekBarListener() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) {
                    mSeekTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mListener != null) {
                    mListener.onSeekStart();
                }
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mListener != null && seekBar.isEnabled()) {
                    mListener.onSeekRequested(seekPos);
                }
                if (mSeekTime != null) {
                    mSeekTime.setText(formatTime(seekPos));
                }
                
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mIsUserSeeking = false;
                        Log.d(TAG, "Seek flag reset - UI updates resumed");
                    }
                }, 150);
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Updates the UI to display information for a given song.
     *
     * @param song The song to display, or null to clear
     */
    public void updateUIForSong(@Nullable Song song) {
        if (mIsDestroyed.get() || mThemeHelper == null) return;
        
        if (song == null) {
            clearSongInfo();
            return;
        }
        
        updateTitleAndArtist(song);
        updateDuration(song.getDuration());
    }
    
    /**
     * Updates the title and artist displays.
     */
    private void updateTitleAndArtist(@NonNull Song song) {
        String displayTitle = truncateText(song.getTitle(), MAX_TITLE_LENGTH);
        if (mSongTitle != null) {
            mSongTitle.setText(displayTitle != null ? displayTitle : "Unknown Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        String displayArtist = truncateText(song.getArtist(), MAX_ARTIST_LENGTH);
        if (mSongArtist != null) {
            mSongArtist.setText(displayArtist != null ? displayArtist : "Unknown Artist");
            mSongArtist.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
    }
    
    /**
     * Updates the total duration display.
     */
    private void updateDuration(long durationMs) {
        if (mTotalTime != null && durationMs > 0) {
            mTotalTime.setText(formatTime((int) durationMs));
        }
    }
    
    /**
     * Clears song information from UI.
     */
    private void clearSongInfo() {
        if (mSongTitle != null) {
            mSongTitle.setText("Title");
        }
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mSeekBar != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
        }
    }
    
    /**
     * Updates the position display (seekbar and time text).
     * Called from the parent's PlaybackController listener.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Total duration in milliseconds
     */
    public void updatePosition(long positionMs, long durationMs) {
        if (mIsDestroyed.get()) return;
        
        // Skip if user is dragging
        if (mIsUserSeeking) return;
        
        if (mSeekBar != null) {
            if (durationMs > 0 && mSeekBar.getMax() != (int) durationMs) {
                mSeekBar.setMax((int) durationMs);
            }
            mSeekBar.setProgress((int) positionMs);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText(formatTime((int) positionMs));
        }
        
        if (mTotalTime != null && durationMs > 0) {
            mTotalTime.setText(formatTime((int) durationMs));
        }
    }
    
    /**
     * Updates the play/pause button state.
     *
     * @param isPlaying True if playing
     * @param playButton The play/pause button
     * @param isEnabled Whether the button is enabled
     */
    public void updatePlayButtonState(boolean isPlaying, @Nullable Button playButton, boolean isEnabled) {
        if (playButton == null || mThemeHelper == null) return;
        
        playButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
        if (isEnabled) {
            mThemeHelper.updateControlButton(playButton, true, true);
        }
    }
    
    /**
     * Updates the repeat button icon.
     *
     * @param repeatMode 0=off, 1=all, 2=one
     * @param repeatButton The repeat button
     * @param isEnabled Whether the button is enabled
     */
    public void updateRepeatButton(int repeatMode, @Nullable Button repeatButton, boolean isEnabled) {
        if (repeatButton == null || mThemeHelper == null) return;
        
        if (repeatMode == 2) {
            repeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            repeatButton.setText(FontAwesome.REPEAT);
        }
        
        boolean isActive = (repeatMode != 0);
        mThemeHelper.updateControlButton(repeatButton, isEnabled, isActive);
    }
    
    /**
     * Updates the shuffle button icon.
     *
     * @param isShuffleOn True if shuffle is enabled
     * @param shuffleButton The shuffle button
     * @param isEnabled Whether the button is enabled
     */
    public void updateShuffleButton(boolean isShuffleOn, @Nullable Button shuffleButton, boolean isEnabled) {
        if (shuffleButton == null || mThemeHelper == null) return;
        
        shuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(shuffleButton, isEnabled, isShuffleOn);
    }
    
    /**
     * Truncates text with ellipsis if it exceeds max length.
     */
    @NonNull
    private String truncateText(@Nullable String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + ELLIPSIS;
    }
    
    /**
     * Formats milliseconds into a time string (MM:SS or HH:MM:SS).
     */
    @NonNull
    public static String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Updates the album art display for the given song file.
     */
    public void updateAlbumArt(@Nullable final String filePath) {
        if (mIsDestroyed.get()) return;
        
        if (mIsSyncInProgress && filePath != null && filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }
        
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            notifyNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        
        // Check cache first (volatile read is safe)
        final android.util.LruCache<String, Bitmap> cache = mAlbumArtCache;
        if (cache != null) {
            final Bitmap cached = cache.get(filePath);
            if (cached != null && !cached.isRecycled()) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        // Cancel any ongoing task
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;
        
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;
                
                MediaMetadataRetriever retriever = null;
                Bitmap result = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        result = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                
                final Bitmap bitmap = result;
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsDestroyed.get()) return;
                        if (!Thread.currentThread().isInterrupted() && 
                            taskPath.equals(mCurrentLoadingArtPath) && 
                            taskPath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null) {
                                final android.util.LruCache<String, Bitmap> currentCache = mAlbumArtCache;
                                if (currentCache != null) {
                                    currentCache.put(taskPath, bitmap);
                                }
                                applyAlbumArtWithFade(bitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtTask == Thread.currentThread()) {
                            mCurrentAlbumArtTask = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Decodes a byte array into a sampled bitmap to save memory.
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Calculates the sample size for efficient bitmap decoding.
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Applies album art with a fade-in animation.
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            notifyNotificationAlbumArt();
            return;
        }
        
        if (mIsDestroyed.get() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        
        mAlbumArtView.animate()
            .alpha(1f)
            .setDuration(ALBUM_ART_FADE_DURATION_MS)
            .setListener(null);
        
        applyAlbumArtClipping();
        notifyNotificationAlbumArt();
    }
    
    /**
     * Checks if a bitmap is valid for display.
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    /**
     * Applies rounded corners to the album art container.
     */
    public void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
        }
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Loads and displays the placeholder album art image.
     */
    public void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    /**
     * Updates the placeholder bitmap with the current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (mIsDestroyed.get() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(mContext.getResources(), 
                            R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    mMainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mIsDestroyed.get()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            if (mAlbumArtView != null && mCurrentAlbumArtPath == null) {
                                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                applyAlbumArtClipping();
                                notifyNotificationAlbumArt();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }
    
    /**
     * Notifies the listener about album art for notification.
     */
    private void notifyNotificationAlbumArt() {
        if (mListener == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = mCurrentAlbumArtPath;
        final android.util.LruCache<String, Bitmap> cache = mAlbumArtCache;
        if (currentPath != null && cache != null) {
            final Bitmap cached = cache.get(currentPath);
            if (cached != null && !cached.isRecycled()) {
                art = cached;
            }
        }
        
        mListener.onNotificationAlbumArtUpdate(art, placeholder, currentPath);
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a dim overlay with a loading spinner.
     */
    public void showLoadingOverlay(@Nullable ViewGroup rootView) {
        if (mIsDestroyed.get()) return;
        if (mDimOverlay != null) return;
        if (rootView == null) return;
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mIsDestroyed.get() || rootView == null) return;

                final android.widget.FrameLayout overlay = new android.widget.FrameLayout(mContext);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(android.graphics.Color.argb(DIM_ALPHA, 18, 18, 18));

                final android.widget.FrameLayout container = new android.widget.FrameLayout(mContext);
                container.setLayoutParams(new android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT, 
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(mContext);
                mLoadingSpinner.setIndeterminate(true);

                final android.widget.FrameLayout.LayoutParams progressParams = 
                    new android.widget.FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                    );
                progressParams.gravity = android.view.Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Hides the loading overlay if it is visible.
     */
    public void hideLoadingOverlay() {
        if (mIsDestroyed.get()) return;
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Button Animation Methods
    // ========================================================================
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     */
    public void animateButton(@Nullable final Button button) {
        if (button == null || mIsDestroyed.get()) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN)
                                   .scaleY(BUTTON_SCALE_DOWN)
                                   .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                   .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL)
                                   .scaleY(BUTTON_SCALE_NORMAL)
                                   .setDuration(BUTTON_ANIMATION_DURATION_MS)
                                   .start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Applies the current theme color to all UI elements.
     */
    public void applyThemeToUI() {
        if (mIsDestroyed.get() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
        
        updatePlaceholderBitmap();
    }
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /**
     * Sets the sync in progress flag.
     */
    public void setSyncInProgress(boolean inProgress) {
        mIsSyncInProgress = inProgress;
    }
    
    /**
     * Sets the user seeking flag.
     */
    public void setUserSeeking(boolean isSeeking) {
        mIsUserSeeking = isSeeking;
    }
    
    /**
     * Checks if the user is currently seeking.
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking;
    }
    
    // ========================================================================
    // Cleanup Methods
    // ========================================================================
    
    /**
     * Cleans up all resources.
     */
    public void release() {
        mIsDestroyed.set(true);
        
        // Cancel album art loading task
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        // Cleanup placeholder bitmaps
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
        
        // Shutdown executors
        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdown();
        }
        
        if (mPlaceholderExecutor != null && !mPlaceholderExecutor.isShutdown()) {
            mPlaceholderExecutor.shutdown();
        }
        
        // Clear cache
        final android.util.LruCache<String, Bitmap> cache = mAlbumArtCache;
        if (cache != null) {
            cache.evictAll();
        }
        mAlbumArtCache = null;
        
        // Remove handler callbacks
        mMainHandler.removeCallbacksAndMessages(null);
        
        // Hide overlay
        hideLoadingOverlay();
        
        mListener = null;
        
        Log.d(TAG, "DisplayManager released");
    }
    
    /**
     * Safely recycles a bitmap if it exists and is not already recycled.
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    /**
     * Converts density-independent pixels to absolute pixels.
     */
    private int dpToPx(int dp) {
        return Math.round(dp * mContext.getResources().getDisplayMetrics().density);
    }
}