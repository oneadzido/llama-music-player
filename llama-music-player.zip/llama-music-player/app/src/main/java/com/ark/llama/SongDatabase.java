package com.ark.llama;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Database helper for caching song metadata with URI support for scoped storage.
 * 
 * <p>This class provides a persistent cache for song metadata (title, artist, album,
 * genre, duration, and document URI) to avoid repeatedly reading ID3 tags from audio files.
 * Reading metadata from audio files is an expensive operation, especially when dealing
 * with large music libraries. This cache significantly improves performance by storing
 * parsed metadata in a local SQLite database.</p>
 * 
 * <h3>Database Schema</h3>
 * <p>The database has two tables:</p>
 * <ul>
 *   <li><b>songs</b> - Cached metadata for songs in imported folders</li>
 *   <li><b>loose_songs</b> - Cached metadata for songs opened as loose tracks</li>
 * </ul>
 * 
 * <p>Both tables now have identical schema for consistency, including the following columns:</p>
 * <ul>
 *   <li><b>path</b> (TEXT PRIMARY KEY) - Absolute file path, unique identifier for each song</li>
 *   <li><b>title</b> (TEXT) - Song title from ID3 tags or filename fallback</li>
 *   <li><b>artist</b> (TEXT) - Artist name from ID3 tags</li>
 *   <li><b>album</b> (TEXT) - Album name from ID3 tags</li>
 *   <li><b>genre</b> (TEXT) - Music genre from ID3 tags</li>
 *   <li><b>duration</b> (INTEGER) - Track duration in milliseconds</li>
 *   <li><b>modified</b> (INTEGER) - Last modified timestamp for cache validation</li>
 *   <li><b>file_size</b> (INTEGER) - File size in bytes for cache validation</li>
 *   <li><b>uri</b> (TEXT) - Document URI for scoped storage write access (Android 10+)</li>
 * </ul>
 * 
 * <h3>Version History</h3>
 * <ul>
 *   <li><b>Version 1</b> - Initial release with basic schema</li>
 *   <li><b>Version 2</b> - Added COL_FILE_SIZE and COL_URI to loose_songs table to match songs table</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>All database operations are annotated with @WorkerThread and should be called
 * from background threads. The class uses write-ahead logging and proper synchronization
 * through SQLite's built-in mechanisms.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Get singleton instance
 * SongDatabase db = SongDatabase.getInstance(context);
 * 
 * // Insert a song (runs on background thread)
 * new Thread(() -> {
 *     db.insertSong(song);
 * }).start();
 * 
 * // Get all songs sorted by title
 * ArrayList&lt;Song&gt; songs = db.getAllSongs();
 * </pre>
 * 
 * @see Song
 * @see SQLiteOpenHelper
 * @see WorkerThread
 * 
 * @author Richard Korbla Adzido
 * @version 2.0
 * @since 1.0
 */
public class SongDatabase extends SQLiteOpenHelper {

    // ========================================================================
    // Database Constants
    // ========================================================================
    
    /** Database file name. */
    private static final String DB_NAME = "songs_cache.db";
    
    /**
     * Database version.
     * 
     * <p>Version 2 adds COL_FILE_SIZE and COL_URI to loose_songs table to
     * match the songs table schema for consistency.</p>
     */
    private static final int DB_VERSION = 2;
    
    /** Main songs table name for imported folder songs. */
    private static final String TABLE_SONGS = "songs";
    
    /** Loose songs table name for individually opened tracks. */
    private static final String TABLE_LOOSE_SONGS = "loose_songs";
    
    // ========================================================================
    // Column Constants
    // ========================================================================
    
    /** File path (primary key) - uniquely identifies a song. */
    private static final String COL_PATH = "path";
    
    /** Song title from ID3 tags or filename fallback. */
    private static final String COL_TITLE = "title";
    
    /** Artist name from ID3 tags. */
    private static final String COL_ARTIST = "artist";
    
    /** Album name from ID3 tags. */
    private static final String COL_ALBUM = "album";
    
    /** Music genre from ID3 tags. */
    private static final String COL_GENRE = "genre";
    
    /** Duration in milliseconds. */
    private static final String COL_DURATION = "duration";
    
    /** Last modified timestamp for cache validation. */
    private static final String COL_MODIFIED = "modified";
    
    /** File size in bytes for cache validation. */
    private static final String COL_FILE_SIZE = "file_size";
    
    /** Document URI for scoped storage write access (Android 10+). */
    private static final String COL_URI = "uri";
    
    // ========================================================================
    // Logging
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SongDatabase";
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance (volatile for thread safety). */
    @Nullable
    private static volatile SongDatabase sInstance;
    
    /**
     * Returns the singleton instance of SongDatabase.
     * 
     * <p>This method is thread-safe and uses double-checked locking for
     * efficient singleton initialization.</p>
     *
     * @param context Application context (will be converted to application context)
     * @return The singleton instance
     */
    @NonNull
    public static SongDatabase getInstance(@NonNull Context context) {
        if (sInstance == null) {
            synchronized (SongDatabase.class) {
                if (sInstance == null) {
                    sInstance = new SongDatabase(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Private constructor for singleton pattern.
     * 
     * <p>Enables write-ahead logging for better concurrent read/write performance.</p>
     *
     * @param context Application context
     */
    private SongDatabase(@NonNull Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        setWriteAheadLoggingEnabled(true);
    }
    
    // ========================================================================
    // SQLiteOpenHelper Methods
    // ========================================================================
    
    /**
     * Called when the database is configured.
     * 
     * <p>Enables foreign key constraints for referential integrity (though
     * currently not using foreign keys, this is good practice for future).</p>
     *
     * @param db The database
     */
    @Override
    public void onConfigure(@NonNull SQLiteDatabase db) {
        super.onConfigure(db);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            db.setForeignKeyConstraintsEnabled(true);
        }
    }
    
    /**
     * Creates the database tables and indexes.
     * 
     * <p>This method is called when the database is created for the first time.
     * Both tables are created with identical schemas for consistency.</p>
     *
     * @param db The database
     */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        // ====================================================================
        // Main songs table with URI column for scoped storage
        // ====================================================================
        db.execSQL("CREATE TABLE " + TABLE_SONGS + " (" +
                COL_PATH + " TEXT PRIMARY KEY, " +
                COL_TITLE + " TEXT, " +
                COL_ARTIST + " TEXT, " +
                COL_ALBUM + " TEXT, " +
                COL_GENRE + " TEXT, " +
                COL_DURATION + " INTEGER, " +
                COL_MODIFIED + " INTEGER, " +
                COL_FILE_SIZE + " INTEGER, " +
                COL_URI + " TEXT)");
        
        // Create indexes for performance on main table
        db.execSQL("CREATE INDEX idx_path ON " + TABLE_SONGS + "(" + COL_PATH + ")");
        db.execSQL("CREATE INDEX idx_title ON " + TABLE_SONGS + "(" + COL_TITLE + ")");
        db.execSQL("CREATE INDEX idx_modified ON " + TABLE_SONGS + "(" + COL_MODIFIED + ")");
        
        // ====================================================================
        // Loose songs table - now identical schema to songs table (Version 2)
        // ====================================================================
        db.execSQL("CREATE TABLE " + TABLE_LOOSE_SONGS + " (" +
                COL_PATH + " TEXT PRIMARY KEY, " +
                COL_TITLE + " TEXT, " +
                COL_ARTIST + " TEXT, " +
                COL_ALBUM + " TEXT, " +
                COL_GENRE + " TEXT, " +
                COL_DURATION + " INTEGER, " +
                COL_MODIFIED + " INTEGER, " +
                COL_FILE_SIZE + " INTEGER, " +
                COL_URI + " TEXT)");
        
        // Create index for loose songs table
        db.execSQL("CREATE INDEX idx_loose_path ON " + TABLE_LOOSE_SONGS + "(" + COL_PATH + ")");
        
        Log.d(TAG, "Database created successfully with version " + DB_VERSION);
    }
    
    /**
     * Upgrades the database schema.
     * 
     * <p>Handles migrations between database versions. Currently supports
     * upgrade from version 1 to version 2 by adding missing columns to
     * the loose_songs table.</p>
     *
     * @param db The database
     * @param oldVersion Old version number
     * @param newVersion New version number
     */
    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);
        
        if (oldVersion < 2) {
            // Add missing columns to loose_songs table for version 2
            try {
                db.execSQL("ALTER TABLE " + TABLE_LOOSE_SONGS + " ADD COLUMN " + COL_FILE_SIZE + " INTEGER DEFAULT 0");
                db.execSQL("ALTER TABLE " + TABLE_LOOSE_SONGS + " ADD COLUMN " + COL_URI + " TEXT");
                Log.d(TAG, "Successfully upgraded loose_songs table to version 2");
            } catch (Exception e) {
                Log.e(TAG, "Failed to upgrade loose_songs table", e);
            }
        }
        
        // Future upgrades can be added here with additional if/else blocks
        // Example:
        // if (oldVersion < 3) {
        //     // Upgrade to version 3
        // }
        
        Log.d(TAG, "Database upgrade completed");
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    /**
     * Safely gets the file size, returning 0 on error.
     * 
     * <p>This method handles SecurityException which can occur if the app
     * doesn't have permission to access the file.</p>
     *
     * @param path File path
     * @return File size in bytes, or 0 if inaccessible
     */
    @WorkerThread
    private long safeGetFileSize(@NonNull String path) {
        try {
            File file = new File(path);
            return (file.exists() && file.canRead()) ? file.length() : 0L;
        } catch (SecurityException e) {
            Log.w(TAG, "No permission for file size: " + path);
            return 0L;
        }
    }
    
    /**
     * Safely closes a cursor, ignoring any exceptions.
     * 
     * <p>This is a utility method to reduce boilerplate in try-finally blocks.</p>
     *
     * @param cursor The cursor to close (can be null)
     */
    private void closeCursorSafely(@Nullable Cursor cursor) {
        if (cursor != null) {
            try {
                cursor.close();
            } catch (Exception e) {
                Log.w(TAG, "Failed to close cursor", e);
            }
        }
    }
    
    /**
     * Gets the count of rows that would be deleted (for return value).
     * 
     * <p>This method is used by deleteSongsNotInSet() to provide accurate
     * deletion counts without actually deleting the rows.</p>
     *
     * @param validPaths Set of valid paths to keep
     * @return Number of rows that would be deleted
     */
    @WorkerThread
    private int getCountOfSongsNotInSet(@NonNull Set<String> validPaths) {
        if (validPaths.isEmpty()) {
            return getSongsCount();
        }
        
        String[] pathArray = validPaths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < pathArray.length; i++) {
            if (i > 0) placeholders.append(",");
            placeholders.append("?");
        }
        
        String query = "SELECT COUNT(*) FROM " + TABLE_SONGS + " WHERE " + COL_PATH + 
                      " NOT IN (" + placeholders.toString() + ")";
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery(query, pathArray);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.e(TAG, "getCountOfSongsNotInSet error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return 0;
    }
    
    // ========================================================================
    // Query Methods - Main Songs Table
    // ========================================================================
    
    /**
     * Checks if a song exists in the database.
     *
     * @param path The file path to check
     * @return True if the song exists in the cache
     */
    @WorkerThread
    public boolean hasSong(@NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE_SONGS, new String[]{COL_PATH},
                    COL_PATH + "=?", new String[]{path}, null, null, null);
            return cursor != null && cursor.moveToFirst();
        } catch (Exception e) {
            Log.e(TAG, "hasSong error", e);
            return false;
        } finally {
            closeCursorSafely(cursor);
        }
    }
    
    /**
     * Gets a set of existing paths from a given set of paths.
     * 
     * <p>This method is used during playlist sync to efficiently determine
     * which songs already exist in the cache without loading full Song objects.</p>
     *
     * @param paths Set of paths to check
     * @return Set of paths that exist in the database
     */
    @NonNull
    @WorkerThread
    public Set<String> getExistingPaths(@Nullable Set<String> paths) {
        Set<String> existing = new HashSet<String>();
        if (paths == null || paths.isEmpty()) {
            return existing;
        }
        
        String[] pathArray = paths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < pathArray.length; i++) {
            if (i > 0) placeholders.append(",");
            placeholders.append("?");
        }
        
        String query = "SELECT " + COL_PATH + " FROM " + TABLE_SONGS + 
                      " WHERE " + COL_PATH + " IN (" + placeholders.toString() + ")";
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery(query, pathArray);
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndex(COL_PATH);
                if (columnIndex >= 0) {
                    while (cursor.moveToNext()) {
                        String path = cursor.getString(columnIndex);
                        if (path != null) {
                            existing.add(path);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getExistingPaths error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return existing;
    }
    
    /**
     * Retrieves a song from the database by its file path.
     *
     * @param path The file path of the song
     * @return The Song object, or null if not found in cache
     */
    @Nullable
    @WorkerThread
    public Song getSong(@NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE_SONGS, null, COL_PATH + "=?",
                    new String[]{path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int titleCol = cursor.getColumnIndex(COL_TITLE);
                int artistCol = cursor.getColumnIndex(COL_ARTIST);
                int albumCol = cursor.getColumnIndex(COL_ALBUM);
                int genreCol = cursor.getColumnIndex(COL_GENRE);
                int durationCol = cursor.getColumnIndex(COL_DURATION);
                int uriCol = cursor.getColumnIndex(COL_URI);
                
                if (titleCol >= 0 && artistCol >= 0 && albumCol >= 0 && durationCol >= 0) {
                    String title = cursor.getString(titleCol);
                    String artist = cursor.getString(artistCol);
                    String album = cursor.getString(albumCol);
                    String genre = (genreCol >= 0) ? cursor.getString(genreCol) : null;
                    long duration = cursor.getLong(durationCol);
                    String uri = (uriCol >= 0) ? cursor.getString(uriCol) : null;
                    return new Song(title, artist, album, genre, path, duration, uri);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getSong error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return null;
    }
    
    // ========================================================================
    // Insert/Update Methods - Main Songs Table
    // ========================================================================
    
    /**
     * Inserts or updates a song in the database.
     * 
     * <p>Uses CONFLICT_REPLACE to handle existing rows, effectively performing
     * an upsert (update if exists, insert if not).</p>
     *
     * @param song The song to insert or update (can be null)
     */
    @WorkerThread
    public void insertSong(@Nullable Song song) {
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            return;
        }
        
        ContentValues values = new ContentValues();
        values.put(COL_PATH, song.getPath());
        values.put(COL_TITLE, song.getTitle() != null ? song.getTitle() : "");
        values.put(COL_ARTIST, song.getArtist() != null ? song.getArtist() : "");
        values.put(COL_ALBUM, song.getAlbum() != null ? song.getAlbum() : "");
        values.put(COL_GENRE, song.getGenre() != null ? song.getGenre() : "");
        values.put(COL_DURATION, song.getDuration());
        values.put(COL_MODIFIED, System.currentTimeMillis());
        values.put(COL_FILE_SIZE, safeGetFileSize(song.getPath()));
        if (song.getUri() != null) {
            values.put(COL_URI, song.getUri());
        }
        
        try {
            getWritableDatabase().insertWithOnConflict(TABLE_SONGS, null, values, 
                SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            Log.e(TAG, "insertSong error", e);
        }
    }
    
    /**
     * Inserts multiple songs in a batch transaction.
     * 
     * <p>Batch insertion is significantly faster than individual inserts
     * for large playlists. All inserts are performed within a single
     * database transaction for atomicity and performance.</p>
     *
     * @param songs List of songs to insert (can be null or empty)
     */
    @WorkerThread
    public void insertSongsBatch(@Nullable ArrayList<Song> songs) {
        if (songs == null || songs.isEmpty()) {
            return;
        }
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            db.beginTransaction();
            for (Song song : songs) {
                if (song == null || TextUtils.isEmpty(song.getPath())) {
                    continue;
                }
                ContentValues values = new ContentValues();
                values.put(COL_PATH, song.getPath());
                values.put(COL_TITLE, song.getTitle());
                values.put(COL_ARTIST, song.getArtist());
                values.put(COL_ALBUM, song.getAlbum());
                values.put(COL_GENRE, song.getGenre());
                values.put(COL_DURATION, song.getDuration());
                values.put(COL_MODIFIED, System.currentTimeMillis());
                values.put(COL_FILE_SIZE, safeGetFileSize(song.getPath()));
                if (song.getUri() != null) {
                    values.put(COL_URI, song.getUri());
                }
                db.insertWithOnConflict(TABLE_SONGS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
            Log.d(TAG, "Batch inserted " + songs.size() + " songs");
        } catch (Exception e) {
            Log.e(TAG, "Batch insert error", e);
        } finally {
            if (db != null) {
                try {
                    db.endTransaction();
                } catch (Exception ignored) {
                }
            }
        }
    }
    
    /**
     * Deletes all songs whose paths are not in the valid set.
     * 
     * <p>This method is used during playlist sync to remove songs that are
     * no longer in any selected folder. It preserves songs whose paths are
     * in the validPaths set. Returns the number of songs deleted.</p>
     *
     * @param validPaths Set of valid paths to keep (can be null or empty)
     * @return Number of songs deleted
     */
    @WorkerThread
    public int deleteSongsNotInSet(@Nullable Set<String> validPaths) {
        int deletedCount = 0;
        
        if (validPaths == null || validPaths.isEmpty()) {
            deletedCount = getSongsCount();
            clearCache();
            return deletedCount;
        }
        
        // First, get count of songs to be deleted
        deletedCount = getCountOfSongsNotInSet(validPaths);
        if (deletedCount == 0) {
            return 0;
        }
        
        // Build IN clause with placeholders
        String[] pathArray = validPaths.toArray(new String[0]);
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < pathArray.length; i++) {
            if (i > 0) placeholders.append(",");
            placeholders.append("?");
        }
        
        String query = "DELETE FROM " + TABLE_SONGS + " WHERE " + COL_PATH + 
                      " NOT IN (" + placeholders.toString() + ")";
        try {
            getWritableDatabase().execSQL(query, pathArray);
            Log.d(TAG, "Deleted " + deletedCount + " songs not in selected folders");
        } catch (Exception e) {
            Log.e(TAG, "deleteSongsNotInSet error", e);
            return 0;
        }
        
        return deletedCount;
    }
    
    /**
     * Clears all cached songs from the database.
     * 
     * <p>This method deletes all rows from the main songs table.
     * Loose songs are preserved as they are stored separately.</p>
     */
    @WorkerThread
    public void clearCache() {
        try {
            int deleted = getWritableDatabase().delete(TABLE_SONGS, null, null);
            Log.d(TAG, "Cleared cache, deleted " + deleted + " songs");
        } catch (Exception e) {
            Log.e(TAG, "clearCache error", e);
        }
    }
    
    /**
     * Removes a single song from the database by its file path.
     *
     * @param path The file path of the song to remove
     */
    @WorkerThread
    public void removeSong(@NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return;
        }
        try {
            int deleted = getWritableDatabase().delete(TABLE_SONGS, COL_PATH + "=?", new String[]{path});
            if (deleted > 0) {
                Log.d(TAG, "Removed song: " + path);
            }
        } catch (Exception e) {
            Log.e(TAG, "removeSong error", e);
        }
    }
    
    /**
     * Returns all songs from the database sorted by title.
     * 
     * <p>The songs are sorted case-insensitively by title for consistent
     * display in the playlist. Loose songs are NOT included in this list;
     * use getLooseSongs() for those.</p>
     *
     * @return List of all songs in the cache (never null, may be empty)
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getAllSongs() {
        ArrayList<Song> songs = new ArrayList<Song>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE_SONGS, null, null, null, null, null,
                    COL_TITLE + " COLLATE NOCASE ASC");
            if (cursor != null && cursor.moveToFirst()) {
                int titleCol = cursor.getColumnIndex(COL_TITLE);
                int artistCol = cursor.getColumnIndex(COL_ARTIST);
                int albumCol = cursor.getColumnIndex(COL_ALBUM);
                int genreCol = cursor.getColumnIndex(COL_GENRE);
                int pathCol = cursor.getColumnIndex(COL_PATH);
                int durationCol = cursor.getColumnIndex(COL_DURATION);
                int uriCol = cursor.getColumnIndex(COL_URI);
                
                if (titleCol >= 0 && artistCol >= 0 && albumCol >= 0 && pathCol >= 0 && durationCol >= 0) {
                    do {
                        String title = cursor.getString(titleCol);
                        String artist = cursor.getString(artistCol);
                        String album = cursor.getString(albumCol);
                        String genre = (genreCol >= 0) ? cursor.getString(genreCol) : null;
                        String path = cursor.getString(pathCol);
                        long duration = cursor.getLong(durationCol);
                        String uri = (uriCol >= 0) ? cursor.getString(uriCol) : null;
                        if (path != null) {
                            songs.add(new Song(
                                    title != null ? title : "Unknown Title",
                                    artist != null ? artist : "Unknown Artist",
                                    album != null ? album : "Unknown Album",
                                    genre,
                                    path, duration, uri));
                        }
                    } while (cursor.moveToNext());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getAllSongs error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return songs;
    }
    
    /**
     * Returns the number of songs in the main songs table.
     *
     * @return Song count
     */
    @WorkerThread
    public int getSongsCount() {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE_SONGS, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.e(TAG, "getSongsCount error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return 0;
    }
    
    /**
     * Checks if a file has been modified since it was cached.
     * 
     * <p>This method compares the current modification timestamp with the
     * cached timestamp. If the file has been modified, the cache should be
     * refreshed by re-reading metadata.</p>
     *
     * @param path The file path
     * @param currentModified The current modification timestamp
     * @return True if the file has been modified since it was cached
     */
    @WorkerThread
    public boolean isFileModified(@NonNull String path, long currentModified) {
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE_SONGS, new String[]{COL_MODIFIED},
                    COL_PATH + "=?", new String[]{path}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                long cachedModified = cursor.getLong(0);
                return cachedModified != currentModified;
            }
        } catch (Exception e) {
            Log.e(TAG, "isFileModified error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return true;
    }
    
    // ========================================================================
    // Loose Songs Table Methods
    // ========================================================================
    
    /**
     * Inserts a loose song into the database.
     * 
     * <p>Loose songs are audio files opened from external apps (ACTION_VIEW)
     * that are not in any imported folder. They are stored separately from
     * the main songs table but use the same schema.</p>
     * 
     * <p><b>Version 2:</b> Now includes COL_FILE_SIZE and COL_URI columns
     * to match the main songs table schema.</p>
     *
     * @param song The loose song to insert (can be null)
     */
    @WorkerThread
    public void insertLooseSong(@Nullable Song song) {
        if (song == null || TextUtils.isEmpty(song.getPath())) {
            return;
        }
        ContentValues values = new ContentValues();
        values.put(COL_PATH, song.getPath());
        values.put(COL_TITLE, song.getTitle() != null ? song.getTitle() : "");
        values.put(COL_ARTIST, song.getArtist() != null ? song.getArtist() : "");
        values.put(COL_ALBUM, song.getAlbum() != null ? song.getAlbum() : "");
        values.put(COL_GENRE, song.getGenre() != null ? song.getGenre() : "");
        values.put(COL_DURATION, song.getDuration());
        values.put(COL_MODIFIED, System.currentTimeMillis());
        values.put(COL_FILE_SIZE, safeGetFileSize(song.getPath()));
        if (song.getUri() != null) {
            values.put(COL_URI, song.getUri());
        }
        
        try {
            getWritableDatabase().insertWithOnConflict(TABLE_LOOSE_SONGS, null, values,
                SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            Log.e(TAG, "insertLooseSong error", e);
        }
    }
    
    /**
     * Returns all loose songs from the database sorted by title.
     * 
     * <p>Loose songs are stored separately from the main playlist and are
     * displayed as a special "Loose Tracks" entry in the folder manager.</p>
     * 
     * <p><b>Version 2:</b> Now reads the URI column to support scoped storage
     * write permissions for metadata editing of loose tracks.</p>
     *
     * @return List of loose songs (never null, may be empty)
     */
    @NonNull
    @WorkerThread
    public ArrayList<Song> getLooseSongs() {
        ArrayList<Song> songs = new ArrayList<Song>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE_LOOSE_SONGS, null, null, null, null, null,
                    COL_TITLE + " COLLATE NOCASE ASC");
            if (cursor != null && cursor.moveToFirst()) {
                int titleCol = cursor.getColumnIndex(COL_TITLE);
                int artistCol = cursor.getColumnIndex(COL_ARTIST);
                int albumCol = cursor.getColumnIndex(COL_ALBUM);
                int genreCol = cursor.getColumnIndex(COL_GENRE);
                int pathCol = cursor.getColumnIndex(COL_PATH);
                int durationCol = cursor.getColumnIndex(COL_DURATION);
                int uriCol = cursor.getColumnIndex(COL_URI);
                
                if (titleCol >= 0 && artistCol >= 0 && albumCol >= 0 && pathCol >= 0 && durationCol >= 0) {
                    do {
                        String title = cursor.getString(titleCol);
                        String artist = cursor.getString(artistCol);
                        String album = cursor.getString(albumCol);
                        String genre = (genreCol >= 0) ? cursor.getString(genreCol) : null;
                        String path = cursor.getString(pathCol);
                        long duration = cursor.getLong(durationCol);
                        String uri = (uriCol >= 0) ? cursor.getString(uriCol) : null;
                        if (path != null) {
                            songs.add(new Song(title, artist, album, genre, path, duration, uri));
                        }
                    } while (cursor.moveToNext());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getLooseSongs error", e);
        } finally {
            closeCursorSafely(cursor);
        }
        return songs;
    }
    
    /**
     * Clears all loose songs from the database.
     * 
     * <p>This is typically called when the user removes the "Loose Tracks"
     * entry from the folder manager or when all loose tracks have been
     * imported into folders.</p>
     */
    @WorkerThread
    public void clearLooseSongs() {
        try {
            int deleted = getWritableDatabase().delete(TABLE_LOOSE_SONGS, null, null);
            Log.d(TAG, "Cleared loose songs, deleted " + deleted + " songs");
        } catch (Exception e) {
            Log.e(TAG, "clearLooseSongs error", e);
        }
    }
    
    /**
     * Removes a specific loose song from the database.
     *
     * @param path The file path of the loose song to remove
     */
    @WorkerThread
    public void removeLooseSong(@NonNull String path) {
        if (TextUtils.isEmpty(path)) {
            return;
        }
        try {
            int deleted = getWritableDatabase().delete(TABLE_LOOSE_SONGS, COL_PATH + "=?", new String[]{path});
            if (deleted > 0) {
                Log.d(TAG, "Removed loose song: " + path);
            }
        } catch (Exception e) {
            Log.e(TAG, "removeLooseSong error", e);
        }
    }
}