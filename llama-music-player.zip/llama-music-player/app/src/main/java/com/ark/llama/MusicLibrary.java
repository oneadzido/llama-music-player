package com.ark.llama;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Manages music library operations including folder scanning, song caching, and playlist management.
 * 
 * <p>This class provides a comprehensive API for:
 * <ul>
 *   <li>Managing selected music folders (add/remove)</li>
 *   <li>Scanning folders for audio files using MediaStore</li>
 *   <li>Caching song metadata (including title, artist, album, genre, duration) in the database for performance</li>
 *   <li>Searching songs by title, artist, album, or genre</li>
 *   <li>Handling loose tracks (songs opened from other apps)</li>
 *   <li>Asynchronous loading with progress callbacks</li>
 * </ul>
 * </p>
 * 
 * <p>The class follows Google's recommendations for:
 * <ul>
 *   <li>Background processing using ExecutorService</li>
 *   <li>Thread-safe operations with synchronized blocks</li>
 *   <li>Proper cursor management and cleanup</li>
 *   <li>WorkerThread annotations for database operations</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All delays use Handler.postDelayed() for UI updates.
 * ExecutorService is properly managed with shutdown on app termination.</p>
 * 
 * @see Song
 * @see SongDatabase
 * @see CharacterMapper
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicLibrary {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing selected folder URIs. */
    private static final String KEY_FOLDERS = "selected_folders_uris";
    
    /** Log tag for this class. */
    private static final String TAG = "MusicLibrary";
    
    /** Intent action for playlist load progress broadcasts. */
    public static final String ACTION_PLAYLIST_LOAD_PROGRESS = "com.ark.llama.PLAYLIST_LOAD_PROGRESS";
    
    /** Threshold for UI updates (number of songs between updates). */
    private static final int UI_UPDATE_THRESHOLD = 10;
    
    /** Minimum time between UI updates (milliseconds). */
    private static final long UI_UPDATE_TIME_MS = 500;
    
    /** Shutdown timeout for executor service in milliseconds. */
    private static final long SHUTDOWN_TIMEOUT_MS = 5000;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** Set of selected folder URIs. */
    @NonNull
    private final Set<String> mSelectedFolderUris;
    
    /** List of all songs in the library. */
    @NonNull
    private final ArrayList<Song> mAllSongs;
    
    /** List of songs from previous load (for comparison). */
    @NonNull
    private final ArrayList<Song> mOldSongs = new ArrayList<Song>();
    
    /** List of loose tracks (songs opened from other apps). */
    @NonNull
    private ArrayList<Song> mLooseSongs = new ArrayList<Song>();
    
    /** Database helper for song caching. */
    @NonNull
    private final SongDatabase mSongDatabase;
    
    /** Executor service for background operations. */
    private final ExecutorService mExecutor;
    
    /** Flag indicating if a load operation is in progress. */
    private final AtomicBoolean mIsLoading = new AtomicBoolean(false);
    
    /** Pending listener waiting for async load to complete. */
    @Nullable
    private OnSongsLoadedListener mPendingListener;
    
    /** Flag indicating if the library is loaded. */
    private volatile boolean mIsLoaded = false;
    
    // ========================================================================
    // Listener Interfaces
    // ========================================================================
    
    /**
     * Listener for asynchronous song loading completion.
     */
    public interface OnSongsLoadedListener {
        
        /**
         * Called when songs have been successfully loaded.
         *
         * @param songs The list of loaded songs
         */
        void onSongsLoaded(@NonNull ArrayList<Song> songs);
        
        /**
         * Called when an error occurs during loading.
         *
         * @param error The error message
         */
        void onLoadingError(@NonNull String error);
    }
    
    /**
     * Listener for update progress during playlist synchronization.
     */
    public interface UpdateProgressListener {
        
        /**
         * Called periodically during update to report progress.
         *
         * @param current Current number of songs processed
         * @param total Total number of songs to process
         * @param message Progress message to display
         */
        void onProgress(int current, int total, @NonNull String message);
        
        /**
         * Called when the update completes successfully.
         */
        void onComplete();
        
        /**
         * Called when an error occurs during update.
         *
         * @param error The error message
         */
        void onError(@NonNull String error);
    }
    
    /**
     * Listener for load progress during playlist loading.
     */
    public interface LoadProgressListener {
        
        /**
         * Called periodically during loading with the current count.
         *
         * @param currentCount Current number of songs found
         */
        void onLoadProgress(int currentCount);
        
        /**
         * Called when loading completes successfully.
         *
         * @param songs The list of loaded songs
         */
        void onLoadComplete(@NonNull ArrayList<Song> songs);
        
        /**
         * Called when an error occurs during loading.
         *
         * @param error The error message
         */
        void onLoadError(@NonNull String error);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new MusicLibrary instance.
     * 
     * <p>Initializes the library by loading saved folders and cached songs.</p>
     *
     * @param context Application context
     */
    public MusicLibrary(@NonNull Context context) {
        mContext = context;
        CharacterMapper.init(context);
        mSelectedFolderUris = new HashSet<String>();
        mAllSongs = new ArrayList<Song>();
        mSongDatabase = SongDatabase.getInstance(context);
        mExecutor = Executors.newSingleThreadExecutor();
        
        loadSavedFolders();
        loadSongsFromDatabaseSync();
        loadLooseSongs();
        mergeLooseSongs();
        
        if (!mAllSongs.isEmpty()) {
            mIsLoaded = true;
        }
        
        deleteOldCacheFile();
    }
    
    // ========================================================================
    // Initialization Helpers
    // ========================================================================
    
    /**
     * Deletes the old serialized cache file (no longer used).
     */
    private void deleteOldCacheFile() {
        try {
            File cacheFile = new File(mContext.getFilesDir(), "playlist_cache.ser");
            if (cacheFile.exists()) {
                if (!cacheFile.delete()) {
                    Log.w(TAG, "Failed to delete old cache file");
                }
            }
        } catch (SecurityException e) {
            Log.w(TAG, "Permission denied deleting cache file");
        }
    }
    
    /**
     * Loads saved folder URIs from SharedPreferences.
     */
    private void loadSavedFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> saved = prefs.getStringSet(KEY_FOLDERS, null);
        if (saved != null) {
            mSelectedFolderUris.addAll(saved);
        }
    }
    
    /**
     * Saves folder URIs to SharedPreferences.
     */
    private void saveFolders() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putStringSet(KEY_FOLDERS, mSelectedFolderUris).apply();
    }
    
    /**
     * Loads songs from the database cache synchronously.
     */
    @WorkerThread
    private void loadSongsFromDatabaseSync() {
        ArrayList<Song> cached = mSongDatabase.getAllSongs();
        if (cached != null && !cached.isEmpty()) {
            synchronized (mAllSongs) {
                mAllSongs.clear();
                mAllSongs.addAll(cached);
            }
        }
    }
    
    /**
     * Loads loose tracks from the database.
     */
    private void loadLooseSongs() {
        mLooseSongs = mSongDatabase.getLooseSongs();
        ArrayList<Song> validLooseSongs = new ArrayList<Song>();
        
        for (Song song : mLooseSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validLooseSongs.add(song);
                } else {
                    mSongDatabase.removeLooseSong(song.getPath());
                }
            }
        }
        mLooseSongs = validLooseSongs;
    }
    
    /**
     * Merges loose tracks into the main song list, avoiding duplicates.
     */
    private void mergeLooseSongs() {
        for (Song loose : mLooseSongs) {
            if (loose == null || loose.getPath() == null) {
                continue;
            }
            
            boolean alreadyExists = false;
            synchronized (mAllSongs) {
                for (Song existing : mAllSongs) {
                    if (existing != null && loose.getPath().equals(existing.getPath())) {
                        alreadyExists = true;
                        break;
                    }
                }
                if (!alreadyExists) {
                    mAllSongs.add(loose);
                }
            }
        }
    }
    
    // ========================================================================
    // Public API - Folder Management
    // ========================================================================
    
    /**
     * Returns the set of selected folder URIs.
     *
     * @return Unmodifiable view of selected folders
     */
    @NonNull
    public Set<String> getSelectedFolders() {
        return mSelectedFolderUris;
    }
    
    /**
     * Adds a folder to the selected folders list.
     *
     * @param uri The folder URI to add
     */
    public void addFolder(@NonNull String uri) {
        mSelectedFolderUris.add(uri);
        saveFolders();
    }
    
    /**
     * Removes a folder from the selected folders list.
     *
     * @param uri The folder URI to remove
     */
    public void removeFolder(@NonNull String uri) {
        mSelectedFolderUris.remove(uri);
        saveFolders();
    }
    
    /**
     * Returns the number of selected folders.
     *
     * @return Folder count
     */
    public int getFolderCount() {
        return mSelectedFolderUris.size();
    }
    
    // ========================================================================
    // Public API - Song Management
    // ========================================================================
    
    /**
     * Refreshes the song list with new songs.
     *
     * @param newSongs New song list (can be null)
     */
    public void refreshSongs(@Nullable ArrayList<Song> newSongs) {
        synchronized (mAllSongs) {
            mAllSongs.clear();
            if (newSongs != null) {
                mAllSongs.addAll(newSongs);
            }
        }
        
        if (newSongs == null || !newSongs.isEmpty()) {
            loadLooseSongs();
            mergeLooseSongs();
        }
        
        mIsLoaded = true;
    }
    
    /**
     * Refreshes the in-memory cache from the database.
     * 
     * <p>This method reloads all songs from the database into the in-memory cache.
     * It is called when components need to sync their cached view after database
     * updates (e.g., after Phase 1 completes or after genre updates).</p>
     * 
     * <p>This is the event-driven alternative to creating a new MusicLibrary
     * instance, allowing existing instances to stay in sync with the database.</p>
     */
    public void refreshCache() {
        synchronized (mAllSongs) {
            // Clear and reload from database
            mAllSongs.clear();
            ArrayList<Song> freshSongs = mSongDatabase.getAllSongs();
            if (freshSongs != null) {
                mAllSongs.addAll(freshSongs);
            }
            mergeLooseSongs();
            mIsLoaded = true;
        }
        Log.d(TAG, "Cache refreshed, now has " + mAllSongs.size() + " songs");
    }
    
    /**
     * Removes files that no longer exist from the playlist.
     *
     * @param currentSongs Current song list (can be null)
     */
    public void removeMissingFiles(@Nullable ArrayList<Song> currentSongs) {
        if (currentSongs == null || currentSongs.isEmpty()) {
            return;
        }
        
        ArrayList<Song> validSongs = new ArrayList<Song>();
        for (Song song : currentSongs) {
            if (song != null && song.getPath() != null) {
                File file = new File(song.getPath());
                if (file.exists() && file.canRead()) {
                    validSongs.add(song);
                } else {
                    Log.d(TAG, "Removing missing file: " + song.getPath());
                }
            }
        }
        
        if (validSongs.size() != currentSongs.size()) {
            synchronized (mAllSongs) {
                mAllSongs.clear();
                mAllSongs.addAll(validSongs);
            }
            mSongDatabase.clearCache();
            if (!validSongs.isEmpty()) {
                mSongDatabase.insertSongsBatch(validSongs);
            }
        }
    }
    
    /**
     * Clears the playlist cache from the database.
     */
    @WorkerThread
    public void clearPlaylistCache() {
        mSongDatabase.clearCache();
    }
    
    /**
     * Returns all songs in the library.
     *
     * @return A copy of the song list
     */
    @NonNull
    public ArrayList<Song> getAllSongs() {
        synchronized (mAllSongs) {
            return new ArrayList<Song>(mAllSongs);
        }
    }
    
    /**
     * Returns the number of songs in the library.
     *
     * @return Song count
     */
    public int getSongCount() {
        synchronized (mAllSongs) {
            return mAllSongs.size();
        }
    }
    
    /**
     * Searches for songs matching a query string.
     * 
     * <p>Searches across title, artist, album, and genre fields.</p>
     *
     * @param query The search query (searches title, artist, album, genre)
     * @return List of matching songs
     */
    @NonNull
    public ArrayList<Song> searchSongs(@NonNull String query) {
        if (TextUtils.isEmpty(query)) {
            synchronized (mAllSongs) {
                return new ArrayList<Song>(mAllSongs);
            }
        }
        
        ArrayList<Song> results = new ArrayList<Song>();
        String lowerQuery = query.toLowerCase().trim();
        
        synchronized (mAllSongs) {
            for (Song song : mAllSongs) {
                if (song != null) {
                    String title = song.getTitle();
                    String artist = song.getArtist();
                    String album = song.getAlbum();
                    String genre = song.getGenre();
                    
                    if ((title != null && title.toLowerCase().contains(lowerQuery)) ||
                        (artist != null && artist.toLowerCase().contains(lowerQuery)) ||
                        (album != null && album.toLowerCase().contains(lowerQuery)) ||
                        (genre != null && genre.toLowerCase().contains(lowerQuery))) {
                        results.add(song);
                    }
                }
            }
        }
        
        return results;
    }
    
    /**
     * Updates the genre for a song in the in-memory cache.
     * 
     * <p>This method is called during Phase 2 (genre loading) to keep the
     * in-memory cache synchronized with the database. Without this, the
     * playlist display would still show "Unknown Genre" even after the
     * database has been updated.</p>
     *
     * @param songPath The absolute file path of the song
     * @param genre The new genre to set
     * @return True if the song was found and updated, false otherwise
     */
    public boolean updateSongGenre(@NonNull String songPath, @NonNull String genre) {
        synchronized (mAllSongs) {
            for (Song song : mAllSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    Log.d(TAG, "Updated in-memory genre for: " + song.getTitle() + " -> " + genre);
                    return true;
                }
            }
        }
        
        // Also check loose songs
        synchronized (mLooseSongs) {
            for (Song song : mLooseSongs) {
                if (song != null && songPath.equals(song.getPath())) {
                    song.setGenre(genre);
                    return true;
                }
            }
        }
        
        return false;
    }
    
    // ========================================================================
    // Public API - Old Song Management (for comparison)
    // ========================================================================
    
    /**
     * Returns the number of songs from the previous load.
     *
     * @return Old song count
     */
    public int getOldSongCount() {
        return mOldSongs.size();
    }
    
    /**
     * Returns a song from the previous load by index.
     *
     * @param index The index
     * @return The song, or null if index is invalid
     */
    @Nullable
    public Song getOldSongAt(int index) {
        return (index >= 0 && index < mOldSongs.size()) ? mOldSongs.get(index) : null;
    }
    
    // ========================================================================
    // Public API - Asynchronous Loading
    // ========================================================================
    
    /**
     * Loads all songs asynchronously with a simple callback.
     *
     * @param listener Listener to receive results (can be null)
     */
    public void loadAllSongsAsync(@Nullable final OnSongsLoadedListener listener) {
        if (mIsLoaded && !mAllSongs.isEmpty()) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mAllSongs) {
                            listener.onSongsLoaded(new ArrayList<Song>(mAllSongs));
                        }
                    }
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            mPendingListener = listener;
            return;
        }
        
        mIsLoading.set(true);
        mPendingListener = listener;
        
        final OnSongsLoadedListener capturedListener = listener;
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    loadAllSongsInternal();
                    mIsLoaded = true;
                    
                    if (capturedListener != null) {
                        final ArrayList<Song> finalSongs;
                        synchronized (mAllSongs) {
                            finalSongs = new ArrayList<Song>(mAllSongs);
                        }
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onSongsLoaded(finalSongs);
                            }
                        });
                    }
                } catch (final Exception e) {
                    if (capturedListener != null) {
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                capturedListener.onLoadingError(
                                    e.getMessage() != null ? e.getMessage() : "Unknown error");
                            }
                        });
                    }
                } finally {
                    mIsLoading.set(false);
                    if (mPendingListener == capturedListener) {
                        mPendingListener = null;
                    }
                }
            }
        });
    }
    
    /**
     * Loads all songs asynchronously with progress reporting.
     *
     * @param listener Listener to receive progress and results (can be null)
     */
    public void loadAllSongsWithProgress(@Nullable final LoadProgressListener listener) {
        if (mIsLoaded && !mAllSongs.isEmpty()) {
            if (listener != null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mAllSongs) {
                            listener.onLoadComplete(new ArrayList<Song>(mAllSongs));
                        }
                    }
                });
            }
            return;
        }
        
        if (mIsLoading.get()) {
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    loadAllSongsWithProgress(listener);
                }
            }, 200);
            return;
        }
        
        mIsLoading.set(true);
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final ArrayList<Song> newSongList = new ArrayList<Song>();
                    
                    if (mSelectedFolderUris.isEmpty()) {
                        loadLooseSongs();
                        newSongList.addAll(mLooseSongs);
                        
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mAllSongs) {
                                    mAllSongs.clear();
                                    mAllSongs.addAll(newSongList);
                                    mergeLooseSongs();
                                }
                                mIsLoaded = true;
                                if (listener != null) {
                                    listener.onLoadComplete(newSongList);
                                }
                                mIsLoading.set(false);
                            }
                        });
                        return;
                    }
                    
                    final AtomicInteger count = new AtomicInteger(0);
                    for (String uriString : mSelectedFolderUris) {
                        scanFolderWithUriProgress(Uri.parse(uriString), newSongList, count, listener);
                    }
                    
                    if (!newSongList.isEmpty()) {
                        Collections.sort(newSongList, new Comparator<Song>() {
                            @Override
                            public int compare(@NonNull Song a, @NonNull Song b) {
                                String titleA = a.getTitle();
                                String titleB = b.getTitle();
                                if (titleA == null && titleB == null) return 0;
                                if (titleA == null) return -1;
                                if (titleB == null) return 1;
                                return titleA.compareToIgnoreCase(titleB);
                            }
                        });
                    }
                    
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (mAllSongs) {
                                mAllSongs.clear();
                                mAllSongs.addAll(newSongList);
                                mergeLooseSongs();
                            }
                            mIsLoaded = true;
                            if (listener != null) {
                                listener.onLoadComplete(newSongList);
                            }
                            mIsLoading.set(false);
                        }
                    });
                } catch (final Exception e) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (listener != null) {
                                listener.onLoadError(e.getMessage() != null ? e.getMessage() : "Unknown error");
                            }
                            mIsLoading.set(false);
                        }
                    });
                }
            }
        });
    }
    
    // ========================================================================
    // Playlist Update Methods
    // ========================================================================
    
    /**
     * Updates the playlist by scanning all selected folders and saving to database.
     *
     * @param listener Listener for progress updates (can be null)
     */
    @WorkerThread
    public void updatePlaylistAndSave(@Nullable final UpdateProgressListener listener) {
        mIsLoaded = false;
        clearPlaylistCache();
        
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    mSongDatabase.clearCache();
                    
                    final ArrayList<Song> newSongs = new ArrayList<Song>();
                    final Set<String> allFoundPaths = new HashSet<String>();
                    
                    int totalFiles = countMusicFiles();
                    Log.d(TAG, "Total music files to scan: " + totalFiles);
                    
                    if (totalFiles == 0) {
                        if (listener != null) {
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    listener.onComplete();
                                }
                            });
                        }
                        return;
                    }
                    
                    final AtomicInteger currentCount = new AtomicInteger(0);
                    final AtomicInteger lastReportedProgress = new AtomicInteger(0);
                    
                    for (String folderUriString : mSelectedFolderUris) {
                        try {
                            scanFolderToDatabaseWithProgress(Uri.parse(folderUriString), newSongs, 
                                allFoundPaths, listener, currentCount, totalFiles, lastReportedProgress);
                        } catch (Exception e) {
                            Log.e(TAG, "Error scanning folder", e);
                        }
                    }
                    
                    if (!newSongs.isEmpty()) {
                        mSongDatabase.insertSongsBatch(newSongs);
                    }
                    
                    mSongDatabase.deleteSongsNotInSet(allFoundPaths);
                    
                    final ArrayList<Song> finalSongs = newSongs;
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (mAllSongs) {
                                mAllSongs.clear();
                                mAllSongs.addAll(finalSongs);
                                mergeLooseSongs();
                            }
                            mIsLoaded = true;
                            
                            SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                            prefs.edit().putBoolean("playlist_updated", true).apply();
                            
                            if (listener != null) {
                                listener.onComplete();
                            }
                        }
                    });
                } catch (final Exception e) {
                    if (listener != null) {
                        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
                            }
                        });
                    }
                }
            }
        });
    }
    
    /**
     * Counts the total number of music files in selected folders.
     *
     * @return Total file count
     */
    private int countMusicFiles() {
        int total = 0;
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        
        for (String folderUriString : mSelectedFolderUris) {
            try {
                Uri folderUri = Uri.parse(folderUriString);
                String folderPath = getFolderPathFromUri(folderUri);
                
                if (folderPath != null) {
                    String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
                    String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                    Cursor cursor = null;
                    try {
                        cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                folderSelection, new String[]{normalizedPath + "%"}, null);
                        if (cursor != null) {
                            total += cursor.getCount();
                        }
                    } finally {
                        if (cursor != null) {
                            try { cursor.close(); } catch (Exception e) {
                                Log.w(TAG, "Failed to close count cursor", e);
                            }
                        }
                    }
                } else {
                    String folderName = getFolderNameFromUri(folderUri);
                    if (folderName != null) {
                        String folderSelection = selection + " AND " + MediaStore.Audio.Media.DATA + " LIKE ?";
                        Cursor cursor = null;
                        try {
                            cursor = resolver.query(mediaUri, new String[]{MediaStore.Audio.Media.DATA},
                                    folderSelection, new String[]{"%/" + folderName + "/%"}, null);
                            if (cursor != null) {
                                total += cursor.getCount();
                            }
                        } finally {
                            if (cursor != null) {
                                try { cursor.close(); } catch (Exception e) {
                                    Log.w(TAG, "Failed to close count cursor", e);
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "count error", e);
            }
        }
        return total;
    }
    
    // ========================================================================
    // Internal Scanning Methods
    // ========================================================================
    
    /**
     * Internal method for synchronous song loading.
     */
    private void loadAllSongsInternal() {
        mOldSongs.clear();
        synchronized (mAllSongs) {
            mOldSongs.addAll(mAllSongs);
            mAllSongs.clear();
        }
        
        if (mSelectedFolderUris.isEmpty()) {
            loadLooseSongs();
            synchronized (mAllSongs) {
                mAllSongs.addAll(mLooseSongs);
            }
            return;
        }
        
        for (String uriString : mSelectedFolderUris) {
            scanFolderWithUriOptimized(Uri.parse(uriString));
        }
        
        if (!mAllSongs.isEmpty()) {
            Collections.sort(mAllSongs, new Comparator<Song>() {
                @Override
                public int compare(@NonNull Song a, @NonNull Song b) {
                    String titleA = a.getTitle();
                    String titleB = b.getTitle();
                    if (titleA == null && titleB == null) return 0;
                    if (titleA == null) return -1;
                    if (titleB == null) return 1;
                    return titleA.compareToIgnoreCase(titleB);
                }
            });
        }
        
        mergeLooseSongs();
    }
    
    /**
     * Scans a folder using optimized method (uses cache).
     *
     * @param folderUri The folder URI to scan
     */
    private void scanFolderWithUriOptimized(@NonNull Uri folderUri) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithCache(folderPath);
            } else {
                String name = getFolderNameFromUri(folderUri);
                if (name != null) {
                    queryMediaStoreByNameWithCache(name);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan optimized error", e);
        }
    }
    
    // ========================================================================
    // Database Scanning with Progress
    // ========================================================================
    
    /**
     * Scans a folder and saves results to database with progress reporting.
     */
    private void scanFolderToDatabaseWithProgress(@NonNull Uri folderUri, 
            @NonNull final ArrayList<Song> newSongs, @NonNull final Set<String> allFoundPaths,
            @Nullable final UpdateProgressListener listener, @NonNull final AtomicInteger currentCount,
            final int totalFiles, @NonNull final AtomicInteger lastReportedProgress) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreToDatabaseWithProgress(folderPath, newSongs, allFoundPaths, 
                    listener, currentCount, totalFiles, lastReportedProgress);
            } else {
                String name = getFolderNameFromUri(folderUri);
                if (name != null) {
                    queryMediaStoreByNameToDatabaseWithProgress(name, newSongs, allFoundPaths,
                        listener, currentCount, totalFiles, lastReportedProgress);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan error", e);
        }
    }
    
    /**
     * Queries MediaStore and adds songs to database with progress.
     */
    private void queryMediaStoreToDatabaseWithProgress(@NonNull String folderPath,
            @NonNull final ArrayList<Song> newSongs, @NonNull final Set<String> allFoundPaths,
            @Nullable final UpdateProgressListener listener, @NonNull final AtomicInteger currentCount,
            final int totalFiles, @NonNull final AtomicInteger lastReportedProgress) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        
        final int[] lastUIUpdate = {0};
        final long[] lastUITime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    allFoundPaths.add(filePath);
                    
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        String rawTitle = cursor.getString(titleCol);
                        String rawArtist = cursor.getString(artistCol);
                        String rawAlbum = cursor.getString(albumCol);
                        long duration = (durCol != -1) ? cursor.getLong(durCol) : 0;
                        
                        String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                        if (TextUtils.isEmpty(title)) {
                            String fileName = new File(filePath).getName();
                            int dot = fileName.lastIndexOf(".");
                            if (dot > 0) fileName = fileName.substring(0, dot);
                            title = CharacterMapper.cleanMusicMetadata(fileName);
                        }
                        
                        String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                        if (TextUtils.isEmpty(artist)) artist = "Unknown Artist";
                        
                        String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                        if (TextUtils.isEmpty(album)) album = "Unknown Album";
                        
                        // Read genre directly from ID3 tags using CharacterMapper
                        String genre = CharacterMapper.getGenre(filePath);
                        if ("Unknown Genre".equals(genre)) {
                            genre = null;
                        }
                        
                        if (CharacterMapper.hasProblematicCharacters(title) || 
                            CharacterMapper.hasProblematicCharacters(artist) || 
                            CharacterMapper.hasProblematicCharacters(album)) {
                            
                            Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                            if (parsedSong != null) {
                                title = parsedSong.getTitle();
                                artist = parsedSong.getArtist();
                                album = parsedSong.getAlbum();
                                genre = parsedSong.getGenre();
                            }
                        }
                        
                        finalSong = new Song(title, artist, album, genre, filePath, duration, null);
                        newSongs.add(finalSong);
                    }
                    
                    int current = currentCount.incrementAndGet();
                    long now = System.currentTimeMillis();
                    
                    if (current - lastUIUpdate[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastUITime[0] >= UI_UPDATE_TIME_MS) {
                        lastUIUpdate[0] = current;
                        lastUITime[0] = now;
                        sendSongAddedBroadcast(finalSong, current);
                        
                        if (listener != null) {
                            final int fCurrent = current;
                            final int fTotal = totalFiles;
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    String message = "Syncing playlist... " + fCurrent + " song" + 
                                        (fCurrent != 1 ? "s" : "") + " found";
                                    listener.onProgress(fCurrent, fTotal, message);
                                }
                            });
                        }
                    }
                    
                } while (cursor.moveToNext());
                
                int finalCount = currentCount.get();
                sendSongAddedBroadcast(null, finalCount);
                if (listener != null) {
                    final int fCurrent = finalCount;
                    final int fTotal = totalFiles;
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            String message = "Syncing playlist... " + fCurrent + " song" + 
                                (fCurrent != 1 ? "s" : "") + " found";
                            listener.onProgress(fCurrent, fTotal, message);
                        }
                    });
                }
            }
        } catch (SecurityException e) {
            if (listener != null) {
                listener.onError("Permission denied");
            }
        } catch (Exception e) {
            Log.e(TAG, "query error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    /**
     * Queries MediaStore by folder name and adds songs to database with progress.
     */
    private void queryMediaStoreByNameToDatabaseWithProgress(@NonNull String folderName,
            @NonNull final ArrayList<Song> newSongs, @NonNull final Set<String> allFoundPaths,
            @Nullable final UpdateProgressListener listener, @NonNull final AtomicInteger currentCount,
            final int totalFiles, @NonNull final AtomicInteger lastReportedProgress) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        
        final int[] lastUIUpdate = {0};
        final long[] lastUITime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    allFoundPaths.add(filePath);
                    
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        String rawTitle = cursor.getString(titleCol);
                        String rawArtist = cursor.getString(artistCol);
                        String rawAlbum = cursor.getString(albumCol);
                        long duration = (durCol != -1) ? cursor.getLong(durCol) : 0;
                        
                        String title = CharacterMapper.cleanMusicMetadata(rawTitle);
                        if (TextUtils.isEmpty(title)) {
                            String fileName = new File(filePath).getName();
                            int dot = fileName.lastIndexOf(".");
                            if (dot > 0) fileName = fileName.substring(0, dot);
                            title = CharacterMapper.cleanMusicMetadata(fileName);
                        }
                        
                        String artist = CharacterMapper.cleanMusicMetadata(rawArtist);
                        if (TextUtils.isEmpty(artist)) artist = "Unknown Artist";
                        
                        String album = CharacterMapper.cleanMusicMetadata(rawAlbum);
                        if (TextUtils.isEmpty(album)) album = "Unknown Album";
                        
                        // Read genre directly from ID3 tags using CharacterMapper
                        String genre = CharacterMapper.getGenre(filePath);
                        if ("Unknown Genre".equals(genre)) {
                            genre = null;
                        }
                        
                        if (CharacterMapper.hasProblematicCharacters(title) || 
                            CharacterMapper.hasProblematicCharacters(artist) || 
                            CharacterMapper.hasProblematicCharacters(album)) {
                            
                            Song parsedSong = CharacterMapper.getSongFromFile(filePath);
                            if (parsedSong != null) {
                                title = parsedSong.getTitle();
                                artist = parsedSong.getArtist();
                                album = parsedSong.getAlbum();
                                genre = parsedSong.getGenre();
                            }
                        }
                        
                        finalSong = new Song(title, artist, album, genre, filePath, duration, null);
                        newSongs.add(finalSong);
                    }
                    
                    int current = currentCount.incrementAndGet();
                    long now = System.currentTimeMillis();
                    
                    if (current - lastUIUpdate[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastUITime[0] >= UI_UPDATE_TIME_MS) {
                        lastUIUpdate[0] = current;
                        lastUITime[0] = now;
                        sendSongAddedBroadcast(finalSong, current);
                        
                        if (listener != null) {
                            final int fCurrent = current;
                            final int fTotal = totalFiles;
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    String message = "Syncing playlist... " + fCurrent + " song" + 
                                        (fCurrent != 1 ? "s" : "") + " found";
                                    listener.onProgress(fCurrent, fTotal, message);
                                }
                            });
                        }
                    }
                    
                } while (cursor.moveToNext());
                
                int finalCount = currentCount.get();
                sendSongAddedBroadcast(null, finalCount);
                if (listener != null) {
                    final int fCurrent = finalCount;
                    final int fTotal = totalFiles;
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            String message = "Syncing playlist... " + fCurrent + " song" + 
                                (fCurrent != 1 ? "s" : "") + " found";
                            listener.onProgress(fCurrent, fTotal, message);
                        }
                    });
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "query by name error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Cache-Based Scanning Methods
    // ========================================================================
    
    /**
     * Queries MediaStore and caches songs.
     */
    private void queryMediaStoreWithCache(@NonNull String folderPath) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<Song>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    
                    if (cached != null) {
                        synchronized (mAllSongs) {
                            mAllSongs.add(cached);
                        }
                    } else {
                        Song newSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                        synchronized (mAllSongs) {
                            mAllSongs.add(newSong);
                        }
                        newSongs.add(newSong);
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryWithCache error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    /**
     * Queries MediaStore by folder name and caches songs.
     */
    private void queryMediaStoreByNameWithCache(@NonNull String folderName) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        ArrayList<Song> newSongs = new ArrayList<Song>();
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    
                    if (cached != null) {
                        synchronized (mAllSongs) {
                            mAllSongs.add(cached);
                        }
                    } else {
                        Song newSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                        synchronized (mAllSongs) {
                            mAllSongs.add(newSong);
                        }
                        newSongs.add(newSong);
                    }
                } while (cursor.moveToNext());
                
                if (!newSongs.isEmpty()) {
                    mSongDatabase.insertSongsBatch(newSongs);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryByNameWithCache error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Progress-Based Scanning Methods
    // ========================================================================
    
    /**
     * Scans a folder and reports progress for each song found.
     */
    private void scanFolderWithUriProgress(@NonNull Uri folderUri, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        try {
            String folderPath = getFolderPathFromUri(folderUri);
            if (folderPath != null) {
                queryMediaStoreWithProgress(folderPath, targetList, count, listener);
            } else {
                String name = getFolderNameFromUri(folderUri);
                if (name != null) {
                    queryMediaStoreByNameWithProgress(name, targetList, count, listener);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scan progress error", e);
        }
    }
    
    /**
     * Queries MediaStore and reports progress for each song.
     */
    private void queryMediaStoreWithProgress(@NonNull String folderPath, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final LoadProgressListener finalListener = listener;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReported = {0};
        final long[] lastTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{normalizedPath + "%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int current = count.incrementAndGet();
                    
                    long now = System.currentTimeMillis();
                    if (finalListener != null && (current - lastReported[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReported[0] = current;
                        lastTime[0] = now;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                finalListener.onLoadProgress(current);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, current);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = count.get();
                if (finalListener != null && finalCount > lastReported[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            finalListener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryWithProgress error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    /**
     * Queries MediaStore by folder name and reports progress for each song.
     */
    private void queryMediaStoreByNameWithProgress(@NonNull String folderName, 
            @NonNull ArrayList<Song> targetList, @NonNull AtomicInteger count, 
            @Nullable LoadProgressListener listener) {
        ContentResolver resolver = mContext.getContentResolver();
        Uri mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.DATA + " LIKE ? AND " + 
                          MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = null;
        final LoadProgressListener finalListener = listener;
        final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] lastReported = {0};
        final long[] lastTime = {0};
        
        try {
            cursor = resolver.query(mediaUri, new String[]{
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DURATION},
                selection, new String[]{"%/" + folderName + "/%"}, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                int pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                int durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                if (pathCol == -1) return;
                
                do {
                    String filePath = cursor.getString(pathCol);
                    if (TextUtils.isEmpty(filePath)) continue;
                    
                    // Validate file is readable
                    try {
                        android.media.MediaMetadataRetriever retriever = 
                            new android.media.MediaMetadataRetriever();
                        retriever.setDataSource(filePath);
                        retriever.release();
                    } catch (Exception e) {
                        continue;
                    }
                    
                    long duration = durCol != -1 ? cursor.getLong(durCol) : 0;
                    Song cached = mSongDatabase.getSong(filePath);
                    Song finalSong;
                    
                    if (cached != null) {
                        finalSong = cached;
                    } else {
                        finalSong = new Song(
                                CharacterMapper.getTitle(filePath),
                                CharacterMapper.getArtist(filePath),
                                CharacterMapper.getAlbum(filePath),
                                CharacterMapper.getGenre(filePath),
                                filePath, duration, null);
                    }
                    
                    targetList.add(finalSong);
                    final int current = count.incrementAndGet();
                    
                    long now = System.currentTimeMillis();
                    if (finalListener != null && (current - lastReported[0] >= UI_UPDATE_THRESHOLD || 
                        now - lastTime[0] >= UI_UPDATE_TIME_MS)) {
                        lastReported[0] = current;
                        lastTime[0] = now;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                finalListener.onLoadProgress(current);
                            }
                        });
                        sendSongAddedBroadcast(finalSong, current);
                    }
                } while (cursor.moveToNext());
                
                final int finalCount = count.get();
                if (finalListener != null && finalCount > lastReported[0]) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            finalListener.onLoadProgress(finalCount);
                        }
                    });
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "queryByNameWithProgress error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close cursor", e);
                }
            }
        }
    }
    
    // ========================================================================
    // Broadcast and Helper Methods
    // ========================================================================
    
    /**
     * Sends a broadcast with song addition progress.
     *
     * @param song The song that was added (can be null for final update)
     * @param currentCount Current number of songs found
     */
    private void sendSongAddedBroadcast(@Nullable Song song, int currentCount) {
        Intent intent = new Intent(ACTION_PLAYLIST_LOAD_PROGRESS);
        
        if (song != null) {
            intent.putExtra("song_title", song.getTitle());
            intent.putExtra("song_artist", song.getArtist());
            intent.putExtra("song_album", song.getAlbum());
            intent.putExtra("song_genre", song.getGenre());
            intent.putExtra("song_path", song.getPath());
            intent.putExtra("song_duration", song.getDuration());
        }
        
        intent.putExtra("current_count", currentCount);
        mContext.sendBroadcast(intent);
    }
    
    /**
     * Shuts down the executor service gracefully.
     * 
     * <p>This method should be called when the MusicLibrary is no longer needed,
     * typically in onDestroy() of the owning Activity.</p>
     */
    public void shutdown() {
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
            try {
                if (!mExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    mExecutor.shutdownNow();
                    Log.w(TAG, "Executor did not terminate in time, forcing shutdown");
                }
            } catch (InterruptedException e) {
                mExecutor.shutdownNow();
                Thread.currentThread().interrupt();
                Log.w(TAG, "Executor shutdown interrupted", e);
            }
        }
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Extracts the file system path from a folder URI.
     *
     * @param uri The folder URI
     * @return The file system path, or null if extraction fails
     */
    @Nullable
    private String getFolderPathFromUri(@NonNull Uri uri) {
        String uriString = uri.toString();
        if (uriString.contains("primary:")) {
            try {
                int start = uriString.indexOf("primary:") + 8;
                String subPath = uriString.substring(start);
                if (subPath.contains("%2F")) subPath = subPath.replace("%2F", "/");
                if (subPath.contains("/tree/")) subPath = subPath.substring(subPath.indexOf("/tree/") + 6);
                if (subPath.contains("/document/")) subPath = subPath.substring(subPath.indexOf("/document/") + 10);
                String path = "/storage/emulated/0/" + subPath;
                path = Uri.decode(path);
                while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
                return path;
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
    
    /**
     * Gets the display name of a folder from its URI.
     *
     * @param uri The folder URI
     * @return The folder name, or null if extraction fails
     */
    @Nullable
    private String getFolderNameFromUri(@NonNull Uri uri) {
        String name = null;
        Cursor cursor = null;
        
        try {
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx != -1) name = cursor.getString(idx);
            }
        } catch (Exception e) {
            Log.e(TAG, "getFolderName error", e);
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception e) {
                    Log.w(TAG, "Failed to close folder name cursor", e);
                }
            }
        }
        
        if (name == null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
            if (name.contains(":")) name = name.substring(name.indexOf(":") + 1);
        }
        
        return name != null ? CharacterMapper.cleanStringMinimal(name) : null;
    }
}