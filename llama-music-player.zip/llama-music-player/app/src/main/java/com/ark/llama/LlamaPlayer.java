package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * LlamaPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides real-time pitch and tempo shifting using the SoundTouch native library.
 * It follows the same lifecycle pattern as Android's {@link android.media.MediaPlayer} for
 * consistency and predictability. The player is the primary audio engine for Llama Music Player,
 * with MediaPlayer serving only as a fallback when SoundTouch fails at runtime.</p>
 * 
 * <h3>Lifecycle Pattern (Same as MediaPlayer)</h3>
 * <pre>
 * LlamaPlayer STATE MACHINE
 * ====================
 * 
 * IDLE ── setDataSource() ──► INITIALIZED ── prepareAsync() ──► PREPARING
 *                                                              │
 *                                                              │ onPrepared()
 *                                                              ▼
 *                                                        PREPARED
 *                                                              │
 *                                                              │ start()
 *                                                              ▼
 *                                                         STARTED
 *                                        ┌───────┴───────┐
 *                                        │                                          │
 *                                    pause()                            completion()
 *                                        │                                          │
 *                                        ▼                                        ▼
 *                                    PAUSED                             COMPLETED
 *                                        │                                          │
 *                                        └───────┬───────┘
 *                                                              │
 *                                                  stop() / reset()
 *                                                              │
 *                                                             ▼
 *                                                  IDLE / STOPPED
 * 
 * Note: Any state can transition to ERROR (on failure) or RELEASED (when release() called)
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. State changes are synchronized and protected
 * against race conditions. The playback loop runs on a dedicated background thread
 * that persists across multiple songs (no thread death on completion).</p>
 * <p>All waiting uses Object.wait() with timeout for proper thread synchronization
 * and immediate interrupt response.</p>
 * 
 * <h3>Multiple Press Handling</h3>
 * <p>The player properly handles rapid button presses:</p>
 * <ul>
 *   <li><b>rapid play/pause:</b> State checks prevent invalid transitions</li>
 *   <li><b>rapid next/prev:</b> reset() ensures clean state before loading new song</li>
 *   <li><b>seek during playback:</b> Seek requests are queued and processed safely</li>
 *   <li><b>prepare while playing:</b> Previous playback is stopped cleanly</li>
 * </ul>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <pre>
 * Audio File -> DecoderManager -> SoundTouch -> AudioTrack -> Speakers
 * </pre>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control (-6 to +6 semitones)</li>
 *   <li>Independent tempo control (0.5x to 1.5x speed)</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Proper AudioTrack priming to prevent buffer underruns</li>
 *   <li>Seamless seek and state management</li>
 *   <li>Broadcasts audio session ID for equalizer attachment</li>
 *   <li>Thread persists across songs (no recreation overhead)</li>
 *   <li>Volume ducking for transient audio focus loss</li>
 * </ul>
 * 
 * <h3>Buffer Design Philosophy</h3>
 * <p>The player uses a 500ms AudioTrack buffer, which provides an optimal
 * balance between seek responsiveness and playback reliability. This buffer
 * size was chosen after extensive testing to ensure:</p>
 * <ul>
 *   <li><b>Responsive seeking:</b> Seek operations complete in under 0.5 seconds,
 *       creating a snappy user experience without perceptible delay</li>
 *   <li><b>Background reliability:</b> The buffer provides enough headroom to
 *       survive CPU scheduling delays during app switching, Doze mode entry,
 *       and background sync operations</li>
 *   <li><b>No underruns:</b> With proper priming (2 chunks = 372ms before play),
 *       a 128ms safety margin prevents audio dropouts</li>
 * </ul>
 * 
 * <h3>Seek Implementation</h3>
 * <p>During seek operations, the decoder is repositioned immediately while the
 * existing AudioTrack buffer continues playing. This approach eliminates the
 * silent gaps that would occur if the buffer were flushed, providing a seamless
 * listening experience. The new audio from the seek position begins playing
 * within 0.5 seconds as the buffer naturally drains.</p>
 * 
 * <p><b>Position Reporting:</b> The {@link #getCurrentPosition()} method returns
 * the seek target immediately after a seek operation, providing instant UI
 * feedback. The reported position remains at the seek target for up to 400ms
 * while the buffer catches up, then switches to the decoder's seek position
 * until AudioTrack reaches that point, preventing seekbar revert.</p>
 * 
 * <p><b>Prefill Support:</b> When a prefill buffer is provided via
 * {@link #seekTo(int, short[], int)}, it is written to AudioTrack immediately,
 * eliminating the playback stall that normally occurs during pipeline refill.</p>
 * 
 * <h3>Volume Ducking</h3>
 * <p>When the system requests transient audio focus loss with ducking (e.g.,
 * navigation app speaking), LlamaPlayer reduces volume to 30% and restores
 * to 100% when focus is regained. This provides a better user experience
 * than ignoring the focus change or pausing playback entirely.</p>
 * 
 * <h3>Usage Example (MediaPlayer-like)</h3>
 * <pre>
 * LlamaPlayer player = new LlamaPlayer(context);
 * player.setListener(new PlaybackListener() { ... });
 * 
 * // Standard playback flow
 * player.reset();
 * player.setDataSource("/sdcard/Music/song.mp3");
 * player.prepareAsync();
 * 
 * // When onPrepared() is called:
 * player.start();
 * 
 * // During playback
 * player.setPitch(2.0f);   // raise by 2 semitones
 * player.setTempo(1.25f);  // speed up by 25%
 * player.seekTo(30000);    // seek to 30 seconds
 * 
 * // Handle audio ducking (automatic via MusicService)
 * // player.duck();   // reduces volume to 30%
 * // player.unduck(); // restores to 100%
 * 
 * // Next song (reuse same instance)
 * player.reset();
 * player.setDataSource("/sdcard/Music/next_song.mp3");
 * player.prepareAsync();
 * 
 * // Clean up
 * player.release();
 * </pre>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #release()} when the player is no longer needed to
 * free native resources and prevent memory leaks.</p>
 * 
 * @see DecoderManager
 * @see SoundTouch
 * @see AudioTrack
 * @see android.media.MediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class LlamaPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "LlamaPlayer";
    
    /** Broadcast action when a song is prepared (duration and session ID available). */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** 
     * Number of stereo frames per internal buffer (8192 = ~186ms at 44.1kHz stereo).
     * This buffer size provides smooth playback while maintaining responsiveness
     * for seek operations. Each chunk represents approximately 186ms of audio.
     */
    private static final int BUFFER_FRAMES = 8192;
    
    /** 
     * Minimum buffer duration in milliseconds for AudioTrack (500ms).
     * This buffer size provides an optimal balance between seek responsiveness
     * (under 0.5 second delay) and background playback reliability. The buffer
     * is large enough to survive CPU scheduling delays during app switching
     * and Doze mode, but small enough to make seek operations feel instant.
     */
    private static final int MIN_BUFFER_MS = 500;
    
    /** 
     * Number of chunks to write to AudioTrack before calling play().
     * With each chunk being ~186ms, 2 chunks provide 372ms of buffered audio
     * before playback begins. This creates a 128ms safety margin that
     * effectively prevents underruns during normal operation.
     */
    private static final int PRIME_CHUNK_COUNT = 2;
    
    /** Interval for position update callbacks to UI (milliseconds). */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Maximum time to wait for thread join during reset/stop (milliseconds). */
    private static final int THREAD_JOIN_TIMEOUT_MS = 500;
    
    /** Time to wait for decoder when not ready (milliseconds) - used with Object.wait. */
    private static final int DECODER_WAIT_MS = 100;
    
    /** Duration in milliseconds that the seek target is reported after a seek operation. */
    private static final int SEEK_WINDOW_MS = 200;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Represents the current state of the player.
     * 
     * <p>This state machine follows the exact same pattern as
     * {@link android.media.MediaPlayer} to ensure predictable behavior.</p>
     */
    public enum State {
        /** Initial state after creation or reset(). No song loaded. */
        IDLE,
        
        /** Data source has been set via setDataSource(). Ready for prepareAsync(). */
        INITIALIZED,
        
        /** Loading song asynchronously (background thread active). */
        PREPARING,
        
        /** Song loaded and ready to play. Call start() to play. */
        PREPARED,
        
        /** Actively playing audio. Position advancing, call pause() to suspend. */
        STARTED,
        
        /** Playback paused. Call start() to resume from current position. */
        PAUSED,
        
        /** Playback stopped via stop(). Must call prepareAsync() again to play. */
        STOPPED,
        
        /** Song finished normally. Can call seekTo(0) then start() to replay. */
        COMPLETED,
        
        /** An error occurred. Must call reset() to recover. */
        ERROR,
        
        /** Player resources released. Cannot be used again. */
        RELEASED
    }
    
    /**
     * Listener interface for playback events.
     * 
     * <p>All callbacks are delivered on the main UI thread, making it safe
     * to update UI components directly from within callbacks.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         * 
         * @param newState The new state (never null)
         * @param oldState The previous state (may be null on first callback)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the song is prepared and ready for playback.
         * 
         * <p>After this callback, {@link #getDuration()} and
         * {@link #getAudioSessionId()} return valid values.</p>
         */
        void onPrepared();
        
        /**
         * Called when the song completes normally (end of file reached).
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * <p>Use this to update UI seek bars and time displays.
         * Frequency is approximately every 100ms.</p>
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback or preparation.
         * 
         * <p>The player enters ERROR state. Call {@link #reset()} to recover.</p>
         *
         * @param error Human-readable description of the error
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context (used for broadcasts). */
    @NonNull private final Context mContext;
    
    /** Playback event listener (null if not set). */
    @Nullable private PlaybackListener mListener;
    
    /** Current player state (protected by mStateLock). */
    private State mState = State.IDLE;
    
    /** Lock object for state transitions (prevents race conditions). */
    private final Object mStateLock = new Object();
    
    /** Decoder manager for audio decoding (main + prefill). */
    @Nullable private DecoderManager mDecoderManager;
    
    /** SoundTouch processor for pitch/tempo shifting. */
    @Nullable private SoundTouch mSoundTouchProcessor;
    
    /** AudioTrack for PCM output. */
    @Nullable private AudioTrack mAudioTrack;
    
    /** Audio sample rate in Hz (from current audio file). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Audio session ID (for equalizer attachment). */
    private int mAudioSessionId = 0;
    
    /** Total duration of current song in milliseconds. */
    private long mDuration = 0;
    
    /** File path of the currently loaded/loading song. */
    private String mCurrentFilePath = null;
    
    /** Flag indicating if audio format has been validated. */
    private boolean mFormatValidated = false;
    
    /** Flag indicating if playback is currently active (atomic for thread safety). */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating if playback is paused (atomic for thread safety). */
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    
    /** Flag indicating if end of stream has been reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Current playback position (cached, updated by playback loop). */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Pending seek target (-1 if no seek pending). */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Timestamp of last seek for position reporting. */
    private final AtomicLong mLastSeekTime = new AtomicLong(0);
    
    /** Last seek target for immediate position reporting. */
    private final AtomicInteger mLastSeekTarget = new AtomicInteger(-1);
    
    /** Last decoder seek position for accurate reporting after seek. */
    private final AtomicLong mDecoderSeekPos = new AtomicLong(-1);
    
    /** Current pitch value (preserved across song changes). */
    private float mCurrentPitch = 0f;
    
    /** Current tempo value (preserved across song changes). */
    private float mCurrentTempo = 1.0f;
    
    /** Background playback thread (persists across songs). */
    @Nullable private Thread mPlaybackThread;
    
    /** Flag indicating if playback thread should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Lock object for playback thread synchronization. */
    private final Object mPlaybackLock = new Object();
    
    /** Lock object for decoder synchronization. */
    private final Object mDecoderLock = new Object();
    
    /** Flag indicating if AudioTrack has been primed (prefilled buffer). */
    private final AtomicBoolean mPrimed = new AtomicBoolean(false);
    
    /** Counter for number of chunks written (for priming). */
    private volatile int mPrimeCount = 0;
    
    /** Handler for UI thread operations (callbacks). */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** Flag indicating if a state transition is in progress (prevents rapid transitions). */
    private final AtomicBoolean mTransitionInProgress = new AtomicBoolean(false);
    
    /** Flag indicating if a user-initiated seek operation is in progress. */
    private final AtomicBoolean mUserSeekInProgress = new AtomicBoolean(false);
    
    /** Flag indicating if prepare was called while previous prepare was ongoing. */
    private volatile int mPrepareSequence = 0;
    
    // ========================================================================
    // Volume Control for Audio Ducking
    // ========================================================================
    
    /** Current volume level (1.0 = normal, 0.0 = silent). */
    private final AtomicReference<Float> mCurrentVolume = new AtomicReference<>(1.0f);
    
    /** Normal volume before ducking (for restoration). */
    private float mNormalVolume = 1.0f;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new LlamaPlayer.
     * 
     * <p>The player is initially in {@link State#IDLE}. The playback thread is not
     * started until the first call to {@link #start()}. The same thread is reused
     * for all subsequent songs, eliminating thread creation overhead.</p>
     *
     * @param context Application context (used for broadcasts and audio session)
     * @throws NullPointerException if context is null
     */
    public LlamaPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "LlamaPlayer created (IDLE state)");
    }
    
    // ========================================================================
    // Public API Methods (MediaPlayer-compatible)
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * <p>Listeners receive state change notifications, preparation completion,
     * position updates, and error events. All callbacks are delivered on the
     * main UI thread.</p>
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Sets the data source for the player.
     * 
     * <p>After calling this method, the player enters {@link State#INITIALIZED}.
     * Call {@link #prepareAsync()} to start loading the song.</p>
     * 
     * <p>This method is safe to call even if a previous song was playing -
     * the player will reset automatically.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @throws IllegalStateException if player is in RELEASED state
     * @throws NullPointerException if filePath is null
     * @throws IllegalArgumentException if filePath is empty or file doesn't exist
     */
    public void setDataSource(@NonNull String filePath) {
        if (filePath.isEmpty()) {
            throw new IllegalArgumentException("filePath cannot be empty");
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("setDataSource called on released player");
            }
            
            if (mState != State.IDLE && mState != State.INITIALIZED && 
                mState != State.ERROR && mState != State.STOPPED) {
                Log.w(TAG, "setDataSource called in state " + mState + " - auto-resetting");
                resetInternal(false);
            }
            
            mCurrentFilePath = filePath;
            mState = State.INITIALIZED;
            mIsEOS.set(false);
            mSeekTarget.set(-1);
            
            Log.d(TAG, "setDataSource: " + filePath + " (INITIALIZED state)");
        }
    }
    
    /**
     * Prepares the player asynchronously (like MediaPlayer.prepareAsync()).
     * 
     * <p>After this method returns, the state becomes {@link State#PREPARING}.
     * When preparation completes successfully, {@link PlaybackListener#onPrepared()}
     * is called and the state becomes {@link State#PREPARED}.</p>
     * 
     * <p>If preparation fails, {@link PlaybackListener#onError(String)} is called
     * and the state becomes {@link State#ERROR}.</p>
     * 
     * <p>Multiple calls to prepareAsync() are safely ignored - only the first
     * preparation proceeds.</p>
     *
     * @throws IllegalStateException if player is not in INITIALIZED state
     */
    public void prepareAsync() {
        final int currentSequence;
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("prepareAsync called on released player");
            }
            if (mState != State.INITIALIZED && mState != State.STOPPED) {
                throw new IllegalStateException("prepareAsync called in invalid state: " + mState);
            }
            
            currentSequence = ++mPrepareSequence;
            mState = State.PREPARING;
        }
        
        Log.d(TAG, "prepareAsync() - starting background preparation (sequence=" + currentSequence + ")");
        
        new Thread(() -> prepareInternal(currentSequence), "SoundTouch-Prepare").start();
    }
    
    /**
     * Internal preparation logic (runs on background thread).
     * 
     * @param sequence The preparation sequence ID (used to ignore stale callbacks)
     */
    private void prepareInternal(int sequence) {
        if (sequence != mPrepareSequence) {
            Log.d(TAG, "prepareInternal: stale preparation (seq=" + sequence + 
                  ", current=" + mPrepareSequence + ") - aborting");
            return;
        }
        
        try {
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            // Release existing decoder manager
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            if (sequence != mPrepareSequence) return;
            
            // Create and initialize decoder manager
            mDecoderManager = new DecoderManager();
            if (!mDecoderManager.initialize(mCurrentFilePath, 0, 0)) {
                transitionToError("Failed to open audio file", sequence);
                return;
            }
            
            // Wait for decoder to actually provide sample rate and channels
            // We need to read a small buffer to get actual format
            int retryCount = 0;
            short[] tempBuffer = new short[BUFFER_FRAMES];
            while (mDecoderManager.getSampleRate() <= 0 && retryCount < 10) {
                int frames = mDecoderManager.read(tempBuffer, BUFFER_FRAMES / 2);
                if (frames > 0) {
                    break;
                }
                try { Thread.sleep(50); } catch (InterruptedException e) { break; }
                retryCount++;
            }
            
            if (mDecoderManager.getSampleRate() <= 0) {
                transitionToError("Failed to get audio format from decoder", sequence);
                return;
            }
            
            mSampleRate = mDecoderManager.getSampleRate();
            mChannels = mDecoderManager.getChannels();
            
            // Get duration (will be updated later via broadcast if needed)
            // For now, we'll rely on the decoder's duration or fallback to 0
            mDuration = 0;
            
            Log.d(TAG, "prepareInternal: " + mSampleRate + "Hz, " + mChannels + "ch");
            
            if (mSampleRate <= 0 || mSampleRate > 192000 || mChannels < 1 || mChannels > 2) {
                transitionToError("Invalid audio format: " + mSampleRate + "Hz, " + mChannels + "ch", sequence);
                return;
            }
            
            if (sequence != mPrepareSequence) return;
            
            if (SoundTouch.isLibraryAvailable()) {
                mSoundTouchProcessor = new SoundTouch(mSampleRate, mChannels);
                mSoundTouchProcessor.setPitch(mCurrentPitch);
                mSoundTouchProcessor.setTempo(mCurrentTempo);
                Log.d(TAG, "SoundTouch processor initialized");
            } else {
                Log.w(TAG, "SoundTouch library not available - pitch/tempo disabled");
            }
            
            createAudioTrack();
            
            if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                transitionToError("AudioTrack creation failed", sequence);
                return;
            }
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            mFormatValidated = true;
            
            broadcastSongPrepared();
            
            if (sequence != mPrepareSequence) {
                Log.d(TAG, "prepareInternal: cancelled after preparation (seq=" + sequence + ")");
                return;
            }
            
            final State oldState;
            synchronized (mStateLock) {
                if (mState == State.RELEASED || mState == State.ERROR) {
                    return;
                }
                oldState = mState;
                mState = State.PREPARED;
            }
            
            Log.d(TAG, "prepareInternal completed (PREPARED state)");
            
            final PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> {
                    listener.onPrepared();
                    listener.onStateChanged(State.PREPARED, oldState);
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "prepareInternal exception", e);
            transitionToError(e.getMessage() != null ? e.getMessage() : "Unknown preparation error", sequence);
        }
    }
    
    /**
     * Starts or resumes playback (like MediaPlayer.start()).
     * 
     * <p>Valid states for calling start():</p>
     * <ul>
     *   <li>{@link State#PREPARED} - starts playback from beginning</li>
     *   <li>{@link State#PAUSED} - resumes playback from current position</li>
     *   <li>{@link State#COMPLETED} - seeks to 0 then starts playback</li>
     * </ul>
     * 
     * <p>Rapid multiple calls to start() are safe - the player ignores
     * calls when already in STARTED state.</p>
     *
     * @throws IllegalStateException if player is in an invalid state
     */
    public void start() {
        if (!mTransitionInProgress.compareAndSet(false, true)) {
            Log.d(TAG, "start() - transition already in progress, skipping");
            return;
        }
        
        try {
            synchronized (mStateLock) {
                if (mState == State.RELEASED) {
                    throw new IllegalStateException("start called on released player");
                }
                
                switch (mState) {
                    case PREPARED:
                        Log.d(TAG, "start() - from PREPARED, starting fresh");
                        startPlaybackThread();
                        transitionState(State.STARTED);
                        break;
                        
                    case PAUSED:
                        Log.d(TAG, "start() - from PAUSED, resuming");
                        resumePlayback();
                        transitionState(State.STARTED);
                        break;
                        
                    case COMPLETED:
                        Log.d(TAG, "start() - from COMPLETED, seeking to 0 then starting");
                        performSeek(0);
                        startPlaybackThread();
                        transitionState(State.STARTED);
                        break;
                        
                    case STARTED:
                        Log.d(TAG, "start() - already STARTED, ignoring");
                        break;
                        
                    default:
                        throw new IllegalStateException("start called in invalid state: " + mState);
                }
            }
        } finally {
            mTransitionInProgress.set(false);
        }
    }
    
    /**
     * Pauses playback (like MediaPlayer.pause()).
     * 
     * <p>This method only works when the player is in {@link State#STARTED}.
     * After pausing, call {@link #start()} to resume from the same position.</p>
     * 
     * <p>Multiple calls to pause() are safe - subsequent calls are ignored.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("pause called on released player");
            }
            
            if (mState != State.STARTED) {
                Log.w(TAG, "pause() called in state: " + mState + " (ignoring)");
                return;
            }
            
            Log.d(TAG, "pause() - pausing playback");
            
            mIsPaused.set(true);
            mIsPlaying.set(false);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                } catch (Exception e) {
                    Log.e(TAG, "pause() - AudioTrack.pause error", e);
                }
            }
            
            transitionState(State.PAUSED);
            
            final PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.STARTED));
            }
        }
    }
    
    /**
     * Stops playback (like MediaPlayer.stop()).
     * 
     * <p>After calling stop(), the player enters {@link State#STOPPED}.
     * To play another song, you must call {@link #reset()} followed by
     * {@link #setDataSource(String)} and {@link #prepareAsync()}.</p>
     * 
     * <p>Valid states for stop(): PREPARED, STARTED, PAUSED, COMPLETED.</p>
     *
     * @throws IllegalStateException if player is in an invalid state
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("stop called on released player");
            }
            
            if (mState != State.PREPARED && mState != State.STARTED && 
                mState != State.PAUSED && mState != State.COMPLETED) {
                Log.w(TAG, "stop() called in state: " + mState + " (ignoring)");
                return;
            }
            
            Log.d(TAG, "stop() - stopping playback");
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    Log.w(TAG, "stop() - interrupted while waiting for thread");
                }
                mPlaybackThread = null;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            mIsEOS.set(false);
            mPrimed.set(false);
            mPrimeCount = 0;
            mCurrentPosition.set(0);
            mLastSeekTarget.set(-1);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    mAudioTrack.flush();
                } catch (Exception e) {
                    Log.e(TAG, "stop() - AudioTrack error", e);
                }
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.seekMainDecoder(0);
            }
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.clear();
            }
            
            transitionState(State.STOPPED);
        }
    }
    
    /**
     * Resets the player to IDLE state (like MediaPlayer.reset()).
     * 
     * <p>After reset(), you must call {@link #setDataSource(String)} and
     * {@link #prepareAsync()} again to play a song. This method is safe to call
     * from any state (except RELEASED) and will cleanly release all resources.</p>
     *
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void reset() {
        resetInternal(true);
    }
    
    /**
     * Internal reset implementation.
     * 
     * @param notifyListener Whether to notify the listener of state change
     */
    private void resetInternal(boolean notifyListener) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("reset called on released player");
            }
            
            final State oldState = mState;
            Log.d(TAG, "reset() from state: " + oldState);
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            mIsEOS.set(false);
            mPrimed.set(false);
            mPrimeCount = 0;
            mCurrentPosition.set(0);
            mSeekTarget.set(-1);
            mLastSeekTarget.set(-1);
            mDecoderSeekPos.set(-1);
            mFormatValidated = false;
            mAudioSessionId = 0;
            mDuration = 0;
            mSampleRate = 44100;
            mChannels = 2;
            mCurrentFilePath = null;
            
            mPrepareSequence++;
            
            transitionState(State.IDLE);
            
            if (notifyListener) {
                final PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.IDLE, oldState));
                }
            }
            
            Log.d(TAG, "reset() - IDLE state");
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>This method performs an immediate seek on the decoder and AudioTrack.
     * <ul>
     *   <li><b>AudioTrack Flush:</b> Immediately clears the AudioTrack buffer to
     *       remove stale audio data. This prevents the position reporting from
     *       continuing to show the old position for up to 500ms after seek.</li>
     *   <li><b>Immediate UI Feedback:</b> Updates mCurrentPosition and sets
     *       mLastSeekTarget so getCurrentPosition() returns the seek target
     *       immediately, providing instant visual feedback to the user.</li>
     *   <li><b>User Seek Flag:</b> Sets mUserSeekInProgress to prioritize the
     *       seek target over playback position updates during the stabilization
     *       window.</li>
     * </ul>
     * 
     * <p><b>Why AudioTrack flush is CRITICAL:</b> Without flushing, the AudioTrack
     * continues playing from its internal buffer (up to 500ms of audio from the
     * old position). During this time, getPlaybackHeadPosition() reports the old
     * position, causing the UI to revert to the old position briefly. Flushing
     * eliminates this stale data entirely.</p>
     *
     * @param positionMs Target position in milliseconds (0 to duration)
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void seekTo(int positionMs) {
        seekTo(positionMs, null, 0);
    }
    
    /**
     * Seeks to the specified position with optional prefill buffer.
     * 
     * <p>This method performs an immediate seek on the decoder and AudioTrack.
     * If a prefill buffer is provided, it is written to AudioTrack immediately
     * to prevent underrun during the seek operation.</p>
     *
     * @param positionMs Target position in milliseconds (0 to duration)
     * @param prefillBuffer Pre-filled audio data (null if not available)
     * @param prefillFrames Number of frames in prefill buffer
     * @throws IllegalStateException if player is in RELEASED state
     */
    public void seekTo(int positionMs, @Nullable short[] prefillBuffer, int prefillFrames) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                throw new IllegalStateException("seekTo called on released player");
            }
            
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            
            Log.d(TAG, "seekTo: " + positionMs + "ms -> clamped: " + clampedPosition + "ms (state=" + mState + ")");
            
            // Mark that a user-initiated seek is in progress
            mUserSeekInProgress.set(true);
            mSeekTarget.set((int) clampedPosition);
            
            // Update position immediately for instant UI feedback
            mCurrentPosition.set(clampedPosition);
            mLastSeekTime.set(System.currentTimeMillis());
            mLastSeekTarget.set((int) clampedPosition);
            
            // Seek the decoder manager to the new position
            if (mDecoderManager != null) {
                mDecoderManager.seekMainDecoder((int) clampedPosition);
                mDecoderSeekPos.set((int) clampedPosition);
                mIsEOS.set(false);
            }
            
            // Clear SoundTouch buffers to prevent artifacts from the transition
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.clear();
            }
            
            // If prefill buffer provided, write it immediately to prevent underrun
            if (prefillBuffer != null && prefillFrames > 0 && mAudioTrack != null) {
                try {
                    int sampleCount = prefillFrames * mChannels;
                    byte[] byteBuffer = new byte[sampleCount * 2];
                    for (int i = 0; i < sampleCount; i++) {
                        byteBuffer[i * 2] = (byte) (prefillBuffer[i] & 0xFF);
                        byteBuffer[i * 2 + 1] = (byte) ((prefillBuffer[i] >> 8) & 0xFF);
                    }
                    mAudioTrack.write(byteBuffer, 0, byteBuffer.length);
                    Log.d(TAG, "Prefill buffer written: " + prefillFrames + " frames");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to write prefill buffer", e);
                }
            }
            
            // CRITICAL: Flush AudioTrack immediately to remove stale buffer
            if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                try {
                    int playState = mAudioTrack.getPlayState();
                    boolean wasPlaying = (playState == AudioTrack.PLAYSTATE_PLAYING);
                    
                    if (wasPlaying) {
                        mAudioTrack.pause();
                    }
                    mAudioTrack.flush();
                    if (wasPlaying) {
                        mAudioTrack.play();
                    }
                    Log.d(TAG, "seekTo: AudioTrack flushed");
                } catch (Exception e) {
                    Log.e(TAG, "seekTo: Failed to flush AudioTrack", e);
                }
            }
            
            // Notify playback thread that a seek is pending
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            // Reset user seek flag after stabilization window
            mUiHandler.postDelayed(() -> {
                mUserSeekInProgress.set(false);
            }, 250);
            
            // Handle paused state separately
            if (mState == State.PAUSED && mDecoderManager != null) {
                if (mSoundTouchProcessor != null) {
                    mSoundTouchProcessor.clear();
                }
            }
            
            // Clear the seek target reporting after the UI feedback window expires
            mUiHandler.postDelayed(() -> {
                if (System.currentTimeMillis() - mLastSeekTime.get() >= SEEK_WINDOW_MS) {
                    mLastSeekTarget.set(-1);
                }
            }, SEEK_WINDOW_MS);
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>This method implements a priority-based position reporting system:</p>
     * <ol>
     *   <li><b>Seek Target Priority:</b> If a user seek occurred within the last
     *       SEEK_WINDOW_MS (200ms), returns the seek target for instant UI feedback.
     *       This prevents the UI from showing the old position during seek.</li>
     *   <li><b>Normal Operation:</b> Returns the AudioTrack playback head position
     *       after the AudioTrack flush ensures it's at the correct location.</li>
     *   <li><b>Fallback:</b> Returns the cached mCurrentPosition if AudioTrack
     *       position is unavailable or invalid.</li>
     * </ol>
     * 
     * <p><b>Why this works:</b> The AudioTrack flush in seekTo() eliminates stale
     * buffer data, so the playback head position is immediately meaningful.
     * The seek target priority provides instant UI feedback while the first
     * frames from the new position are being written.</p>
     *
     * @return Current position in milliseconds (0 if not available)
     */
    public long getCurrentPosition() {
        // Stage 1: Immediately after seek - return seek target for instant UI feedback
        int lastSeekTarget = mLastSeekTarget.get();
        if (lastSeekTarget >= 0) {
            long lastSeekTime = mLastSeekTime.get();
            if (lastSeekTime > 0 && System.currentTimeMillis() - lastSeekTime < SEEK_WINDOW_MS) {
                return lastSeekTarget;
            } else {
                mLastSeekTarget.set(-1);
            }
        }
        
        // Stage 2: Normal operation - AudioTrack position
        if (mAudioTrack != null && mState == State.STARTED && mPrimed.get() && !mIsPaused.get()) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                if (mSampleRate > 0 && frames > 0) {
                    long positionMs = (frames * 1000) / mSampleRate;
                    if (positionMs < mDuration) {
                        long cachedPos = mCurrentPosition.get();
                        if (positionMs >= cachedPos - 100) {
                            return positionMs;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        
        // Fallback to cached position
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds (0 if not available)
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Checks if the player is currently playing audio.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get() && mState == State.STARTED;
    }
    
    /**
     * Checks if the player is prepared (song loaded and ready to play).
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mState == State.PREPARED || mState == State.STARTED || 
               mState == State.PAUSED || mState == State.COMPLETED;
    }
    
    /**
     * Returns the audio session ID for the current AudioTrack.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return Current {@link State} (never null)
     */
    @NonNull
    public State getState() {
        return mState;
    }
    
    /**
     * Returns the current sample rate.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the current channel count.
     *
     * @return Number of channels (1 or 2)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * Recommended range: -6 to +6 semitones.</p>
     * 
     * <p><b>Parameter Change Implementation:</b> This method clears the SoundTouch
     * buffers and resets priming state without flushing the AudioTrack. The new
     * pitch setting takes effect as soon as the existing AudioTrack buffer drains
     * (within 500ms), providing a smooth transition without audio dropouts.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.setPitch(semitones);
            clearBuffersForParameterChange();
            Log.d(TAG, "setPitch: " + semitones + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down, greater than 1.0 speed up.
     * Recommended range: 0.5 to 1.5.</p>
     * 
     * <p><b>Parameter Change Implementation:</b> This method clears the SoundTouch
     * buffers and resets priming state without flushing the AudioTrack. The new
     * tempo setting takes effect as soon as the existing AudioTrack buffer drains
     * (within 500ms), providing a smooth transition without audio dropouts.</p>
     *
     * @param tempo The tempo multiplier (0.5 = half speed, 1.0 = normal, 1.5 = 1.5x speed)
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.setTempo(tempo);
            clearBuffersForParameterChange();
            Log.d(TAG, "setTempo: " + tempo + "x");
        }
    }
    
    // ========================================================================
    // Volume Control Methods for Audio Ducking
    // ========================================================================
    
    /**
     * Sets the volume level for ducking.
     * Range: 0.0 (silent) to 1.0 (full volume).
     * 
     * <p>This method is used primarily for audio ducking when the system
     * requests transient focus loss with ducking (e.g., navigation apps speaking).</p>
     *
     * @param volume Volume level (clamped to 0.0-1.0)
     */
    public void setVolume(float volume) {
        volume = Math.max(0.0f, Math.min(1.0f, volume));
        Float oldVolume = mCurrentVolume.getAndSet(volume);
        
        if (oldVolume != null && Math.abs(oldVolume - volume) < 0.01f) {
            return;
        }
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.setVolume(volume);
                Log.d(TAG, "Volume set to: " + volume);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set volume", e);
            }
        }
    }
    
    /**
     * Gets the current volume level.
     *
     * @return Current volume (0.0 to 1.0)
     */
    public float getVolume() {
        Float volume = mCurrentVolume.get();
        return volume != null ? volume : 1.0f;
    }
    
    /**
     * Ducks volume (reduces to 30%) for transient audio focus loss.
     * 
     * <p>Used when navigation apps speak, alarms sound, or other transient
     * audio events occur that should not pause music but should lower its
     * volume temporarily. Saves current volume for later restoration.</p>
     */
    public void duck() {
        mNormalVolume = getVolume();
        setVolume(0.3f);
        Log.d(TAG, "Volume ducked to 30% (was " + mNormalVolume + ")");
    }
    
    /**
     * Restores volume to normal level after ducking.
     * 
     * <p>Call this when the system regains audio focus after a transient
     * ducking event.</p>
     */
    public void unduck() {
        setVolume(mNormalVolume);
        Log.d(TAG, "Volume unducked to " + mNormalVolume);
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Pre-loads a song without starting playback (convenience method).
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully
     */
    public boolean preLoad(@NonNull String filePath) {
        try {
            reset();
            setDataSource(filePath);
            prepareAsync();
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "preLoad failed", e);
            return false;
        }
    }
    
    /**
     * Loads and plays a song (convenience method).
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully
     */
    public boolean loadSong(@NonNull String filePath) {
        try {
            reset();
            setDataSource(filePath);
            prepareAsync();
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "loadSong failed", e);
            return false;
        }
    }
    
    /**
     * Plays the loaded song (convenience method).
     */
    public void play() {
        start();
    }
    
    /**
     * Releases all resources held by the player (like MediaPlayer.release()).
     * 
     * <p>After calling this method, the player enters {@link State#RELEASED}
     * and cannot be used again. Always call release() when the player is
     * no longer needed to prevent memory leaks.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release() - releasing all resources");
            
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.join(THREAD_JOIN_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            cleanupAudioTrack();
            
            if (mSoundTouchProcessor != null) {
                mSoundTouchProcessor.close();
                mSoundTouchProcessor = null;
            }
            
            if (mDecoderManager != null) {
                mDecoderManager.release();
                mDecoderManager = null;
            }
            
            mState = State.RELEASED;
            
            Log.d(TAG, "release() - RELEASED state");
        }
    }
    
    /**
     * Transitions the player to a new state with thread-safe logging.
     */
    private void transitionState(State newState) {
        final State oldState = mState;
        mState = newState;
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
    }
    
    /**
     * Transitions the player to ERROR state and notifies listener.
     *
     * @param error Human-readable error description
     * @param sequence The preparation sequence ID (to ignore stale errors)
     */
    private void transitionToError(String error, int sequence) {
        if (sequence != mPrepareSequence) {
            Log.d(TAG, "transitionToError: stale error (seq=" + sequence + 
                  ", current=" + mPrepareSequence + ") - ignoring");
            return;
        }
        
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            Log.e(TAG, "Error: " + error);
            mState = State.ERROR;
        }
        
        mRunning.set(false);
        mIsPlaying.set(false);
        
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        synchronized (mDecoderLock) {
            mDecoderLock.notifyAll();
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, null);
            });
        }
    }
    
    /**
     * Cleans up AudioTrack resources.
     */
    private void cleanupAudioTrack() {
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "cleanupAudioTrack error", e);
            }
            mAudioTrack = null;
        }
    }
    
    /**
     * Creates and configures the AudioTrack instance.
     * 
     * <p>The buffer size is calculated to provide approximately 500ms of
     * audio, balancing seek responsiveness with background playback reliability.
     * The buffer is sized as max(4x minimum hardware buffer, target buffer size)
     * to ensure compatibility across different devices.</p>
     */
    private void createAudioTrack() {
        cleanupAudioTrack();
        
        int channelConfig = (mChannels == 2) ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize * 4, targetBufferSize);
        
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        int actualBufferMs = (bufferSize * 1000) / (mSampleRate * mChannels * 2);
        Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + "ch, " +
              "minBuffer=" + minBufferSize + ", finalBuffer=" + bufferSize + " bytes (" + actualBufferMs + "ms)");
    }
    
    /**
     * Starts the playback thread (creates new thread if not running).
     * 
     * <p>If the thread is already running, it just resumes playback.
     * The thread persists across multiple songs, eliminating thread
     * creation overhead.</p>
     */
    private void startPlaybackThread() {
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            Log.d(TAG, "startPlaybackThread: thread already running, resuming");
            mIsPlaying.set(true);
            mIsPaused.set(false);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                } catch (Exception e) {
                    Log.e(TAG, "startPlaybackThread - AudioTrack.play error", e);
                }
            }
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            return;
        }
        
        mPrimed.set(false);
        mPrimeCount = 0;
        
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "startPlaybackThread: new thread created and started");
    }
    
    /**
     * Resumes playback from paused state.
     */
    private void resumePlayback() {
        mIsPaused.set(false);
        mIsPlaying.set(true);
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
            } catch (Exception e) {
                Log.e(TAG, "resumePlayback - AudioTrack.play error", e);
            }
        }
        
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onStateChanged(State.STARTED, State.PAUSED));
        }
        
        Log.d(TAG, "resumePlayback() - playback resumed");
    }
    
    /**
     * Performs a seek operation from the playback loop (background thread).
     * 
     * <p>This method is called by the background playback thread when it detects
     * a pending seek request. The actual AudioTrack flush has already been performed
     * in seekTo() on the UI thread, so this method only updates the decoder and
     * SoundTouch state.</p>
     * 
     * <p><b>Note:</b> The AudioTrack flush is NOT repeated here because it would
     * cause a race condition. The flush is done immediately in seekTo() to ensure
     * the UI sees the correct position as soon as possible.</p>
     *
     * @param positionMs Target position in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs + "ms");
        
        // UI already updated in seekTo(), just update internal decoder state
        if (mDecoderManager != null) {
            mDecoderManager.seekMainDecoder(positionMs);
            mIsEOS.set(false);
        }
        
        // Clear SoundTouch buffers to prevent audio artifacts
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.clear();
        }
        
        // Store the decoder seek position for any edge-case position queries
        mDecoderSeekPos.set(positionMs);
        
        // Clear the user seek flag - the seek is now fully processed
        mUserSeekInProgress.set(false);
    }
    
    /**
     * Updates the cached current position from AudioTrack's playback head.
     * 
     * <p>This method is called periodically from the playback loop to update
     * the UI with the current playback position.</p>
     */
    private void updateCurrentPosition() {
        if (mUserSeekInProgress.get()) {
            return;
        }
        
        int lastSeekTarget = mLastSeekTarget.get();
        if (lastSeekTarget >= 0) {
            long lastSeekTime = mLastSeekTime.get();
            if (lastSeekTime > 0 && System.currentTimeMillis() - lastSeekTime < SEEK_WINDOW_MS) {
                return;
            } else {
                mLastSeekTarget.set(-1);
            }
        }
        
        if (mAudioTrack != null && mState == State.STARTED && mPrimed.get()) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                if (mSampleRate > 0 && frames > 0) {
                    long positionMs = (frames * 1000) / mSampleRate;
                    if (positionMs < mDuration && positionMs > 0) {
                        mCurrentPosition.set(positionMs);
                    }
                }
            } catch (Exception ignored) {}
        }
    }
    
    /**
     * Broadcasts an intent with song duration and audio session ID.
     * 
     * <p>This broadcast is received by MusicPlayer and EqualizerManager
     * to update the UI and attach the equalizer before playback starts.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "broadcastSongPrepared: dur=" + mDuration + "ms, session=" + mAudioSessionId);
    }
    
    /**
     * Clears audio buffers when pitch or tempo changes.
     * 
     * <p>This method ensures that new pitch/tempo settings take effect quickly
     * without causing audio dropouts. It clears the SoundTouch internal buffers
     * and resets the priming state, but does NOT flush the AudioTrack. The
     * existing AudioTrack buffer continues playing with the old settings, and
     * new audio processed with the new settings will begin playing as the buffer
     * naturally drains (within 500ms).</p>
     */
    private void clearBuffersForParameterChange() {
        if (mSoundTouchProcessor != null) {
            mSoundTouchProcessor.clear();
            Log.d(TAG, "SoundTouch buffers cleared for parameter change");
        }
        
        mPrimed.set(false);
        mPrimeCount = 0;
        
        Log.d(TAG, "Parameter change applied - AudioTrack buffer preserved");
    }
    
    // ========================================================================
    // Playback Loop (Runs on Background Thread)
    // ========================================================================
    
    /**
     * Main playback loop (runs on background thread).
     * 
     * <p>This loop runs continuously while mRunning is true. It handles:
     * <ul>
     *   <li>Reading PCM data from DecoderManager</li>
     *   <li>Processing through SoundTouch (if available)</li>
     *   <li>Writing to AudioTrack with optimal buffering</li>
     *   <li>Priming the AudioTrack before starting playback</li>
     *   <li>Seek requests</li>
     *   <li>Pause/resume handling</li>
     *   <li>End-of-stream detection and completion callbacks</li>
     * </ul>
     * 
     * The thread does NOT exit on song completion - it enters a waiting state
     * until the next play command, eliminating thread creation overhead.
     * 
     * <p>All waiting uses Object.wait() with timeout for proper thread
     * synchronization and immediate interrupt response.</p>
     * </p>
     */
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Playback loop started (thread persists across songs)");
        
        while (mRunning.get() && mState != State.RELEASED) {
            try {
                if (mIsPaused.get() || mState != State.STARTED) {
                    synchronized (mPlaybackLock) {
                        if (mIsPaused.get() || mState != State.STARTED) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0) {
                    performSeek(seekTarget);
                }
                
                if (mIsEOS.get() || (mDecoderManager != null && mDecoderManager.isEOS())) {
                    handleCompletion();
                    synchronized (mPlaybackLock) {
                        mPlaybackLock.wait();
                    }
                    continue;
                }
                
                if (mDecoderManager == null || !mFormatValidated) {
                    synchronized (mDecoderLock) {
                        if (mDecoderManager == null || !mFormatValidated) {
                            mDecoderLock.wait(DECODER_WAIT_MS);
                            continue;
                        }
                    }
                    continue;
                }
                
                int framesRead = mDecoderManager.read(inputBuffer, BUFFER_FRAMES);
                if (framesRead < 0) {
                    transitionToError("Decoder read error", mPrepareSequence);
                    break;
                }
                if (framesRead == 0) {
                    Thread.yield();
                    continue;
                }
                
                short[] samplesToWrite = inputBuffer;
                int sampleCount = framesRead * mChannels;
                
                if (mSoundTouchProcessor != null && mSoundTouchProcessor.isInitialized()) {
                    mSoundTouchProcessor.putFrames(inputBuffer, framesRead);
                    int available = mSoundTouchProcessor.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mSoundTouchProcessor.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                
                for (int i = 0; i < sampleCount; i++) {
                    byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                    byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                }
                
                int written = -1;
                try {
                    written = mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                } catch (IllegalStateException e) {
                    Log.e(TAG, "AudioTrack.write IllegalStateException", e);
                    try {
                        if (mAudioTrack != null) {
                            mAudioTrack.flush();
                        }
                    } catch (Exception ignored) {}
                    continue;
                } catch (IllegalArgumentException e) {
                    Log.e(TAG, "AudioTrack.write IllegalArgumentException", e);
                    continue;
                }
                
                if (written < 0) {
                    Log.e(TAG, "AudioTrack.write error: " + written);
                    if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                        Log.w(TAG, "AudioTrack dead, attempting recovery");
                        try {
                            cleanupAudioTrack();
                            createAudioTrack();
                            mPrimed.set(false);
                            mPrimeCount = 0;
                        } catch (Exception ex) {
                            Log.e(TAG, "Failed to recreate AudioTrack", ex);
                        }
                    }
                    continue;
                }
                
                if (!mPrimed.get()) {
                    mPrimeCount++;
                    if (mPrimeCount >= PRIME_CHUNK_COUNT && 
                        mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        try {
                            mAudioTrack.play();
                            mPrimed.set(true);
                            Log.d(TAG, "AudioTrack primed and playing after " + mPrimeCount + " chunks");
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to start AudioTrack after priming", e);
                        }
                    }
                } else if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && 
                           mState == State.STARTED) {
                    try {
                        mAudioTrack.play();
                    } catch (Exception e) {
                        Log.e(TAG, "Re-start AudioTrack failed", e);
                    }
                }
                
                updateCurrentPosition();
                
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    final PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "Playback loop interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Playback loop exception", e);
                transitionToError(e.getMessage() != null ? e.getMessage() : "Playback loop error", mPrepareSequence);
                break;
            }
        }
        Log.d(TAG, "Playback loop exited");
    }
    
    /**
     * Handles normal song completion (end of file reached).
     * 
     * <p>When a song completes, the player enters COMPLETED state.
     * The playback thread does NOT exit - it enters a waiting state
     * to handle the next play command, eliminating thread creation overhead.</p>
     */
    private void handleCompletion() {
        Log.d(TAG, "Song completed - entering COMPLETED state (thread continues waiting)");
        
        mIsPlaying.set(false);
        mIsEOS.set(true);
        
        mCurrentPosition.set(0);
        mLastSeekTarget.set(-1);
        
        final State oldState;
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            oldState = mState;
            mState = State.COMPLETED;
        }
        
        final PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onCompletion();
                listener.onStateChanged(State.COMPLETED, oldState);
                listener.onPositionUpdate(0);
            });
        }
    }
}