package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Playback stall recovery with user feedback</li>
 *   <li>Sort mode synchronization with PlaylistActivity</li>
 * </ul>
 * 
 * <h3>Pre-initialization Support</h3>
 * <p>This activity listens for {@link #ACTION_SONG_PREPARED} broadcasts from
 * {@link SoundTouchPlayer} to receive song duration and audio session ID
 * before playback begins. This ensures the timer shows total time and the
 * equalizer is ready immediately after folder import.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings dialog. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing first run flag. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Intent action for restarting the app after update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Broadcast action for updating sort mode from playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Broadcast action for player status update (diagnostic). */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Broadcast action for song prepared event (from SoundTouchPlayer). */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Timeout for loading overlay display. */
    private static final long LOADING_OVERLAY_DELAY_MS = 5000;
    
    /** Delay for play/pause button update. */
    private static final long PLAY_PAUSE_UPDATE_DELAY_MS = 50;
    
    /** Delay for next/prev button updates. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;
    
    /** Delay for seek reset flag in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 150;
    
    /** Buffer size for file copying operations. */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Duration of album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView for displaying song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView for displaying artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView for current seek position. */
    @Nullable private TextView mSeekTime;
    
    /** TextView for total track duration. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Play/Pause control button. */
    @Nullable private Button mPlayButton;
    
    /** Previous track button. */
    @Nullable private Button mPrevButton;
    
    /** Next track button. */
    @Nullable private Button mNextButton;
    
    /** Repeat mode button (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Shuffle mode button. */
    @Nullable private Button mShuffleButton;
    
    /** Button to open folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button to open credits dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button to open playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button to open equalizer. */
    @Nullable private Button mEqualizerButton;
    
    /** Button to open metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for album art display. */
    @Nullable private ImageView mAlbumArtView;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Music library manager for song data. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Bound music service instance. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Main thread handler for delayed operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for time display updates (to prevent memory leaks). */
    @Nullable private Handler mTimeHandler = null;
    
    /** Flag indicating service binding state. */
    private boolean mIsServiceBound = false;
    
    /** Flag indicating user is currently seeking. */
    private volatile boolean mIsUserSeeking = false;
    
    /** Target seek position during user drag. */
    private int mSeekTargetPosition = -1;
    
    /** Handler for seek reset delay. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Atomic flag to prevent concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for thread-safe service access. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating post-update restart. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transitions. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    /** LRU cache for album art bitmaps. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Currently running album art loading task. */
    @Nullable private AsyncTask<Void, Void, Bitmap> mCurrentAlbumArtTask = null;
    
    /** Path of currently loading album art. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    /** Path of currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    /** Themed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Executor for placeholder generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock object for placeholder synchronization. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components (Only loading overlay remains - persistent overlays use ToastManager)
    // ========================================================================
    
    /** Dim overlay for loading state. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner inside dim overlay. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Theme manager for color management. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Theme helper for UI color application. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme changes. */
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick loading. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    // ========================================================================
    // Executor for Metadata Loading (replaces AsyncTask)
    // ========================================================================
    
    /** Single-thread executor for loading last song metadata. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Service connection for binding to MusicService.
     * Handles service lifecycle, initial UI setup, and automatic reconnection.
     * 
     * Playback controls are ENABLED after the playlist has been fully loaded 
     * and the current song index has been restored from SharedPreferences.
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            // Load the full playlist asynchronously (this also restores the saved song)
            loadFullPlaylistInBackground();
            
            // Update repeat and shuffle button icons (visual state only, not enabled yet)
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();

            // Delayed UI initialization - only after playlist has been loaded
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        // Playlist is loaded - update all controls
                        updateRepeatButtonIcon();
                        updateShuffleButtonIcon();
                        
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        
                        // Enable play button after restoration is complete
                        final boolean isPlayingNow = (mMusicService != null && mMusicService.isAnyPlayerPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        
                        // Enable other control buttons
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButtonIcon();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButtonIcon();
                        }
                        
                        // Display the currently restored song (from SharedPreferences)
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        // No songs in library - apply empty state
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);
            
            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            // Attempt to reconnect after a delay
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * Initializes all components, sets up UI, and binds to MusicService.
     * 
     * @param savedInstanceState Previously saved state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        // Handle app closure intent
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        // Initialize album art cache with size limit
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        // Register for navigation button state changes
        NavigationController.getInstance().registerListener(this);
    }
    
    /**
     * Called when the activity starts.
     * Re-registers theme receiver if needed.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity stops.
     * Unregisters theme receiver to prevent memory leaks.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes.
     * Reattaches ToastManager persistent overlay and updates UI with current playback state.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Reattach ToastManager persistent overlay if exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        // Update StorageObserver activity reference for toasts
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        // Sync button state with NavigationController
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButtonIcon();
            updateShuffleButtonIcon();
            updatePlayPauseButton();
            
            // Always use the service's current song directly
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity restarts after being stopped.
     * Reattaches ToastManager persistent overlay to ensure it survives activity recreation.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        // Reattach ToastManager persistent overlay if exists
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     * Cleans up all resources, unregisters receivers, and unbinds service.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // Clean up time handler to prevent memory leaks
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        
        // Unregister from navigation button state changes
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();
        
        // Hide ToastManager persistent overlay if showing
        ToastManager.hidePersistentOverlay();
        
        hideLoadingOverlay();
        
        // Shutdown metadata executor
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    /**
     * Called when the system is running low on memory.
     * Forwards the event to MusicService for MediaPlayer health check.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        // Forward to MusicService if bound
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Called when a new intent is received while activity is running.
     * Handles file import and app closure requests.
     * 
     * @param intent The new intent
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when window focus changes.
     * Re-applies immersive mode when window has focus.
     * 
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    /**
     * Handles media button key events (headset controls).
     * 
     * @param keyCode The key code
     * @param event The key event
     * @return True if handled, false otherwise
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    /**
     * Handles activity results from folder selection and battery optimization dialogs.
     *
     * @param requestCode The request code
     * @param resultCode The result code
     * @param data The result data intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        // Handle battery optimization dialog result
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        // Handle folder selection result
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Handles runtime permission request results.
     * 
     * <p>After permissions are granted, also checks and requests
     * battery optimization exemption.</p>
     *
     * @param requestCode The request code
     * @param permissions Requested permissions
     * @param grantResults Grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when navigation button group state changes.
     * Disables playlist and metadata buttons during database operations.
     * 
     * @param group The button group that changed
     * @param disabled True if the group is now disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // PLAYLIST button
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }
                    
                    // METADATA button
                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets appropriate status bar and navigation bar colors based on Android version.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components, sets up typefaces,
     * and configures button animations.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        // Set FontAwesome icons
        final Typeface faTypeface = FontAwesome.getTypeface();
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        // Set button backgrounds
        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        // Set letter spacing for action buttons
        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        // Apply animations to all buttons
        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButtonIcon();
        updateShuffleButtonIcon();
        updateControlButtonsState();
    }

    /**
     * Adds a scale animation to a button for visual touch feedback.
     * 
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests runtime permissions for storage access.
     * 
     * <p>Handles Android version-specific permissions:</p>
     * <ul>
     *   <li>Android 13+ (API 33+): READ_MEDIA_AUDIO, POST_NOTIFICATIONS</li>
     *   <li>Android 10-12 (API 29-32): READ_EXTERNAL_STORAGE</li>
     *   <li>Android 12+ (API 31+): BLUETOOTH_CONNECT</li>
     * </ul>
     * 
     * <p>After permissions are granted, also checks and requests
     * battery optimization exemption to ensure background playback continues
     * when the device enters doze mode.</p>
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            // Android 13+ (API 33+) uses granular media permissions
            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                // Pre-Android 13 uses READ_EXTERNAL_STORAGE
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            // Bluetooth connect permission for Android 12+ (API 31+)
            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * Starts and binds MusicService, loads last song metadata.
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks if the app is already exempt from battery optimizations.
     * 
     * <p>If not exempt and the user hasn't been asked before, this method
     * displays a system dialog requesting battery optimization exemption.</p>
     * 
     * <p>This is a one-time request - once shown, it will not appear again
     * even if the user denies it. The user can manually enable it later in
     * system settings if desired.</p>
     * 
     * <p>Exemption allows the app to continue playing music when the device
     * enters doze mode (screen off for extended periods).</p>
     * 
     * <p>This method is called automatically after permissions are granted,
     * as part of the initialization flow.</p>
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                // Mark that we've asked to avoid spamming on every launch
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles audio files opened from external apps (ACTION_VIEW intent).
     * Adds the file as a loose track and plays it immediately.
     * 
     * @param intent The incoming intent
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                // Create or retrieve song object
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                // Add to loose tracks database
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                // Build complete playlist including loose tracks
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<Song>();
                }
                
                // Find or add the song in playlist (duplicate check)
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<Song>(allSongs);
                
                // Clear last playing state
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                // Play the song using path-based method (reliable, avoids index issues)
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                // Broadcast updates
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming song using already bound service.
     * Uses path-based playback for reliability.
     * 
     * @param finalSongs Complete playlist
     * @param filePath Path of the song to play
     * @param newSong Song object to play
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            // Set playlist with preserveCurrentSong = false (we are replacing completely)
            mMusicService.setPlaylist(finalSongs, false);
            
            // Update UI with the new song metadata (will be refined after play starts)
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    enableAllControls();
                    updateUIForSong(newSong);
                }
            });
            
            // Play by path – this finds the song in the playlist and sets current index internally
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to service first, then plays incoming song.
     * Uses path-based playback for reliability.
     * 
     * @param finalSongs Complete playlist
     * @param filePath Path of the song to play
     * @param newSong Song object to play
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    // Set playlist with preserveCurrentSong = false
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            enableAllControls();
                            updateUIForSong(newSong);
                            applyAlbumArtClipping();
                        }
                    });
                    
                    // Play by path – reliable, avoids index mismatches
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     * Falls back to copying to temporary file if direct resolution fails.
     * 
     * @param uri The URI to convert
     * @return File system path or null
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file when direct path resolution fails.
     * 
     * @param uri The content URI
     * @return Path to temporary file or null
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that belong to a newly imported folder.
     * Prevents duplicates when a folder containing previously imported loose tracks is added.
     * 
     * @param folderUri The folder URI being imported
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist asynchronously and sets it on MusicService.
     * 
     * <p>This method is called when the service first connects. It loads all songs
     * from the music library, sets the playlist on the service (which triggers
     * restoration of the last played song from SharedPreferences), and then
     * enables playback controls. The play button is enabled only after this
     * process completes to ensure the correct song is selected on cold start.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    // Set the playlist with preserveCurrentSong = true
                    // This triggers the path-based restoration of the last played song
                    mMusicService.setPlaylist(songs, true);
                    
                    // Now the restoration is complete - update UI on the main thread
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Enable play button and other controls
                            if (mPlayButton != null && !songs.isEmpty()) {
                                mPlayButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    boolean isPlaying = (mMusicService != null && mMusicService.isAnyPlayerPlaying());
                                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                            }
                            
                            // Display the restored current song
                            Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                                mSongTitle.setText(current.getTitle());
                                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                mSongArtist.setText(current.getArtist());
                                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                updateAlbumArt(current.getPath());
                            }
                            
                            // Update UI state
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    });
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG);
                    }
                });
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Thread-safe UI update method that prevents concurrent updates.
     * 
     * @param update The runnable to execute on UI thread
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pending = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pending);
                    }
                }
            }
        });
    }
    
    /**
     * Updates UI with song metadata (non-playing state).
     * 
     * @param song The song to display
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        final Song finalSong = song;

        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                // Set total time from Song object
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Updates UI with song metadata when playing (triggers album art reload).
     * 
     * @param song The song being played
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        final Song finalSong = song;
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                // Set total time from Song object
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Enables all playback control buttons.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButtonIcon();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButtonIcon();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }
    
    /**
     * Updates control buttons state based on playlist size.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButtonIcon();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButtonIcon();
        }
    }
    
    /**
     * Applies the "no songs" state (placeholder display, disabled controls).
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }
        
        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on the MusicService with synchronization.
     * 
     * @param action The action to execute
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     * 
     * @param index The playlist index
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            // Use service's current song after play
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method follows the path-based playback design. When starting fresh
     * playback, it sends a PLAY_SONG intent with the song path, ensuring that the
     * correct song (the last played song or the first song in the playlist) is played.
     * The MusicService handles the actual playback via playSongByPath().</p>
     */
    private void togglePlayPause() {
        if (mPlayButton != null && mPlayButton.isEnabled()) {
            // If any player is playing, pause
            if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                mMusicService.pause();
                updatePlayPauseButton();
                return;
            }
            
            // If any player has a prepared/paused song, resume (don't restart)
            if (mMusicService != null && mMusicService.isAnyPlayerPrepared() && !mMusicService.isAnyPlayerPlaying()) {
                mMusicService.resume();
                updatePlayPauseButton();
                return;
            }
            
            // Otherwise, start fresh playback using path-based method
            safeCallService(new Runnable() {
                @Override
                public void run() {
                    ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                    if (allSongs == null || allSongs.isEmpty()) {
                        return;
                    }
                    
                    // Get current song path (or first song's path)
                    String songPath = null;
                    int currentIndex = mMusicService.getCurrentIndex();
                    
                    if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                        songPath = allSongs.get(currentIndex).getPath();
                    } else if (!allSongs.isEmpty()) {
                        songPath = allSongs.get(0).getPath();
                    }
                    
                    if (songPath != null) {
                        // Use the same path-based playback as playlist tapping
                        Intent intent = new Intent(MusicPlayer.this, MusicService.class);
                        intent.setAction("PLAY_SONG");
                        intent.putExtra("song_path", songPath);
                        startService(intent);
                    }
                }
            });
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playNext();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playPrevious();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button icon based on current repeat mode.
     */
    private void updateRepeatButtonIcon() {
        if (mMusicService != null && mRepeatButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mRepeatButton.isEnabled();
            
            if (isEnabled) {
                final int repeatMode = mMusicService.getRepeatMode();
                final boolean isActive = (repeatMode != 0);
                
                if (repeatMode == 0) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else if (repeatMode == 1) {
                    mRepeatButton.setText(FontAwesome.REPEAT);
                } else {
                    mRepeatButton.setText(FontAwesome.REPEAT_ONE);
                }
                
                mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
                mThemeHelper.updateControlButton(mRepeatButton, false, false);
            }
        }
    }
    
    /**
     * Updates the shuffle button icon based on current shuffle state.
     */
    private void updateShuffleButtonIcon() {
        if (mMusicService != null && mShuffleButton != null && mThemeHelper != null) {
            final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            final boolean isEnabled = hasSongs && mShuffleButton.isEnabled();
            
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            
            if (isEnabled) {
                final boolean isShuffleOn = mMusicService.isShuffle();
                mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
            } else {
                mThemeHelper.updateControlButton(mShuffleButton, false, false);
            }
        }
    }
    
    /**
     * Updates the play/pause button text and theme state.
     */
    private void updatePlayPauseButton() {
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
                
                final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
                
                if (!hasSongs) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                    return;
                }
                
                mPlayButton.setEnabled(true);
                
                if (mMusicService == null) {
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                    return;
                }
                
                try {
                    final boolean isPlaying = mMusicService.isAnyPlayerPlaying();
                    mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                } catch (Exception e) {
                    Log.e(TAG, "Error updating play/pause button", e);
                    mPlayButton.setText(FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
            }
        });
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position seeking.
     * 
     * Blocks UI updates during user interaction using {@link #mIsUserSeeking}
     * flag to allow the service to complete the seek operation.
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled()) {
                    if (mSeekTime != null) {
                        mSeekTime.setText(formatTime(progress));
                    }
                    mSeekTargetPosition = progress;
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                mSeekHandler.removeCallbacksAndMessages(null);
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled() && mSeekTargetPosition >= 0) {
                    final int seekPos = mSeekTargetPosition;
                    
                    // Reset flag BEFORE seek so UI updates resume immediately
                    mIsUserSeeking = false;
                    
                    mMusicService.seekTo(seekPos);
                    
                    if (mSeekTime != null) {
                        mSeekTime.setText(formatTime(seekPos));
                    }
                    
                    // Force immediate position update
                    if (mSeekBar != null) {
                        mSeekBar.setProgress(seekPos);
                    }
                    
                    Log.d(TAG, "Seek completed - moved to position: " + seekPos + "ms");
                    
                    mSeekHandler.removeCallbacksAndMessages(null);
                    mSeekTargetPosition = -1;
                } else {
                    mIsUserSeeking = false;
                    mSeekTargetPosition = -1;
                }
            }
        });
    }
    
    // ========================================================================
    // Time Display Methods
    // ========================================================================
    
    /**
     * Starts a recurring handler to update time display and SeekBar position.
     * Uses a member Handler to prevent memory leaks.
     * 
     * Respects {@link #mIsUserSeeking} flag to prevent overwriting user's seek position.
     * Handles song completion to fill seekbar to 100%.
     */
    private void updateTimeDisplay() {
        // Clean up existing handler if any
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }
        
        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                
                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }
                
                // Don't update while user is seeking
                if (mIsUserSeeking) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, 100); // Check more frequently
                    }
                    return;
                }
                
                try {
                    if (service.isAnyPlayerPrepared()) {
                        int currentPosition = service.getCurrentPosition();
                        int duration = service.getDuration();
                        
                        if (duration > 0) {
                            // Update time text
                            if (mSeekTime != null) {
                                mSeekTime.setText(formatTime(currentPosition));
                            }
                            if (mTotalTime != null) {
                                mTotalTime.setText(formatTime(duration));
                            }
                            
                            // Update seekbar (only if not seeking)
                            if (mSeekBar != null && mSeekBar.isEnabled()) {
                                if (mSeekBar.getMax() != duration) {
                                    mSeekBar.setMax(duration);
                                }
                                mSeekBar.setProgress(currentPosition);
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error updating time display", e);
                }
                
                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }
    
    /**
     * Formats milliseconds into time string (MM:SS or HH:MM:SS).
     * 
     * @param milliseconds Time in milliseconds
     * @return Formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Calculates the appropriate sample size for loading album art.
     * 
     * @param options BitmapFactory.Options with outWidth and outHeight set
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The calculated sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Decodes sampled bitmap from byte array to prevent OOM errors.
     * 
     * @param data The image byte array
     * @param reqWidth Requested width
     * @param reqHeight Requested height
     * @return Sampled bitmap or null
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Updates album art for the given song path.
     * Uses LRU cache and async loading with downsampling.
     * 
     * @param filePath Path to the song file
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        if (mCurrentAlbumArtTask != null) {
            mCurrentAlbumArtTask.cancel(true);
            mCurrentAlbumArtTask = null;
        }
        
        mCurrentLoadingArtPath = filePath;
        mCurrentAlbumArtTask = new AsyncTask<Void, Void, Bitmap>() {
            private final String taskPath = filePath;
            
            @Override
            protected Bitmap doInBackground(Void... params) {
                if (isCancelled()) return null;
                
                MediaMetadataRetriever retriever = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !isCancelled()) {
                        return decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                return null;
            }
            
            @Override
            protected void onPostExecute(Bitmap bitmap) {
                if (isFinishing() || isDestroyed()) return;
                if (!isCancelled() && taskPath.equals(mCurrentLoadingArtPath) && taskPath.equals(mCurrentAlbumArtPath)) {
                    if (bitmap != null && mAlbumArtCache != null) {
                        mAlbumArtCache.put(taskPath, bitmap);
                        applyAlbumArtWithFade(bitmap);
                    } else {
                        loadAndDisplayPlaceholder();
                    }
                    applyAlbumArtClipping();
                }
                if (mCurrentAlbumArtTask == this) {
                    mCurrentAlbumArtTask = null;
                    mCurrentLoadingArtPath = null;
                }
            }
        }.execute();
    }
    
    /**
     * Applies album art bitmap with fade animation.
     * 
     * @param bitmap The bitmap to display
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }
        
        if (isFinishing() || isDestroyed() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        
        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }
        
        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }
    
    /**
     * Loads and displays the themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    /**
     * Updates the notification with current album art.
     */
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(currentPath);
            if (cached != null && !cached.isRecycled()) {
                art = cached;
            }
        }
        
        mMusicService.setNotificationAlbumArt(art, placeholder, currentPath);
    }
    
    /**
     * Gets the path of the currently playing song.
     * 
     * @return Song path or null
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }
    
    /**
     * Checks if a bitmap is valid for display.
     * 
     * @param bitmap The bitmap to check
     * @return True if bitmap is valid
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Updates the themed placeholder bitmap asynchronously.
     * Tints the placeholder with current theme color.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }
    
    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    /**
     * Safely recycles a bitmap.
     * 
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corner clipping to the album art container.
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a loading overlay with dim background and progress spinner.
     * Used for initial app loading only. Persistent overlays use ToastManager.
     */
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) return;

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Hides the loading overlay.
     */
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the FolderManager activity.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the PlaylistActivity.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the MetadataEditor for the current song.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song.
     * 
     * @return Current song or null
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song metadata from SharedPreferences.
     * 
     * <p>This method first checks the database cache for the song to get
     * the real genre (if previously loaded by Phase 2). If not found in
     * cache, it falls back to reading from the file using MediaMetadataRetriever.
     * This ensures that the genre is properly displayed when the app restarts.</p>
     * 
     * <p><b>Note:</b> This method uses ExecutorService instead of AsyncTask
     * to avoid memory leaks and threading issues on modern Android versions.</p>
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    Song song = null;
                    try {
                        // First check database for cached song with real genre
                        Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        
                        if (cachedSong != null && cachedSong.getTitle() != null && 
                            !cachedSong.getTitle().isEmpty() && 
                            !"Unknown Title".equals(cachedSong.getTitle())) {
                            song = cachedSong;
                        } else {
                            // Fall back to reading from file (as original)
                            final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                            mmr.setDataSource(lastPath);
                            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                            String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                            final byte[] art = mmr.getEmbeddedPicture();
                            mmr.release();
                            
                            if (title == null || title.isEmpty()) {
                                final File file = new File(lastPath);
                                String name = file.getName();
                                final int dot = name.lastIndexOf('.');
                                if (dot > 0) name = name.substring(0, dot);
                                title = name;
                            }
                            if (artist == null) artist = "Unknown Artist";
                            if (album == null) album = "Unknown Album";
                            
                            // Try to get real genre from database or file
                            String genre = "Unknown Genre";
                            Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                            if (dbSong != null && dbSong.getGenre() != null && 
                                !"Unknown Genre".equals(dbSong.getGenre())) {
                                genre = dbSong.getGenre();
                                Log.d(TAG, "Found genre in database: " + genre);
                            } else {
                                // Try to read from file using CharacterMapper
                                String fileGenre = CharacterMapper.getGenre(lastPath);
                                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                    genre = fileGenre;
                                    Log.d(TAG, "Read genre from file: " + genre);
                                }
                            }
                            
                            song = new Song(title, artist, album, genre, lastPath, 0, null);
                            if (art != null && mAlbumArtCache != null) {
                                final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                                if (bmp != null) {
                                    mAlbumArtCache.put(lastPath, bmp);
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                    }
                    
                    final Song finalSong = song;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            if (finalSong != null && mThemeHelper != null) {
                                mCachedLastSong = finalSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(finalSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(finalSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                } else {
                                    loadAndDisplayPlaceholder();
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Starts MusicService with the cached last song as a temporary playlist.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<Song>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs from library and starts MusicService.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    // Use service's current song for display
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers restart receiver for app updates.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers theme change broadcast receiver.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies current theme color to all UI components.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs app restart after update.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for inter-component communication.
     */
    private void registerReceivers() {
        // Update player receiver
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    safeUpdateUI(new Runnable() {
                        @Override
                        public void run() {
                            // Handle song completion - force seekbar to 100%
                            if (songCompleted && completedPosition > 0) {
                                if (mSeekBar != null) {
                                    mSeekBar.setMax(completedPosition);
                                    mSeekBar.setProgress(completedPosition);
                                }
                                if (mSeekTime != null) {
                                    mSeekTime.setText(formatTime(completedPosition));
                                }
                                if (mTotalTime != null) {
                                    mTotalTime.setText(formatTime(completedPosition));
                                }
                                Log.d(TAG, "Song completed - seekbar filled to 100%");
                            }
                            
                            updatePlayPauseButton();
                            
                            if (mMusicService != null) {
                                if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                    final int duration = mMusicService.getDuration();
                                    final int position = mMusicService.getCurrentPosition();
                                    mSeekBar.setMax(duration);
                                    mSeekBar.setProgress(position);
                                }
                                
                                // Always get current song from service
                                final Song song = mMusicService.getCurrentSong();
                                if (song != null) {
                                    if (mMusicService.isAnyPlayerPlaying()) {
                                        updateUIForPlayingSong(song);
                                    } else {
                                        updateUIForSong(song);
                                    }
                                }
                            }
                            setupSeekBar();
                        }
                    });
                }
            }
        };
        
        // Play song receiver
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        // Bluetooth play receiver
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Bluetooth pause receiver
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        
        // Media button receiver
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        // Get playing state receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        // Reset player receiver
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };
        
        // Force update player receiver
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            }
                        }
                        
                        // Use service's current song for display
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };
        
        // Save player state now receiver
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        // Bluetooth connection receiver
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        // Sync started receiver - uses ToastManager (matches FolderManager approach)
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        // Sync complete receiver - uses ToastManager (matches FolderManager approach)
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        // Update playlist from folders receiver
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    // Use service's current song for display
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        // Soft update playlist receiver
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        // Force refresh to get latest database state
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    // Use service's current song for album art
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        // Update song in playlist receiver
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) {
                        return;
                    }
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    // Use service's current song for display
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        /**
         * Playback recovery receiver - displays a toast message when MusicService
         * successfully recovers from a playback stall. This provides user feedback
         * that the app detected and fixed an issue automatically.
         */
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, 
                        "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        /**
         * Sort mode update receiver - synchronizes playlist sort order with PlaylistActivity.
         * When the user changes sort mode in PlaylistActivity, this receiver refreshes
         * the current song display to reflect the new sort order. The actual playlist
         * reordering is handled by MusicService's internal sort mode receiver.
         */
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        // Refresh the current song display - the service handles reordering internally
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        /**
         * Player status update receiver - shows a status toast indicating which
         * audio player is active (SoundTouch or MediaPlayer fallback).
         * 
         * <p>This receiver listens for PLAYER_STATUS_UPDATE broadcasts from MusicService
         * when the player initializes or falls back. The toast provides visual confirmation
         * of which audio engine is currently in use, helping to verify that the SoundTouch
         * player is working correctly.</p>
         * 
         * <p>The receiver shows a normal toast with the active player type (e.g., 
         * "SoundTouch is active..." or "MediaPlayer is active...").</p>
         */
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.showToast(MusicPlayer.this, 
                                    playerType + " is active...", 
                                    ToastManager.LENGTH_NORMAL);
                            }
                        });
                    }
                }
            }
        };
        
        /**
         * Song prepared receiver - listens for pre-initialization completion from
         * SoundTouchPlayer. When a song is pre-loaded (before play is pressed),
         * this receiver updates the UI with the song duration and enables the
         * equalizer with the audio session ID.
         */
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra("duration", 0);
                    final int audioSessionId = intent.getIntExtra("audio_session_id", -1);
                    final String songPath = intent.getStringExtra("song_path");
                    
                    Log.d(TAG, "SONG_PREPARED received: duration=" + duration + 
                          "ms, session=" + audioSessionId + ", path=" + songPath);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Update total time display
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime(duration));
                                Log.d(TAG, "Updated total time to: " + formatTime(duration));
                            }
                            
                            // Update seekbar max value
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(0);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                                Log.d(TAG, "Updated seekbar max to: " + duration + "ms");
                            }
                            
                            // Ensure play button is enabled
                            if (mPlayButton != null) {
                                mPlayButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                            }
                            
                            // Enable equalizer button (session now exists)
                            if (mEqualizerButton != null) {
                                mEqualizerButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateButton(mEqualizerButton, true);
                                }
                            }
                            
                            // Update current song display if path matches
                            if (songPath != null && mMusicService != null) {
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                    // Update duration in the song object
                                    if (duration > 0) {
                                        currentSong.setDuration(duration);
                                    }
                                    updateUIForSong(currentSong);
                                }
                            }
                        }
                    });
                }
            }
        };
        
        // Register all receivers
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
        registerReceiverSafely(mPlayerStatusReceiver, "PLAYER_STATUS_UPDATE");
        registerReceiverSafely(mSongPreparedReceiver, ACTION_SONG_PREPARED);
    }
    
    /**
     * Safely registers a broadcast receiver.
     * 
     * @param receiver The receiver to register
     * @param action The intent action to listen for
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     * 
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all control buttons.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButtonIcon();
                            final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButtonIcon();
                            ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(android.content.DialogInterface d) {
                                final View mainContent = findViewById(android.R.id.content);
                                mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }
    
    /**
     * Compatibility method for checking if activity is destroyed.
     * 
     * @return True if activity is destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels (dp) to pixels (px).
     *
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}