package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Playback stall recovery with user feedback</li>
 *   <li>Sort mode synchronization with PlaylistActivity</li>
 * </ul>
 * 
 * <h3>Pre-initialization Support</h3>
 * <p>This activity listens for {@link #ACTION_SONG_PREPARED} broadcasts from
 * {@link LlamaPlayer} to receive song duration and audio session ID
 * before playback begins. This ensures the timer shows total time and the
 * equalizer is ready immediately after folder import.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for runtime permissions. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection result. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings dialog. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing first run flag. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing last song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Intent action for restarting the app after update. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Broadcast action for updating sort mode from playlist. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Broadcast action for player status update (diagnostic). */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Broadcast action for song prepared event (from LlamaPlayer). */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Broadcast action when player is ready for playback. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum dimension for album art in pixels (for downsampling). */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Timeout for loading overlay display. */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Delay for play/pause button update. */
    private static final long PLAY_PAUSE_UPDATE_DELAY_MS = 50;
    
    /** Delay for next/prev button updates. */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus scroll operations. */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Interval for time display updates. */
    private static final long TIME_UPDATE_INTERVAL_MS = 500;
    
    /** Delay for seek reset flag in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    /** Buffer size for file copying operations. */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Duration of album art fade animation. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Alpha value for dim overlay (0-255). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in dp. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art in dp. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView for displaying song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView for displaying artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView for current seek position. */
    @Nullable private TextView mSeekTime;
    
    /** TextView for total track duration. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Play/Pause control button. */
    @Nullable private Button mPlayButton;
    
    /** Previous track button. */
    @Nullable private Button mPrevButton;
    
    /** Next track button. */
    @Nullable private Button mNextButton;
    
    /** Repeat mode button (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Shuffle mode button. */
    @Nullable private Button mShuffleButton;
    
    /** Button to open folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button to open credits dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button to open playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button to open equalizer. */
    @Nullable private Button mEqualizerButton;
    
    /** Button to open metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for album art display. */
    @Nullable private ImageView mAlbumArtView;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Music library manager for song data. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Bound music service instance. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Main thread handler for delayed operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for time display updates (to prevent memory leaks). */
    @Nullable private Handler mTimeHandler = null;
    
    /** Flag indicating service binding state. */
    private boolean mIsServiceBound = false;
    
    /** Flag indicating user is currently seeking. */
    private volatile boolean mIsUserSeeking = false;
    
    /** Target seek position during user drag. */
    private int mSeekTargetPosition = -1;
    
    /** Handler for seek reset delay. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Atomic flag to prevent concurrent UI updates. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for thread-safe service access. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating post-update restart. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transitions. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    /** LRU cache for album art bitmaps. */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Executor for album art loading (replaces deprecated AsyncTask). */
    @Nullable private ExecutorService mAlbumArtExecutor = null;
    
    /** Future for currently running album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    
    /** Path of currently loading album art. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    /** Path of currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    /** Themed placeholder bitmap. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Executor for placeholder generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock object for placeholder synchronization. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components (Only loading overlay remains - persistent overlays use ToastManager)
    // ========================================================================
    
    /** Dim overlay for loading state. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner inside dim overlay. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Theme manager for color management. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Theme helper for UI color application. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme changes. */
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick loading. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    // ========================================================================
    // Executor for Metadata Loading (replaces AsyncTask)
    // ========================================================================
    
    /** Single-thread executor for loading last song metadata. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // PlaybackController
    // ========================================================================
    
    /** Centralized playback state controller. */
    @Nullable private PlaybackController mPlaybackController;
    
    /** PlaybackController listener for UI updates. */
    @Nullable private PlaybackController.PlaybackControllerListener mPlaybackControllerListener;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    @Nullable private BroadcastReceiver mPlayerReadyReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Service connection for binding to MusicService.
     * Handles service lifecycle, initial UI setup, and automatic reconnection.
     * 
     * Playback controls are ENABLED after the playlist has been fully loaded.
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        updateRepeatButton();
                        updateShuffleButton();
                        
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(true);
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                        
                        // Play button enabled immediately like other controls
                        final boolean isPlayingNow = (mPlaybackController != null) 
                            ? mPlaybackController.isPlaying()
                            : (mMusicService != null && mMusicService.isAnyPlayerPlaying());
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(true);
                            mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(true);
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                        if (mRepeatButton != null) {
                            mRepeatButton.setEnabled(true);
                            updateRepeatButton();
                        }
                        if (mShuffleButton != null) {
                            mShuffleButton.setEnabled(true);
                            updateShuffleButton();
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            updateUIForSong(currentSong);
                            updateAlbumArt(currentSong.getPath());
                        }
                    } else {
                        applyNoSongState();
                    }
                }
            }, FOCUS_SCROLL_DELAY_MS);
            
            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * Initializes all components, sets up UI, and binds to MusicService.
     * 
     * @param savedInstanceState Previously saved state (not used)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        // Initialize album art executor (replaces deprecated AsyncTask)
        mAlbumArtExecutor = Executors.newSingleThreadExecutor();

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        NavigationController.getInstance().registerListener(this);
        
        // Initialize PlaybackController
        mPlaybackController = PlaybackController.getInstance();
        setupPlaybackControllerListener();
    }
    
    /**
     * Called when the activity starts.
     * Re-registers theme receiver if needed.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity stops.
     * Unregisters theme receiver to prevent memory leaks.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes.
     * Reattaches ToastManager persistent overlay and updates UI with current playback state.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity restarts after being stopped.
     * Reattaches ToastManager persistent overlay to ensure it survives activity recreation.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     * Cleans up all resources, unregisters receivers, and unbinds service.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        unregisterReceiverSafely(mPlayerReadyReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();
        
        ToastManager.hidePersistentOverlay();
        hideLoadingOverlay();
        
        // Shutdown album art executor
        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdown();
        }
        
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    /**
     * Called when the system is running low on memory.
     * Forwards the event to MusicService for MediaPlayer health check.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Called when a new intent is received while activity is running.
     * Handles file import and app closure requests.
     * 
     * @param intent The new intent
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when window focus changes.
     * Re-applies immersive mode when window has focus.
     * 
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    /**
     * Handles media button key events (headset controls).
     * 
     * @param keyCode The key code
     * @param event The key event
     * @return True if handled, false otherwise
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNextSong();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPreviousSong();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    /**
     * Handles activity results from folder selection and battery optimization dialogs.
     *
     * @param requestCode The request code
     * @param resultCode The result code
     * @param data The result data intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Handles runtime permission request results.
     * 
     * <p>After permissions are granted, also checks and requests
     * battery optimization exemption.</p>
     *
     * @param requestCode The request code
     * @param permissions Requested permissions
     * @param grantResults Grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }
    
    // ========================================================================
    // PlaybackController Setup
    // ========================================================================
    
    /**
     * Sets up the PlaybackController listener for UI updates.
     * This replaces the old position polling mechanism with event-driven updates.
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        
        mPlaybackControllerListener = new PlaybackController.PlaybackControllerListener() {
            @Override
            public void onPositionChanged(long positionMs, long durationMs) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || mIsUserSeeking) return;
                    if (mSeekBar != null && mSeekBar.isEnabled()) {
                        if (mSeekBar.getMax() != (int) durationMs && durationMs > 0)
                            mSeekBar.setMax((int) durationMs);
                        mSeekBar.setProgress((int) positionMs);
                    }
                    if (mSeekTime != null) mSeekTime.setText(formatTime((int) positionMs));
                    if (mTotalTime != null && durationMs > 0) mTotalTime.setText(formatTime((int) durationMs));
                });
            }
            
            @Override
            public void onPlayStateChanged(boolean isPlaying) {
                runOnUiThread(() -> { 
                    if (!isFinishing() && !isDestroyed()) {
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                    }
                });
            }
            
            @Override
            public void onSongChanged(String title, String artist, String path, long duration) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (mSongTitle != null) {
                        String t = title != null ? title : "Unknown";
                        if (t.length() > MAX_TITLE_LENGTH) t = t.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                        mSongTitle.setText(t);
                        if (mThemeHelper != null) mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                    }
                    if (mSongArtist != null) {
                        String a = artist != null ? artist : "Unknown";
                        if (a.length() > MAX_ARTIST_LENGTH) a = a.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                        mSongArtist.setText(a);
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                    }
                    if (mSeekBar != null && duration > 0) {
                        mSeekBar.setMax((int) duration);
                        mSeekBar.setProgress(0);
                        mSeekBar.setEnabled(true);
                        if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, true);
                    }
                    if (mTotalTime != null && duration > 0) mTotalTime.setText(formatTime((int) duration));
                    if (mSeekTime != null) mSeekTime.setText("00:00");
                    updateAlbumArt(path);
                    if (mPlayButton != null) {
                        mPlayButton.setEnabled(true);
                        if (mThemeHelper != null) mThemeHelper.updateControlButton(mPlayButton, true, true);
                    }
                });
            }
            
            @Override
            public void onPreparedStateChanged(boolean isPrepared) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        // Update UI when song is prepared (show duration, etc.)
                        if (isPrepared && mPlaybackController != null) {
                            long duration = mPlaybackController.getDuration();
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime((int) duration));
                            }
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax((int) duration);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, true);
                            }
                        }
                    }
                });
            }
        };
        
        mPlaybackController.setListener(mPlaybackControllerListener);
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when navigation button group state changes.
     * Disables playlist and metadata buttons during database operations.
     * 
     * @param group The button group that changed
     * @param disabled True if the group is now disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }
                    
                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets appropriate status bar and navigation bar colors based on Android version.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components, sets up typefaces,
     * and configures button animations.
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        final Typeface faTypeface = FontAwesome.getTypeface();
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Adds a scale animation to a button for visual touch feedback.
     * 
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests runtime permissions for storage access.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * Starts and binds MusicService, loads last song metadata.
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks if the app is already exempt from battery optimizations.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles audio files opened from external apps (ACTION_VIEW intent).
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<Song>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<Song>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming song using already bound service.
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    enableAllControls();
                    updateUIForSong(newSong);
                }
            });
            
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to service first, then plays incoming song.
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            enableAllControls();
                            updateUIForSong(newSong);
                            applyAlbumArtClipping();
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist asynchronously and sets it on MusicService.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                                mSongTitle.setText(current.getTitle());
                                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                mSongArtist.setText(current.getArtist());
                                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                updateAlbumArt(current.getPath());
                            }
                            
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    });
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG);
                    }
                });
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Thread-safe UI update method that prevents concurrent updates.
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pending = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pending);
                    }
                }
            }
        });
    }
    
    /**
     * Updates UI with song metadata (non-playing state).
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        // Update PlaybackController first
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song);
        }
        
        final Song finalSong = song;
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Updates UI with song metadata when playing (triggers album art reload).
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        
        // Update PlaybackController first
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song);
        }
        
        final Song finalSong = song;
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Enables all playback control buttons.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(false);
                    mThemeHelper.updateControlButton(mPlayButton, false, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }
    
    /**
     * Updates control buttons state based on playlist size.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }
    
    /**
     * Applies the "no songs" state (placeholder display, disabled controls).
     */
    private void applyNoSongState() {
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }
        
        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on the MusicService with synchronization.
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method handles three distinct cases:
     * <ol>
     *   <li>Currently playing -> pause</li>
     *   <li>Paused but prepared -> resume</li>
     *   <li>No song prepared -> start new playback from current index or first song</li>
     * </ol>
     * </p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        // Get actual playback state from music service
        boolean isPlaying = mMusicService.isAnyPlayerPlaying();
        boolean isPrepared = mMusicService.isAnyPlayerPrepared();
        
        if (isPlaying) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
        } else if (isPrepared) {
            // Song is loaded and ready - resume/start it
            Log.d(TAG, "togglePlayPause: Starting/resuming playback");
            mMusicService.resume();
        } else {
            // Nothing prepared – start new playback
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playNext();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playPrevious();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates repeat button appearance based on current repeat mode.
     * 
     * Mode 0 (OFF):     REPEAT icon (gray/disabled appearance)
     * Mode 1 (ALL):     REPEAT icon (themed/active appearance)  
     * Mode 2 (ONE):     REPEAT_ONE icon (themed/active appearance)
     */
    private void updateRepeatButton() {
        if (mRepeatButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mRepeatButton.setText(FontAwesome.REPEAT);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isActive = (repeatMode != 0);
        
        if (repeatMode == 2) {
            mRepeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
        }
        
        mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
    }
    
    /**
     * Updates shuffle button appearance based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mShuffleButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
    }
    
    /**
     * Updates the play/pause button appearance based on current playback state.
     */
    private void updatePlayPauseButton() {
        if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        // Check if we have songs
        boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (!hasSongs) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
            return;
        }
        
        // Get playback state
        boolean isPlaying = false;
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
        } else if (mMusicService != null) {
            isPlaying = mMusicService.isAnyPlayerPlaying();
        }
        
        // Update for normal state
        mPlayButton.setEnabled(true);
        mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
        mThemeHelper.updateControlButton(mPlayButton, true, true);
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position seeking.
     * 
     * <p>This method implements proper seek handling with a reset delay
     * to ensure the seekbar continues updating after a seek operation.
     * When a user finishes seeking, the flag is reset after SEEK_RESET_DELAY_MS
     * and the UI is forced to update with the current position.</p>
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) mSeekTime.setText(formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mPlaybackController != null) mPlaybackController.onSeekStart();
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekPos);
                    if (mSeekTime != null) mSeekTime.setText(formatTime(seekPos));
                }
                mSeekTargetPosition = -1;
                
                // Clear any existing callbacks
                mSeekHandler.removeCallbacksAndMessages(null);
                
                // Safety reset of the flag after delay
                mSeekHandler.postDelayed(() -> {
                    mIsUserSeeking = false;
                    if (mPlaybackController != null) {
                        mPlaybackController.forceResetSeeking();
                    }
                    // Force position sync
                    if (mMusicService != null) {
                        int currentPos = mMusicService.getCurrentPosition();
                        if (mSeekBar != null) mSeekBar.setProgress(currentPos);
                        if (mSeekTime != null) mSeekTime.setText(formatTime(currentPos));
                    }
                    Log.d(TAG, "Seek flag reset - UI updates resumed");
                }, 500);
            }
        });
    }
    
    // ========================================================================
    // Time Display Methods
    // ========================================================================
    
    /**
     * Stops the polling loop and only sets initial values.
     * All position updates now come from the PlaybackController listener.
     */
    private void updateTimeDisplay() {
        // No polling loop! All position updates come from PlaybackController listener.
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        // Set initial values only
        if (mMusicService != null) {
            int duration = mMusicService.getDuration();
            int position = mMusicService.getCurrentPosition();
            if (mSeekBar != null && duration > 0) {
                mSeekBar.setMax(duration);
                mSeekBar.setProgress(position);
            }
            if (mTotalTime != null && duration > 0) {
                mTotalTime.setText(formatTime(duration));
            }
            if (mSeekTime != null) {
                mSeekTime.setText(formatTime(position));
            }
        }
    }
    
    /**
     * Formats milliseconds into time string (MM:SS or HH:MM:SS).
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Updates album art for the given song path using ExecutorService.
     * Replaces deprecated AsyncTask implementation.
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null && !cached.isRecycled()) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        // Cancel any ongoing task
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;
        
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;
                
                MediaMetadataRetriever retriever = null;
                Bitmap result = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        result = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                
                final Bitmap bitmap = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        if (!Thread.currentThread().isInterrupted() && 
                            taskPath.equals(mCurrentLoadingArtPath) && 
                            taskPath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, bitmap);
                                applyAlbumArtWithFade(bitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtTask == Thread.currentThread()) {
                            mCurrentAlbumArtTask = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Applies album art bitmap with fade animation.
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }
        
        if (isFinishing() || isDestroyed() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        
        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }
        
        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }
    
    /**
     * Loads and displays the themed placeholder bitmap.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    /**
     * Updates the notification with current album art.
     */
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(currentPath);
            if (cached != null && !cached.isRecycled()) {
                art = cached;
            }
        }
        
        mMusicService.setNotificationAlbumArt(art, placeholder, currentPath);
    }
    
    /**
     * Gets the path of the currently playing song.
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }
    
    /**
     * Checks if a bitmap is valid for display.
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Updates the themed placeholder bitmap asynchronously.
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }
    
    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    /**
     * Safely recycles a bitmap.
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corner clipping to the album art container.
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a loading overlay with dim background and progress spinner.
     */
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) return;

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Hides the loading overlay.
     */
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the FolderManager activity.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the PlaylistActivity.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the MetadataEditor for the current song.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song.
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song metadata from SharedPreferences.
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    Song song = null;
                    try {
                        Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        
                        if (cachedSong != null && cachedSong.getTitle() != null && 
                            !cachedSong.getTitle().isEmpty() && 
                            !"Unknown Title".equals(cachedSong.getTitle())) {
                            song = cachedSong;
                        } else {
                            final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                            mmr.setDataSource(lastPath);
                            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                            String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                            final byte[] art = mmr.getEmbeddedPicture();
                            mmr.release();
                            
                            if (title == null || title.isEmpty()) {
                                final File file = new File(lastPath);
                                String name = file.getName();
                                final int dot = name.lastIndexOf('.');
                                if (dot > 0) name = name.substring(0, dot);
                                title = name;
                            }
                            if (artist == null) artist = "Unknown Artist";
                            if (album == null) album = "Unknown Album";
                            
                            String genre = "Unknown Genre";
                            Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                            if (dbSong != null && dbSong.getGenre() != null && 
                                !"Unknown Genre".equals(dbSong.getGenre())) {
                                genre = dbSong.getGenre();
                                Log.d(TAG, "Found genre in database: " + genre);
                            } else {
                                String fileGenre = CharacterMapper.getGenre(lastPath);
                                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                    genre = fileGenre;
                                    Log.d(TAG, "Read genre from file: " + genre);
                                }
                            }
                            
                            song = new Song(title, artist, album, genre, lastPath, 0, null);
                            if (art != null && mAlbumArtCache != null) {
                                final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                                if (bmp != null) {
                                    mAlbumArtCache.put(lastPath, bmp);
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                    }
                    
                    final Song finalSong = song;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            if (finalSong != null && mThemeHelper != null) {
                                mCachedLastSong = finalSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(finalSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(finalSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                } else {
                                    loadAndDisplayPlaceholder();
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Starts MusicService with the cached last song as a temporary playlist.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<Song>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs from library and starts MusicService.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers restart receiver for app updates.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers theme change broadcast receiver.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies current theme color to all UI components.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(false);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs app restart after update.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for inter-component communication.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final boolean isPlaying = intent.getBooleanExtra("is_playing", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    safeUpdateUI(new Runnable() {
                        @Override
                        public void run() {
                            if (songCompleted && !isPlaying) {
                                if (mSeekBar != null) {
                                    mSeekBar.setProgress(0);
                                }
                                if (mSeekTime != null) {
                                    mSeekTime.setText("00:00");
                                }
                                Log.d(TAG, "Song completed - seekbar reset to 0");
                            } else if (songCompleted && completedPosition > 0) {
                                if (mSeekBar != null) {
                                    mSeekBar.setMax(completedPosition);
                                    mSeekBar.setProgress(completedPosition);
                                }
                                if (mSeekTime != null) {
                                    mSeekTime.setText(formatTime(completedPosition));
                                }
                                if (mTotalTime != null) {
                                    mTotalTime.setText(formatTime(completedPosition));
                                }
                                Log.d(TAG, "Song completed - seekbar filled to 100%");
                            }
                            
                            updatePlayPauseButton();
                            
                            if (mMusicService != null) {
                                if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                    final int duration = mMusicService.getDuration();
                                    final int position = mMusicService.getCurrentPosition();
                                    mSeekBar.setMax(duration);
                                    mSeekBar.setProgress(position);
                                }
                                
                                final Song song = mMusicService.getCurrentSong();
                                if (song != null) {
                                    if (mMusicService.isAnyPlayerPlaying()) {
                                        updateUIForPlayingSong(song);
                                    } else {
                                        updateUIForSong(song);
                                    }
                                }
                            }
                            setupSeekBar();
                        }
                    });
                }
            }
        };
        
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };
        
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) {
                        return;
                    }
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.showToast(MusicPlayer.this, playerType + " is active...", ToastManager.LENGTH_NORMAL);
                            }
                        });
                    }
                }
            }
        };
        
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra("duration", 0);
                    final int audioSessionId = intent.getIntExtra("audio_session_id", -1);
                    final String songPath = intent.getStringExtra("song_path");
                    
                    Log.d(TAG, "SONG_PREPARED received: duration=" + duration + "ms, session=" + audioSessionId + ", path=" + songPath);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime(duration));
                                Log.d(TAG, "Updated total time to: " + formatTime(duration));
                            }
                            
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(0);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                                Log.d(TAG, "Updated seekbar max to: " + duration + "ms");
                            }
                            
                            if (mPlayButton != null) {
                                mPlayButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                            }
                            
                            if (mEqualizerButton != null) {
                                mEqualizerButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateButton(mEqualizerButton, true);
                                }
                            }
                            
                            if (songPath != null && mMusicService != null) {
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                    if (duration > 0) {
                                        currentSong.setDuration(duration);
                                    }
                                    updateUIForSong(currentSong);
                                }
                            }
                        }
                    });
                }
            }
        };
        
        mPlayerReadyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_READY.equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mPlayButton != null && mMusicLibrary != null && 
                                mMusicLibrary.getSongCount() > 0) {
                                mPlayButton.setEnabled(true);
                                mPlayButton.setText(FontAwesome.PLAY);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                                Log.d(TAG, "Play button enabled via PLAYER_READY broadcast");
                            }
                        }
                    });
                }
            }
        };
        
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
        registerReceiverSafely(mPlayerStatusReceiver, ACTION_PLAYER_STATUS_UPDATE);
        registerReceiverSafely(mSongPreparedReceiver, ACTION_SONG_PREPARED);
        registerReceiverSafely(mPlayerReadyReceiver, ACTION_PLAYER_READY);
    }
    
    /**
     * Safely registers a broadcast receiver.
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all control buttons.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(android.content.DialogInterface d) {
                                final View mainContent = findViewById(android.R.id.content);
                                mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }
    
    /**
     * Compatibility method for checking if activity is destroyed.
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels (dp) to pixels (px).
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}