package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It provides:</p>
 * <ul>
 *   <li>Full music playback controls (play/pause, next, previous)</li>
 *   <li>Seek bar for position tracking and seeking</li>
 *   <li>Album art display with caching and fallback placeholders</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Navigation to playlist, folder manager, equalizer, and metadata editor</li>
 *   <li>Bluetooth headset support</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>Theme color integration</li>
 *   <li>Background service binding for continuous playback</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Playback stall recovery with user feedback</li>
 *   <li>Sort mode synchronization with PlaylistActivity</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>MusicPlayer follows the Model-View-Controller pattern where:</p>
 * <ul>
 *   <li><b>Activity</b> serves as the View, displaying UI and capturing user input</li>
 *   <li><b>MusicService</b> acts as the Controller, managing playback in background</li>
 *   <li><b>PlaybackController</b> provides the single source of truth for state</li>
 *   <li><b>MusicLibrary</b> manages the data model (songs, playlists)</li>
 * </ul>
 * 
 * <h3>Threading Model</h3>
 * <p>The activity uses a multi-threaded architecture:</p>
 * <ul>
 *   <li><b>UI Thread:</b> All View operations and user interaction handling</li>
 *   <li><b>Handler Thread:</b> Background operations and service communication</li>
 *   <li><b>ExecutorService:</b> Album art loading and metadata extraction</li>
 *   <li><b>Separate Executor:</b> Placeholder bitmap generation</li>
 * </ul>
 * 
 * <h3>State Management</h3>
 * <p>UI state is synchronized with MusicService through:</p>
 * <ul>
 *   <li>Broadcast receivers for service events</li>
 *   <li>PlaybackController for centralized state</li>
 *   <li>ServiceConnection callbacks for binding events</li>
 *   <li>SharedPreferences for persistence across app restarts</li>
 * </ul>
 * 
 * <h3>Permission Handling</h3>
 * <p>The activity requests necessary permissions at runtime:</p>
 * <ul>
 *   <li>READ_MEDIA_AUDIO (Android 13+) or READ_EXTERNAL_STORAGE (older)</li>
 *   <li>POST_NOTIFICATIONS (Android 13+)</li>
 *   <li>BLUETOOTH_CONNECT (Android 12+)</li>
 *   <li>Battery optimization exemption for background playback</li>
 * </ul>
 * 
 * <h3>Album Art Caching</h3>
 * <p>Album art uses a two-level caching strategy:</p>
 * <ul>
 *   <li><b>L1 Cache:</b> LruCache with 50MB maximum size</li>
 *   <li><b>Memory Management:</b> onTrimMemory() forwards to MusicService</li>
 *   <li><b>Bitmap Recycling:</b> Proper cleanup on activity destroy</li>
 * </ul>
 * 
 * <h3>Click Debouncing</h3>
 * <p>All control buttons implement click debouncing (500ms) to prevent:</p>
 * <ul>
 *   <li>Accidental double-taps during transitions</li>
 *   <li>Rapid successive operations that could cause race conditions</li>
 *   <li>UI jitter from overlapping state updates</li>
 * </ul>
 * 
 * <h3>Lifecycle Integration</h3>
 * <p>The activity properly manages resources across lifecycle events:</p>
 * <ul>
 *   <li><b>onCreate:</b> Initialize UI, services, and restore state</li>
 *   <li><b>onResume:</b> Refresh UI and reconnect observers</li>
 *   <li><b>onPause:</b> Save state and release non-critical resources</li>
 *   <li><b>onDestroy:</b> Unbind services, unregister receivers, cleanup bitmaps</li>
 * </ul>
 * 
 * @see MusicService
 * @see PlaybackController
 * @see MusicLibrary
 * @see ThemeManager
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Tag for logging messages from this class. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for permission requests. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for tracking first run of the application. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing the last played song's file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Action for restarting the application after updates. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action indicating a song has been prepared for playback. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Action indicating the player is ready for playback. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Maximum album art cache size in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Maximum album art dimension in pixels for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Debounce delay for button clicks to prevent rapid firing (milliseconds). */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before showing loading overlay (milliseconds). */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Delay for play/pause button sync after operation (milliseconds). */
    private static final long PLAY_PAUSE_SYNC_DELAY_MS = 100;
    
    /** Delay for next/previous button UI updates (milliseconds). */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    
    /** Delay for focus operations and scrolling (milliseconds). */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Interval for time display updates in milliseconds. */
    private static final long TIME_UPDATE_INTERVAL_MS = 200;
    
    /** Delay before resetting seek state after user stops seeking. */
    private static final int SEEK_RESET_DELAY_MS = 150;
    
    /** Buffer size for file copying operations (8KB). */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum length for song title display before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum length for artist name display before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Duration of album art fade animation in milliseconds. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    /** Alpha value for dim overlay background (180 = 70% opacity). */
    private static final int DIM_ALPHA = 180;
    
    /** Size of progress bar in density-independent pixels. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Corner radius for album art container in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Button for play/pause toggling. */
    @Nullable private Button mPlayButton;
    
    /** Button for previous song navigation. */
    @Nullable private Button mPrevButton;
    
    /** Button for next song navigation. */
    @Nullable private Button mNextButton;
    
    /** Button for repeat mode cycling (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Button for shuffle mode toggling. */
    @Nullable private Button mShuffleButton;
    
    /** Button for opening folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button for showing credits/about dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button for opening playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button for opening equalizer settings. */
    @Nullable private Button mEqualizerButton;
    
    /** Button for opening metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Library manager for accessing song data and playlists. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Background service for music playback. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for storage access framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for time display updates. */
    @Nullable private Handler mTimeHandler = null;
    
    /** Flag indicating if the service is bound. */
    private volatile boolean mIsServiceBound = false;
    
    /** Flag indicating if user is actively seeking (dragging seek bar). */
    private volatile boolean mIsUserSeeking = false;
    
    /** Target position for pending seek operations. */
    private int mSeekTargetPosition = -1;
    
    /** Handler for seek operation timeouts. */
    private final Handler mSeekHandler = new Handler(Looper.getMainLooper());
    
    /** Atomic flag for UI update synchronization. */
    @NonNull private final AtomicBoolean mIsUpdatingUI = new AtomicBoolean(false);
    
    /** Pending UI update runnable for debounced updates. */
    @Nullable private Runnable mPendingUIUpdate = null;
    
    /** Lock object for service synchronization. */
    @NonNull private final Object mServiceLock = new Object();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating if activity is restarting after an update. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Atomic flag for control button transition synchronization. */
    @NonNull private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    /** Timestamp of last play/pause button click. */
    private long mLastPlayPauseClickTime = 0;
    
    /** Timestamp of last next button click. */
    private long mLastNextClickTime = 0;
    
    /** Timestamp of last previous button click. */
    private long mLastPrevClickTime = 0;
    
    /** Timestamp of last repeat button click. */
    private long mLastRepeatClickTime = 0;
    
    /** Timestamp of last shuffle button click. */
    private long mLastShuffleClickTime = 0;
    
    /** Timestamp of last equalizer button click. */
    private long mLastEqualizerClickTime = 0;
    
    /** Timestamp of last manager button click. */
    private long mLastManagerClickTime = 0;
    
    /** Timestamp of last llama/credits button click. */
    private long mLastLlamaClickTime = 0;
    
    /** Timestamp of last playlist button click. */
    private long mLastPlaylistClickTime = 0;
    
    /** Timestamp of last metadata button click. */
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Album Art Components
    // ========================================================================
    
    /** LRU cache for album art bitmaps (50MB max). */
    @Nullable private android.util.LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Executor for asynchronous album art loading. */
    @Nullable private ExecutorService mAlbumArtExecutor = null;
    
    /** Future for the current album art loading task. */
    @Nullable private Future<?> mCurrentAlbumArtTask = null;
    
    /** Path of the album art currently being loaded. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    /** Path of the currently displayed album art. */
    @Nullable private String mCurrentAlbumArtPath = null;
    
    // ========================================================================
    // Placeholder Components
    // ========================================================================
    
    /** Placeholder bitmap for when album art is unavailable. */
    @Nullable private Bitmap mPlaceholderBitmap = null;
    
    /** Original untinted placeholder bitmap before theme color applied. */
    @Nullable private Bitmap mOriginalPlaceholderBitmap = null;
    
    /** Executor for placeholder bitmap generation. */
    @NonNull private final ExecutorService mPlaceholderExecutor = Executors.newSingleThreadExecutor();
    
    /** Future for the current placeholder generation task. */
    @Nullable private Future<?> mCurrentPlaceholderTask = null;
    
    /** Lock for placeholder bitmap operations. */
    @NonNull private final Object mPlaceholderLock = new Object();
    
    // ========================================================================
    // Overlay Components
    // ========================================================================
    
    /** Dim overlay view for loading states. */
    @Nullable private View mDimOverlay = null;
    
    /** Loading spinner shown during long operations. */
    @Nullable private ProgressBar mLoadingSpinner = null;
    
    // ========================================================================
    // Theme Components
    // ========================================================================
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Broadcast receiver for theme change events. */
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Storage Observer
    // ========================================================================
    
    /** Observer for external storage changes. */
    @Nullable private StorageObserver mStorageObserver;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick access. */
    @Nullable private Song mCachedLastSong = null;
    
    /** Cached loose songs list. */
    @Nullable private ArrayList<Song> mLooseSongs = null;
    
    // ========================================================================
    // Executor for Metadata Loading
    // ========================================================================
    
    /** Single-thread executor for metadata extraction operations. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // PlaybackController
    // ========================================================================
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable private PlaybackController mPlaybackController;
    
    /** Listener for PlaybackController callbacks. */
    @Nullable private PlaybackController.PlaybackControllerListener mPlaybackControllerListener;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for general player updates. */
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    
    /** Receiver for play song requests. */
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    
    /** Receiver for Bluetooth play commands. */
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    
    /** Receiver for Bluetooth pause commands. */
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    
    /** Receiver for media button events. */
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    
    /** Receiver for playing state queries. */
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for player reset commands. */
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    
    /** Receiver for force update commands. */
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    
    /** Receiver for restart commands. */
    @Nullable private BroadcastReceiver mRestartReceiver;
    
    /** Receiver for save player state commands. */
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    
    /** Receiver for Bluetooth connection events. */
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    
    /** Receiver for sync started events. */
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    
    /** Receiver for sync complete events. */
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    
    /** Receiver for playlist update from folders. */
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    
    /** Receiver for soft playlist updates. */
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    
    /** Receiver for song updates in playlist. */
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    
    /** Receiver for playback recovery events. */
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    
    /** Receiver for sort mode changes. */
    @Nullable private BroadcastReceiver mSortModeReceiver;
    
    /** Receiver for player status updates. */
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    
    /** Receiver for song prepared events. */
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    
    /** Receiver for player ready events. */
    @Nullable private BroadcastReceiver mPlayerReadyReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Connection to the MusicService for playback control.
     * 
     * <p>This ServiceConnection handles binding to MusicService and initializing
     * the UI once the service is connected. It includes automatic reconnection
     * logic if the service disconnects unexpectedly.</p>
     * 
     * <p><b>Key responsibilities:</b></p>
     * <ul>
     *   <li>Obtain service reference via LocalBinder</li>
     *   <li>Load playlist data asynchronously</li>
     *   <li>Update UI with current playback state</li>
     *   <li>Setup seek bar and time display</li>
     *   <li>Handle unexpected disconnection with retry logic</li>
     *   <li>Play button is enabled immediately (no 500ms delay)</li>
     * </ul>
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            // Enable controls immediately when service connects
            if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                updateRepeatButton();
                updateShuffleButton();
                
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(true);
                    mThemeHelper.updateSeekBar(mSeekBar, true);
                }
                
                final boolean isPlayingNow = (mPlaybackController != null) 
                    ? mPlaybackController.isPlaying()
                    : (mMusicService != null && mMusicService.isAnyPlayerPlaying());
                if (mPlayButton != null && mThemeHelper != null) {
                    // Play button is already enabled from initializeViews()
                    // Just update the text and theme
                    mPlayButton.setText(isPlayingNow ? FontAwesome.PAUSE : FontAwesome.PLAY);
                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                }
                
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(true);
                    mThemeHelper.updateControlButton(mPrevButton, true, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(true);
                    mThemeHelper.updateControlButton(mNextButton, true, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(true);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(true);
                    updateShuffleButton();
                }
                
                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                if (currentSong != null) {
                    updateUIForSong(currentSong);
                    updateAlbumArt(currentSong.getPath());
                }
            } else {
                applyNoSongState();
            }
            
            setupSeekBar();
            updateTimeDisplay();
            hideLoadingOverlay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                        Log.d(TAG, "Attempting to reconnect to MusicService");
                        Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                    }
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>This method performs the following initialization steps:</p>
     * <ol>
     *   <li>Sets full-screen immersive mode</li>
     *   <li>Inflates the layout from activity_music_player.xml</li>
     *   <li>Initializes ToastManager for user feedback</li>
     *   <li>Checks for close_app intent flag</li>
     *   <li>Initializes FontAwesome icon library</li>
     *   <li>Creates album art LRU cache (50MB)</li>
     *   <li>Initializes album art executor service</li>
     *   <li>Gets ThemeManager and ThemeHelper instances</li>
     *   <li>Initializes StorageAccessHelper</li>
     *   <li>Creates MusicLibrary instance</li>
     *   <li>Initializes UI views and sets up listeners</li>
     *   <li>Registers broadcast receivers for service communication</li>
     *   <li>Sets up theme change receiver</li>
     *   <li>Registers restart receiver for app updates</li>
     *   <li>Sets up media button receiver for headset controls</li>
     *   <li>Checks permissions and initializes further</li>
     *   <li>Starts StorageObserver for external storage monitoring</li>
     *   <li>Applies theme colors to UI elements</li>
     *   <li>Registers with NavigationController for button state</li>
     *   <li>Sets up PlaybackController listener</li>
     * </ol>
     *
     * @param savedInstanceState Saved instance state bundle, or null if new instance
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new android.util.LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };

        mAlbumArtExecutor = Executors.newSingleThreadExecutor();

        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        checkPermissionsAndInitialize();
        
        mStorageObserver = new StorageObserver(this);
        mStorageObserver.startObserving();
        
        applyThemeToUI();
        
        NavigationController.getInstance().registerListener(this);
        
        mPlaybackController = PlaybackController.getInstance();
        setupPlaybackControllerListener();
    }
    
    /**
     * Called when the activity becomes visible to the user.
     * 
     * <p>This method ensures the theme receiver is registered and
     * re-registers it if it was unregistered during onStop.</p>
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
    }
    
    /**
     * Called when the activity is no longer visible to the user.
     * 
     * <p>This method unregisters the theme receiver to prevent
     * memory leaks and unnecessary broadcasts.</p>
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mThemeReceiver != null) {
            try {
                unregisterReceiver(mThemeReceiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
            mThemeReceiver = null;
        }
    }
    
    /**
     * Called when the activity resumes and comes to the foreground.
     * 
     * <p>This method:</p>
     * <ul>
     *   <li>Reattaches ToastManager to current activity for persistent toasts</li>
     *   <li>Sets current activity reference in StorageObserver</li>
     *   <li>Updates button states based on NavigationController</li>
     *   <li>Refreshes repeat and shuffle button states</li>
     *   <li>Updates play/pause button state</li>
     *   <li>Refreshes current song display and album art</li>
     *   <li>Hides loading overlay if songs are loaded</li>
     *   <li>Applies theme colors</li>
     *   <li>Refreshes ToastManager theme color</li>
     * </ul>
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mStorageObserver != null) {
            mStorageObserver.setActivity(this);
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            updatePlayPauseButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                updateAlbumArt(currentSong.getPath());
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     * 
     * <p>This method reattaches ToastManager for persistent toasts
     * that should survive activity restarts.</p>
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called before the activity is destroyed.
     * 
     * <p>This method performs comprehensive cleanup:</p>
     * <ul>
     *   <li>Stops time handler and removes callbacks</li>
     *   <li>Unregisters from NavigationController</li>
     *   <li>Saves player state to MusicService</li>
     *   <li>Refreshes notification before service stops</li>
     *   <li>Stops StorageObserver to prevent memory leaks</li>
     *   <li>Unbinds from MusicService</li>
     *   <li>Unregisters all broadcast receivers</li>
     *   <li>Clears Handler callbacks and messages</li>
     *   <li>Unregisters media button receiver</li>
     *   <li>Cleans up placeholder bitmaps</li>
     *   <li>Hides persistent toasts and loading overlay</li>
     *   <li>Shuts down executor services</li>
     * </ul>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
            mTimeHandler = null;
        }
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mStorageObserver != null) {
            mStorageObserver.stopObserving();
        }
        
        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore - service may already be unbound
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        unregisterReceiverSafely(mPlayerReadyReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        unregisterMediaButtonReceiver();
        cleanupPlaceholderBitmaps();
        
        ToastManager.hidePersistentOverlay();
        hideLoadingOverlay();
        
        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdown();
        }
        
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    /**
     * Called when the system requests memory trimming.
     * 
     * <p>Forwards the memory trim event to MusicService to allow
     * it to release caches and reduce memory footprint.</p>
     *
     * @param level The memory trim level (e.g., TRIM_MEMORY_RUNNING_MODERATE)
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     * 
     * <p>Handles file opening intents (ACTION_VIEW) and close_app commands.
     * When a file is opened from another app, it is imported as a loose song
     * and played immediately.</p>
     *
     * @param intent The new intent that was delivered
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     * 
     * <p>Sets the immersive sticky mode when the window has focus,
     * ensuring full-screen experience with system UI hidden.</p>
     *
     * @param hasFocus True if the window has focus, false otherwise
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    /**
     * Called when a key is pressed down.
     * 
     * <p>Consumes media button events to prevent default handling
     * and allows custom processing in onKeyUp.</p>
     *
     * @param keyCode The key code of the pressed key
     * @param event The KeyEvent object
     * @return True if the event was handled, false otherwise
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) {
            return super.onKeyDown(keyCode, event);
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /**
     * Called when a key is released.
     * 
     * <p>Processes media button events to control playback:</p>
     * <ul>
     *   <li>KEYCODE_MEDIA_PLAY_PAUSE: Toggle play/pause</li>
     *   <li>KEYCODE_MEDIA_PLAY: Resume or start playback</li>
     *   <li>KEYCODE_MEDIA_PAUSE: Pause playback</li>
     *   <li>KEYCODE_MEDIA_NEXT: Play next song</li>
     *   <li>KEYCODE_MEDIA_PREVIOUS: Play previous song</li>
     * </ul>
     *
     * @param keyCode The key code of the released key
     * @param event The KeyEvent object
     * @return True if the event was handled, false otherwise
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mMusicService != null && !mMusicService.isAnyPlayerPlaying()) {
                    if (mMusicService.isAnyPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
    /**
     * Called when an activity launched with startActivityForResult completes.
     * 
     * <p>Handles results from:</p>
     * <ul>
     *   <li>Battery optimization request - logs user preference</li>
     *   <li>Folder selection - imports folder and adds to music library</li>
     * </ul>
     *
     * @param requestCode The request code from startActivityForResult
     * @param resultCode The result code (RESULT_OK or RESULT_CANCELED)
     * @param data The intent containing result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Called when permission request results are available.
     * 
     * <p>Processes permission results:</p>
     * <ul>
     *   <li>If all permissions granted, proceeds with initialization</li>
     *   <li>Requests battery optimization exemption on Android M+</li>
     *   <li>If permissions denied, shows error message and stops</li>
     * </ul>
     *
     * @param requestCode The request code from requestPermissions
     * @param permissions The array of requested permissions
     * @param grantResults The array of grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                hideLoadingOverlay();
            }
        }
    }
    
    // =========================================================================
    // PlaybackController Setup
    // =========================================================================
    
    /**
     * Sets up the PlaybackController listener for state change callbacks.
     * 
     * <p>This method configures a listener that receives:</p>
     * <ul>
     *   <li>Position updates for seek bar and time display</li>
     *   <li>Play state changes for play/pause button icon</li>
     *   <li>Song changes for updating title, artist, and album art</li>
     *   <li>Prepared state changes for enabling controls</li>
     *   <li>Operation failures for user feedback</li>
     * </ul>
     * 
     * <p>The listener is set on the PlaybackController singleton, ensuring
     * the UI stays synchronized with the single source of truth.</p>
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        
        if (mPlaybackControllerListener != null) {
            mPlaybackController.setListener(null);
        }
        
        mPlaybackControllerListener = new PlaybackController.PlaybackControllerListener() {
            @Override
            public void onPositionChanged(long positionMs, long durationMs) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    if (!mIsUserSeeking && mSeekBar != null && mSeekBar.isEnabled()) {
                        if (mSeekBar.getMax() != (int) durationMs && durationMs > 0) {
                            mSeekBar.setMax((int) durationMs);
                        }
                        mSeekBar.setProgress((int) positionMs);
                    }
                    if (mSeekTime != null && !mIsUserSeeking) {
                        mSeekTime.setText(formatTime((int) positionMs));
                    }
                    if (mTotalTime != null && durationMs > 0) {
                        mTotalTime.setText(formatTime((int) durationMs));
                    }
                });
            }
            
            @Override
            public void onPlayStateChanged(boolean isPlaying) {
                if (mControlsTransitioning.get()) return;
                
                runOnUiThread(() -> { 
                    if (!isFinishing() && !isDestroyed()) {
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                            Log.d(TAG, "Play state changed via controller: " + (isPlaying ? "PLAYING" : "PAUSED"));
                        }
                    }
                });
            }
            
            @Override
            public void onSongChanged(String title, String artist, String path, long duration) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    if (mSongTitle != null) {
                        String t = title != null ? title : "Unknown Title";
                        if (t.length() > MAX_TITLE_LENGTH) {
                            t = t.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                        }
                        mSongTitle.setText(t);
                        if (mThemeHelper != null) {
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                    }
                    
                    if (mSongArtist != null) {
                        String a = artist != null ? artist : "Unknown Artist";
                        if (a.length() > MAX_ARTIST_LENGTH) {
                            a = a.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                        }
                        mSongArtist.setText(a);
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                    }
                    
                    if (mSeekBar != null && duration > 0) {
                        mSeekBar.setMax((int) duration);
                        mSeekBar.setProgress(0);
                        mSeekBar.setEnabled(true);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                    }
                    
                    if (mTotalTime != null && duration > 0) {
                        mTotalTime.setText(formatTime((int) duration));
                    }
                    if (mSeekTime != null) {
                        mSeekTime.setText("00:00");
                    }
                    
                    updateAlbumArt(path);
                });
            }
            
            @Override
            public void onPreparedStateChanged(boolean isPrepared) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        if (isPrepared && mPlaybackController != null) {
                            long duration = mPlaybackController.getDuration();
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime((int) duration));
                            }
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax((int) duration);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                            }
                            Log.d(TAG, "Player prepared - duration: " + duration + "ms");
                        }
                    }
                });
            }
            
            @Override
            public void onOperationFailed(String operation, String reason) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        String message = "Cannot " + operation;
                        if (reason != null && !reason.isEmpty()) {
                            message += ": " + reason;
                        }
                        ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                        Log.w(TAG, "Operation failed: " + operation + " - " + reason);
                    }
                });
            }
        };
        
        mPlaybackController.setListener(mPlaybackControllerListener);
        Log.d(TAG, "PlaybackController listener configured with failure callback");
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes.
     * 
     * <p>This method is part of the NavigationController.ButtonStateListener
     * interface. It updates playlist and metadata buttons based on whether
     * database actions are disabled (e.g., during sync operations).</p>
     *
     * @param group The button group that changed
     * @param disabled True if buttons in this group should be disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mPlaylistButton != null) {
                        mPlaylistButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                        }
                    }
                    
                    if (mMetadataButton != null) {
                        mMetadataButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * 
     * <p>This method:</p>
     * <ul>
     *   <li>Requests no title bar (FEATURE_NO_TITLE)</li>
     *   <li>Sets status and navigation bar colors on API 21+</li>
     *   <li>Configures immersive sticky mode on API 19+</li>
     *   <li>Clears FLAG_FULLSCREEN to use system UI visibility flags instead</li>
     * </ul>
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI views and sets up visual properties.
     * 
     * <p>This method:</p>
     * <ul>
     *   <li>Finds all views by ID using findViewById</li>
     *   <li>Applies album art clipping for rounded corners</li>
     *   <li>Sets FontAwesome typeface and text for control buttons</li>
     *   <li>Applies background drawables to all buttons</li>
     *   <li>Configures letter spacing for action buttons</li>
     *   <li>Sets up button touch animations for visual feedback</li>
     *   <li>Loads and displays placeholder album art</li>
     *   <li>Initializes repeat and shuffle button states</li>
     *   <li>Updates control buttons enabled state</li>
     *   <li>Sets play button to enabled from the start for responsiveness</li>
     * </ul>
     */
    private void initializeViews() {
        mSongTitle = (TextView) findViewById(R.id.songTitle);
        mSongArtist = (TextView) findViewById(R.id.songArtist);
        mSeekTime = (TextView) findViewById(R.id.seekTime);
        mTotalTime = (TextView) findViewById(R.id.totalTime);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mPlayButton = (Button) findViewById(R.id.playButton);
        mPrevButton = (Button) findViewById(R.id.prevButton);
        mNextButton = (Button) findViewById(R.id.nextButton);
        mRepeatButton = (Button) findViewById(R.id.repeatButton);
        mShuffleButton = (Button) findViewById(R.id.shuffleButton);
        mManagerButton = (Button) findViewById(R.id.managerButton);
        mLlamaButton = (Button) findViewById(R.id.llamaButton);
        mPlaylistButton = (Button) findViewById(R.id.playlistButton);
        mEqualizerButton = (Button) findViewById(R.id.equalizerButton);
        mMetadataButton = (Button) findViewById(R.id.metadataButton);
        mAlbumArtView = (ImageView) findViewById(R.id.albumArtView);

        applyAlbumArtClipping();

        final Typeface faTypeface = FontAwesome.getTypeface();
        
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setTextSize(36);
            // Enable play button from the start for responsiveness
            // The button will be disabled only if no songs exist after loading
            mPlayButton.setEnabled(true);
        }
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setTextSize(32);
        }
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setTextSize(32);
        }
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setTextSize(28);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setTextSize(28);
        }

        if (mPlayButton != null) mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mPrevButton != null) mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mNextButton != null) mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mRepeatButton != null) mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mShuffleButton != null) mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        if (mManagerButton != null) mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mLlamaButton != null) mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mPlaylistButton != null) mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mEqualizerButton != null) mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
        if (mMetadataButton != null) mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);

        if (mManagerButton != null) mManagerButton.setLetterSpacing(0.1f);
        if (mLlamaButton != null) mLlamaButton.setLetterSpacing(0.1f);
        if (mPlaylistButton != null) mPlaylistButton.setLetterSpacing(0.1f);
        if (mEqualizerButton != null) mEqualizerButton.setLetterSpacing(0.1f);
        if (mMetadataButton != null) mMetadataButton.setLetterSpacing(0.1f);

        animateButton(mPlayButton);
        animateButton(mPrevButton);
        animateButton(mNextButton);
        animateButton(mRepeatButton);
        animateButton(mShuffleButton);
        animateButton(mManagerButton);
        animateButton(mLlamaButton);
        animateButton(mPlaylistButton);
        animateButton(mEqualizerButton);
        animateButton(mMetadataButton);

        loadAndDisplayPlaceholder();
        updateRepeatButton();
        updateShuffleButton();
        updateControlButtonsState();
    }

    /**
     * Adds touch animation to a button for visual feedback.
     * 
     * <p>When the button is pressed, it scales down to 97% of its size.
     * When released, it scales back to 100% with a smooth animation.</p>
     *
     * @param button The button to animate, or null to skip
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) return;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(BUTTON_SCALE_DOWN).scaleY(BUTTON_SCALE_DOWN).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(BUTTON_SCALE_NORMAL).scaleY(BUTTON_SCALE_NORMAL).setDuration(BUTTON_ANIMATION_DURATION_MS).start();
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests necessary runtime permissions.
     * 
     * <p>This method requests different permissions based on Android version:</p>
     * <ul>
     *   <li>Android 13+ (API 33): READ_MEDIA_AUDIO and POST_NOTIFICATIONS</li>
     *   <li>Android 12+ (API 31): Also requests BLUETOOTH_CONNECT</li>
     *   <li>Older versions: READ_EXTERNAL_STORAGE</li>
     * </ul>
     * 
     * <p>If all permissions are already granted, proceeds with initialization
     * and requests battery optimization exemption.</p>
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<String>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     * 
     * <p>For first run, shows a loading message, starts the MusicService,
     * and binds to it. For subsequent runs, loads the last played song's
     * metadata and restores playback state.</p>
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks and requests battery optimization exemption for background playback.
     * 
     * <p>This is required for reliable background playback on Android 6.0+.
     * The request is only shown once to avoid bothering the user repeatedly.</p>
     *
     * @requires ApiLevel = 23 (Android M)
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers a media button event receiver for headset controls.
     * 
     * <p>This allows the app to receive media button events (play/pause,
     * next, previous) from wired headsets and Bluetooth devices.</p>
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters the media button event receiver.
     * 
     * <p>This should be called in onDestroy to prevent the app from
     * receiving media button events when it's not active.</p>
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles incoming files from other apps via ACTION_VIEW intent.
     * 
     * <p>When a user opens an audio file from a file manager or another app,
     * this method:</p>
     * <ol>
     *   <li>Extracts the file path from the URI</li>
     *   <li>Creates or retrieves Song metadata</li>
     *   <li>Adds the song as a "loose song" in the database</li>
     *   <li>Updates the music library</li>
     *   <li>Starts playback of the imported file</li>
     *   <li>Broadcasts updates to playlist views</li>
     * </ol>
     *
     * @param intent The intent containing the file URI
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<Song>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<Song>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).commit();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming file using the already-bound MusicService.
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath The file path of the song to play
     * @param newSong The Song object for the incoming file
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    enableAllControls();
                    updateUIForSong(newSong);
                }
            });
            
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                }
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to MusicService and plays an incoming file.
     * 
     * <p>Used when the service is not yet bound. Creates a one-time
     * ServiceConnection that plays the file once connected.</p>
     *
     * @param finalSongs The complete playlist including the new song
     * @param filePath The file path of the song to play
     * @param newSong The Song object for the incoming file
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            enableAllControls();
                            updateUIForSong(newSong);
                            applyAlbumArtClipping();
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     * 
     * <p>Handles both file:// and content:// URIs. For content URIs,
     * queries MediaStore.DATA column or copies to temp file if needed.</p>
     *
     * @param uri The URI to convert
     * @return The file system path, or null if conversion fails
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file.
     * 
     * <p>Used when the MediaStore doesn't have a file path for the URI,
     * such as when opening files from Google Drive or other cloud storage.</p>
     *
     * @param uri The content URI to copy
     * @return The path to the temporary file, or null if copying fails
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that are inside an imported folder.
     * 
     * <p>When a user imports a folder, any loose songs that are actually
     * inside that folder are removed from the loose songs list to avoid
     * duplication.</p>
     *
     * @param folderUri The URI of the imported folder
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist in the background asynchronously.
     * 
     * <p>Uses MusicLibrary.loadAllSongsAsync to load all songs without
     * blocking the UI thread. Once loaded, the playlist is set on MusicService
     * and the UI is updated.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                                mSongTitle.setText(current.getTitle());
                                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                mSongArtist.setText(current.getArtist());
                                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                updateAlbumArt(current.getPath());
                            }
                            
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    });
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG);
                    }
                });
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Safely updates UI with thread-safe queuing.
     * 
     * <p>This method prevents overlapping UI updates by queueing pending
     * updates if an update is already in progress.</p>
     *
     * @param update The UI update runnable to execute
     */
    private void safeUpdateUI(@NonNull final Runnable update) {
        if (isFinishing() || isDestroyed()) return;
        
        if (mIsUpdatingUI.get()) {
            mPendingUIUpdate = update;
            return;
        }
        
        mIsUpdatingUI.set(true);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isFinishing() && !isDestroyed()) {
                        update.run();
                    }
                } finally {
                    mIsUpdatingUI.set(false);
                    if (mPendingUIUpdate != null) {
                        final Runnable pending = mPendingUIUpdate;
                        mPendingUIUpdate = null;
                        safeUpdateUI(pending);
                    }
                }
            }
        });
    }
    
    /**
     * Updates the UI to display information for a given song.
     * 
     * <p>Updates title, artist, total time, and play/pause button state.
     * Does NOT update album art or playback position.</p>
     *
     * @param song The song to display, or null to clear
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Updates the UI for a song that is currently playing.
     * 
     * <p>Similar to updateUIForSong but also updates album art.</p>
     *
     * @param song The currently playing song
     */
    private void updateUIForPlayingSong(@Nullable Song song) {
        if (song == null) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForPlayingSong");
        }
        
        final Song finalSong = song;
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

                String displayText = finalSong.getTitle();
                if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                    displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                }
                if (mSongTitle != null) {
                    mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                }
                
                if (mSongArtist != null) {
                    String artistText = finalSong.getArtist();
                    if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                        artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                    }
                    mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                if (mTotalTime != null && finalSong.getDuration() > 0) {
                    mTotalTime.setText(formatTime((int) finalSong.getDuration()));
                }
                
                updateAlbumArt(finalSong.getPath());
                updatePlayPauseButton();
                hideLoadingOverlay();
                applyAlbumArtClipping();
            }
        });
    }
    
    /**
     * Enables or disables all playback controls based on song availability.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        safeUpdateUI(new Runnable() {
            @Override
            public void run() {
                if (mPlayButton != null && mThemeHelper != null) {
                    mPlayButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPlayButton, hasSongs, true);
                }
                if (mPrevButton != null && mThemeHelper != null) {
                    mPrevButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
                }
                if (mNextButton != null && mThemeHelper != null) {
                    mNextButton.setEnabled(hasSongs);
                    mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
                }
                if (mRepeatButton != null) {
                    mRepeatButton.setEnabled(hasSongs);
                    updateRepeatButton();
                }
                if (mShuffleButton != null) {
                    mShuffleButton.setEnabled(hasSongs);
                    updateShuffleButton();
                }
                if (mSeekBar != null && mThemeHelper != null) {
                    mSeekBar.setEnabled(hasSongs);
                    mThemeHelper.updateSeekBar(mSeekBar, hasSongs);
                }
            }
        });
    }
    
    /**
     * Updates the enabled state of prev, next, repeat, and shuffle buttons.
     */
    private void updateControlButtonsState() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mPrevButton, hasSongs, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(hasSongs);
            mThemeHelper.updateControlButton(mNextButton, hasSongs, false);
        }
        if (mRepeatButton != null) {
            mRepeatButton.setEnabled(hasSongs);
            updateRepeatButton();
        }
        if (mShuffleButton != null) {
            mShuffleButton.setEnabled(hasSongs);
            updateShuffleButton();
        }
    }
    
    /**
     * Applies the "no song" state to all UI components.
     * 
     * <p>Shows placeholder text and disables all controls when
     * no songs are available in the library.</p>
     */
    private void applyNoSongState() {
        int totalSongs = (mMusicLibrary != null ? mMusicLibrary.getSongCount() : 0);
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        int looseCount = (looseSongs != null ? looseSongs.size() : 0);
        if (totalSongs + looseCount > 0) return;
        
        if (mIsSyncInProgress) return;
        
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mAlbumArtView != null) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
            } else {
                loadAndDisplayPlaceholder();
            }
            if (mAlbumArtCache != null) {
                mAlbumArtCache.evictAll();
            }
            mCurrentAlbumArtPath = null;
        }
        
        applyAlbumArtClipping();

        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            // Disable play button when there are no songs
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on MusicService with synchronization.
     *
     * @param action The action to execute
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     *
     * @param index The playlist index of the song to play
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0 && 
            index >= 0 && index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method queries PlaybackController for the current state
     * and calls the appropriate MusicService method. If the player is
     * not prepared, it starts playback from the current or first song.</p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        boolean isCurrentlyPlaying = false;
        if (mPlaybackController != null) {
            isCurrentlyPlaying = mPlaybackController.isPlaying();
        } else if (mMusicService != null) {
            isCurrentlyPlaying = mMusicService.isAnyPlayerPlaying();
        }
        
        boolean isPrepared = false;
        if (mPlaybackController != null) {
            isPrepared = mPlaybackController.isPrepared();
        } else if (mMusicService != null) {
            isPrepared = mMusicService.isAnyPlayerPrepared();
        }
        
        if (isCurrentlyPlaying) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
        } else if (isPrepared) {
            Log.d(TAG, "togglePlayPause: Resuming playback");
            mMusicService.resume();
        } else {
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     * Uses a transition lock to prevent rapid successive calls.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playNext();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * Uses a transition lock to prevent rapid successive calls.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playPrevious();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button icon based on current repeat mode.
     * 
     * <p>Repeat modes:</p>
     * <ul>
     *   <li>0 = Off (no repeat) - shows standard repeat icon, not active</li>
     *   <li>1 = All (repeat playlist) - shows standard repeat icon, active</li>
     *   <li>2 = One (repeat single song) - shows repeat-one icon, active</li>
     * </ul>
     */
    private void updateRepeatButton() {
        if (mRepeatButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mRepeatButton.setText(FontAwesome.REPEAT);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isActive = (repeatMode != 0);
        
        if (repeatMode == 2) {
            mRepeatButton.setText(FontAwesome.REPEAT_ONE);
        } else {
            mRepeatButton.setText(FontAwesome.REPEAT);
        }
        
        mThemeHelper.updateControlButton(mRepeatButton, true, isActive);
    }
    
    /**
     * Updates the shuffle button icon based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mShuffleButton == null || mThemeHelper == null) return;
        
        if (mMusicService == null) {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        
        mShuffleButton.setText(FontAwesome.SHUFFLE);
        mThemeHelper.updateControlButton(mShuffleButton, true, isShuffleOn);
    }
    
    /**
     * Updates the play/pause button text and enabled state.
     */
    private void updatePlayPauseButton() {
        if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (!hasSongs) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
            return;
        }
        
        boolean isPlaying = false;
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
        } else if (mMusicService != null) {
            isPlaying = mMusicService.isAnyPlayerPlaying();
        }
        
        mPlayButton.setEnabled(true);
        mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
        mThemeHelper.updateControlButton(mPlayButton, true, true);
    }
    
    // ========================================================================
    // SeekBar Methods
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position tracking and seeking.
     * 
     * <p>The seek bar behavior:</p>
     * <ul>
     *   <li>During dragging, only the time display updates (not the player position)</li>
     *   <li>When dragging stops, seeks to the selected position</li>
     *   <li>A timeout resets the seeking flag to prevent stuck states</li>
     * </ul>
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mSeekTime != null) mSeekTime.setText(formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                if (mPlaybackController != null) mPlaybackController.onSeekStart();
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int seekPos = seekBar.getProgress();
                if (mMusicService != null && seekBar.isEnabled()) {
                    mMusicService.seekTo(seekPos);
                    if (mSeekTime != null) mSeekTime.setText(formatTime(seekPos));
                }
                mSeekTargetPosition = -1;
                
                mSeekHandler.removeCallbacksAndMessages(null);
                
                mSeekHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mIsUserSeeking = false;
                        if (mPlaybackController != null) {
                            mPlaybackController.forceResetSeeking();
                        }
                        if (mMusicService != null) {
                            int currentPos = mMusicService.getCurrentPosition();
                            int duration = mMusicService.getDuration();
                            if (mSeekBar != null) {
                                if (duration > 0 && mSeekBar.getMax() != duration) {
                                    mSeekBar.setMax(duration);
                                }
                                mSeekBar.setProgress(currentPos);
                            }
                            if (mSeekTime != null) {
                                mSeekTime.setText(formatTime(currentPos));
                            }
                        }
                        Log.d(TAG, "Seek flag reset - UI updates resumed");
                    }
                }, SEEK_RESET_DELAY_MS);
            }
        });
    }
    
    // ========================================================================
    // Time Display Methods
    // ========================================================================
    
    /**
     * Starts a polling loop to update time displays and seek bar position.
     * 
     * <p>The polling runs every TIME_UPDATE_INTERVAL_MS (200ms) and updates
     * the seek bar position and time text when the user is not seeking.</p>
     */
    private void updateTimeDisplay() {
        if (mTimeHandler == null) {
            mTimeHandler = new Handler(Looper.getMainLooper());
        }
        
        mTimeHandler.removeCallbacksAndMessages(null);
        
        mTimeHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                
                if (!mIsUserSeeking && mMusicService != null) {
                    int position = mMusicService.getCurrentPosition();
                    int duration = mMusicService.getDuration();
                    
                    if (mSeekBar != null && duration > 0) {
                        if (mSeekBar.getMax() != duration) {
                            mSeekBar.setMax(duration);
                        }
                        mSeekBar.setProgress(position);
                    }
                    if (mSeekTime != null) {
                        mSeekTime.setText(formatTime(position));
                    }
                    if (mTotalTime != null && duration > 0) {
                        mTotalTime.setText(formatTime(duration));
                    }
                }
                
                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        });
        
        Log.d(TAG, "Time display polling started (" + TIME_UPDATE_INTERVAL_MS + "ms interval)");
    }
    
    /**
     * Formats milliseconds into a time string (MM:SS or HH:MM:SS).
     *
     * @param milliseconds The time in milliseconds
     * @return Formatted time string
     */
    @NonNull
    private String formatTime(int milliseconds) {
        final int totalSeconds = milliseconds / 1000;
        final int hours = totalSeconds / 3600;
        final int minutes = (totalSeconds % 3600) / 60;
        final int seconds = totalSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    // ========================================================================
    // Album Art Methods
    // ========================================================================
    
    /**
     * Calculates the sample size for efficient bitmap decoding.
     *
     * @param options The BitmapFactory.Options with out dimensions
     * @param reqWidth The requested width
     * @param reqHeight The requested height
     * @return The sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    /**
     * Decodes a byte array into a sampled bitmap to save memory.
     *
     * @param data The byte array containing image data
     * @param reqWidth The requested width
     * @param reqHeight The requested height
     * @return The sampled bitmap, or null if decoding fails
     */
    @Nullable
    private Bitmap decodeSampledBitmap(@NonNull byte[] data, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, options);
        
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    
    /**
     * Updates the album art display for the given song file.
     * 
     * <p>This method uses a caching strategy:</p>
     * <ol>
     *   <li>Check if the bitmap is already in the LRU cache</li>
     *   <li>If not, submit a background task to extract embedded album art</li>
     *   <li>Decode the album art with sampling to reduce memory usage</li>
     *   <li>Store in cache and display with fade animation</li>
     *   <li>Fall back to placeholder if no album art is available</li>
     * </ol>
     *
     * @param filePath The file path of the song
     */
    private void updateAlbumArt(@Nullable final String filePath) {
        if (mIsSyncInProgress && filePath != null && filePath.equals(mCurrentAlbumArtPath)) {
            return;
        }
        
        if (filePath == null) {
            if (mCurrentAlbumArtPath != null) {
                mCurrentAlbumArtPath = null;
                loadAndDisplayPlaceholder();
            }
            updateNotificationAlbumArt();
            return;
        }
        
        if (filePath.equals(mCurrentAlbumArtPath)) return;
        
        mCurrentAlbumArtPath = filePath;
        if (mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(filePath);
            if (cached != null && !cached.isRecycled()) {
                applyAlbumArtWithFade(cached);
                return;
            }
        }
        
        if (mCurrentAlbumArtTask != null && !mCurrentAlbumArtTask.isDone()) {
            mCurrentAlbumArtTask.cancel(true);
        }
        
        mCurrentLoadingArtPath = filePath;
        final String taskPath = filePath;
        
        mCurrentAlbumArtTask = mAlbumArtExecutor.submit(new Runnable() {
            @Override
            public void run() {
                if (Thread.currentThread().isInterrupted()) return;
                
                MediaMetadataRetriever retriever = null;
                Bitmap result = null;
                try {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(taskPath);
                    final byte[] artBytes = retriever.getEmbeddedPicture();
                    if (artBytes != null && !Thread.currentThread().isInterrupted()) {
                        result = decodeSampledBitmap(artBytes, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to extract album art for: " + taskPath, e);
                } finally {
                    if (retriever != null) {
                        try { retriever.release(); } catch (Exception ignored) {}
                    }
                }
                
                final Bitmap bitmap = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        if (!Thread.currentThread().isInterrupted() && 
                            taskPath.equals(mCurrentLoadingArtPath) && 
                            taskPath.equals(mCurrentAlbumArtPath)) {
                            if (bitmap != null && mAlbumArtCache != null) {
                                mAlbumArtCache.put(taskPath, bitmap);
                                applyAlbumArtWithFade(bitmap);
                            } else {
                                loadAndDisplayPlaceholder();
                            }
                            applyAlbumArtClipping();
                        }
                        if (mCurrentAlbumArtTask == Thread.currentThread()) {
                            mCurrentAlbumArtTask = null;
                            mCurrentLoadingArtPath = null;
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Applies album art with a fade-in animation.
     *
     * @param bitmap The album art bitmap to display
     */
    private void applyAlbumArtWithFade(@Nullable Bitmap bitmap) {
        if (!isBitmapValid(bitmap)) {
            loadAndDisplayPlaceholder();
            applyAlbumArtClipping();
            updateNotificationAlbumArt();
            return;
        }
        
        if (isFinishing() || isDestroyed() || mAlbumArtView == null) return;
        
        mAlbumArtView.setImageBitmap(bitmap);
        mAlbumArtView.setAlpha(0f);
        
        android.view.ViewPropertyAnimator animator = mAlbumArtView.animate();
        if (animator != null) {
            animator.alpha(1f).setDuration(ALBUM_ART_FADE_DURATION_MS).setListener(null);
        }
        
        applyAlbumArtClipping();
        updateNotificationAlbumArt();
    }
    
    /**
     * Loads and displays the placeholder album art image.
     */
    private void loadAndDisplayPlaceholder() {
        updatePlaceholderBitmap();
    }
    
    /**
     * Updates the album art in the notification.
     */
    private void updateNotificationAlbumArt() {
        if (mMusicService == null) return;
        
        Bitmap art = null;
        Bitmap placeholder = null;
        
        synchronized (mPlaceholderLock) {
            if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                placeholder = mPlaceholderBitmap;
            }
        }
        
        final String currentPath = getCurrentSongPath();
        if (currentPath != null && mAlbumArtCache != null) {
            final Bitmap cached = mAlbumArtCache.get(currentPath);
            if (cached != null && !cached.isRecycled()) {
                art = cached;
            }
        }
        
        mMusicService.setNotificationAlbumArt(art, placeholder, currentPath);
    }
    
    /**
     * Gets the file path of the currently playing song.
     *
     * @return The file path, or null if no song is playing
     */
    @Nullable
    private String getCurrentSongPath() {
        if (mMusicService != null && mMusicService.getCurrentSong() != null) {
            return mMusicService.getCurrentSong().getPath();
        }
        return null;
    }
    
    /**
     * Checks if a bitmap is valid for display.
     *
     * @param bitmap The bitmap to check
     * @return True if the bitmap is non-null, not recycled, and has positive dimensions
     */
    private boolean isBitmapValid(@Nullable Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled() && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
    }
    
    // ========================================================================
    // Placeholder Methods
    // ========================================================================
    
    /**
     * Updates the placeholder bitmap with the current theme color.
     * 
     * <p>This method runs on a background thread to tint the placeholder
     * drawable with the current theme color.</p>
     */
    private void updatePlaceholderBitmap() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
            }
        }
        
        final int themeColor = mThemeHelper.getThemeColorInt();
        
        final Future<?> task = mPlaceholderExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap tinted = null;
                    synchronized (mPlaceholderLock) {
                        if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                            tinted = mOriginalPlaceholderBitmap.copy(Bitmap.Config.ARGB_8888, true);
                        }
                    }
                    
                    if (tinted == null) {
                        final BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap loaded = BitmapFactory.decodeResource(getResources(), R.drawable.album_art_placeholder, opts);
                        if (loaded != null) {
                            tinted = loaded.copy(Bitmap.Config.ARGB_8888, true);
                            loaded.recycle();
                            synchronized (mPlaceholderLock) {
                                if (mOriginalPlaceholderBitmap != null && !mOriginalPlaceholderBitmap.isRecycled()) {
                                    mOriginalPlaceholderBitmap.recycle();
                                }
                                mOriginalPlaceholderBitmap = tinted.copy(Bitmap.Config.ARGB_8888, true);
                            }
                        }
                    }
                    
                    if (tinted == null) return;
                    
                    final Canvas canvas = new Canvas(tinted);
                    final Paint paint = new Paint();
                    paint.setColorFilter(new PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN));
                    canvas.drawBitmap(tinted, 0, 0, paint);
                    
                    final Bitmap finalTinted = tinted;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            synchronized (mPlaceholderLock) {
                                if (mPlaceholderBitmap != null && !mPlaceholderBitmap.isRecycled()) {
                                    mPlaceholderBitmap.recycle();
                                }
                                mPlaceholderBitmap = finalTinted;
                            }
                            final String currentPath = getCurrentSongPath();
                            if (currentPath == null || (mAlbumArtCache != null && mAlbumArtCache.get(currentPath) == null)) {
                                if (mAlbumArtView != null) {
                                    mAlbumArtView.setImageBitmap(mPlaceholderBitmap);
                                    applyAlbumArtClipping();
                                    updateNotificationAlbumArt();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "updatePlaceholderBitmap error", e);
                }
            }
        });
        
        synchronized (mPlaceholderLock) {
            mCurrentPlaceholderTask = task;
        }
    }
    
    /**
     * Cleans up placeholder bitmaps to prevent memory leaks.
     */
    private void cleanupPlaceholderBitmaps() {
        synchronized (mPlaceholderLock) {
            if (mCurrentPlaceholderTask != null) {
                mCurrentPlaceholderTask.cancel(true);
                mCurrentPlaceholderTask = null;
            }
            
            safeRecycleBitmap(mPlaceholderBitmap);
            mPlaceholderBitmap = null;
            
            safeRecycleBitmap(mOriginalPlaceholderBitmap);
            mOriginalPlaceholderBitmap = null;
        }
    }
    
    /**
     * Safely recycles a bitmap if it exists and is not already recycled.
     *
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Error recycling bitmap", e);
            }
        }
    }
    
    // ========================================================================
    // Album Art Clipping Methods
    // ========================================================================
    
    /**
     * Applies rounded corners to the album art container.
     * 
     * <p>On Android 5.0+, uses ViewOutlineProvider for clipping.
     * On older versions, uses a background drawable with rounded corners.</p>
     */
    private void applyAlbumArtClipping() {
        final FrameLayout albumArtContainer = (FrameLayout) findViewById(R.id.albumArtContainer);
        if (albumArtContainer == null) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            albumArtContainer.setClipToOutline(true);
            albumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    final int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        } else {
            albumArtContainer.setBackgroundResource(R.drawable.album_art_container);
        }
    }
    
    // ========================================================================
    // Loading Overlay Methods
    // ========================================================================
    
    /**
     * Shows a dim overlay with a loading spinner.
     * 
     * <p>The overlay is added to the decor view's content and
     * prevents user interaction during long operations.</p>
     */
    private void showLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null) return;
                
                final ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView == null) return;

                final FrameLayout overlay = new FrameLayout(MusicPlayer.this);
                overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                overlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));

                final FrameLayout container = new FrameLayout(MusicPlayer.this);
                container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                mLoadingSpinner = new ProgressBar(MusicPlayer.this);
                mLoadingSpinner.setIndeterminate(true);

                final FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                        dpToPx(PROGRESS_BAR_SIZE_DP),
                        dpToPx(PROGRESS_BAR_SIZE_DP)
                );
                progressParams.gravity = Gravity.CENTER;
                mLoadingSpinner.setLayoutParams(progressParams);
                container.addView(mLoadingSpinner);
                overlay.addView(container);
                rootView.addView(overlay);
                mDimOverlay = overlay;
                
                if (mThemeHelper != null && mLoadingSpinner != null) {
                    mThemeHelper.updateProgressBar(mLoadingSpinner);
                }
            }
        });
    }
    
    /**
     * Hides the loading overlay if it is visible.
     */
    private void hideLoadingOverlay() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDimOverlay != null && mDimOverlay.getParent() != null) {
                    ((ViewGroup) mDimOverlay.getParent()).removeView(mDimOverlay);
                }
                mDimOverlay = null;
                mLoadingSpinner = null;
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the folder manager activity for importing music folders.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the playlist activity to view and manage playlists.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the metadata editor for editing song tags.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song from MusicService.
     *
     * @return The current Song, or null if no song is playing
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song's metadata from storage.
     * 
     * <p>This method is called on app startup to restore the last playback state.
     * It loads metadata asynchronously to avoid blocking the UI thread.</p>
     */
    private void loadLastSongMetadata() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    Song song = null;
                    try {
                        Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        
                        if (cachedSong != null && cachedSong.getTitle() != null && 
                            !cachedSong.getTitle().isEmpty() && 
                            !"Unknown Title".equals(cachedSong.getTitle())) {
                            song = cachedSong;
                        } else {
                            final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                            mmr.setDataSource(lastPath);
                            String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                            String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                            String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                            final byte[] art = mmr.getEmbeddedPicture();
                            mmr.release();
                            
                            if (title == null || title.isEmpty()) {
                                final File file = new File(lastPath);
                                String name = file.getName();
                                final int dot = name.lastIndexOf('.');
                                if (dot > 0) name = name.substring(0, dot);
                                title = name;
                            }
                            if (artist == null) artist = "Unknown Artist";
                            if (album == null) album = "Unknown Album";
                            
                            String genre = "Unknown Genre";
                            Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                            if (dbSong != null && dbSong.getGenre() != null && 
                                !"Unknown Genre".equals(dbSong.getGenre())) {
                                genre = dbSong.getGenre();
                                Log.d(TAG, "Found genre in database: " + genre);
                            } else {
                                String fileGenre = CharacterMapper.getGenre(lastPath);
                                if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                    genre = fileGenre;
                                    Log.d(TAG, "Read genre from file: " + genre);
                                }
                            }
                            
                            song = new Song(title, artist, album, genre, lastPath, 0, null);
                            if (art != null && mAlbumArtCache != null) {
                                final Bitmap bmp = decodeSampledBitmap(art, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
                                if (bmp != null) {
                                    mAlbumArtCache.put(lastPath, bmp);
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                    }
                    
                    final Song finalSong = song;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing() || isDestroyed()) return;
                            if (finalSong != null && mThemeHelper != null) {
                                mCachedLastSong = finalSong;
                                if (mSongTitle != null) {
                                    mSongTitle.setText(finalSong.getTitle());
                                    mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                }
                                if (mSongArtist != null) {
                                    mSongArtist.setText(finalSong.getArtist());
                                    mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                }
                                final Bitmap cachedArt = mAlbumArtCache != null ? mAlbumArtCache.get(lastPath) : null;
                                if (cachedArt != null) {
                                    applyAlbumArtWithFade(cachedArt);
                                } else {
                                    loadAndDisplayPlaceholder();
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                                updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                            }
                                        }
                                    }, FOCUS_SCROLL_DELAY_MS);
                                }
                                startServiceWithCachedSong();
                            } else {
                                applyNoSongState();
                                loadSongsAndStartService();
                            }
                        }
                    });
                }
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Starts the MusicService with the cached last song.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<Song>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs and starts the MusicService.
     */
    private void loadSongsAndStartService() {
        showLoadingOverlay();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingOverlay();
            }
        }, LOADING_OVERLAY_DELAY_MS);
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                        }
                        updateAlbumArt(current.getPath());
                    }
                    updatePlayPauseButton();
                    setupSeekBar();
                    updateTimeDisplay();
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                hideLoadingOverlay();
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                hideLoadingOverlay();
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers a receiver for app restart commands.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers a receiver for theme color change events.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies the current theme color to all UI elements.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            if (!mPlayButton.isEnabled() && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                mPlayButton.setEnabled(true);
            }
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mLoadingSpinner != null) {
            mThemeHelper.updateProgressBar(mLoadingSpinner);
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        updatePlaceholderBitmap();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs an app update by restarting the activity.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for service communication.
     */
    private void registerReceivers() {
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final boolean isPlaying = intent.getBooleanExtra("is_playing", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    safeUpdateUI(new Runnable() {
                        @Override
                        public void run() {
                            if (songCompleted && !isPlaying) {
                                if (mSeekBar != null) {
                                    mSeekBar.setProgress(0);
                                }
                                if (mSeekTime != null) {
                                    mSeekTime.setText("00:00");
                                }
                                Log.d(TAG, "Song completed - seekbar reset to 0");
                            } else if (songCompleted && completedPosition > 0) {
                                if (mSeekBar != null) {
                                    mSeekBar.setMax(completedPosition);
                                    mSeekBar.setProgress(completedPosition);
                                }
                                if (mSeekTime != null) {
                                    mSeekTime.setText(formatTime(completedPosition));
                                }
                                if (mTotalTime != null) {
                                    mTotalTime.setText(formatTime(completedPosition));
                                }
                                Log.d(TAG, "Song completed - seekbar filled to 100%");
                            }
                            
                            updatePlayPauseButton();
                            
                            if (mMusicService != null) {
                                if (mSeekBar != null && mSeekBar.isEnabled() && !mIsUserSeeking) {
                                    final int duration = mMusicService.getDuration();
                                    final int position = mMusicService.getCurrentPosition();
                                    mSeekBar.setMax(duration);
                                    mSeekBar.setProgress(position);
                                }
                                
                                final Song song = mMusicService.getCurrentSong();
                                if (song != null) {
                                    if (mMusicService.isAnyPlayerPlaying()) {
                                        updateUIForPlayingSong(song);
                                    } else {
                                        updateUIForSong(song);
                                    }
                                }
                            }
                            setupSeekBar();
                        }
                    });
                }
            }
        };
        
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                        updatePlayPauseButton();
                    }
                }
            }
        };
        
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                    updatePlayPauseButton();
                }
            }
        };
        
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<Song>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            applyNoSongState();
                            
                            if (!preserveSettings && mMusicService != null) {
                                mMusicService.setRepeatMode(0);
                                mMusicService.setShuffle(false);
                            }
                            
                            if (mShuffleButton != null && mThemeHelper != null) {
                                mShuffleButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mShuffleButton, false, false);
                            }
                            if (mRepeatButton != null && mThemeHelper != null) {
                                mRepeatButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mRepeatButton, false, false);
                            }
                            if (mPlayButton != null && mThemeHelper != null) {
                                mPlayButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPlayButton, false, false);
                            }
                            if (mPrevButton != null && mThemeHelper != null) {
                                mPrevButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mPrevButton, false, false);
                            }
                            if (mNextButton != null && mThemeHelper != null) {
                                mNextButton.setEnabled(false);
                                mThemeHelper.updateControlButton(mNextButton, false, false);
                            }
                            if (mSeekBar != null && mThemeHelper != null) {
                                mSeekBar.setEnabled(false);
                                mThemeHelper.updateSeekBar(mSeekBar, false);
                            }
                            
                            ToastManager.hidePersistentOverlay();
                            hideLoadingOverlay();
                            updatePlayPauseButton();
                        }
                    });
                }
            }
        };
        
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                boolean found = false;
                                
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        found = true;
                                        break;
                                    }
                                }
                                
                                if (!found) {
                                    final ArrayList<Song> looseSongs = SongDatabase.getInstance(MusicPlayer.this).getLooseSongs();
                                    if (looseSongs != null) {
                                        for (int i = 0; i < looseSongs.size(); i++) {
                                            final Song s = looseSongs.get(i);
                                            if (s != null && targetPath.equals(s.getPath())) {
                                                looseSongs.set(i, updatedSong);
                                                SongDatabase.getInstance(MusicPlayer.this).insertLooseSong(updatedSong);
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        if (albumArtRemoved && mAlbumArtCache != null && targetPath != null) {
                            mAlbumArtCache.remove(targetPath);
                            if (mCurrentAlbumArtPath != null && mCurrentAlbumArtPath.equals(targetPath)) {
                                mCurrentAlbumArtPath = null;
                                loadAndDisplayPlaceholder();
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && targetPath.equals(currentSong.getPath()) && mAlbumArtCache != null) {
                                mAlbumArtCache.remove(targetPath);
                                mCurrentAlbumArtPath = null;
                                updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForPlayingSong(currentSong);
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                        updatePlayPauseButton();
                        setupSeekBar();
                        updateTimeDisplay();
                    }
                }
            }
        };
        
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    updatePlayPauseButton();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateUIForSong(currentSong);
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    enableAllControls();
                                    setupSeekBar();
                                    updateTimeDisplay();
                                    updatePlayPauseButton();
                                    Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                    if (currentSong != null) {
                                        updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<Song>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    applyNoSongState();
                                    ToastManager.hidePersistentOverlay();
                                    hideLoadingOverlay();
                                    sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                                }
                            });
                        }
                    }
                }
            }
        };
        
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) {
                        return;
                    }
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (albumArtRemoved && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            loadAndDisplayPlaceholder();
                        } else if (hasAlbumArt && mAlbumArtCache != null) {
                            mAlbumArtCache.remove(songPath);
                            mCurrentAlbumArtPath = null;
                            updateAlbumArt(songPath);
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                }
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ToastManager.showToast(MusicPlayer.this, playerType + " is active...", ToastManager.LENGTH_NORMAL);
                            }
                        });
                    }
                }
            }
        };
        
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra("duration", 0);
                    final int audioSessionId = intent.getIntExtra("audio_session_id", -1);
                    final String songPath = intent.getStringExtra("song_path");
                    
                    Log.d(TAG, "SONG_PREPARED received: duration=" + duration + "ms, session=" + audioSessionId + ", path=" + songPath);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime(duration));
                                Log.d(TAG, "Updated total time to: " + formatTime(duration));
                            }
                            
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax(duration);
                                mSeekBar.setProgress(0);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                                Log.d(TAG, "Updated seekbar max to: " + duration + "ms");
                            }
                            
                            if (mPlayButton != null) {
                                mPlayButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                            }
                            
                            if (mEqualizerButton != null) {
                                mEqualizerButton.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateButton(mEqualizerButton, true);
                                }
                            }
                            
                            if (songPath != null && mMusicService != null) {
                                Song currentSong = mMusicService.getCurrentSong();
                                if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                    if (duration > 0) {
                                        currentSong.setDuration(duration);
                                    }
                                    updateUIForSong(currentSong);
                                }
                            }
                        }
                    });
                }
            }
        };
        
        mPlayerReadyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_READY.equals(intent.getAction())) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mPlayButton != null && mMusicLibrary != null && 
                                mMusicLibrary.getSongCount() > 0) {
                                mPlayButton.setEnabled(true);
                                mPlayButton.setText(FontAwesome.PLAY);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateControlButton(mPlayButton, true, true);
                                }
                                Log.d(TAG, "Play button enabled via PLAYER_READY broadcast");
                            }
                        }
                    });
                }
            }
        };
        
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
        registerReceiverSafely(mPlayerStatusReceiver, ACTION_PLAYER_STATUS_UPDATE);
        registerReceiverSafely(mSongPreparedReceiver, ACTION_SONG_PREPARED);
        registerReceiverSafely(mPlayerReadyReceiver, ACTION_PLAYER_READY);
    }
    
    /**
     * Safely registers a broadcast receiver with the given action.
     *
     * @param receiver The receiver to register
     * @param action The intent action to listen for
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) {
            return;
        }
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up click listeners for all UI buttons with debouncing.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlayPauseClickTime = currentTime;
                        togglePlayPause();
                    }
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastNextClickTime = currentTime;
                        playNextSong();
                    }
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPrevClickTime = currentTime;
                        playPreviousSong();
                    }
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastRepeatClickTime = currentTime;
                        if (mMusicService != null && mRepeatButton.isEnabled()) {
                            final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                            mMusicService.setRepeatMode(newMode);
                            updateRepeatButton();
                            final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                            ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastShuffleClickTime = currentTime;
                        if (mMusicService != null && mShuffleButton.isEnabled()) {
                            final boolean newShuffle = !mMusicService.isShuffle();
                            mMusicService.setShuffle(newShuffle);
                            updateShuffleButton();
                            ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                        }
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastManagerClickTime = currentTime;
                        openFolderManager();
                    }
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastLlamaClickTime = currentTime;
                        final View mainContent = findViewById(android.R.id.content);
                        mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                        final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                        dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(android.content.DialogInterface d) {
                                final View mainContent = findViewById(android.R.id.content);
                                mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                            }
                        });
                        dialog.show();
                    }
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastPlaylistClickTime = currentTime;
                        openPlaylist();
                    }
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastEqualizerClickTime = currentTime;
                        startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                    }
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final long currentTime = System.currentTimeMillis();
                    if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastMetadataClickTime = currentTime;
                        openMetadataEditor();
                    }
                }
            });
        }
    }
    
    /**
     * Checks if the activity is destroyed (Android 4.3+).
     *
     * @return True if the activity is destroyed
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }

    /**
     * Converts density-independent pixels to absolute pixels.
     *
     * @param dp The value in density-independent pixels
     * @return The value in absolute pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}