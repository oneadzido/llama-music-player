package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MusicPlayer - Main activity for music playback and control.
 * 
 * <p>This activity is the main entry point of the Llama Music Player application.
 * It delegates all UI display responsibilities to {@link DisplayManager} and
 * all playback responsibilities to {@link MusicService}.</p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>MusicPlayer follows the Model-View-Controller pattern where:</p>
 * <ul>
 *   <li><b>MusicPlayer</b> serves as the Controller, managing playback 
 *       coordination, service binding, and high-level state</li>
 *   <li><b>DisplayManager</b> serves as the View, managing all UI components,
 *       album art caching, and visual updates</li>
 *   <li><b>MusicService</b> handles background audio playback</li>
 *   <li><b>PlaybackController</b> provides the single source of truth for state</li>
 * </ul>
 * 
 * <h3>Responsibilities</h3>
 * <ul>
 *   <li>Service binding and lifecycle management</li>
 *   <li>Playback control (play/pause/next/prev) with debouncing</li>
 *   <li>Playlist management and sorting coordination</li>
 *   <li>Runtime permission handling (storage, notifications, Bluetooth)</li>
 *   <li>Broadcast receiver registration for service communication</li>
 *   <li>Notification and storage observer coordination</li>
 *   <li>Media button handling (headset controls)</li>
 *   <li>File import handling (opening audio files from other apps)</li>
 *   <li>Battery optimization exemption request</li>
 * </ul>
 * 
 * <h3>Control Button Management</h3>
 * <p><b>IMPORTANT:</b> All control buttons start DISABLED and only become
 * enabled when the player is prepared (song loaded and ready to play).</p>
 * 
 * <h3>Click Debouncing</h3>
 * <p>All control buttons implement click debouncing (500ms) to prevent
 * accidental double-taps and race conditions.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All UI updates are delegated to DisplayManager which handles threading.
 * Service operations use synchronized blocks and AtomicBoolean flags.</p>
 * 
 * @see DisplayManager
 * @see MusicService
 * @see PlaybackController
 * @see ThemeManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Tag for logging messages from this class. */
    private static final String TAG = "MusicPlayer";
    
    /** Request code for permission requests. */
    private static final int PERMISSION_REQUEST_CODE = 100;
    
    /** Request code for folder selection. */
    private static final int FOLDER_SELECT_CODE = 200;
    
    /** Request code for battery optimization settings. */
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing whether music was playing when app was closed. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for tracking first run of the application. */
    private static final String KEY_FIRST_RUN = "first_run";
    
    /** Key for storing the last played song's file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Action for restarting the application after updates. */
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    
    /** Action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action indicating a song has been prepared for playback. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Action indicating the player is ready for playback. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Action for position updates on pause. */
    private static final String ACTION_UPDATE_PLAYER_POSITION = "UPDATE_PLAYER_POSITION";
    
    /** Action for force UI refresh. */
    private static final String ACTION_FORCE_UI_REFRESH = "FORCE_UI_REFRESH";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Buffer size for file copying operations (8KB). */
    private static final int BUFFER_SIZE = 8192;
    
    /** Maximum length for song title display before truncation. */
    private static final int MAX_TITLE_LENGTH = 40;
    
    /** Maximum length for artist name display before truncation. */
    private static final int MAX_ARTIST_LENGTH = 35;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Debounce delay for button clicks to prevent rapid firing (milliseconds). */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay before showing loading overlay (milliseconds). */
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    
    /** Delay for next/previous button UI updates (milliseconds). */
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 250;
    
    /** Delay for focus operations and scrolling (milliseconds). */
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    
    /** Minimum time between position UI updates (33ms = ~30fps). */
    private static final long POSITION_UPDATE_THROTTLE_MS = 33;
    
    /** Maximum album art dimension in pixels for memory optimization. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** Duration of album art fade animation in milliseconds. */
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    
    /** Duration of button press animation in milliseconds. */
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (pressed state). */
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    
    /** Scale factor for button press animation (normal state). */
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    
    // ========================================================================
    // UI Components (managed by DisplayManager)
    // ========================================================================
    
    /** TextView displaying the current song title. */
    @Nullable private TextView mSongTitle;
    
    /** TextView displaying the current artist name. */
    @Nullable private TextView mSongArtist;
    
    /** TextView displaying the current seek position (elapsed time). */
    @Nullable private TextView mSeekTime;
    
    /** TextView displaying the total duration of the current song. */
    @Nullable private TextView mTotalTime;
    
    /** SeekBar for position tracking and seeking. */
    @Nullable private SeekBar mSeekBar;
    
    /** Button for play/pause toggling. */
    @Nullable private Button mPlayButton;
    
    /** Button for previous song navigation. */
    @Nullable private Button mPrevButton;
    
    /** Button for next song navigation. */
    @Nullable private Button mNextButton;
    
    /** Button for repeat mode cycling (off/all/one). */
    @Nullable private Button mRepeatButton;
    
    /** Button for shuffle mode toggling. */
    @Nullable private Button mShuffleButton;
    
    /** Button for opening folder manager. */
    @Nullable private Button mManagerButton;
    
    /** Button for showing credits/about dialog. */
    @Nullable private Button mLlamaButton;
    
    /** Button for opening playlist view. */
    @Nullable private Button mPlaylistButton;
    
    /** Button for opening equalizer settings. */
    @Nullable private Button mEqualizerButton;
    
    /** Button for opening metadata editor. */
    @Nullable private Button mMetadataButton;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Container for album art with rounded corners. */
    @Nullable private FrameLayout mAlbumArtContainer;
    
    // ========================================================================
    // Display Manager (handles all UI display)
    // ========================================================================
    
    /**
     * DisplayManager handles all UI display responsibilities including:
     * <ul>
     *   <li>Album art loading and caching</li>
     *   <li>Placeholder bitmap generation</li>
     *   <li>Song title and artist display updates</li>
     *   <li>Seekbar and time display updates</li>
     *   <li>Button state and theming</li>
     *   <li>Loading overlay management</li>
     * </ul>
     */
    @Nullable private DisplayManager mDisplayManager;
    
    // ========================================================================
    // Managers and Services
    // ========================================================================
    
    /** Library manager for accessing song data and playlists. */
    @Nullable private MusicLibrary mMusicLibrary;
    
    /** Background service for music playback. */
    @Nullable private MusicService mMusicService;
    
    /** Helper for storage access framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Manager for theme color and styling. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Centralized playback state controller (single source of truth). */
    @Nullable private PlaybackController mPlaybackController;
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mHandler = new Handler(Looper.getMainLooper());
    
    /** Executor for metadata extraction operations. */
    private final ExecutorService mMetadataExecutor = Executors.newSingleThreadExecutor();
    
    // ========================================================================
    // State Flags
    // ========================================================================
    
    /** Flag indicating if the service is bound. */
    private volatile boolean mIsServiceBound = false;
    
    /** Flag indicating if sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    /** Flag indicating if activity is restarting after an update. */
    private boolean mIsPostUpdateRestart = false;
    
    /** Flag indicating if any player has been prepared. */
    private final AtomicBoolean mIsPlayerPrepared = new AtomicBoolean(false);
    
    /** Flag indicating if playlist has songs. */
    private volatile boolean mHasSongs = false;
    
    /** Flag indicating if a transition is in progress. */
    private final AtomicBoolean mControlsTransitioning = new AtomicBoolean(false);
    
    /** Flag to prevent multiple concurrent play button updates. */
    private final AtomicBoolean mPlayButtonUpdateQueued = new AtomicBoolean(false);
    
    // ========================================================================
    // Control Enable Handler
    // ========================================================================
    
    /** Lock object for service operations. */
    private final Object mServiceLock = new Object();
    
    /** Handler for enabling controls after player preparation. */
    private final Handler mEnableHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for enabling controls with retry. */
    private Runnable mEnableControlsRunnable;
    
    // ========================================================================
    // Click Debounce Timestamps
    // ========================================================================
    
    private long mLastPlayPauseClickTime = 0;
    private long mLastNextClickTime = 0;
    private long mLastPrevClickTime = 0;
    private long mLastRepeatClickTime = 0;
    private long mLastShuffleClickTime = 0;
    private long mLastEqualizerClickTime = 0;
    private long mLastManagerClickTime = 0;
    private long mLastLlamaClickTime = 0;
    private long mLastPlaylistClickTime = 0;
    private long mLastMetadataClickTime = 0;
    
    // ========================================================================
    // Cached Data
    // ========================================================================
    
    /** Cached last song for quick access. */
    @Nullable private Song mCachedLastSong = null;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    @Nullable private BroadcastReceiver mUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mPlaySongReceiver;
    @Nullable private BroadcastReceiver mBluetoothPlayReceiver;
    @Nullable private BroadcastReceiver mBluetoothPauseReceiver;
    @Nullable private BroadcastReceiver mMediaButtonReceiver;
    @Nullable private BroadcastReceiver mGetPlayingStateReceiver;
    @Nullable private BroadcastReceiver mResetPlayerReceiver;
    @Nullable private BroadcastReceiver mForceUpdatePlayerReceiver;
    @Nullable private BroadcastReceiver mRestartReceiver;
    @Nullable private BroadcastReceiver mSavePlayerStateNowReceiver;
    @Nullable private BroadcastReceiver mBluetoothConnectionReceiver;
    @Nullable private BroadcastReceiver mSyncStartedReceiver;
    @Nullable private BroadcastReceiver mSyncCompleteReceiver;
    @Nullable private BroadcastReceiver mUpdatePlaylistFromFoldersReceiver;
    @Nullable private BroadcastReceiver mSoftUpdatePlaylistReceiver;
    @Nullable private BroadcastReceiver mUpdateSongInPlaylistReceiver;
    @Nullable private BroadcastReceiver mPlaybackRecoveryReceiver;
    @Nullable private BroadcastReceiver mSortModeReceiver;
    @Nullable private BroadcastReceiver mPlayerStatusReceiver;
    @Nullable private BroadcastReceiver mSongPreparedReceiver;
    @Nullable private BroadcastReceiver mPlayerReadyReceiver;
    @Nullable private BroadcastReceiver mPositionUpdateReceiver;
    @Nullable private BroadcastReceiver mForceUiRefreshReceiver;
    @Nullable private BroadcastReceiver mThemeReceiver;
    
    // ========================================================================
    // Service Connection
    // ========================================================================
    
    /**
     * Connection to the MusicService for playback control.
     * 
     * <p>This ServiceConnection handles binding to MusicService and initializing
     * the UI once the service is connected. It includes automatic reconnection
     * logic if the service disconnects unexpectedly.</p>
     */
    @NonNull
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            mMusicService = binder.getService();
            mIsServiceBound = true;

            loadFullPlaylistInBackground();
            
            updateRepeatButton();
            updateShuffleButton();

            // Enable controls immediately when service connects
            if (mMusicLibrary != null && mMusicLibrary.getAllSongs().size() > 0) {
                updateRepeatButton();
                updateShuffleButton();
                
                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                if (currentSong != null) {
                    updateUIForSong(currentSong);
                    if (mDisplayManager != null) {
                        mDisplayManager.updateAlbumArt(currentSong.getPath());
                    }
                }
            } else {
                applyNoSongState();
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mIsServiceBound = false;
            Log.w(TAG, "MusicService disconnected unexpectedly");
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (!mIsServiceBound && !isFinishing() && !isDestroyed()) {
                    Log.d(TAG, "Attempting to reconnect to MusicService");
                    Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
            }, 1000);
        }
    };
    
    // ========================================================================
    // PlaybackController Listener
    // ========================================================================
    
    /**
     * PlaybackController listener for state change callbacks.
     * 
     * <p>MusicPlayer is the OWNER of UI decisions. It decides:
     * <ul>
     *   <li>When to throttle position updates (33ms minimum)</li>
     *   <li>When to skip updates (during user seek)</li>
     *   <li>When to update the UI</li>
     * </ul>
     * PlaybackController simply provides the data without making decisions.</p>
     */
    private final PlaybackController.PlaybackControllerListener mPlaybackControllerListener = 
        new PlaybackController.PlaybackControllerListener() {
        
        private long mLastPositionUpdateTime = 0;
        
        @Override
        public void onPositionChanged(long positionMs, long durationMs) {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (mDisplayManager == null) return;
                
                // Skip if user is dragging (owner's decision)
                if (mDisplayManager.isUserSeeking()) {
                    return;
                }
                
                // Throttle UI updates (33ms = ~30fps)
                long now = SystemClock.elapsedRealtime();
                if (now - mLastPositionUpdateTime < POSITION_UPDATE_THROTTLE_MS) {
                    return;
                }
                mLastPositionUpdateTime = now;
                
                mDisplayManager.updatePosition(positionMs, durationMs);
            });
        }
        
        @Override
        public void onPlayStateChanged(boolean isPlaying) {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                safeUpdatePlayButton();
            });
        }
        
        @Override
        public void onSongChanged(String title, String artist, String path, long duration) {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                
                mHasSongs = true;
                
                Song tempSong = new Song(title, artist, "", "", path, duration, null);
                if (mDisplayManager != null) {
                    mDisplayManager.updateUIForSong(tempSong);
                    mDisplayManager.updateAlbumArt(path);
                }
                
                safeUpdatePlayButton();
            });
        }
        
        @Override
        public void onPreparedStateChanged(boolean isPrepared) {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                
                Log.d(TAG, "onPreparedStateChanged: isPrepared=" + isPrepared);
                mIsPlayerPrepared.set(isPrepared);
                
                if (isPrepared) {
                    enableControlsWhenReady();
                } else {
                    disableAllControls();
                }
                
                safeUpdatePlayButton();
            });
        }
        
        @Override
        public void onOperationFailed(String operation, String reason) {
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) {
                    String message = "Cannot " + operation;
                    if (reason != null && !reason.isEmpty()) {
                        message += ": " + reason;
                    }
                    ToastManager.showToast(MusicPlayer.this, message, ToastManager.LENGTH_SHORT);
                    Log.w(TAG, "Operation failed: " + operation + " - " + reason);
                }
            });
        }
    };
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>Initializes managers, sets up UI components, creates DisplayManager,
     * checks permissions, and registers receivers.</p>
     *
     * @param savedInstanceState Saved instance state bundle, or null if new instance
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_music_player);
        
        ToastManager.init(this);
        
        if (getIntent().getBooleanExtra("close_app", false)) {
            finishAffinity();
            return;
        }
        
        FontAwesome.init(this);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        
        mIsPostUpdateRestart = getIntent().getBooleanExtra("is_post_update_restart", false);
        if (mIsPostUpdateRestart) {
            MusicService.clearPlayerStateBeforeUpdate(this);
        }

        mMusicLibrary = new MusicLibrary(this);
        
        initializeViews();
        setupListeners();
        registerReceivers();
        registerThemeReceiver();
        registerRestartReceiver();
        setupMediaButtonReceiver();
        
        // Create DisplayManager with listener
        mDisplayManager = new DisplayManager(this, new DisplayManager.DisplayListener() {
            @Override
            public void onSeekRequested(int position) {
                if (mMusicService != null) {
                    mMusicService.seekTo(position);
                }
            }
            
            @Override
            public void onSeekStart() {
                if (mPlaybackController != null) {
                    mPlaybackController.onSeekStart();
                }
            }
            
            @Override
            public void onSeekStop() {
                // Handled by seek bar listener
            }
            
            @Override
            public void onNotificationAlbumArtUpdate(Bitmap art, Bitmap placeholder, String artPath) {
                if (mMusicService != null) {
                    mMusicService.setNotificationAlbumArt(art, placeholder, artPath);
                }
            }
        });
        
        // Bind UI components to DisplayManager
        mDisplayManager.bindViews(mSongTitle, mSongArtist, mSeekTime, mTotalTime,
            mSeekBar, mAlbumArtView, mAlbumArtContainer);
        
        // Animate buttons via DisplayManager
        animateButtonsWithDisplayManager();
        
        checkPermissionsAndInitialize();
        
        mPlaybackController = PlaybackController.getInstance();
        setupPlaybackControllerListener();
        
        NavigationController.getInstance().registerListener(this);
        
        // Start storage observer
        StorageObserver storageObserver = new StorageObserver(this);
        storageObserver.startObserving();
        
        applyThemeToUI();
    }
    
    /**
     * Called when the activity resumes and comes to the foreground.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
        
        if (mThemeReceiver == null) {
            registerThemeReceiver();
        }
        
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        if (mMusicService != null && mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(currentSong.getPath());
                }
            }
        }
        
        // Restore position from PlaybackController on resume
        if (mPlaybackController != null && mDisplayManager != null) {
            long savedPosition = mPlaybackController.getCurrentPosition();
            if (savedPosition > 0 && mSeekBar != null) {
                mDisplayManager.updatePosition(savedPosition, mPlaybackController.getDuration());
            }
        }
        
        if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0 && mDisplayManager != null) {
            mDisplayManager.hideLoadingOverlay();
        }
        
        applyThemeToUI();
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Called when the activity is restarting after being stopped.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        
        if (ToastManager.hasPersistentToast()) {
            ToastManager.reattachToCurrentActivity(this);
        }
    }
    
    /**
     * Called when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        NavigationController.getInstance().unregisterListener(this);
        
        if (mMusicService != null) {
            mMusicService.savePlayerState();
            mMusicService.refreshNotification();
        }
        
        final Intent stopNotifIntent = new Intent(this, MusicService.class);
        stopNotifIntent.setAction("ACTION_STOP_NOTIFICATION");
        startService(stopNotifIntent);

        if (mIsServiceBound) {
            try {
                unbindService(mServiceConnection);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        unregisterReceiverSafely(mUpdatePlayerReceiver);
        unregisterReceiverSafely(mPlaySongReceiver);
        unregisterReceiverSafely(mBluetoothPlayReceiver);
        unregisterReceiverSafely(mBluetoothPauseReceiver);
        unregisterReceiverSafely(mMediaButtonReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mResetPlayerReceiver);
        unregisterReceiverSafely(mForceUpdatePlayerReceiver);
        unregisterReceiverSafely(mRestartReceiver);
        unregisterReceiverSafely(mSavePlayerStateNowReceiver);
        unregisterReceiverSafely(mBluetoothConnectionReceiver);
        unregisterReceiverSafely(mSyncStartedReceiver);
        unregisterReceiverSafely(mSyncCompleteReceiver);
        unregisterReceiverSafely(mUpdatePlaylistFromFoldersReceiver);
        unregisterReceiverSafely(mSoftUpdatePlaylistReceiver);
        unregisterReceiverSafely(mUpdateSongInPlaylistReceiver);
        unregisterReceiverSafely(mPlaybackRecoveryReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlayerStatusReceiver);
        unregisterReceiverSafely(mSongPreparedReceiver);
        unregisterReceiverSafely(mPlayerReadyReceiver);
        unregisterReceiverSafely(mPositionUpdateReceiver);
        unregisterReceiverSafely(mForceUiRefreshReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        
        if (mEnableHandler != null) {
            mEnableHandler.removeCallbacksAndMessages(null);
        }
        mEnableControlsRunnable = null;
        
        unregisterMediaButtonReceiver();
        
        // Release DisplayManager
        if (mDisplayManager != null) {
            mDisplayManager.release();
            mDisplayManager = null;
        }
        
        ToastManager.hidePersistentOverlay();
        
        if (mMetadataExecutor != null && !mMetadataExecutor.isShutdown()) {
            mMetadataExecutor.shutdown();
        }
    }
    
    /**
     * Called when a new intent is delivered to the activity.
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("close_app", false)) {
            finishAffinity();
        } else {
            handleIncomingFile(intent);
        }
    }
    
    /**
     * Called when the window gains or loses focus.
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        // Refresh control buttons when window regains focus
        if (hasFocus && mMusicService != null && mMusicLibrary != null && 
            mMusicLibrary.getSongCount() > 0) {
            updateRepeatButton();
            updateShuffleButton();
            
            Song currentSong = mMusicService.getCurrentSong();
            if (currentSong != null) {
                updateUIForSong(currentSong);
                if (mDisplayManager != null) {
                    mDisplayManager.updateAlbumArt(currentSong.getPath());
                }
            }
        }
    }
    
    /**
     * Called when a key is pressed down.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() > 0) {
            return super.onKeyDown(keyCode, event);
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /**
     * Called when a key is released.
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (mMusicService != null && !mMusicService.isAnyPlayerPlaying()) {
                    if (mMusicService.isAnyPlayerPrepared()) {
                        mMusicService.resume();
                    } else if (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0) {
                        mMusicService.playSong(0);
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                    mMusicService.pause();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSong();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPreviousSong();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
    /**
     * Called when an activity launched with startActivityForResult completes.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    ToastManager.showToast(this, "Background playback optimized", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User granted battery optimization exemption");
                } else {
                    ToastManager.showToast(this, "Background playback restricted", ToastManager.LENGTH_NORMAL);
                    Log.d(TAG, "User declined battery optimization exemption");
                }
            }
            return;
        }
        
        if (requestCode == FOLDER_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            final Uri treeUri = data.getData();
            if (treeUri != null && mStorageHelper != null) {
                final String folderPath = mStorageHelper.getFolderPathFromUri(treeUri);
                mStorageHelper.storeFolderPermission(treeUri, folderPath);
                final String folderUriString = treeUri.toString();
                if (mMusicLibrary != null) {
                    mMusicLibrary.addFolder(folderUriString);
                }
                cleanLooseSongsInFolder(treeUri);
                final String folderName = mStorageHelper.getFolderNameFromUri(treeUri);
                ToastManager.showToast(this, "Imported: " + folderName, ToastManager.LENGTH_NORMAL);
            }
        }
    }
    
    /**
     * Called when permission request results are available.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            } else {
                ToastManager.showToast(MusicPlayer.this, "Permission required to read songs", ToastManager.LENGTH_NORMAL);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
        }
    }
    
    /**
     * Called when the system requests memory trimming.
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mMusicService != null && mIsServiceBound) {
            try {
                mMusicService.onTrimMemory(level);
            } catch (Exception e) {
                Log.e(TAG, "Failed to forward onTrimMemory to service", e);
            }
        }
    }
    
    /**
     * Checks if the activity is destroyed (Android 4.3+).
     */
    @Override
    public boolean isDestroyed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return super.isDestroyed();
        }
        return false;
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes.
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.DATABASE_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(() -> {
                if (mPlaylistButton != null) {
                    mPlaylistButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mPlaylistButton, !finalDisabled);
                    }
                }
                
                if (mMetadataButton != null) {
                    mMetadataButton.setEnabled(!finalDisabled);
                    if (mThemeHelper != null) {
                        mThemeHelper.updateButton(mMetadataButton, !finalDisabled);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI views and sets up visual properties.
     * 
     * <p>ALL control buttons start DISABLED and only become enabled when
     * the player is prepared.</p>
     */
    private void initializeViews() {
        mSongTitle = findViewById(R.id.songTitle);
        mSongArtist = findViewById(R.id.songArtist);
        mSeekTime = findViewById(R.id.seekTime);
        mTotalTime = findViewById(R.id.totalTime);
        mSeekBar = findViewById(R.id.seekBar);
        mPlayButton = findViewById(R.id.playButton);
        mPrevButton = findViewById(R.id.prevButton);
        mNextButton = findViewById(R.id.nextButton);
        mRepeatButton = findViewById(R.id.repeatButton);
        mShuffleButton = findViewById(R.id.shuffleButton);
        mManagerButton = findViewById(R.id.managerButton);
        mLlamaButton = findViewById(R.id.llamaButton);
        mPlaylistButton = findViewById(R.id.playlistButton);
        mEqualizerButton = findViewById(R.id.equalizerButton);
        mMetadataButton = findViewById(R.id.metadataButton);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);

        final android.graphics.Typeface faTypeface = FontAwesome.getTypeface();
        
        // Initialize all buttons as disabled - will be enabled when player is ready
        if (mPlayButton != null) {
            mPlayButton.setTypeface(faTypeface);
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        
        if (mPrevButton != null) {
            mPrevButton.setTypeface(faTypeface);
            mPrevButton.setText(FontAwesome.BACKWARD);
            mPrevButton.setEnabled(false);
            mPrevButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        
        if (mNextButton != null) {
            mNextButton.setTypeface(faTypeface);
            mNextButton.setText(FontAwesome.FORWARD);
            mNextButton.setEnabled(false);
            mNextButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setTypeface(faTypeface);
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mShuffleButton.setEnabled(false);
            mShuffleButton.setBackgroundResource(R.drawable.control_button_selector);
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setTypeface(faTypeface);
            mRepeatButton.setText(FontAwesome.REPEAT);
            mRepeatButton.setEnabled(false);
            mRepeatButton.setBackgroundResource(R.drawable.control_button_selector);
        }

        // Action buttons
        if (mManagerButton != null) {
            mManagerButton.setBackgroundResource(R.drawable.button_border_selector);
            mManagerButton.setLetterSpacing(0.1f);
        }
        if (mLlamaButton != null) {
            mLlamaButton.setBackgroundResource(R.drawable.button_border_selector);
            mLlamaButton.setLetterSpacing(0.1f);
        }
        if (mPlaylistButton != null) {
            mPlaylistButton.setBackgroundResource(R.drawable.button_border_selector);
            mPlaylistButton.setLetterSpacing(0.1f);
        }
        if (mEqualizerButton != null) {
            mEqualizerButton.setBackgroundResource(R.drawable.button_border_selector);
            mEqualizerButton.setLetterSpacing(0.1f);
        }
        if (mMetadataButton != null) {
            mMetadataButton.setBackgroundResource(R.drawable.button_border_selector);
            mMetadataButton.setLetterSpacing(0.1f);
        }

        // Initialize button states
        updateRepeatButton();
        updateShuffleButton();
        
        // Ensure seek bar is disabled initially
        if (mSeekBar != null) {
            mSeekBar.setEnabled(false);
        }
    }
    
    /**
     * Animates buttons via DisplayManager.
     */
    private void animateButtonsWithDisplayManager() {
        if (mDisplayManager == null) return;
        
        mDisplayManager.animateButton(mPlayButton);
        mDisplayManager.animateButton(mPrevButton);
        mDisplayManager.animateButton(mNextButton);
        mDisplayManager.animateButton(mRepeatButton);
        mDisplayManager.animateButton(mShuffleButton);
        mDisplayManager.animateButton(mManagerButton);
        mDisplayManager.animateButton(mLlamaButton);
        mDisplayManager.animateButton(mPlaylistButton);
        mDisplayManager.animateButton(mEqualizerButton);
        mDisplayManager.animateButton(mMetadataButton);
    }
    
    // ========================================================================
    // Control Enable Methods
    // ========================================================================
    
    /**
     * Enables all playback controls when the player is prepared.
     */
    private void enableControlsWhenReady() {
        if (mEnableControlsRunnable != null) {
            mEnableHandler.removeCallbacks(mEnableControlsRunnable);
        }
        
        mEnableControlsRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                
                boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
                boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
                
                Log.d(TAG, "enableControlsWhenReady: hasSongs=" + hasSongs + ", isPrepared=" + isPrepared);
                
                if (hasSongs && isPrepared) {
                    // Enable play button
                    if (mPlayButton != null && !mPlayButton.isEnabled()) {
                        mPlayButton.setEnabled(true);
                        mPlayButton.setAlpha(1.0f);
                        if (mThemeHelper != null) {
                            boolean isPlaying = (mPlaybackController != null) ? 
                                mPlaybackController.isPlaying() : false;
                            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                        Log.d(TAG, "Play button ENABLED - player prepared");
                    }
                    
                    // Enable prev/next buttons
                    if (mPrevButton != null && !mPrevButton.isEnabled()) {
                        mPrevButton.setEnabled(true);
                        mPrevButton.setAlpha(1.0f);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateControlButton(mPrevButton, true, false);
                        }
                    }
                    
                    if (mNextButton != null && !mNextButton.isEnabled()) {
                        mNextButton.setEnabled(true);
                        mNextButton.setAlpha(1.0f);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateControlButton(mNextButton, true, false);
                        }
                    }
                    
                    // Enable repeat/shuffle buttons
                    if (mRepeatButton != null && !mRepeatButton.isEnabled()) {
                        mRepeatButton.setEnabled(true);
                        mRepeatButton.setAlpha(1.0f);
                        updateRepeatButton();
                    }
                    
                    if (mShuffleButton != null && !mShuffleButton.isEnabled()) {
                        mShuffleButton.setEnabled(true);
                        mShuffleButton.setAlpha(1.0f);
                        updateShuffleButton();
                    }
                    
                    // Enable seekbar
                    if (mSeekBar != null && !mSeekBar.isEnabled()) {
                        mSeekBar.setEnabled(true);
                        mSeekBar.setAlpha(1.0f);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateSeekBar(mSeekBar, true);
                        }
                    }
                } else if (hasSongs && !isPrepared) {
                    // Retry after 500ms - 'this' now correctly refers to the Runnable
                    mEnableHandler.postDelayed(this, 500);
                    Log.d(TAG, "enableControlsWhenReady: waiting for player preparation...");
                }
            }
        };
        
        mEnableHandler.post(mEnableControlsRunnable);
        
        // Safety timeout
        mEnableHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mEnableControlsRunnable != null) {
                    mEnableHandler.removeCallbacks(mEnableControlsRunnable);
                    mEnableControlsRunnable = null;
                    Log.d(TAG, "Enable controls timeout - giving up");
                }
            }
        }, 10000);
    }
    
    /**
     * Disables all playback controls.
     */
    private void disableAllControls() {
        Log.d(TAG, "disableAllControls - disabling all controls");
        
        if (mPlayButton != null) mPlayButton.setEnabled(false);
        if (mPrevButton != null) mPrevButton.setEnabled(false);
        if (mNextButton != null) mNextButton.setEnabled(false);
        if (mRepeatButton != null) mRepeatButton.setEnabled(false);
        if (mShuffleButton != null) mShuffleButton.setEnabled(false);
        if (mSeekBar != null) mSeekBar.setEnabled(false);
    }
    
    // ========================================================================
    // Permission and Initialization Methods
    // ========================================================================
    
    /**
     * Checks and requests necessary runtime permissions.
     */
    private void checkPermissionsAndInitialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final ArrayList<String> permissionsToRequest = new ArrayList<>();

            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.READ_MEDIA_AUDIO");
                }
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.POST_NOTIFICATIONS");
                }
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT >= 31) {
                if (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add("android.permission.BLUETOOTH_CONNECT");
                }
            }

            if (!permissionsToRequest.isEmpty()) {
                requestPermissions(permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                proceedWithInitialization();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkAndRequestBatteryOptimization();
                }
            }
        } else {
            proceedWithInitialization();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestBatteryOptimization();
            }
        }
    }
    
    /**
     * Proceeds with app initialization after permissions are granted.
     */
    private void proceedWithInitialization() {
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final boolean isFirstRun = !prefs.getBoolean(KEY_FIRST_RUN, false);

        if (isFirstRun) {
            applyNoSongState();
            ToastManager.showToast(MusicPlayer.this, "Just a moment...", ToastManager.LENGTH_NORMAL);

            final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
            startService(serviceIntent);
            bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
        } else {
            loadLastSongMetadata();
        }
        
        handleIncomingFile(getIntent());
    }
    
    /**
     * Checks and requests battery optimization exemption for background playback.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkAndRequestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean hasAsked = prefs.getBoolean("asked_battery_optimization", false);
            if (!hasAsked) {
                prefs.edit().putBoolean("asked_battery_optimization", true).apply();
                
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent, BATTERY_OPTIMIZATION_REQUEST_CODE);
                    Log.d(TAG, "Battery optimization request dialog shown");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to open battery optimization settings", e);
                }
            }
        } else {
            Log.d(TAG, "Already exempt from battery optimizations");
        }
    }
    
    // ========================================================================
    // Media Button Receiver Methods
    // ========================================================================
    
    /**
     * Registers a media button event receiver for headset controls.
     */
    @SuppressWarnings("deprecation")
    private void setupMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.registerMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register media button receiver", e);
        }
    }
    
    /**
     * Unregisters the media button event receiver.
     */
    @SuppressWarnings("deprecation")
    private void unregisterMediaButtonReceiver() {
        try {
            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager != null) {
                final ComponentName receiver = new ComponentName(getPackageName(), BluetoothReceiver.class.getName());
                audioManager.unregisterMediaButtonEventReceiver(receiver);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to unregister media button receiver", e);
        }
    }
    
    // ========================================================================
    // Incoming File Handling Methods
    // ========================================================================
    
    /**
     * Handles incoming files from other apps via ACTION_VIEW intent.
     */
    private void handleIncomingFile(@Nullable Intent intent) {
        if (intent == null) return;
        
        final String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            final Uri uri = intent.getData();
            if (uri != null) {
                final String filePath = getFilePathFromUri(uri);
                if (filePath == null || !new File(filePath).exists()) {
                    ToastManager.showToast(this, "File not found or inaccessible", ToastManager.LENGTH_NORMAL);
                    return;
                }
                
                Song tempSong = CharacterMapper.getSongFromFile(filePath);
                final Song newSong;
                if (tempSong == null) {
                    String fileName = new File(filePath).getName();
                    final int dot = fileName.lastIndexOf(".");
                    if (dot > 0) fileName = fileName.substring(0, dot);
                    newSong = new Song(fileName, "Unknown Artist", "Unknown Album", "Unknown Genre", filePath, 0, null);
                } else {
                    newSong = tempSong;
                }
                
                SongDatabase.getInstance(this).insertLooseSong(newSong);
                Log.d(TAG, "Loose song added to database: " + filePath);
                
                mMusicLibrary = new MusicLibrary(this);
                
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs == null) {
                    allSongs = new ArrayList<>();
                }
                
                int existingIndex = -1;
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getPath().equals(filePath)) {
                        existingIndex = i;
                        break;
                    }
                }
                
                final int playIndex;
                if (existingIndex >= 0) {
                    playIndex = existingIndex;
                } else {
                    allSongs.add(newSong);
                    playIndex = allSongs.size() - 1;
                }
                
                final ArrayList<Song> finalSongs = new ArrayList<>(allSongs);
                
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_LAST_PLAYING, false).apply();
                
                if (mMusicService != null) {
                    playSongFromIncoming(finalSongs, filePath, newSong);
                } else {
                    bindServiceForIncomingFile(finalSongs, filePath, newSong);
                }
                
                sendBroadcast(new Intent("LOOSE_TRACKS_UPDATED"));
                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
            }
        }
    }
    
    /**
     * Plays an incoming file using the already-bound MusicService.
     */
    private void playSongFromIncoming(@NonNull final ArrayList<Song> finalSongs, 
                                      @NonNull final String filePath, 
                                      @NonNull final Song newSong) {
        if (mMusicService != null) {
            mMusicService.setPlaylist(finalSongs, false);
            
            runOnUiThread(() -> {
                enableAllControls();
                updateUIForSong(newSong);
            });
            
            mMusicService.playSongByPath(filePath);
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                // Play button state will be updated via PlaybackController listener
            }, FOCUS_SCROLL_DELAY_MS);
        }
    }
    
    /**
     * Binds to MusicService and plays an incoming file.
     */
    private void bindServiceForIncomingFile(final ArrayList<Song> finalSongs, 
                                            final String filePath, 
                                            final Song newSong) {
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                final MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
                mMusicService = binder.getService();
                mIsServiceBound = true;
                
                if (mMusicService != null) {
                    mMusicService.setPlaylist(finalSongs, false);
                    
                    runOnUiThread(() -> {
                        enableAllControls();
                        updateUIForSong(newSong);
                        if (mAlbumArtContainer != null) {
                            if (mDisplayManager != null) {
                                mDisplayManager.applyAlbumArtClipping();
                            }
                        }
                    });
                    
                    mMusicService.playSongByPath(filePath);
                    
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        // Play button state will be updated via PlaybackController listener
                    }, FOCUS_SCROLL_DELAY_MS);
                }
            }
            
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mMusicService = null;
            }
        }, BIND_AUTO_CREATE);
    }
    
    // ========================================================================
    // URI Helper Methods
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = null;
            try {
                final String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    final int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                    path = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                path = copyContentUriToTempFile(uri);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Copies a content URI to a temporary file.
     */
    @Nullable
    private String copyContentUriToTempFile(@NonNull Uri uri) {
        try {
            final InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            final File tempFile = new File(getCacheDir(), "temp_audio_" + SystemClock.elapsedRealtime() + ".mp3");
            final FileOutputStream outputStream = new FileOutputStream(tempFile);
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy URI to temp file", e);
            return null;
        }
    }
    
    /**
     * Removes loose songs that are inside an imported folder.
     */
    private void cleanLooseSongsInFolder(@NonNull Uri folderUri) {
        if (mStorageHelper == null) return;
        
        final String folderPath = mStorageHelper.getFolderPathFromUri(folderUri);
        if (folderPath == null) return;
        
        final ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        if (looseSongs == null) return;
        
        final String normalizedPath = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        for (Song loose : looseSongs) {
            if (loose.getPath().startsWith(normalizedPath)) {
                SongDatabase.getInstance(this).removeLooseSong(loose.getPath());
            }
        }
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist in the background asynchronously.
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(() -> {
                        Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                            updateUIForSong(current);
                            if (mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(current.getPath());
                            }
                        }
                    });
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                runOnUiThread(() -> ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG));
            }
        });
    }
    
    // ========================================================================
    // UI Update Methods
    // ========================================================================
    
    /**
     * Updates the UI to display information for a given song.
     */
    private void updateUIForSong(@Nullable Song song) {
        if (song == null || isFinishing() || isDestroyed()) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "MusicPlayer.updateUIForSong");
        }
        
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed() || mThemeHelper == null) return;

            String displayText = song.getTitle();
            if (displayText != null && displayText.length() > MAX_TITLE_LENGTH) {
                displayText = displayText.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
            }
            if (mSongTitle != null) {
                mSongTitle.setText(displayText != null ? displayText : "Unknown Title");
                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
            }
            
            if (mSongArtist != null) {
                String artistText = song.getArtist();
                if (artistText != null && artistText.length() > MAX_ARTIST_LENGTH) {
                    artistText = artistText.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                }
                mSongArtist.setText(artistText != null ? artistText : "Unknown Artist");
                mSongArtist.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
            }
            
            if (mTotalTime != null && song.getDuration() > 0) {
                mTotalTime.setText(DisplayManager.formatTime((int) song.getDuration()));
            }
            
            if (mDisplayManager != null) {
                mDisplayManager.hideLoadingOverlay();
            }
        });
    }
    
    /**
     * Enables or disables all playback controls based on song availability.
     */
    private void enableAllControls() {
        final boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        final boolean isPrepared = (mPlaybackController != null && mPlaybackController.isPrepared());
        
        runOnUiThread(() -> {
            if (mPlayButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPlayButton.setEnabled(enabled);
                mPlayButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPlayButton, enabled, true);
            }
            if (mPrevButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mPrevButton.setEnabled(enabled);
                mPrevButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mPrevButton, enabled, false);
            }
            if (mNextButton != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mNextButton.setEnabled(enabled);
                mNextButton.setAlpha(enabled ? 1.0f : 0.5f);
                mThemeHelper.updateControlButton(mNextButton, enabled, false);
            }
            if (mRepeatButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mRepeatButton.setEnabled(enabled);
                mRepeatButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateRepeatButton();
            }
            if (mShuffleButton != null) {
                boolean enabled = hasSongs && isPrepared;
                mShuffleButton.setEnabled(enabled);
                mShuffleButton.setAlpha(enabled ? 1.0f : 0.5f);
                updateShuffleButton();
            }
            if (mSeekBar != null && mThemeHelper != null) {
                boolean enabled = hasSongs && isPrepared;
                mSeekBar.setEnabled(enabled);
                mThemeHelper.updateSeekBar(mSeekBar, enabled);
            }
        });
    }
    
    /**
     * Applies the "no song" state to all UI components.
     */
    private void applyNoSongState() {
        int totalSongs = (mMusicLibrary != null ? mMusicLibrary.getSongCount() : 0);
        ArrayList<Song> looseSongs = SongDatabase.getInstance(this).getLooseSongs();
        int looseCount = (looseSongs != null ? looseSongs.size() : 0);
        if (totalSongs + looseCount > 0) return;
        
        if (mIsSyncInProgress) return;
        
        mHasSongs = false;
        mIsPlayerPrepared.set(false);
        
        if (mSongTitle != null && mThemeHelper != null) {
            mSongTitle.setText("Title");
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSongArtist != null) {
            mSongArtist.setText("Artist");
            mSongArtist.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
        }
        
        if (mDisplayManager != null) {
            mDisplayManager.loadAndDisplayPlaceholder();
        }

        // Disable all controls with faded appearance
        if (mPlayButton != null && mThemeHelper != null) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mPlayButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
        }
        if (mPrevButton != null && mThemeHelper != null) {
            mPrevButton.setEnabled(false);
            mPrevButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mPrevButton, false, false);
        }
        if (mNextButton != null && mThemeHelper != null) {
            mNextButton.setEnabled(false);
            mNextButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mNextButton, false, false);
        }
        if (mRepeatButton != null && mThemeHelper != null) {
            mRepeatButton.setEnabled(false);
            mRepeatButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mRepeatButton, false, false);
        }
        if (mShuffleButton != null && mThemeHelper != null) {
            mShuffleButton.setEnabled(false);
            mShuffleButton.setAlpha(0.5f);
            mThemeHelper.updateControlButton(mShuffleButton, false, false);
        }
        
        if (mSeekBar != null && mThemeHelper != null) {
            mSeekBar.setProgress(0);
            mSeekBar.setMax(100);
            mSeekBar.setEnabled(false);
            mSeekBar.setAlpha(0.5f);
            mThemeHelper.updateSeekBar(mSeekBar, false);
        }
        
        if (mSeekTime != null) {
            mSeekTime.setText("00:00");
        }
        if (mTotalTime != null) {
            mTotalTime.setText("00:00");
        }
        
        mCachedLastSong = null;
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Safely executes an action on MusicService with synchronization.
     */
    private void safeCallService(@NonNull Runnable action) {
        synchronized (mServiceLock) {
            if (mMusicService != null && mIsServiceBound) {
                action.run();
            }
        }
    }
    
    /**
     * Plays a song at the specified index in the playlist.
     */
    private void playSong(int index) {
        if (mMusicService != null && mMusicLibrary != null && 
            mMusicLibrary.getAllSongs().size() > 0 && index >= 0 && 
            index < mMusicLibrary.getAllSongs().size()) {
            mMusicService.playSong(index);
            final Song song = mMusicService.getCurrentSong();
            if (song != null) {
                updateUIForSong(song);
            }
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        boolean isPlaying = false;
        boolean isPrepared = false;
        
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
            isPrepared = mPlaybackController.isPrepared();
        }
        
        if (isPlaying) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
        } else if (isPrepared) {
            Log.d(TAG, "togglePlayPause: Resuming playback");
            mMusicService.resume();
        } else {
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playNext();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state updated via listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(() -> {
                    mMusicService.playPrevious();
                    mHandler.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            // Play button state updated via listener
                        }
                    }, NEXT_PREV_UPDATE_DELAY_MS);
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ========================================================================
    // Button State Update Methods
    // ========================================================================
    
    /**
     * Updates the repeat button icon based on current repeat mode.
     */
    private void updateRepeatButton() {
        if (mMusicService == null || mRepeatButton == null || mThemeHelper == null) {
            return;
        }
        
        final int repeatMode = mMusicService.getRepeatMode();
        final boolean isEnabled = mRepeatButton.isEnabled();
        
        if (mDisplayManager != null) {
            mDisplayManager.updateRepeatButton(repeatMode, mRepeatButton, isEnabled);
        } else {
            if (repeatMode == 2) {
                mRepeatButton.setText(FontAwesome.REPEAT_ONE);
            } else {
                mRepeatButton.setText(FontAwesome.REPEAT);
            }
            mThemeHelper.updateControlButton(mRepeatButton, isEnabled, repeatMode != 0);
        }
    }
    
    /**
     * Updates the shuffle button icon based on current shuffle state.
     */
    private void updateShuffleButton() {
        if (mMusicService == null || mShuffleButton == null || mThemeHelper == null) {
            return;
        }
        
        final boolean isShuffleOn = mMusicService.isShuffle();
        final boolean isEnabled = mShuffleButton.isEnabled();
        
        if (mDisplayManager != null) {
            mDisplayManager.updateShuffleButton(isShuffleOn, mShuffleButton, isEnabled);
        } else {
            mShuffleButton.setText(FontAwesome.SHUFFLE);
            mThemeHelper.updateControlButton(mShuffleButton, isEnabled, isShuffleOn);
        }
    }
    
    /**
     * Safely updates the play/pause button state.
     */
    private void safeUpdatePlayButton() {
        if (mPlayButtonUpdateQueued.getAndSet(true)) {
            return;
        }
        
        mHandler.post(() -> {
            mPlayButtonUpdateQueued.set(false);
            
            if (isFinishing() || isDestroyed() || mThemeHelper == null || mPlayButton == null) {
                return;
            }
            
            boolean isPlaying = false;
            boolean isPrepared = false;
            
            if (mPlaybackController != null) {
                isPlaying = mPlaybackController.isPlaying();
                isPrepared = mPlaybackController.isPrepared();
            }
            
            boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
            
            if (!hasSongs) {
                mPlayButton.setText(FontAwesome.PLAY);
                mPlayButton.setEnabled(false);
                if (mThemeHelper != null) {
                    mThemeHelper.updateControlButton(mPlayButton, false, false);
                }
                Log.d(TAG, "Play button: DISABLED (no songs)");
                return;
            }
            
            boolean shouldEnable = isPrepared;
            if (mPlayButton.isEnabled() != shouldEnable) {
                mPlayButton.setEnabled(shouldEnable);
            }
            
            String newText = isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY;
            if (!newText.equals(mPlayButton.getText())) {
                mPlayButton.setText(newText);
                if (mThemeHelper != null && shouldEnable) {
                    mThemeHelper.updateControlButton(mPlayButton, shouldEnable, true);
                }
            }
        });
    }
    
    // ========================================================================
    // Navigation Methods
    // ========================================================================
    
    /**
     * Opens the folder manager activity for importing music folders.
     */
    private void openFolderManager() {
        final Intent intent = new Intent(this, FolderManager.class);
        startActivityForResult(intent, FOLDER_SELECT_CODE);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
    
    /**
     * Opens the playlist activity to view and manage playlists.
     */
    private void openPlaylist() {
        final Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    
    /**
     * Opens the metadata editor for editing song tags.
     */
    private void openMetadataEditor() {
        final Intent editorIntent = new Intent(this, MetadataEditor.class);
        
        final Song currentSong = getCurrentSong();
        
        if (currentSong != null && currentSong.getPath() != null) {
            editorIntent.putExtra("song_path", currentSong.getPath());
            if (currentSong.getUri() != null) {
                editorIntent.putExtra("song_uri", currentSong.getUri());
            }
            editorIntent.putExtra("awaiting_file_selection", false);
        } else {
            editorIntent.putExtra("awaiting_file_selection", true);
        }
        
        startActivity(editorIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    
    /**
     * Gets the currently playing song from MusicService.
     */
    @Nullable
    private Song getCurrentSong() {
        if (mMusicService != null) {
            return mMusicService.getCurrentSong();
        }
        return null;
    }
    
    // ========================================================================
    // Initial Loading Methods
    // ========================================================================
    
    /**
     * Loads the last played song's metadata from storage.
     */
    private void loadLastSongMetadata() {
        if (mDisplayManager != null) {
            mDisplayManager.showLoadingOverlay((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content));
            mHandler.postDelayed(() -> {
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }, LOADING_OVERLAY_DELAY_MS);
        }
        
        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);

        if (lastPath != null && new File(lastPath).exists()) {
            if (mSongTitle != null) {
                mSongTitle.setText("Loading...");
            }
            if (mSongArtist != null) {
                mSongArtist.setText("Loading...");
            }
            
            mMetadataExecutor.execute(() -> {
                Song song = null;
                try {
                    Song cachedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                    
                    if (cachedSong != null && cachedSong.getTitle() != null && 
                        !cachedSong.getTitle().isEmpty() && 
                        !"Unknown Title".equals(cachedSong.getTitle())) {
                        song = cachedSong;
                    } else {
                        final MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                        mmr.setDataSource(lastPath);
                        String title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        final byte[] art = mmr.getEmbeddedPicture();
                        mmr.release();
                        
                        if (title == null || title.isEmpty()) {
                            final File file = new File(lastPath);
                            String name = file.getName();
                            final int dot = name.lastIndexOf('.');
                            if (dot > 0) name = name.substring(0, dot);
                            title = name;
                        }
                        if (artist == null) artist = "Unknown Artist";
                        if (album == null) album = "Unknown Album";
                        
                        String genre = "Unknown Genre";
                        Song dbSong = SongDatabase.getInstance(MusicPlayer.this).getSong(lastPath);
                        if (dbSong != null && dbSong.getGenre() != null && 
                            !"Unknown Genre".equals(dbSong.getGenre())) {
                            genre = dbSong.getGenre();
                        } else {
                            String fileGenre = CharacterMapper.getGenre(lastPath);
                            if (fileGenre != null && !"Unknown Genre".equals(fileGenre)) {
                                genre = fileGenre;
                            }
                        }
                        
                        song = new Song(title, artist, album, genre, lastPath, 0, null);
                        if (art != null && mDisplayManager != null) {
                            // Album art handled by DisplayManager
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to load last song metadata for: " + lastPath, e);
                }
                
                final Song finalSong = song;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (finalSong != null && mThemeHelper != null) {
                        mCachedLastSong = finalSong;
                        if (mSongTitle != null) {
                            mSongTitle.setText(finalSong.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(finalSong.getArtist());
                            mSongArtist.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
                        }
                        if (mDisplayManager != null) {
                            mDisplayManager.loadAndDisplayPlaceholder();
                            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                if (mMusicService != null && mMusicService.getCurrentSong() != null) {
                                    mDisplayManager.updateAlbumArt(mMusicService.getCurrentSong().getPath());
                                }
                            }, FOCUS_SCROLL_DELAY_MS);
                        }
                        startServiceWithCachedSong();
                    } else {
                        applyNoSongState();
                        loadSongsAndStartService();
                    }
                });
            });
        } else {
            applyNoSongState();
            loadSongsAndStartService();
        }
    }
    
    /**
     * Starts the MusicService with the cached last song.
     */
    private void startServiceWithCachedSong() {
        if (mCachedLastSong == null) return;
        final ArrayList<Song> tempPlaylist = new ArrayList<>();
        tempPlaylist.add(mCachedLastSong);
        final Intent serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }
    
    /**
     * Loads all songs and starts the MusicService.
     */
    private void loadSongsAndStartService() {
        if (mDisplayManager != null) {
            mDisplayManager.showLoadingOverlay((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content));
            mHandler.postDelayed(() -> {
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }, LOADING_OVERLAY_DELAY_MS);
        }
        
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    Song current = mMusicService.getCurrentSong();
                    if (current != null && mThemeHelper != null) {
                        if (mSongTitle != null) {
                            mSongTitle.setText(current.getTitle());
                            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                        }
                        if (mSongArtist != null) {
                            mSongArtist.setText(current.getArtist());
                            mSongArtist.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
                        }
                        if (mDisplayManager != null) {
                            mDisplayManager.updateAlbumArt(current.getPath());
                        }
                    }
                } else {
                    final Intent serviceIntent = new Intent(MusicPlayer.this, MusicService.class);
                    startService(serviceIntent);
                    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
                }
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
            }
            
            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading songs: " + error);
                if (mDisplayManager != null) {
                    mDisplayManager.hideLoadingOverlay();
                }
                ToastManager.showToast(MusicPlayer.this, "Error loading songs", ToastManager.LENGTH_LONG);
            }
        });
    }
    
    // ========================================================================
    // Theme Methods
    // ========================================================================
    
    /**
     * Registers a receiver for app restart commands.
     */
    private void registerRestartReceiver() {
        mRestartReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_RESTART_APP.equals(intent.getAction())) {
                    performUpdate();
                }
            }
        };
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_RESTART_APP);
        registerReceiver(mRestartReceiver, filter);
    }
    
    /**
     * Registers a receiver for theme color change events.
     */
    private void registerThemeReceiver() {
        if (mThemeReceiver != null) return;
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    applyThemeToUI();
                }
            }
        };
        final IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Applies the current theme color to all UI elements.
     */
    private void applyThemeToUI() {
        if (isFinishing() || isDestroyed() || mThemeHelper == null || mThemeManager == null) return;

        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mManagerButton != null) {
            mThemeHelper.updateButton(mManagerButton, mManagerButton.isEnabled());
        }
        if (mLlamaButton != null) {
            mThemeHelper.updateButton(mLlamaButton, mLlamaButton.isEnabled());
        }
        if (mPlaylistButton != null) {
            mThemeHelper.updateButton(mPlaylistButton, mPlaylistButton.isEnabled());
        }
        if (mEqualizerButton != null) {
            mThemeHelper.updateButton(mEqualizerButton, mEqualizerButton.isEnabled());
        }
        if (mMetadataButton != null) {
            mThemeHelper.updateButton(mMetadataButton, mMetadataButton.isEnabled());
        }
        
        if (mPlayButton != null) {
            boolean isPlaying = (mPlaybackController != null) ? mPlaybackController.isPlaying() : false;
            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
            mThemeHelper.updateControlButton(mPlayButton, mPlayButton.isEnabled(), true);
        }
        if (mPrevButton != null) {
            mThemeHelper.updateControlButton(mPrevButton, mPrevButton.isEnabled(), false);
        }
        if (mNextButton != null) {
            mThemeHelper.updateControlButton(mNextButton, mNextButton.isEnabled(), false);
        }
        if (mRepeatButton != null) {
            final boolean isRepeatOn = mMusicService != null && mMusicService.getRepeatMode() != 0;
            mThemeHelper.updateControlButton(mRepeatButton, mRepeatButton.isEnabled(), isRepeatOn);
        }
        if (mShuffleButton != null) {
            final boolean isShuffleOn = mMusicService != null && mMusicService.isShuffle();
            mThemeHelper.updateControlButton(mShuffleButton, mShuffleButton.isEnabled(), isShuffleOn);
        }
        
        if (mSeekBar != null) {
            mThemeHelper.updateSeekBar(mSeekBar, mSeekBar.isEnabled());
        }
        
        if (mSongTitle != null) {
            mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
        }
        
        if (mSeekTime != null) {
            mSeekTime.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
        }
        if (mTotalTime != null) {
            mTotalTime.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
        }
        if (mSongArtist != null) {
            mSongArtist.setTextColor(android.graphics.Color.parseColor("#C0C0C0"));
        }
        
        if (mDisplayManager != null) {
            mDisplayManager.applyThemeToUI();
        }
        
        ToastManager.refreshThemeColor();
    }
    
    /**
     * Performs an app update by restarting the activity.
     */
    private void performUpdate() {
        final Intent restartIntent = new Intent(this, MusicPlayer.class);
        restartIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        restartIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(restartIntent);
        finish();
    }
    
    // ========================================================================
    // Broadcast Receiver Setup
    // ========================================================================
    
    /**
     * Registers all broadcast receivers for service communication.
     */
    private void registerReceivers() {
        // UPDATE_PLAYER receiver
        mUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean songCompleted = intent.getBooleanExtra("song_completed", false);
                    final int completedPosition = intent.getIntExtra("completed_position", 0);
                    
                    if (songCompleted && mDisplayManager != null) {
                        mDisplayManager.updatePosition(0, completedPosition);
                    }
                    
                    if (mMusicService != null) {
                        final Song song = mMusicService.getCurrentSong();
                        if (song != null) {
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForSong(song);
                                if (mDisplayManager != null) {
                                    mDisplayManager.updateAlbumArt(song.getPath());
                                }
                            } else {
                                updateUIForSong(song);
                            }
                        }
                    }
                }
            }
        };
        
        // PLAY_SONG receiver
        mPlaySongReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "PLAY_SONG".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    if (songPath != null && mMusicService != null) {
                        mMusicService.playSongByPath(songPath);
                    }
                }
            }
        };
        
        // BLUETOOTH_PLAY receiver
        mBluetoothPlayReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PLAY".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        final int currentIndex = mMusicService.getCurrentIndex();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                            if (mMusicService.getDuration() == 0) {
                                playSong(currentIndex);
                            } else {
                                mMusicService.resume();
                            }
                        } else if (mMusicLibrary.getSongCount() > 0) {
                            playSong(0);
                        }
                    }
                }
            }
        };
        
        // BLUETOOTH_PAUSE receiver
        mBluetoothPauseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_PAUSE".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
                        mMusicService.pause();
                    }
                }
            }
        };
        
        // MEDIA_BUTTON_ACTION receiver
        mMediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "MEDIA_BUTTON_ACTION".equals(intent.getAction())) {
                    final int keyCode = intent.getIntExtra("key_code", -1);
                    if (mMusicService != null && keyCode != -1) {
                        mMusicService.handleMediaButton(keyCode);
                    }
                }
            }
        };
        
        // GET_PLAYING_STATE receiver
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "GET_PLAYING_STATE".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        prefs.edit().putBoolean(KEY_LAST_PLAYING, mMusicService.isAnyPlayerPlaying()).apply();
                    }
                }
            }
        };
        
        // RESET_PLAYER_STATE receiver
        mResetPlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "RESET_PLAYER_STATE".equals(intent.getAction())) {
                    final boolean preserveSettings = intent.getBooleanExtra("preserve_settings", false);
                    
                    if (mMusicService != null) {
                        mMusicService.stop();
                    }
                    mCachedLastSong = null;
                    if (mMusicLibrary != null) {
                        final ArrayList<Song> emptyList = new ArrayList<>();
                        mMusicLibrary.refreshSongs(emptyList);
                    }
                    runOnUiThread(() -> {
                        applyNoSongState();
                        
                        if (!preserveSettings && mMusicService != null) {
                            mMusicService.setRepeatMode(0);
                            mMusicService.setShuffle(false);
                        }
                        
                        if (mShuffleButton != null && mThemeHelper != null) {
                            mShuffleButton.setEnabled(false);
                            mShuffleButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mShuffleButton, false, false);
                        }
                        if (mRepeatButton != null && mThemeHelper != null) {
                            mRepeatButton.setEnabled(false);
                            mRepeatButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mRepeatButton, false, false);
                        }
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setEnabled(false);
                            mPlayButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mPlayButton, false, false);
                        }
                        if (mPrevButton != null && mThemeHelper != null) {
                            mPrevButton.setEnabled(false);
                            mPrevButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mPrevButton, false, false);
                        }
                        if (mNextButton != null && mThemeHelper != null) {
                            mNextButton.setEnabled(false);
                            mNextButton.setAlpha(0.5f);
                            mThemeHelper.updateControlButton(mNextButton, false, false);
                        }
                        if (mSeekBar != null && mThemeHelper != null) {
                            mSeekBar.setEnabled(false);
                            mThemeHelper.updateSeekBar(mSeekBar, false);
                        }
                        
                        ToastManager.hidePersistentOverlay();
                        if (mDisplayManager != null) {
                            mDisplayManager.hideLoadingOverlay();
                        }
                    });
                }
            }
        };
        
        // FORCE_UPDATE_PLAYER receiver
        mForceUpdatePlayerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "FORCE_UPDATE_PLAYER".equals(intent.getAction())) {
                    final boolean refreshAlbumArt = intent.getBooleanExtra("refresh_album_art", false);
                    final boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final String targetPath = intent.getStringExtra("song_path");
                    
                    if (mMusicService != null && mMusicLibrary != null && 
                        mMusicLibrary.getAllSongs().size() > 0) {
                        
                        if (refreshMetadata && targetPath != null) {
                            final Song updatedSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                            if (updatedSong != null) {
                                final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                                for (int i = 0; i < allSongs.size(); i++) {
                                    final Song s = allSongs.get(i);
                                    if (s != null && targetPath.equals(s.getPath())) {
                                        allSongs.set(i, updatedSong);
                                        break;
                                    }
                                }
                                mMusicLibrary.refreshSongs(allSongs);
                                if (mMusicService != null) {
                                    mMusicService.setPlaylist(allSongs, true);
                                }
                            }
                        }
                        
                        Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                        if (currentSong != null) {
                            if (refreshAlbumArt && targetPath != null && 
                                targetPath.equals(currentSong.getPath()) && mDisplayManager != null) {
                                mDisplayManager.updateAlbumArt(targetPath);
                            }
                            if (refreshMetadata && targetPath != null && 
                                targetPath.equals(currentSong.getPath())) {
                                final Song freshSong = SongDatabase.getInstance(MusicPlayer.this).getSong(targetPath);
                                if (freshSong != null) {
                                    currentSong = freshSong;
                                }
                            }
                            if (mMusicService.isAnyPlayerPlaying()) {
                                updateUIForSong(currentSong);
                                if (mDisplayManager != null) {
                                    mDisplayManager.updateAlbumArt(currentSong.getPath());
                                }
                            } else {
                                updateUIForSong(currentSong);
                            }
                        }
                    }
                }
            }
        };
        
        // SAVE_PLAYER_STATE_NOW receiver
        mSavePlayerStateNowReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SAVE_PLAYER_STATE_NOW".equals(intent.getAction())) {
                    if (mMusicService != null) {
                        mMusicService.savePlayerState();
                    }
                }
            }
        };
        
        // BLUETOOTH_CONNECTED receiver
        mBluetoothConnectionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "BLUETOOTH_CONNECTED".equals(intent.getAction())) {
                    final boolean connected = intent.getBooleanExtra("connected", false);
                    if (mMusicService != null) {
                        mMusicService.setBluetoothConnected(connected);
                    }
                }
            }
        };
        
        // SYNC_STARTED receiver
        mSyncStartedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTED".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    if (mDisplayManager != null) {
                        mDisplayManager.setSyncInProgress(true);
                    }
                    final String text = intent.getStringExtra("custom_text");
                    if (text != null) {
                        if (!ToastManager.hasPersistentToast()) {
                            ToastManager.showPersistentOverlay(MusicPlayer.this, text);
                        } else {
                            ToastManager.updatePersistentOverlay(text);
                        }
                    }
                }
            }
        };
        
        // SYNC_COMPLETE receiver
        mSyncCompleteReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_COMPLETE".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    if (mDisplayManager != null) {
                        mDisplayManager.setSyncInProgress(false);
                    }
                    ToastManager.hidePersistentOverlay();
                }
            }
        };
        
        // UPDATE_PLAYLIST_FROM_FOLDERS receiver
        mUpdatePlaylistFromFoldersReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_PLAYLIST_FROM_FOLDERS".equals(intent.getAction())) {
                    mMusicLibrary = new MusicLibrary(MusicPlayer.this);
                    if (mMusicService != null) {
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null) {
                                    updateUIForSong(currentSong);
                                    if (mDisplayManager != null) {
                                        mDisplayManager.updateAlbumArt(currentSong.getPath());
                                    }
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            sendBroadcast(new Intent("DISPLAY_PLAYLIST"));
                        } else {
                            mMusicService.setPlaylist(null, false);
                            runOnUiThread(() -> applyNoSongState());
                        }
                    }
                }
            }
        };
        
        // SOFT_UPDATE_PLAYLIST receiver
        mSoftUpdatePlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "SOFT_UPDATE_PLAYLIST".equals(intent.getAction())) {
                    if (mMusicService != null && mMusicLibrary != null) {
                        mMusicLibrary.refreshCache();
                        final ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                        if (allSongs != null && !allSongs.isEmpty()) {
                            mMusicService.setPlaylist(allSongs, true);
                            runOnUiThread(() -> {
                                enableAllControls();
                                Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                                if (currentSong != null && mDisplayManager != null) {
                                    mDisplayManager.updateAlbumArt(currentSong.getPath());
                                }
                            });
                            sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                        } else {
                            mMusicService.stop();
                            mMusicService.setPlaylist(null, false);
                            final ArrayList<Song> emptyList = new ArrayList<>();
                            mMusicLibrary.refreshSongs(emptyList);
                            runOnUiThread(() -> {
                                applyNoSongState();
                                ToastManager.hidePersistentOverlay();
                                if (mDisplayManager != null) {
                                    mDisplayManager.hideLoadingOverlay();
                                }
                                sendBroadcast(new Intent("FORCE_UPDATE_PLAYER"));
                            });
                        }
                    }
                }
            }
        };
        
        // UPDATE_SONG_IN_PLAYLIST receiver
        mUpdateSongInPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && "UPDATE_SONG_IN_PLAYLIST".equals(intent.getAction())) {
                    final String songPath = intent.getStringExtra("song_path");
                    final boolean hasAlbumArt = intent.getBooleanExtra("has_album_art", false);
                    final boolean albumArtRemoved = intent.getBooleanExtra("album_art_removed", false);
                    final byte[] albumArtBytes = intent.getByteArrayExtra("album_art_bytes");
                    
                    if (songPath == null || mMusicService == null) return;
                    
                    final String title = intent.getStringExtra("title");
                    final String artist = intent.getStringExtra("artist");
                    final String album = intent.getStringExtra("album");
                    final String genre = intent.getStringExtra("genre");
                    
                    mMusicService.refreshMetadataForSong(songPath, title, artist, album, genre, albumArtBytes, albumArtRemoved);
                    
                    final Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                    if (currentSong != null && songPath.equals(currentSong.getPath())) {
                        if (mDisplayManager != null) {
                            if (albumArtRemoved) {
                                mDisplayManager.updateAlbumArt(songPath);
                            } else if (hasAlbumArt) {
                                mDisplayManager.updateAlbumArt(songPath);
                            }
                        }
                        updateUIForSong(currentSong);
                    }
                    
                    final Intent refreshDisplayIntent = new Intent("DISPLAY_PLAYLIST");
                    sendBroadcast(refreshDisplayIntent);
                    
                    Log.d(TAG, "Metadata updated for song: " + songPath);
                }
            }
        };
        
        // PLAYBACK_RECOVERED receiver
        mPlaybackRecoveryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("PLAYBACK_RECOVERED".equals(intent.getAction())) {
                    ToastManager.showToast(MusicPlayer.this, "Playback recovered", ToastManager.LENGTH_SHORT);
                }
            }
        };
        
        // SORT_MODE receiver
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    final int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, 0);
                    if (mMusicService != null && mMusicLibrary != null) {
                        runOnUiThread(() -> {
                            Song currentSong = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (currentSong != null) {
                                updateUIForSong(currentSong);
                            }
                        });
                        Log.d(TAG, "Sort mode update received, refreshed UI: " + newSortMode);
                    }
                }
            }
        };
        
        // PLAYER_STATUS_UPDATE receiver
        mPlayerStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_STATUS_UPDATE.equals(intent.getAction())) {
                    final String playerType = intent.getStringExtra("player_type");
                    if (playerType != null) {
                        runOnUiThread(() -> {
                            ToastManager.showToast(MusicPlayer.this, playerType + " is active...", ToastManager.LENGTH_NORMAL);
                        });
                    }
                }
            }
        };
        
        // SONG_PREPARED receiver
        mSongPreparedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_SONG_PREPARED.equals(intent.getAction())) {
                    final int duration = intent.getIntExtra("duration", 0);
                    final int audioSessionId = intent.getIntExtra("audio_session_id", -1);
                    final String songPath = intent.getStringExtra("song_path");
                    
                    Log.d(TAG, "SONG_PREPARED received: duration=" + duration + "ms, session=" + audioSessionId);
                    
                    runOnUiThread(() -> {
                        if (mTotalTime != null && duration > 0) {
                            mTotalTime.setText(DisplayManager.formatTime(duration));
                        }
                        
                        if (mSeekBar != null && duration > 0) {
                            mSeekBar.setMax(duration);
                            mSeekBar.setProgress(0);
                            if (mIsPlayerPrepared.get() && mSeekBar != null) {
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) {
                                    mThemeHelper.updateSeekBar(mSeekBar, true);
                                }
                            }
                        }
                        
                        if (mEqualizerButton != null) {
                            mEqualizerButton.setEnabled(true);
                            if (mThemeHelper != null) {
                                mThemeHelper.updateButton(mEqualizerButton, true);
                            }
                        }
                        
                        if (songPath != null && mMusicService != null) {
                            Song currentSong = mMusicService.getCurrentSong();
                            if (currentSong != null && songPath.equals(currentSong.getPath())) {
                                if (duration > 0) {
                                    currentSong.setDuration(duration);
                                }
                                updateUIForSong(currentSong);
                            }
                        }
                    });
                }
            }
        };
        
        // PLAYER_READY receiver
        mPlayerReadyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_PLAYER_READY.equals(intent.getAction())) {
                    runOnUiThread(() -> {
                        if (mPlayButton != null && mMusicLibrary != null && 
                            mMusicLibrary.getSongCount() > 0) {
                            Log.d(TAG, "PLAYER_READY broadcast received");
                        }
                    });
                }
            }
        };
        
        // POSITION_UPDATE receiver
        mPositionUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_PLAYER_POSITION.equals(intent.getAction())) {
                    int position = intent.getIntExtra("position", 0);
                    runOnUiThread(() -> {
                        if (mSeekBar != null && !mDisplayManager.isUserSeeking()) {
                            mSeekBar.setProgress(position);
                        }
                        if (mSeekTime != null) {
                            mSeekTime.setText(DisplayManager.formatTime(position));
                        }
                        Log.d(TAG, "Position updated on pause: " + position + "ms");
                    });
                }
            }
        };
        
        // FORCE_UI_REFRESH receiver
        mForceUiRefreshReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_FORCE_UI_REFRESH.equals(intent.getAction())) {
                    boolean refreshMetadata = intent.getBooleanExtra("refresh_metadata", false);
                    if (refreshMetadata && mMusicService != null) {
                        Song currentSong = mMusicService.getCurrentSong();
                        if (currentSong != null) {
                            runOnUiThread(() -> {
                                updateUIForSong(currentSong);
                                if (mDisplayManager != null) {
                                    mDisplayManager.updateAlbumArt(currentSong.getPath());
                                }
                                Log.d(TAG, "Force UI refresh completed for: " + currentSong.getTitle());
                            });
                        }
                    }
                }
            }
        };
        
        registerReceiverSafely(mUpdatePlayerReceiver, "UPDATE_PLAYER");
        registerReceiverSafely(mPlaySongReceiver, "PLAY_SONG");
        registerReceiverSafely(mBluetoothPlayReceiver, "BLUETOOTH_PLAY");
        registerReceiverSafely(mBluetoothPauseReceiver, "BLUETOOTH_PAUSE");
        registerReceiverSafely(mMediaButtonReceiver, "MEDIA_BUTTON_ACTION");
        registerReceiverSafely(mGetPlayingStateReceiver, "GET_PLAYING_STATE");
        registerReceiverSafely(mResetPlayerReceiver, "RESET_PLAYER_STATE");
        registerReceiverSafely(mForceUpdatePlayerReceiver, "FORCE_UPDATE_PLAYER");
        registerReceiverSafely(mSavePlayerStateNowReceiver, "SAVE_PLAYER_STATE_NOW");
        registerReceiverSafely(mBluetoothConnectionReceiver, "BLUETOOTH_CONNECTED");
        registerReceiverSafely(mSyncStartedReceiver, "SYNC_STARTED");
        registerReceiverSafely(mSyncCompleteReceiver, "SYNC_COMPLETE");
        registerReceiverSafely(mUpdatePlaylistFromFoldersReceiver, "UPDATE_PLAYLIST_FROM_FOLDERS");
        registerReceiverSafely(mSoftUpdatePlaylistReceiver, "SOFT_UPDATE_PLAYLIST");
        registerReceiverSafely(mUpdateSongInPlaylistReceiver, "UPDATE_SONG_IN_PLAYLIST");
        registerReceiverSafely(mPlaybackRecoveryReceiver, "PLAYBACK_RECOVERED");
        registerReceiverSafely(mSortModeReceiver, ACTION_UPDATE_SORT_MODE);
        registerReceiverSafely(mPlayerStatusReceiver, ACTION_PLAYER_STATUS_UPDATE);
        registerReceiverSafely(mSongPreparedReceiver, ACTION_SONG_PREPARED);
        registerReceiverSafely(mPlayerReadyReceiver, ACTION_PLAYER_READY);
        registerReceiverSafely(mPositionUpdateReceiver, ACTION_UPDATE_PLAYER_POSITION);
        registerReceiverSafely(mForceUiRefreshReceiver, ACTION_FORCE_UI_REFRESH);
    }
    
    /**
     * Safely registers a broadcast receiver with the given action.
     */
    private void registerReceiverSafely(@Nullable BroadcastReceiver receiver, @NonNull String action) {
        if (receiver == null) return;
        try {
            final IntentFilter filter = new IntentFilter();
            filter.addAction(action);
            registerReceiver(receiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Failed to register receiver for " + action, e);
        }
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     */
    private void unregisterReceiverSafely(@Nullable BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                // Ignore - receiver may already be unregistered
            }
        }
    }
    
    // ========================================================================
    // Listener Setup Methods
    // ========================================================================
    
    /**
     * Sets up the PlaybackController listener.
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        mPlaybackController.setListener(mPlaybackControllerListener);
        Log.d(TAG, "PlaybackController listener configured");
    }
    
    /**
     * Sets up click listeners for all UI buttons with debouncing.
     */
    private void setupListeners() {
        if (mPlayButton != null) {
            mPlayButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlayPauseClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlayPauseClickTime = currentTime;
                    togglePlayPause();
                }
            });
        }
        
        if (mNextButton != null) {
            mNextButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastNextClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastNextClickTime = currentTime;
                    playNextSong();
                }
            });
        }
        
        if (mPrevButton != null) {
            mPrevButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPrevClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPrevClickTime = currentTime;
                    playPreviousSong();
                }
            });
        }
        
        if (mRepeatButton != null) {
            mRepeatButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastRepeatClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastRepeatClickTime = currentTime;
                    if (mMusicService != null && mRepeatButton.isEnabled()) {
                        final int newMode = (mMusicService.getRepeatMode() + 1) % 3;
                        mMusicService.setRepeatMode(newMode);
                        updateRepeatButton();
                        final String msg = newMode == 0 ? "Repeat: OFF" : (newMode == 1 ? "Repeat: ALL" : "Repeat: ONE");
                        ToastManager.showToast(MusicPlayer.this, msg, ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mShuffleButton != null) {
            mShuffleButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastShuffleClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastShuffleClickTime = currentTime;
                    if (mMusicService != null && mShuffleButton.isEnabled()) {
                        final boolean newShuffle = !mMusicService.isShuffle();
                        mMusicService.setShuffle(newShuffle);
                        updateShuffleButton();
                        ToastManager.showToast(MusicPlayer.this, newShuffle ? "Shuffle: ON" : "Shuffle: OFF", ToastManager.LENGTH_NORMAL);
                    }
                }
            });
        }
        
        if (mManagerButton != null) {
            mManagerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastManagerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastManagerClickTime = currentTime;
                    openFolderManager();
                }
            });
        }
        
        if (mLlamaButton != null) {
            mLlamaButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastLlamaClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastLlamaClickTime = currentTime;
                    final View mainContent = findViewById(android.R.id.content);
                    mainContent.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_out_down));
                    final CreditsDialog dialog = new CreditsDialog(MusicPlayer.this);
                    dialog.setOnDismissListener(d -> {
                        final View content = findViewById(android.R.id.content);
                        content.startAnimation(AnimationUtils.loadAnimation(MusicPlayer.this, R.anim.slide_in_up));
                    });
                    dialog.show();
                }
            });
        }
    
        if (mPlaylistButton != null) {
            mPlaylistButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastPlaylistClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastPlaylistClickTime = currentTime;
                    openPlaylist();
                }
            });
        }
        
        if (mEqualizerButton != null) {
            mEqualizerButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastEqualizerClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastEqualizerClickTime = currentTime;
                    startActivity(new Intent(MusicPlayer.this, EqualizerActivity.class));
                }
            });
        }
        
        if (mMetadataButton != null) {
            mMetadataButton.setOnClickListener(v -> {
                final long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - mLastMetadataClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                    mLastMetadataClickTime = currentTime;
                    openMetadataEditor();
                }
            });
        }
    }
}