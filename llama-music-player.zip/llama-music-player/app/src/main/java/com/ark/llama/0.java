package com.ark.llama;

// ... (all unaffected imports and code remain the same) ...

public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    private static final String TAG = "MusicPlayer";
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int FOLDER_SELECT_CODE = 200;
    private static final int BATTERY_OPTIMIZATION_REQUEST_CODE = 300;
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String ACTION_RESTART_APP = "com.ark.llama.RESTART_APP";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    private static final int MAX_CACHE_SIZE_MB = 50;
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    private static final long LOADING_OVERLAY_DELAY_MS = 1500;
    private static final long PLAY_PAUSE_UPDATE_DELAY_MS = 50;
    private static final long NEXT_PREV_UPDATE_DELAY_MS = 100;
    private static final long FOCUS_SCROLL_DELAY_MS = 500;
    private static final long TIME_UPDATE_INTERVAL_MS = 500;
    private static final int SEEK_RESET_DELAY_MS = 300;  // ADDED: Delay for seek flag reset
    private static final int BUFFER_SIZE = 8192;
    private static final int MAX_TITLE_LENGTH = 40;
    private static final int MAX_ARTIST_LENGTH = 35;
    private static final String ELLIPSIS = "...";
    private static final int ALBUM_ART_FADE_DURATION_MS = 250;
    private static final int BUTTON_ANIMATION_DURATION_MS = 80;
    private static final float BUTTON_SCALE_DOWN = 0.97f;
    private static final float BUTTON_SCALE_NORMAL = 1.0f;
    private static final int DIM_ALPHA = 180;
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;

    // ... (all unaffected member variables remain the same) ...

    // ========================================================================
    // Playlist Loading Method (MODIFIED - removed play button disable)
    // ========================================================================
    
    /**
     * Loads the full playlist asynchronously and sets it on MusicService.
     * 
     * <p>This method no longer disables the play button during loading.
     * The play button is now enabled via the PLAYER_READY broadcast when
     * SoundTouchPlayer finishes preparing the first song.</p>
     */
    private void loadFullPlaylistInBackground() {
        if (mMusicLibrary == null) return;
        
        mMusicLibrary.loadAllSongsAsync(new MusicLibrary.OnSongsLoadedListener() {
            @Override
            public void onSongsLoaded(ArrayList<Song> songs) {
                if (mMusicService != null) {
                    mMusicService.setPlaylist(songs, true);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // REMOVED: if (mPlayButton != null && !songs.isEmpty()) {
                            // REMOVED:     mPlayButton.setEnabled(false);
                            // REMOVED: }
                            
                            Song current = (mMusicService != null) ? mMusicService.getCurrentSong() : null;
                            if (current != null && mSongTitle != null && mSongArtist != null && mThemeHelper != null) {
                                mSongTitle.setText(current.getTitle());
                                mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                                mSongArtist.setText(current.getArtist());
                                mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                                updateAlbumArt(current.getPath());
                            }
                            
                            updatePlayPauseButton();
                            setupSeekBar();
                            updateTimeDisplay();
                        }
                    });
                }
                hideLoadingOverlay();
            }

            @Override
            public void onLoadingError(String error) {
                Log.e(TAG, "Error loading full playlist: " + error);
                hideLoadingOverlay();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.showToast(MusicPlayer.this, "Error loading playlist: " + error, ToastManager.LENGTH_LONG);
                    }
                });
            }
        });
    }

    // ========================================================================
    // Playback Control Method (MODIFIED - improved state handling)
    // ========================================================================
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method handles three distinct cases:
     * <ol>
     *   <li>Currently playing -> pause</li>
     *   <li>Paused but prepared -> resume</li>
     *   <li>No song prepared -> start new playback from current index or first song</li>
     * </ol>
     * </p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        // Case 1: Currently playing - pause
        if (mMusicService != null && mMusicService.isAnyPlayerPlaying()) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
            updatePlayPauseButton();
            return;
        }
        
        // Case 2: Paused but prepared - resume
        if (mMusicService != null && mMusicService.isAnyPlayerPrepared() && !mMusicService.isAnyPlayerPlaying()) {
            Log.d(TAG, "togglePlayPause: Resuming playback");
            mMusicService.resume();
            updatePlayPauseButton();
            return;
        }
        
        // Case 3: Need to start new playback (no song prepared)
        if (mMusicService != null && mMusicLibrary != null) {
            ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
            if (allSongs != null && !allSongs.isEmpty()) {
                int currentIndex = mMusicService.getCurrentIndex();
                String songPath = null;
                
                if (currentIndex >= 0 && currentIndex < allSongs.size()) {
                    Song song = allSongs.get(currentIndex);
                    if (song != null) {
                        songPath = song.getPath();
                    }
                }
                
                // If no valid current index, play first song
                if (songPath == null && allSongs.size() > 0) {
                    Song firstSong = allSongs.get(0);
                    if (firstSong != null) {
                        songPath = firstSong.getPath();
                    }
                }
                
                if (songPath != null) {
                    Log.d(TAG, "togglePlayPause: Starting new playback for: " + songPath);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                    mMusicService.playSongByPath(songPath);
                    
                    // Give service time to start, then update button
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updatePlayPauseButton();
                        }
                    }, 200);
                } else {
                    Log.w(TAG, "togglePlayPause: No valid song path found");
                }
            } else {
                Log.w(TAG, "togglePlayPause: No songs in playlist");
                ToastManager.showToast(this, "No songs in playlist. Use MANAGER to import music.", ToastManager.LENGTH_NORMAL);
            }
        } else {
            Log.w(TAG, "togglePlayPause: MusicService is null");
        }
    }

    // ========================================================================
    // SeekBar Setup Method (MODIFIED - improved seek handling)
    // ========================================================================
    
    /**
     * Sets up the SeekBar listener for position seeking.
     * 
     * <p>This method implements proper seek handling with a reset delay
     * to ensure the seekbar continues updating after a seek operation.
     * When a user finishes seeking, the flag is reset after SEEK_RESET_DELAY_MS
     * and the UI is forced to update with the current position.</p>
     */
    private void setupSeekBar() {
        if (mSeekBar == null) return;
        
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mMusicService != null && seekBar.isEnabled()) {
                    if (mSeekTime != null) {
                        mSeekTime.setText(formatTime(progress));
                    }
                    mSeekTargetPosition = progress;
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mIsUserSeeking = true;
                mSeekHandler.removeCallbacksAndMessages(null);
                Log.d(TAG, "Seek started - UI updates paused");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mMusicService != null && seekBar.isEnabled() && mSeekTargetPosition >= 0) {
                    final int seekPos = mSeekTargetPosition;
                    
                    Log.d(TAG, "Seek requested to: " + seekPos + "ms");
                    mMusicService.seekTo(seekPos);
                    
                    if (mSeekTime != null) {
                        mSeekTime.setText(formatTime(seekPos));
                    }
                    
                    if (mSeekBar != null) {
                        mSeekBar.setProgress(seekPos);
                    }
                    
                    mSeekTargetPosition = -1;
                    
                    // Remove any pending reset callbacks
                    mSeekHandler.removeCallbacksAndMessages(null);
                    
                    // Reset the seeking flag after a delay and force UI update
                    mSeekHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mIsUserSeeking = false;
                            Log.d(TAG, "Seek flag reset - UI updates resumed");
                            
                            // Force an immediate position update after seek flag clears
                            if (mSeekBar != null && mMusicService != null) {
                                int currentPos = mMusicService.getCurrentPosition();
                                mSeekBar.setProgress(currentPos);
                                if (mSeekTime != null) {
                                    mSeekTime.setText(formatTime(currentPos));
                                }
                            }
                        }
                    }, SEEK_RESET_DELAY_MS);
                } else {
                    mIsUserSeeking = false;
                    mSeekTargetPosition = -1;
                }
            }
        });
    }

    // ========================================================================
    // Time Display Method (MODIFIED - seek-aware updates)
    // ========================================================================
    
    /**
     * Starts a recurring handler to update time display and SeekBar position.
     * 
     * <p>This method is seek-aware: during user seeking, it shows the target
     * position instead of querying the service. Once seeking ends, it resumes
     * normal position updates from the service. This provides smooth visual
     * feedback during seek operations without jarring position jumps.</p>
     */
    private void updateTimeDisplay() {
        if (mTimeHandler != null) {
            mTimeHandler.removeCallbacksAndMessages(null);
        }
        
        mTimeHandler = new Handler(Looper.getMainLooper());
        final Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                
                final MusicService service = mMusicService;
                if (service == null) {
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                    }
                    return;
                }
                
                // During user seek, show target position but don't update from service
                if (mIsUserSeeking) {
                    if (mSeekTargetPosition >= 0 && mSeekTime != null) {
                        mSeekTime.setText(formatTime(mSeekTargetPosition));
                    }
                    if (mTimeHandler != null) {
                        mTimeHandler.postDelayed(this, 100);
                    }
                    return;
                }
                
                try {
                    if (service.isAnyPlayerPrepared()) {
                        int currentPosition = service.getCurrentPosition();
                        int duration = service.getDuration();
                        
                        if (duration > 0) {
                            if (mSeekTime != null) {
                                mSeekTime.setText(formatTime(currentPosition));
                            }
                            if (mTotalTime != null) {
                                mTotalTime.setText(formatTime(duration));
                            }
                            
                            if (mSeekBar != null && mSeekBar.isEnabled()) {
                                if (mSeekBar.getMax() != duration) {
                                    mSeekBar.setMax(duration);
                                }
                                // Only update if not seeking
                                if (!mIsUserSeeking) {
                                    mSeekBar.setProgress(currentPosition);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error updating time display", e);
                }
                
                if (mTimeHandler != null) {
                    mTimeHandler.postDelayed(this, TIME_UPDATE_INTERVAL_MS);
                }
            }
        };
        mTimeHandler.post(timeRunnable);
    }

    // ... (all unaffected code after these methods remains the same) ...
}