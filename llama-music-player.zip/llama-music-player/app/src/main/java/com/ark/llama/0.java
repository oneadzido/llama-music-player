/**
 * Pauses playback.
 * Notifies PlaybackController on failure.
 */
public void pause() {
    // Cache position before pausing to prevent seek bar reset
    if (mPlaybackController != null) {
        mPlaybackController.onPause();
        
        // FIX: Update time display immediately from cached position
        if (mSeekTime != null) {
            mSeekTime.setText(formatTime((int) mPlaybackController.getCurrentPosition()));
        }
    }
    
    if (mLlamaPlayer != null && mIsUsingLlamaPlayer && mLlamaPlayer.isPlaying()) {
        mLlamaPlayer.pause();
        savePlayingState();
        savePlayerState();
        saveFullState();
        return;
    }
    
    stopHealthMonitoring();
    synchronized (mPlayerLock) {
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.pause();
                    
                    // FIX: Also update here for MediaPlayer fallback
                    if (mSeekTime != null && mPlaybackController != null) {
                        mSeekTime.setText(formatTime((int) mPlaybackController.getCurrentPosition()));
                    }
                } else {
                    Log.d(TAG, "pause called but MediaPlayer already paused");
                }
            } catch (IllegalStateException e) {
                Log.e(TAG, "pause error", e);
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("pause", e.getMessage());
                }
            }
            setPlaybackState(false, true);
            savePlayingState();
            savePlayerState();
            saveFullState();
        } else {
            Log.d(TAG, "pause called but no player available");
        }
    }
}