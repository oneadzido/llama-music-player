package com.ark.llama;

// ... all existing imports remain unchanged ...

public class MusicPlayer extends Activity implements NavigationController.ButtonStateListener {

    // =========================================================================
    // Constants (unchanged - skipped)
    // =========================================================================
    
    // ... all existing member variables remain unchanged ...
    
    // =========================================================================
    // PlaybackController Setup
    // =========================================================================
    
    /**
     * Sets up the PlaybackController listener for UI updates.
     * This replaces the old position polling mechanism with event-driven updates.
     */
    private void setupPlaybackControllerListener() {
        if (mPlaybackController == null) return;
        
        mPlaybackControllerListener = new PlaybackController.PlaybackControllerListener() {
            @Override
            public void onPositionChanged(long positionMs, long durationMs) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || mIsUserSeeking) return;
                    if (mSeekBar != null && mSeekBar.isEnabled()) {
                        if (mSeekBar.getMax() != (int) durationMs && durationMs > 0)
                            mSeekBar.setMax((int) durationMs);
                        mSeekBar.setProgress((int) positionMs);
                    }
                    if (mSeekTime != null) mSeekTime.setText(formatTime((int) positionMs));
                    if (mTotalTime != null && durationMs > 0) mTotalTime.setText(formatTime((int) durationMs));
                });
            }
            
            @Override
            public void onPlayStateChanged(boolean isPlaying) {
                runOnUiThread(() -> { 
                    if (!isFinishing() && !isDestroyed()) {
                        if (mPlayButton != null && mThemeHelper != null) {
                            mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                    }
                });
            }
            
            @Override
            public void onSongChanged(String title, String artist, String path, long duration) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    
                    if (mSongTitle != null) {
                        String t = title != null ? title : "Unknown";
                        if (t.length() > MAX_TITLE_LENGTH) t = t.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
                        mSongTitle.setText(t);
                        if (mThemeHelper != null) mSongTitle.setTextColor(mThemeHelper.getThemeColorInt());
                    }
                    
                    if (mSongArtist != null) {
                        String a = artist != null ? artist : "Unknown";
                        if (a.length() > MAX_ARTIST_LENGTH) a = a.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
                        mSongArtist.setText(a);
                        mSongArtist.setTextColor(Color.parseColor("#C0C0C0"));
                    }
                    
                    if (mSeekBar != null && duration > 0) {
                        mSeekBar.setMax((int) duration);
                        mSeekBar.setProgress(0);
                        mSeekBar.setEnabled(true);
                        if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, true);
                    }
                    
                    if (mTotalTime != null && duration > 0) mTotalTime.setText(formatTime((int) duration));
                    if (mSeekTime != null) mSeekTime.setText("00:00");
                    
                    updateAlbumArt(path);
                    
                    // Only set button to PLAY if the song is NOT playing
                    if (mPlayButton != null && mThemeHelper != null) {
                        boolean isPlaying = false;
                        if (mMusicService != null) {
                            isPlaying = mMusicService.isAnyPlayerPlaying();
                        } else if (mPlaybackController != null) {
                            isPlaying = mPlaybackController.isPlaying();
                        }
                        
                        if (!isPlaying) {
                            mPlayButton.setText(FontAwesome.PLAY);
                            mThemeHelper.updateControlButton(mPlayButton, true, true);
                        }
                    }
                });
            }
            
            @Override
            public void onPreparedStateChanged(boolean isPrepared) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        if (isPrepared && mPlaybackController != null) {
                            long duration = mPlaybackController.getDuration();
                            if (mTotalTime != null && duration > 0) {
                                mTotalTime.setText(formatTime((int) duration));
                            }
                            if (mSeekBar != null && duration > 0) {
                                mSeekBar.setMax((int) duration);
                                mSeekBar.setEnabled(true);
                                if (mThemeHelper != null) mThemeHelper.updateSeekBar(mSeekBar, true);
                            }
                        }
                    }
                });
            }
        };
        
        mPlaybackController.setListener(mPlaybackControllerListener);
    }
    
    // =========================================================================
    // Playback Control Methods (partial - only togglePlayPause shown for context)
    // =========================================================================
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method handles three distinct cases:
     * <ol>
     *   <li>Currently playing -> pause</li>
     *   <li>Paused but prepared -> resume</li>
     *   <li>No song prepared -> start new playback from current index or first song</li>
     * </ol>
     * </p>
     */
    private void togglePlayPause() {
        if (mPlayButton == null || !mPlayButton.isEnabled()) {
            Log.d(TAG, "togglePlayPause: Play button not enabled, ignoring");
            return;
        }
        
        if (mMusicService == null) {
            Log.w(TAG, "togglePlayPause: MusicService is null");
            return;
        }
        
        // Get actual playback state from music service
        boolean isPlaying = mMusicService.isAnyPlayerPlaying();
        boolean isPrepared = mMusicService.isAnyPlayerPrepared();
        
        if (isPlaying) {
            Log.d(TAG, "togglePlayPause: Pausing playback");
            mMusicService.pause();
        } else if (isPrepared) {
            Log.d(TAG, "togglePlayPause: Starting/resuming playback");
            mMusicService.resume();
        } else {
            // Nothing prepared – start new playback
            if (mMusicLibrary != null) {
                ArrayList<Song> allSongs = mMusicLibrary.getAllSongs();
                if (allSongs != null && !allSongs.isEmpty()) {
                    int index = mMusicService.getCurrentIndex();
                    if (index < 0 || index >= allSongs.size()) index = 0;
                    Log.d(TAG, "togglePlayPause: Starting new playback at index " + index);
                    mMusicService.playSong(index, true);
                    ToastManager.showToast(this, "Loading...", ToastManager.LENGTH_SHORT);
                }
            }
        }
        
        // Force immediate button update after action
        updatePlayPauseButton();
    }
    
    // =========================================================================
    // Button State Update Methods
    // =========================================================================
    
    /**
     * Updates the play/pause button appearance based on current playback state.
     */
    private void updatePlayPauseButton() {
        if (mPlayButton == null || isFinishing() || isDestroyed() || mThemeHelper == null) return;
        
        // Check if we have songs
        boolean hasSongs = (mMusicLibrary != null && mMusicLibrary.getSongCount() > 0);
        
        if (!hasSongs) {
            mPlayButton.setText(FontAwesome.PLAY);
            mPlayButton.setEnabled(false);
            mThemeHelper.updateControlButton(mPlayButton, false, false);
            return;
        }
        
        // Get playback state
        boolean isPlaying = false;
        if (mPlaybackController != null) {
            isPlaying = mPlaybackController.isPlaying();
        } else if (mMusicService != null) {
            isPlaying = mMusicService.isAnyPlayerPlaying();
        }
        
        // Update for normal state
        mPlayButton.setEnabled(true);
        mPlayButton.setText(isPlaying ? FontAwesome.PAUSE : FontAwesome.PLAY);
        mThemeHelper.updateControlButton(mPlayButton, true, true);
    }
    
    // =========================================================================
    // Playback Control Methods (Next/Previous)
    // =========================================================================
    
    /**
     * Plays the next song in the playlist.
     */
    private void playNextSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mNextButton != null && mNextButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playNext();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    private void playPreviousSong() {
        if (!mControlsTransitioning.compareAndSet(false, true)) return;
        try {
            if (mPrevButton != null && mPrevButton.isEnabled()) {
                safeCallService(new Runnable() {
                    @Override
                    public void run() {
                        mMusicService.playPrevious();
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!isFinishing() && !isDestroyed()) {
                                    updatePlayPauseButton();
                                }
                            }
                        }, NEXT_PREV_UPDATE_DELAY_MS);
                    }
                });
            }
        } finally {
            mControlsTransitioning.set(false);
        }
    }
    
    // ... rest of file unchanged ...
}