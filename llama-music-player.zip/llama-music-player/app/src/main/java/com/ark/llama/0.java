// File: MusicService.java
// ============================================================================
// Affected Methods: playSongWithLlamaPlayerSilent, prepareAndPlaySilent, prepareOnlySilent
// ============================================================================

package com.ark.llama;

// ... (imports remain unchanged - same as original) ...

public class MusicService extends Service {

    // ========================================================================
    // Constants (unchanged - same as original)
    // ========================================================================
    
    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";
    private static final int NOTIFICATION_ID = 1;
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_LAST_PLAYING = "last_playing";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    private static final String EXTRA_SORT_MODE = "sort_mode";
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    private static final int HEALTH_CHECK_INTERVAL_MS = 1500;
    private static final int MAX_STALL_TIME_MS = 3000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    private static final int PRE_INIT_DELAY_MS = 100;
    private static final int SEEK_RESET_DELAY_MS = 250;
    private static final int PREPARE_TIMEOUT_MS = 500;
    private static final int MEDIA_PLAYER_POLLING_INTERVAL_MS = 150;
    
    // ========================================================================
    // Sort Mode Constants (unchanged)
    // ========================================================================
    
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members (unchanged)
    // ========================================================================
    
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // LlamaPlayer Members (PRIMARY PLAYER)
    // ========================================================================
    
    private LlamaPlayer mLlamaPlayer;
    private boolean mIsUsingLlamaPlayer = false;
    private boolean mLlamaPlayerFailed = false;
    private final AtomicBoolean mIsPreparingLlamaPlayer = new AtomicBoolean(false);
    private final Handler mPrepareTimeoutHandler = new Handler(Looper.getMainLooper());
    private Runnable mPrepareTimeoutRunnable = null;
    private boolean mShouldStartAfterPrepare = false;
    
    // ========================================================================
    // MediaPlayer Members (FALLBACK PLAYER)
    // ========================================================================
    
    private MediaPlayer mMediaPlayer;
    private Handler mMediaPlayerPollingHandler;
    private Runnable mMediaPlayerPollingRunnable;
    private boolean mIsPollingForMediaPlayer = false;
    
    // ========================================================================
    // Playback State
    // ========================================================================
    
    private ArrayList<Song> mCurrentPlaylist;
    private volatile int mCurrentIndex = -1;
    private volatile boolean mIsPlaying = false;
    private volatile int mRepeatMode = 0;
    private volatile boolean mIsShuffle = false;
    private long mPlaybackStartTime = 0;
    private int mPendingRestorePosition = 0;
    private int mCurrentSortMode = SORT_TITLE_AZ;
    private Handler mHealthHandler;
    private Runnable mHealthCheckRunnable;
    private int mRecoveryAttempts = 0;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    private AudioManager mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    private AudioFocusRequest mAudioFocusRequest;
    
    // ========================================================================
    // Media Session
    // ========================================================================
    
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    private final Object mPlayerLock = new Object();
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparingFallback = new AtomicBoolean(false);
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    private volatile int mCurrentPrepId = -1;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private boolean mIsRestoringPlayback = false;
    
    // ========================================================================
    // PlaybackController
    // ========================================================================
    
    @Nullable
    private PlaybackController mPlaybackController;
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    private ArrayList<Integer> mShuffleHistory;
    private Random mRandom;
    private ArrayList<Song> mPendingPlaylist = null;
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ... (Comparator classes unchanged) ...
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    @Override
    public void onCreate() {
        // ... existing implementation unchanged ...
    }
    
    private void createForegroundNotificationChannel() {
        // ... existing implementation unchanged ...
    }
    
    private Notification createMinimalForegroundNotification() {
        // ... existing implementation unchanged ...
    }
    
    private void initLlamaPlayer() {
        // ... existing implementation unchanged ...
    }
    
    private void startMediaPlayerPolling() {
        // ... existing implementation unchanged ...
    }
    
    private void stopMediaPlayerPolling() {
        // ... existing implementation unchanged ...
    }
    
    private void setPlaybackState(boolean isPlaying, boolean isPrepared) {
        // ... existing implementation unchanged ...
    }
    
    private void handleLlamaPlayerStateChange(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
        // ... existing implementation unchanged ...
    }
    
    private void sendPlayerStatusBroadcast(boolean isLlamaPlayerActive) {
        // ... existing implementation unchanged ...
    }
    
    private void fallbackToMediaPlayer() {
        // ... existing implementation unchanged ...
    }
    
    private void preInitializeCurrentSong() {
        // ... existing implementation unchanged ...
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // ... existing implementation unchanged ...
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    @Override
    public void onDestroy() {
        // ... existing implementation unchanged ...
    }
    
    @Override
    public void onTrimMemory(int level) {
        // ... existing implementation unchanged ...
    }
    
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Public API Methods for MusicPlayer
    // ========================================================================
    
    public boolean isAnyPlayerPlaying() {
        // ... existing implementation unchanged ...
    }
    
    public boolean isAnyPlayerPrepared() {
        // ... existing implementation unchanged ...
    }
    
    public boolean isUsingLlamaPlayer() {
        return mIsUsingLlamaPlayer;
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    private void loadSortMode() {
        // ... existing implementation unchanged ...
    }
    
    private void saveSortMode() {
        // ... existing implementation unchanged ...
    }
    
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        // ... existing implementation unchanged ...
    }
    
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    private void reorderPlaylistByCurrentSort() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    private void registerNotificationReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void registerPlaybackParamsReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void registerClearPlaylistReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void registerThemeReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void registerGetPlayingStateReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void registerSortModeReceiver() {
        // ... existing implementation unchanged ...
    }
    
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // ========================================================================
    
    private void removeAllListeners(MediaPlayer player) {
        // ... existing implementation unchanged ...
    }
    
    private void resetPlayerSafely() {
        // ... existing implementation unchanged ...
    }
    
    private void releaseMediaPlayer() {
        // ... existing implementation unchanged ...
    }
    
    private MediaPlayer getOrCreatePlayer() {
        // ... existing implementation unchanged ...
    }
    
    private boolean isPlayerReady() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // ========================================================================
    
    private void startHealthMonitoring() {
        // ... existing implementation unchanged ...
    }
    
    private void stopHealthMonitoring() {
        // ... existing implementation unchanged ...
    }
    
    private void checkPlaybackHealth() {
        // ... existing implementation unchanged ...
    }
    
    private void recoverFromStall() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Async Operation Management
    // ========================================================================
    
    private void invalidateAllPreparations() {
        // ... existing implementation unchanged ...
    }
    
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    private void updateNotificationPlaybackState(boolean isPlaying) {
        // ... existing implementation unchanged ...
    }
    
    private void createNotification() {
        // ... existing implementation unchanged ...
    }
    
    public void refreshNotification() {
        // ... existing implementation unchanged ...
    }
    
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    public void savePlayerState() {
        // ... existing implementation unchanged ...
    }
    
    private void saveFullState() {
        // ... existing implementation unchanged ...
    }
    
    public int getSavedPosition() {
        // ... existing implementation unchanged ...
    }
    
    public boolean wasPlayingBeforeRestart() {
        // ... existing implementation unchanged ...
    }
    
    public String getSavedSongPath() {
        // ... existing implementation unchanged ...
    }
    
    private void saveCurrentPlayingIndex() {
        // ... existing implementation unchanged ...
    }
    
    private void savePlayingState() {
        // ... existing implementation unchanged ...
    }
    
    private void loadRepeatAndShuffle() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Sets the current playlist.
     * Prevents audio glitches during sync by preserving AudioTrack.
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        // ... existing implementation unchanged - already fixed ...
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Soft updates the playlist for next transition.
     *
     * @param newPlaylist The new playlist to apply on next transition
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Immediately updates the UI with song information without waiting for preparation.
     * Called when a track change is initiated by user action.
     *
     * @param index The index of the song to display
     */
    private void updateUIImmediately(int index) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays a song with SoundTouch-based LlamaPlayer.
     *
     * @param index Index of song to play
     * @param autoStart Whether to start playback immediately after preparation
     */
    private void playSongWithLlamaPlayer(int index, boolean autoStart) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays a song at the specified index with auto-start option.
     *
     * @param index The song index in the current playlist
     * @param autoStart Whether to start playback immediately
     */
    public synchronized void playSong(int index, boolean autoStart) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays a song at the specified index (auto-starts by default).
     *
     * @param index The song index in the current playlist
     */
    public synchronized void playSong(int index) {
        playSong(index, true);
    }
    
    /**
     * Prepares and starts playback using MediaPlayer (FALLBACK).
     *
     * @param index The song index
     * @param seekPosition The position to seek to
     */
    private void prepareAndPlay(int index, int seekPosition) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Prepares a song without starting playback, using MediaPlayer (FALLBACK).
     *
     * @param index The song index to prepare
     */
    private void prepareOnly(int index) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to
     */
    public synchronized void playSongAtPosition(int index, int position) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The file path of the song to play
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays the next song in the playlist.
     * 
     * <p>This method handles the transition to the next song, respecting
     * shuffle mode if enabled. If a pending playlist exists, it is applied
     * before playing the next song.</p>
     */
    public synchronized void playNext() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Plays the previous song in the playlist.
     * 
     * <p>This method handles the transition to the previous song, respecting
     * shuffle history if shuffle mode is enabled. If a pending playlist exists,
     * it is applied before playing the previous song.</p>
     */
    public synchronized void playPrevious() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        // ... existing implementation unchanged ...
    }

    /**
     * Pauses playback.
     */
    public void pause() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Resumes playback from a paused state.
     */
    public void resume() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Stops playback and resets the player.
     */
    public void stop() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Seeks to the specified position in the current song.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Playback Parameter Methods
    // ========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from EqualizerManager.
     */
    public void updatePlaybackParams() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>This method is called when the current song finishes playing.
     * It determines the next action based on repeat mode, shuffle mode,
     * and playlist size. If repeat one is enabled, the song replays from
     * the beginning. If repeat all is enabled, it advances to the next song.
     * If at the end of the playlist, playback stops.</p>
     */
    private void handleCompletion() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Broadcasts song completion with full duration for UI seekbar fill.
     */
    private void broadcastSongCompletion() {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration
     */
    public int getDuration() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song
     */
    public Song getCurrentSong() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Updates MediaSession metadata (song title, artist, album) for lock screen display.
     * 
     * <p>This method sets the current song information on the MediaSession so that
     * the system can display it on the lock screen, in notifications, and on
     * connected devices like Android Auto or Wear OS. Without this, the lock screen
     * would show "LlamaMusicService" instead of the actual song title.</p>
     * 
     * <p>Call this method whenever the current song changes, including:</p>
     * <ul>
     *   <li>When a new song starts playing (playSong, playNext, playPrevious)</li>
     *   <li>When metadata is edited (refreshMetadataForSong)</li>
     *   <li>When the player is prepared (onPrepared callback)</li>
     * </ul>
     */
    private void updateMediaSessionMetadata() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Sets up audio focus for proper audio ducking.
     */
    private void setupAudioFocus() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     *
     * @param songPath The path of the song
     * @param newTitle The new title
     * @param newArtist The new artist
     * @param newAlbum The new album
     * @param newGenre The new genre
     * @param albumArtBytes The new album art bytes
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Handles the close action from the notification.
     */
    private void handleCloseAction() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Requests audio focus from the system.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Broadcasts a playback state update to activities.
     */
    private void broadcastUpdate() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        // ... existing implementation unchanged ...
    }
    
    /**
     * Handles audio focus changes.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        // ... existing implementation unchanged ...
    }
    
    // ========================================================================
    // NEW SILENT METHODS (Prevent audio glitches during sync)
    // ========================================================================
    
    /**
     * Plays a song with LlamaPlayer without audio glitches (preserves AudioTrack and position).
     */
    private void playSongWithLlamaPlayerSilent(int index, boolean autoStart) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            return;
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "playSongWithLlamaPlayerSilent");
        }
        
        try {
            // Save current playback position before changing song
            final int savedPosition = (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) 
                ? (int) mLlamaPlayer.getCurrentPosition() : getSavedPosition();
            
            mCurrentIndex = index;
            
            // Instead of resetting which flushes AudioTrack, just change the data source
            // This prevents audio glitches during sync
            if (mLlamaPlayer != null) {
                mLlamaPlayer.setDataSource(song.getPath());
                mLlamaPlayer.prepareAsync();
                mShouldStartAfterPrepare = autoStart;
                
                // Restore position after prepare completes
                if (savedPosition > 0 && autoStart) {
                    mMainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                                mLlamaPlayer.seekTo(savedPosition);
                                Log.d(TAG, "playSongWithLlamaPlayerSilent: Restored position to " + savedPosition + "ms");
                            }
                        }
                    }, 100);
                }
                
                Log.d(TAG, "playSongWithLlamaPlayerSilent: Updated song without resetting AudioTrack, saved position=" + savedPosition);
            }
            
            createNotification();
            broadcastUpdate();
            savePlayerState();
            
        } catch (Exception e) {
            Log.e(TAG, "playSongWithLlamaPlayerSilent failed", e);
            fallbackToMediaPlayer();
        }
    }
    
    /**
     * Prepares and plays using MediaPlayer without audio glitches.
     */
    private void prepareAndPlaySilent(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null) return;
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "prepareAndPlaySilent");
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            
            // Don't reset if we're continuing playback - prevents audio glitch
            boolean wasPlayingTemp = false;
            try {
                wasPlayingTemp = player.isPlaying();
            } catch (Exception ignored) {
                // wasPlayingTemp already false
            }
            final boolean wasPlaying = wasPlayingTemp;
            
            if (!wasPlaying) {
                player.reset();
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        try {
                            if (finalSeek > 0 && finalSeek < mp.getDuration()) {
                                mp.seekTo(finalSeek);
                            }
                            
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mCurrentIndex = finalIndex;
                            saveCurrentPlayingIndex();
                            
                            if (wasPlaying) {
                                // Continue playback without glitch
                                mp.start();
                            }
                            
                            if (mPlaybackController != null) {
                                mPlaybackController.setPrepared(true, "prepareAndPlaySilent");
                                mPlaybackController.setDuration(mp.getDuration(), "prepareAndPlaySilent");
                                if (wasPlaying) {
                                    mPlaybackController.setPlaying(true, "prepareAndPlaySilent");
                                }
                            }
                            
                            broadcastUpdate();
                            createNotification();
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareAndPlaySilent onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            Log.e(TAG, "prepareAndPlaySilent failed", e);
        }
    }
    
    /**
     * Prepares a song without starting playback, without audio glitches.
     */
    private void prepareOnlySilent(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            
            // Don't reset if we're continuing - prevents audio glitch
            boolean wasPlayingTemp = false;
            try {
                wasPlayingTemp = player.isPlaying();
            } catch (Exception ignored) {
                // wasPlayingTemp already false
            }
            final boolean wasPlaying = wasPlayingTemp;
            
            if (!wasPlaying) {
                player.reset();
            }
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            if (mPlaybackController != null) {
                                mPlaybackController.setPrepared(true, "prepareOnlySilent");
                                mPlaybackController.setDuration(mp.getDuration(), "prepareOnlySilent");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnlySilent onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            Log.e(TAG, "prepareOnlySilent failed", e);
        }
    }
}

// ============================================================================
// End of MusicService.java - Affected Methods
// ============================================================================