package com.ark.llama;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Custom toast notification manager with theme support.
 * 
 * <p>This class provides a custom toast implementation using styled overlays
 * instead of system Toasts, with theme color integration and fade animations.</p>
 * 
 * <p>Features:
 * <ul>
 *   <li>Custom-styled overlays matching app theme</li>
 *   <li>Support for both Activity and ViewGroup targets</li>
 *   <li>Fade in/out animations</li>
 *   <li>Theme color integration</li>
 *   <li>Global theme update via broadcast receiver</li>
 *   <li>True persistent overlay that stays until explicitly hidden</li>
 * </ul>
 * </p>
 * 
 * <p><b>Usage Example:</b>
 * <pre>
 * // Initialize in Application class
 * ToastManager.init(getApplicationContext());
 * 
 * // Show temporary toast
 * ToastManager.showToast(activity, "Operation completed");
 * 
 * // Show persistent overlay
 * ToastManager.showPersistentOverlay(activity, "Loading...");
 * 
 * // Update persistent overlay text
 * ToastManager.updatePersistentOverlay("Syncing files...");
 * 
 * // Hide persistent overlay
 * ToastManager.hidePersistentOverlay();
 * </pre>
 * </p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class ToastManager {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Short duration: 500 milliseconds */
    public static final int LENGTH_SHORT = 500;
    
    /** Normal duration: 1000 milliseconds */
    public static final int LENGTH_NORMAL = 1000;
    
    /** Long duration: 2000 milliseconds */
    public static final int LENGTH_LONG = 2000;
    
    /** Duration for fade in/out animations (milliseconds) */
    private static final int FADE_DURATION_MS = 150;
    
    /** Maximum toast width in density-independent pixels */
    private static final int MAX_TOAST_WIDTH_DP = 320;
    
    /** Horizontal padding for toast content (dp) */
    private static final int TOAST_PADDING_HORIZONTAL_DP = 16;
    
    /** Vertical padding for toast content (dp) */
    private static final int TOAST_PADDING_VERTICAL_DP = 8;
    
    /** Bottom margin from screen edge (dp) */
    private static final int TOAST_BOTTOM_MARGIN_DP = 76;
    
    /** Corner radius for toast background (dp) */
    private static final int TOAST_CORNER_RADIUS_DP = 5;
    
    /** Stroke width for toast border (dp) */
    private static final int TOAST_STROKE_WIDTH_DP = 1;
    
    /** Elevation for toast on Lollipop+ (dp) */
    private static final int TOAST_ELEVATION_DP = 6;
    
    /** Default toast background color (dark gray) */
    private static final String TOAST_BACKGROUND_COLOR = "#1A1A1A";
    
    /** Default toast stroke color (slightly lighter gray) */
    private static final String TOAST_STROKE_COLOR = "#1E1E1E";
    
    /** Default theme color when ThemeManager is unavailable (gold/amber) */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    
    /** Broadcast action for theme color change notifications */
    private static final String ACTION_THEME_COLOR_CHANGED = "THEME_COLOR_CHANGED";
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    /** Main thread handler for delayed operations */
    private static final Handler sHandler = new Handler(Looper.getMainLooper());
    
    /** Reference to the current persistent overlay view */
    @Nullable
    private static View sPersistentOverlay = null;
    
    /** Reference to the text view inside the persistent overlay */
    @Nullable
    private static TextView sPersistentTextView = null;
    
    /** Runnable for auto-hiding temporary toasts */
    @Nullable
    private static Runnable sHideRunnable = null;
    
    /** Broadcast receiver for theme color change events */
    @Nullable
    private static BroadcastReceiver sThemeReceiver = null;
    
    /** Flag indicating whether the theme receiver is registered */
    private static boolean sReceiverRegistered = false;
    
    /** Application context reference */
    @Nullable
    private static Context sAppContext = null;
    
    /** Flag indicating if the current toast is persistent */
    private static boolean sIsPersistentToast = false;
    
    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the ToastManager with application context.
     * 
     * <p>This method should be called early in the application lifecycle,
     * typically in the Application class onCreate() method. If not called
     * explicitly, it will be called automatically when showing the first toast.</p>
     *
     * @param context Application context (will be converted to application context)
     */
    public static void init(@NonNull Context context) {
        sAppContext = context.getApplicationContext();
        registerGlobalThemeReceiver();
    }
    
    /**
     * Registers a global broadcast receiver to listen for theme color changes.
     * The receiver updates the active toast's text color when the theme changes.
     */
    private static void registerGlobalThemeReceiver() {
        if (sReceiverRegistered || sAppContext == null) {
            return;
        }
        
        sThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(@NonNull Context context, @NonNull Intent intent) {
                if (ACTION_THEME_COLOR_CHANGED.equals(intent.getAction())) {
                    refreshThemeColor();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_THEME_COLOR_CHANGED);
        try {
            sAppContext.registerReceiver(sThemeReceiver, filter);
            sReceiverRegistered = true;
        } catch (Exception e) {
            sReceiverRegistered = false;
        }
    }
    
    // ========================================================================
    // Activity-Based Toast Methods
    // ========================================================================
    
    /**
     * Shows a temporary toast message with the specified duration.
     * The toast will auto-hide after the duration expires.
     *
     * @param activity The activity to show the toast in (must be non-null and active)
     * @param message The message to display
     * @param duration The duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToast(@Nullable Activity activity, @NonNull String message, int duration) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        if (sAppContext == null) {
            init(activity);
        }
        
        showToastInView((ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content), message, duration);
    }
    
    /**
     * Shows a temporary toast message with LONG duration (2000ms).
     *
     * @param activity The activity to show the toast in
     * @param message The message to display
     */
    public static void showToast(@NonNull Activity activity, @NonNull String message) {
        showToast(activity, message, LENGTH_LONG);
    }
    
    /**
     * Shows a persistent overlay message that stays until explicitly hidden.
     * No auto-hide timer is set. Useful for long-running operations like
     * file syncing, loading indicators, or progress notifications.
     *
     * @param activity The activity to show the overlay in
     * @param message The message to display
     */
    public static void showPersistentOverlay(@NonNull Activity activity, @NonNull String message) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        if (sAppContext == null) {
            init(activity);
        }
        
        sIsPersistentToast = true;
        
        hidePersistentOverlayInternal(false);
        
        ViewGroup rootView = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (rootView == null) {
            return;
        }
        
        createPersistentOverlayInView(rootView, message);
    }
    
    /**
     * Shows a persistent overlay message in a specific view container.
     * No auto-hide timer is set. Useful for showing toasts within dialogs
     * or custom view hierarchies.
     *
     * @param rootView The root view to attach the overlay to (must be a ViewGroup)
     * @param message The message to display
     */
    public static void showPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        if (sAppContext == null) {
            sAppContext = rootView.getContext().getApplicationContext();
        }
        
        sIsPersistentToast = true;
        createPersistentOverlayInView(rootView, message);
    }
    
    /**
     * Creates the persistent overlay view and attaches it to the rootView.
     * This method handles view creation, styling, and fade-in animation.
     *
     * @param rootView The parent view to attach the overlay to
     * @param message The message to display
     */
    private static void createPersistentOverlayInView(@NonNull ViewGroup rootView, @NonNull String message) {
        // Remove existing overlay if present
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {
                // Ignore
            }
        }
        
        // Create container frame
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        // Create text view with ToastManager styling
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        // Set theme color using ColorStateList to override theme defaults
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(rootView.getContext());
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        // Apply background
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), 
            Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(background);
        
        // Add elevation for Android Lollipop and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        // Store references for theme updates
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        // Fade in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        
        // NO auto-hide - this is a true persistent overlay
    }
    
    /**
     * Reattaches the persistent toast to a new activity.
     * Call this in onRestart() or onResume() of activities when a persistent
     * toast should persist across activity transitions.
     *
     * @param activity The activity to attach the toast to
     */
    public static void reattachToCurrentActivity(@NonNull final Activity activity) {
        if (!sIsPersistentToast) {
            return; // Not a persistent toast
        }
        
        if (sPersistentTextView == null || sPersistentOverlay == null) {
            return; // No toast to reattach
        }
        
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        
        // Post to ensure view hierarchy is ready
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Detach from old parent
                if (sPersistentOverlay.getParent() != null) {
                    try {
                        ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
                    } catch (Exception e) {
                        // Ignore
                    }
                }
                
                // Attach to new activity
                ViewGroup rootView = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
                if (rootView != null && sPersistentOverlay != null) {
                    // Remove any duplicate toasts
                    removeDuplicateToasts(rootView);
                    
                    rootView.addView(sPersistentOverlay);
                    sPersistentOverlay.setVisibility(View.VISIBLE);
                    
                    // Ensure text is still visible
                    if (sPersistentTextView != null) {
                        sPersistentTextView.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }
    
    /**
     * Helper method to remove duplicate toast views from the view hierarchy.
     * This prevents multiple overlays from stacking on top of each other.
     *
     * @param rootView The root view to scan for duplicates
     */
    private static void removeDuplicateToasts(ViewGroup rootView) {
        for (int i = 0; i < rootView.getChildCount(); i++) {
            View child = rootView.getChildAt(i);
            // Check if this is our persistent overlay
            if (child == sPersistentOverlay) {
                continue;
            }
            // Check if it looks like a toast overlay
            if (child instanceof FrameLayout) {
                FrameLayout frame = (FrameLayout) child;
                if (frame.getChildCount() > 0 && frame.getChildAt(0) instanceof TextView) {
                    TextView tv = (TextView) frame.getChildAt(0);
                    String text = tv.getText().toString();
                    if (text.contains("Searching folders") || text.contains("Syncing playlist")) {
                        rootView.removeView(child);
                        i--;
                    }
                }
            }
        }
    }
    
    /**
     * Updates the text of the persistent overlay without recreating the view.
     * Also refreshes the theme color to ensure consistency.
     *
     * @param message The new message to display
     */
    public static void updatePersistentOverlay(@NonNull String message) {
        if (sPersistentTextView != null) {
            sPersistentTextView.setText(message);
            refreshThemeColor();
        }
    }
    
    /**
     * Hides the persistent overlay immediately with fade-out animation.
     * After hiding, the toast state is reset and can be shown again.
     */
    public static void hidePersistentOverlay() {
        sIsPersistentToast = false;
        hidePersistentOverlayInternal(true);
    }
    
    /**
     * Checks if a persistent toast is currently active and visible.
     *
     * @return true if a persistent toast exists, false otherwise
     */
    public static boolean hasPersistentToast() {
        return sIsPersistentToast && sPersistentTextView != null;
    }
    
    /**
     * Gets the current persistent toast text.
     *
     * @return The current message text, or null if no persistent toast exists
     */
    @Nullable
    public static String getPersistentToastText() {
        if (sPersistentTextView != null && sIsPersistentToast) {
            return sPersistentTextView.getText().toString();
        }
        return null;
    }
    
    /**
     * Ensures the persistent overlay is attached to the current window.
     * Call this in onRestart() to reattach if needed after configuration changes.
     *
     * @param activity The current activity
     */
    public static void ensureOverlayAttached(@NonNull Activity activity) {
        if (sPersistentOverlay == null) {
            // No overlay exists, nothing to attach
            return;
        }
        
        // Check if the overlay is still attached to a window
        boolean isAttached = false;
        View currentParent = (View) sPersistentOverlay.getParent();
        while (currentParent != null) {
            if (currentParent.isAttachedToWindow()) {
                isAttached = true;
                break;
            }
            currentParent = (View) currentParent.getParent();
        }
        
        if (!isAttached && sPersistentTextView != null) {
            // Overlay exists but is detached - reattach to current decor view
            final String currentMessage = sPersistentTextView.getText().toString();
            
            // Remove the old reference (it's already detached)
            sPersistentOverlay = null;
            sPersistentTextView = null;
            
            // Create new overlay on current decor view with the same message
            ViewGroup rootView = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (rootView != null) {
                showPersistentOverlayInView(rootView, currentMessage);
            }
        }
    }
    
    // ========================================================================
    // View-Based Toast Method (For Dialogs, etc.)
    // ========================================================================
    
    /**
     * Shows a themed toast within a specific view container (e.g., a dialog).
     * This toast auto-hides after the specified duration.
     *
     * @param rootView The root view to attach the toast to (must be a ViewGroup)
     * @param message The message to display
     * @param durationMs Duration in milliseconds (use LENGTH_* constants)
     */
    public static void showToastInView(@NonNull ViewGroup rootView, @NonNull String message, int durationMs) {
        // Mark as non-persistent
        sIsPersistentToast = false;
        
        if (sAppContext == null) {
            sAppContext = rootView.getContext().getApplicationContext();
        }
        
        // Remove existing toast if any in this view
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            try {
                ((ViewGroup) sPersistentOverlay.getParent()).removeView(sPersistentOverlay);
            } catch (Exception ignored) {
                // Ignore
            }
        }
        
        // Create container frame
        FrameLayout container = new FrameLayout(rootView.getContext());
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        containerParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        container.setLayoutParams(containerParams);
        container.setPadding(0, 0, 0, dpToPx(rootView.getContext(), TOAST_BOTTOM_MARGIN_DP));
        
        // Create text view with ToastManager styling
        TextView textView = new TextView(rootView.getContext());
        textView.setText(message);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxWidth(dpToPx(rootView.getContext(), MAX_TOAST_WIDTH_DP));
        textView.setPadding(dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_HORIZONTAL_DP),
            dpToPx(rootView.getContext(), TOAST_PADDING_VERTICAL_DP));
        
        // Set theme color using ColorStateList to override theme defaults
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(rootView.getContext());
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : Color.parseColor(DEFAULT_THEME_COLOR);
        } catch (Exception e) {
            themeColor = Color.parseColor(DEFAULT_THEME_COLOR);
        }
        textView.setTextColor(ColorStateList.valueOf(themeColor));
        
        // Apply background
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(TOAST_BACKGROUND_COLOR));
        background.setCornerRadius(dpToPx(rootView.getContext(), TOAST_CORNER_RADIUS_DP));
        background.setStroke(dpToPx(rootView.getContext(), TOAST_STROKE_WIDTH_DP), 
            Color.parseColor(TOAST_STROKE_COLOR));
        textView.setBackground(background);
        
        // Add elevation for Android Lollipop and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textView.setElevation(dpToPx(rootView.getContext(), TOAST_ELEVATION_DP));
        }
        
        container.addView(textView);
        rootView.addView(container);
        
        // Store references for theme updates
        sPersistentOverlay = container;
        sPersistentTextView = textView;
        
        // Fade in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION_MS);
        container.startAnimation(fadeIn);
        
        // Auto hide after duration
        sHandler.removeCallbacks(sHideRunnable);
        sHideRunnable = new Runnable() {
            @Override
            public void run() {
                hidePersistentOverlayInternal(true);
            }
        };
        sHandler.postDelayed(sHideRunnable, durationMs);
    }
    
    // ========================================================================
    // Theme Management
    // ========================================================================
    
    /**
     * Refreshes the theme color of the active toast overlay.
     * Called automatically when the theme color changes via broadcast.
     * Also available for manual refresh if needed.
     */
    public static void refreshThemeColor() {
        if (sPersistentTextView != null && sAppContext != null) {
            try {
                int themeColor = ThemeManager.getInstance(sAppContext).getCurrentColorInt();
                sPersistentTextView.setTextColor(ColorStateList.valueOf(themeColor));
            } catch (Exception e) {
                // Keep current color on error
            }
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Internal method to hide the persistent overlay with fade-out animation.
     *
     * @param removeCallbacks Whether to remove the hide runnable from the handler
     */
    private static void hidePersistentOverlayInternal(boolean removeCallbacks) {
        if (sPersistentOverlay != null && sPersistentOverlay.getParent() != null) {
            final View overlay = sPersistentOverlay;
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(FADE_DURATION_MS);
            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    // Do nothing
                }
                
                @Override
                public void onAnimationEnd(Animation animation) {
                    try {
                        ViewGroup parent = (ViewGroup) overlay.getParent();
                        if (parent != null) {
                            parent.removeView(overlay);
                        }
                    } catch (Exception ignored) {
                        // Ignore
                    }
                }
                
                @Override
                public void onAnimationRepeat(Animation animation) {
                    // Do nothing
                }
            });
            overlay.startAnimation(fadeOut);
        }
        
        sPersistentOverlay = null;
        sPersistentTextView = null;
        
        if (removeCallbacks && sHideRunnable != null) {
            sHandler.removeCallbacks(sHideRunnable);
            sHideRunnable = null;
        }
    }
    
    /**
     * Converts density-independent pixels (dp) to absolute pixels (px).
     *
     * @param context The context for accessing display metrics
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private static int dpToPx(@NonNull Context context, int dp) {
        return Math.round(dp * context.getResources().getDisplayMetrics().density);
    }
}