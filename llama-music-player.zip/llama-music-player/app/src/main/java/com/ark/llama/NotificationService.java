package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Service for managing media playback notifications.
 * 
 * <p>This class provides a comprehensive notification system for music playback
 * that follows industry standards. The notification is only shown when media is
 * loaded or actively playing. It integrates with the NavigationController to
 * display sync status during playlist updates.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Media playback controls (play/pause, next, previous, close)</li>
 *   <li>Album art display with caching and memory management</li>
 *   <li>Theme color integration for visual consistency</li>
 *   <li>Sync state indication during playlist updates</li>
 *   <li>Timeout watchdog to reset stuck sync state (added for reliability)</li>
 *   <li>Forced notification refresh when sync ends (overcomes channel name caching)</li>
 * </ul>
 * 
 * <h3>Watchdog Protection</h3>
 * <p>When sync state is active, a watchdog timer is started. If sync does not
 * complete within SYNC_TIMEOUT_MS (30 seconds), the sync state is forcibly reset
 * and the notification is updated. This prevents the notification from getting
 * stuck in "Syncing" state indefinitely due to unhandled exceptions or bugs.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All delays use Handler.postDelayed().
 * State updates are atomic using AtomicReference and AtomicBoolean.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NotificationService implements NavigationController.ButtonStateListener, PlaybackController.PlaybackControllerListener {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "NotificationService";
    
    /** Notification channel ID for music playback. */
    private static final String CHANNEL_ID = "music_playback_channel";
    
    /** Group key for grouping notifications. */
    private static final String GROUP_KEY = "llama_music_group";
    
    /** Notification ID for the main playback notification. */
    public static final int NOTIFICATION_ID = 1;
    
    /** Notification ID for the group summary notification. */
    private static final int GROUP_SUMMARY_ID = 2;
    
    /** Maximum size for album art in pixels. */
    private static final int MAX_ART_SIZE_PX = 512;
    
    /** Maximum cache size for album art in megabytes. */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Neutral color for secondary action buttons (silver/gray). */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;
    
    /** Red color for close action button. */
    private static final int RED_COLOR = 0xFFE53935;
    
    /** Maximum title length before truncation. */
    private static final int MAX_TITLE_LENGTH = 20;
    
    /** Maximum artist length before truncation. */
    private static final int MAX_ARTIST_LENGTH = 30;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Default icon size in pixels. */
    private static final int DEFAULT_ICON_SIZE = 96;
    
    /**
     * Timeout for stuck sync state (30 seconds).
     * If sync does not complete within this time, the sync state is forcibly reset.
     */
    private static final long SYNC_TIMEOUT_MS = 30000;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Immutable state object representing the current notification state.
     * 
     * <p>This class encapsulates all the information needed to build the
     * notification, including playback state, metadata, and album art.
     * Immutability ensures thread-safe state transitions.</p>
     */
    private static class NotificationState {
        
        /** The current channel state (e.g., "Playing", "Paused", "Syncing", "Resting"). */
        final String channelState;
        
        /** Whether music is currently playing. */
        final boolean isPlaying;
        
        /** The song title (empty string if none). */
        final String title;
        
        /** The artist name (empty string if none). */
        final String artist;
        
        /** The album art bitmap (null if none). */
        final Bitmap albumArt;
        
        /** The placeholder bitmap for when album art is missing (null if none). */
        final Bitmap placeholder;
        
        /** Cache key for the album art bitmap. */
        final String artKey;

        /**
         * Constructs a new NotificationState.
         *
         * @param channelState The current channel state
         * @param isPlaying True if music is playing
         * @param title The song title
         * @param artist The artist name
         * @param albumArt The album art bitmap
         * @param placeholder The placeholder bitmap
         * @param artKey The cache key for album art
         */
        NotificationState(String channelState, boolean isPlaying, 
                         String title, String artist, 
                         Bitmap albumArt, Bitmap placeholder, String artKey) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.placeholder = placeholder;
            this.artKey = artKey;
        }
        
        /**
         * Creates a copy of this state with a new channel state.
         *
         * @param newChannelState The new channel state
         * @return A new NotificationState with updated channel state
         */
        NotificationState withChannelState(String newChannelState) {
            return new NotificationState(
                newChannelState, isPlaying, title, artist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy of this state with new song info.
         *
         * @param newTitle The new title
         * @param newArtist The new artist
         * @return A new NotificationState with updated song info
         */
        NotificationState withSongInfo(String newTitle, String newArtist) {
            return new NotificationState(
                channelState, isPlaying, newTitle, newArtist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy of this state with new playing state.
         *
         * @param newIsPlaying The new playing state
         * @return A new NotificationState with updated playing state
         */
        NotificationState withPlayingState(boolean newIsPlaying) {
            String newChannelState = channelState;
            if (!"Syncing".equals(channelState) && title != null && !title.isEmpty()) {
                newChannelState = newIsPlaying ? "Playing" : "Paused";
            }
            return new NotificationState(
                newChannelState, newIsPlaying, title, artist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy of this state with new album art.
         *
         * @param newAlbumArt The new album art
         * @param newPlaceholder The new placeholder
         * @param newArtKey The new cache key
         * @return A new NotificationState with updated album art
         */
        NotificationState withAlbumArt(Bitmap newAlbumArt, Bitmap newPlaceholder, String newArtKey) {
            return new NotificationState(
                channelState, isPlaying, title, artist, 
                newAlbumArt, newPlaceholder, newArtKey
            );
        }
        
        /**
         * Creates a resting state (no content).
         *
         * @return A resting NotificationState
         */
        static NotificationState resting() {
            return new NotificationState("Resting", false, "", "", null, null, null);
        }
        
        /**
         * Creates a syncing state.
         *
         * @return A syncing NotificationState
         */
        static NotificationState syncing() {
            return new NotificationState("Syncing", false, "", "", null, null, null);
        }
    }
    
    /**
     * Functional interface for updating the notification state.
     * 
     * <p>This interface allows for atomic state updates using a
     * compare-and-swap pattern.</p>
     */
    private interface StateUpdater {
        
        /**
         * Updates the notification state.
         *
         * @param current The current state
         * @return The new state
         */
        NotificationState update(NotificationState current);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** The service this notification service is attached to. */
    private final Service mService;
    
    /** Notification manager for displaying notifications. */
    private NotificationManager mNotificationManager;
    
    /** Main thread handler for UI operations. */
    private final Handler mMainHandler;
    
    /** Handler for sync timeout watchdog. */
    private final Handler mTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for sync timeout watchdog. */
    private final Runnable mSyncTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsSyncActive) {
                Log.w(TAG, "Sync state stuck for " + SYNC_TIMEOUT_MS + "ms, forcing reset");
                mIsSyncActive = false;
                updateSyncState();
                forceUpdate();
            }
        }
    };
    
    /** Current notification state (atomic reference for thread safety). */
    private final AtomicReference<NotificationState> mCurrentState = 
        new AtomicReference<NotificationState>(NotificationState.resting());
    
    /** Flag indicating whether the service is in foreground mode. */
    private final AtomicBoolean mForegroundStarted = new AtomicBoolean(false);
    
    /** Flag indicating whether a notification update is scheduled. */
    private final AtomicBoolean mUpdateScheduled = new AtomicBoolean(false);
    
    /** LRU cache for album art bitmaps. */
    private final LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Lock object for notification operations. */
    private final Object mNotificationLock = new Object();
    
    /** Flag indicating whether a playlist sync is active. */
    private volatile boolean mIsSyncActive = false;
    
    /** PlaybackController for centralized state. */
    private PlaybackController mPlaybackController;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new NotificationService.
     *
     * @param service The service this notification service is attached to
     */
    public NotificationService(@NonNull Service service) {
        mService = service;
        mContext = service.getApplicationContext();
        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
            
            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled()) {
                    NotificationState state = mCurrentState.get();
                    if (oldValue != state.albumArt && oldValue != state.placeholder) {
                        safeRecycleBitmap(oldValue);
                    }
                }
            }
        };
        
        createNotificationChannel();
        
        // Register with NavigationController to listen for sync state changes
        NavigationController.getInstance().registerListener(this);
        
        // Initialize PlaybackController and register as listener
        mPlaybackController = PlaybackController.getInstance();
        mPlaybackController.setListener(this);
    }
    
    // ========================================================================
    // PlaybackController.PlaybackControllerListener Implementation
    // ========================================================================
    
    @Override
    public void onPositionChanged(long positionMs, long durationMs) {
        // No action needed - position doesn't affect notification
    }
    
    @Override
    public void onPlayStateChanged(boolean isPlaying) {
        Log.d(TAG, "onPlayStateChanged: " + isPlaying);
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return current.withPlayingState(isPlaying);
            }
        });
        forceUpdate();
    }
    
    @Override
    public void onSongChanged(@NonNull String title, @NonNull String artist, 
                              @NonNull String path, long duration) {
        Log.d(TAG, "onSongChanged: " + title + " - " + artist);
        updateSongInfo(title, artist, path);
    }
    
    @Override
    public void onPreparedStateChanged(boolean isPrepared) {
        // No action needed - prepared state doesn't affect notification display
        // The notification only cares about playing/paused state
        Log.d(TAG, "onPreparedStateChanged: " + isPrepared);
    }
    
    // ========================================================================
    // NavigationController.ButtonStateListener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes in NavigationController.
     * Updates the sync state when folder actions are disabled.
     * 
     * <p><b>Watchdog Protection:</b> When sync starts, a 30-second watchdog timer
     * is started. If sync does not complete within this timeout, the sync state
     * is forcibly reset and the notification is updated. This prevents the
     * notification from getting stuck in "Syncing" state indefinitely.</p>
     * 
     * <p><b>Force Refresh on Sync End:</b> When sync ends, the notification is
     * forced to refresh immediately to overcome any channel name caching issues
     * that might prevent the "Syncing" text from being cleared.</p>
     *
     * @param group The button group that changed
     * @param disabled True if buttons in this group should be disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            mIsSyncActive = disabled;
            updateSyncState();
            
            if (disabled) {
                // Sync started: start watchdog timer
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                mTimeoutHandler.postDelayed(mSyncTimeoutRunnable, SYNC_TIMEOUT_MS);
                Log.d(TAG, "Sync started, watchdog timer started (" + SYNC_TIMEOUT_MS + "ms)");
            } else {
                // Sync ended: cancel watchdog and force notification refresh
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                // Force notification update to clear any stale channel name
                forceUpdate();
                Log.d(TAG, "Sync ended, watchdog cancelled, forced notification refresh");
            }
        }
    }
    
    /**
     * Updates the notification state based on current sync activity.
     */
    public void updateSyncState() {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                if (mIsSyncActive) {
                    return NotificationState.syncing();
                } else if (current.title != null && !current.title.isEmpty()) {
                    String newState = current.isPlaying ? "Playing" : "Paused";
                    return current.withChannelState(newState);
                } else {
                    return NotificationState.resting();
                }
            }
        });
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the sync active state for the notification.
     *
     * @param isSyncActive True if sync is in progress
     */
    public void setSyncActive(boolean isSyncActive) {
        Log.d(TAG, "setSyncActive: " + isSyncActive);
        mIsSyncActive = isSyncActive;
        updateSyncState();
        
        // Reset watchdog when sync state changes
        if (isSyncActive) {
            mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
            mTimeoutHandler.postDelayed(mSyncTimeoutRunnable, SYNC_TIMEOUT_MS);
        } else {
            mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
        }
    }
    
    /**
     * Stops the foreground notification and releases resources.
     * This method should be called when the service is being destroyed.
     */
    public void stopForeground() {
        release();
    }
    
    /**
     * Releases all resources and unregisters from NavigationController.
     * After this method is called, the notification service should not be used.
     * 
     * <p>This method also cancels the sync watchdog timer to prevent any
     * pending timeout callbacks from firing after release.</p>
     */
    public void release() {
        // Cancel watchdog
        mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
        
        // Unregister from NavigationController
        NavigationController.getInstance().unregisterListener(this);
        
        // Unregister from PlaybackController
        if (mPlaybackController != null) {
            mPlaybackController.setListener(null);
        }
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return NotificationState.resting();
            }
        });
    }
    
    // ========================================================================
    // Core API Methods
    // ========================================================================
    
    /**
     * Updates the song information in the notification.
     *
     * @param title The song title (can be null)
     * @param artist The artist name (can be null)
     * @param artPath The file path of the album art (can be null)
     */
    public void updateSongInfo(@Nullable final String title, @Nullable final String artist, @Nullable final String artPath) {
        final String newTitle = (title != null && !title.isEmpty()) ? title : "";
        final String newArtist = (artist != null && !artist.isEmpty()) ? artist : "";
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                NotificationState newState = current.withSongInfo(newTitle, newArtist);
                
                // Update channel state based on content
                if (mIsSyncActive) {
                    return newState.withChannelState("Syncing");
                } else if (!newTitle.isEmpty()) {
                    String channelState = current.isPlaying ? "Playing" : "Paused";
                    return newState.withChannelState(channelState);
                } else {
                    return newState.withChannelState("Resting");
                }
            }
        });
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap for when art is missing (can be null)
     * @param artPath The file path of the album art (used for caching)
     */
    public void setAlbumArt(@Nullable final Bitmap art, @Nullable final Bitmap placeholder, @Nullable final String artPath) {
        if (mIsSyncActive && art == null) return;

        final Bitmap finalArt = art;
        final Bitmap finalPlaceholder = placeholder;
        final String finalArtPath = artPath;
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                Bitmap newPlaceholder = current.placeholder;
                if (finalPlaceholder != null && !finalPlaceholder.isRecycled()) {
                    if (newPlaceholder == null || newPlaceholder.isRecycled() || 
                        finalPlaceholder != newPlaceholder) {
                        safeRecycleBitmap(newPlaceholder);
                        newPlaceholder = createSafeCopy(finalPlaceholder, MAX_ART_SIZE_PX);
                    }
                }
                
                Bitmap newAlbumArt = null;
                String newArtKey = null;
                
                if (finalArt != null && !finalArt.isRecycled()) {
                    String cacheKey = (finalArtPath != null) ? finalArtPath : 
                                     Integer.toHexString(finalArt.hashCode());
                    Bitmap cached = mAlbumArtCache.get(cacheKey);
                    
                    if (cached != null && !cached.isRecycled()) {
                        newAlbumArt = cached;
                        newArtKey = cacheKey;
                    } else {
                        Bitmap safeCopy = createSafeCopy(finalArt, MAX_ART_SIZE_PX);
                        if (safeCopy != null) {
                            mAlbumArtCache.put(cacheKey, safeCopy);
                            newAlbumArt = safeCopy;
                            newArtKey = cacheKey;
                        }
                    }
                }
                
                if (newAlbumArt == null) {
                    newAlbumArt = (newPlaceholder != null && !newPlaceholder.isRecycled()) ? 
                                 newPlaceholder : null;
                }
                
                if (current.albumArt != newAlbumArt) {
                    safeRecycleBitmap(current.albumArt);
                }
                
                return current.withAlbumArt(newAlbumArt, newPlaceholder, newArtKey);
            }
        });
    }
    
    /**
     * Sets the playing state in the notification.
     * 
     * <p>This method updates the notification's play/pause button icon
     * to reflect the current playback state. The notification is forced
     * to update immediately to ensure UI responsiveness.</p>
     *
     * @param playing True if music is playing, false if paused
     */
    public void setPlayingState(final boolean playing) {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return current.withPlayingState(playing);
            }
        });
        forceUpdate();
    }
    
    /**
     * Forces a notification update regardless of state changes.
     * 
     * <p>Called when playback state changes (play/pause) or when sync ends
     * to ensure the UI reflects reality.</p>
     * 
     * <p>Immediately cancels any pending updates and posts the update directly,
     * eliminating any delay in notification refresh.</p>
     */
    public void forceUpdate() {
        if (mMainHandler != null) {
            // Cancel any pending updates to avoid race conditions
            mMainHandler.removeCallbacksAndMessages(null);
            mUpdateScheduled.set(false);
            // Post immediate update
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    performUpdateNotification();
                }
            });
        }
    }
    
    // ========================================================================
    // State Management Methods
    // ========================================================================
    
    /**
     * Updates the notification state atomically.
     *
     * @param updater The state updater function
     */
    private void updateState(StateUpdater updater) {
        NotificationState oldState, newState;
        do {
            oldState = mCurrentState.get();
            newState = updater.update(oldState);
        } while (!mCurrentState.compareAndSet(oldState, newState));
        
        if (!oldState.channelState.equals(newState.channelState)) {
            updateChannel(newState.channelState);
        }
        
        scheduleNotificationUpdate();
    }
    
    /**
     * Schedules a notification update on the main thread.
     * Uses a flag to prevent multiple pending updates.
     */
    private void scheduleNotificationUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mUpdateScheduled.set(false);
                performUpdateNotification();
            }
        });
    }
    
    /**
     * Performs the actual notification update.
     * Builds and displays the notification based on current state.
     */
    private void performUpdateNotification() {
        NotificationState state = mCurrentState.get();
        
        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                boolean hasContent = state.title != null && !state.title.isEmpty();
                boolean isValidState = !"Resting".equals(state.channelState) && hasContent;
                
                if (isValidState) {
                    Notification notification = buildNotification(state);
                    mNotificationManager.notify(NOTIFICATION_ID, notification);
                    updateGroupSummary(state);
                    
                    if (!mForegroundStarted.getAndSet(true)) {
                        mService.startForeground(NOTIFICATION_ID, notification);
                        Log.d(TAG, "Foreground service started");
                    }
                } else {
                    mNotificationManager.cancel(NOTIFICATION_ID);
                    mNotificationManager.cancel(GROUP_SUMMARY_ID);
                    
                    if (mForegroundStarted.getAndSet(false)) {
                        mService.stopForeground(true);
                        Log.d(TAG, "Foreground service stopped - no content");
                    }
                }
            } catch (SecurityException e) {
                Log.e(TAG, "Missing notification permission", e);
            } catch (Exception e) {
                Log.e(TAG, "Failed to update notification", e);
            }
        }
    }
    
    // ========================================================================
    // Notification Building Methods
    // ========================================================================
    
    /**
     * Builds the notification based on the current state.
     *
     * @param state The current notification state
     * @return The built notification
     */
    @NonNull
    private Notification buildNotification(NotificationState state) {
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
        } catch (Exception e) {
            themeColor = ThemeHelper.getDefaultColor();
        }
        
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);
        
        PendingIntent playPauseIntent = PendingIntent.getService(mContext, 1,
            new Intent(mContext, MusicService.class).setAction("ACTION_PLAY_PAUSE"),
            flags);
        
        PendingIntent nextIntent = PendingIntent.getService(mContext, 2,
            new Intent(mContext, MusicService.class).setAction("ACTION_NEXT"),
            flags);
        
        PendingIntent prevIntent = PendingIntent.getService(mContext, 3,
            new Intent(mContext, MusicService.class).setAction("ACTION_PREV"),
            flags);
        
        PendingIntent closeIntent = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_CLOSE"),
            flags);
        
        String title = state.title.isEmpty() ? "Title" : state.title;
        String artist = state.artist.isEmpty() ? "Artist" : state.artist;
        String subText = "";
        
        if ("Playing".equals(state.channelState)) {
            subText = "Playing";
        } else if ("Paused".equals(state.channelState)) {
            subText = "Paused";
        } else if ("Syncing".equals(state.channelState)) {
            subText = "Syncing";
        }
        
        if (title.length() > MAX_TITLE_LENGTH) {
            title = title.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (artist.length() > MAX_ARTIST_LENGTH) {
            artist = artist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }
        
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_ID);
        } else {
            @SuppressWarnings("deprecation")
            Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
            builder = deprecatedBuilder;
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(artist)
            .setSubText(subText)
            .setColor(themeColor)
            .setColorized(true)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)
            .setGroup(GROUP_KEY);
        
        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }
        
        addActionButton(builder, R.drawable.ic_notification_prev, "Prev", prevIntent, NEUTRAL_COLOR);
        int playPauseRes = state.isPlaying ? R.drawable.ic_notification_pause : R.drawable.ic_notification_play;
        String playPauseLabel = state.isPlaying ? "Pause" : "Play";
        addActionButton(builder, playPauseRes, playPauseLabel, playPauseIntent, themeColor);
        addActionButton(builder, R.drawable.ic_notification_next, "Next", nextIntent, NEUTRAL_COLOR);
        addActionButton(builder, R.drawable.ic_notification_close, "Close", closeIntent, RED_COLOR);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.app.Notification.MediaStyle style = new android.app.Notification.MediaStyle();
            style.setShowActionsInCompactView(0, 1, 2);
            builder.setStyle(style);
        }
        
        return builder.build();
    }
    
    /**
     * Adds an action button to the notification.
     *
     * @param builder The notification builder
     * @param iconRes The icon resource ID
     * @param label The button label
     * @param intent The pending intent for the button
     * @param color The icon color
     */
    private void addActionButton(Notification.Builder builder, int iconRes, 
                                  String label, PendingIntent intent, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon icon = createThemedIcon(iconRes, color);
            if (icon != null) {
                Notification.Action action = new Notification.Action.Builder(icon, label, intent).build();
                builder.addAction(action);
                return;
            }
        }
        
        @SuppressWarnings("deprecation")
        Notification.Action action = new Notification.Action.Builder(iconRes, label, intent).build();
        builder.addAction(action);
    }
    
    /**
     * Gets a safe large icon for the notification.
     *
     * @param state The current notification state
     * @return The large icon bitmap, or null if none available
     */
    @Nullable
    private Bitmap getSafeLargeIcon(NotificationState state) {
        if (state.artKey != null) {
            Bitmap cached = mAlbumArtCache.get(state.artKey);
            if (cached != null && !cached.isRecycled()) {
                return cached;
            }
        }
        
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        
        if (state.placeholder != null && !state.placeholder.isRecycled()) {
            return state.placeholder;
        }
        
        return null;
    }
    
    /**
     * Creates a safe copy of a bitmap scaled to the specified maximum size.
     *
     * @param source The source bitmap
     * @param maxSize The maximum dimension in pixels
     * @return The scaled bitmap copy, or null if copy fails
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            
            if (width <= 0 || height <= 0) {
                return null;
            }
            
            Bitmap scaled;
            if (width <= maxSize && height <= maxSize) {
                scaled = source.copy(source.getConfig() != null ? source.getConfig() : Bitmap.Config.ARGB_8888, false);
            } else {
                float scale = Math.min((float) maxSize / width, (float) maxSize / height);
                scaled = Bitmap.createScaledBitmap(source, Math.round(width * scale), Math.round(height * scale), true);
            }
            
            return scaled;
        } catch (Exception e) {
            Log.e(TAG, "Failed to create safe bitmap copy", e);
            return null;
        }
    }
    
    /**
     * Safely recycles a bitmap.
     *
     * @param bitmap The bitmap to recycle (can be null)
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception ignored) {
            }
        }
    }
    
    /**
     * Creates a themed icon with the specified color.
     *
     * @param drawableRes The drawable resource ID
     * @param color The icon color
     * @return The themed icon, or null if creation fails
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);
            
            if (drawable == null) {
                Log.w(TAG, "Failed to load drawable: " + drawableRes);
                return null;
            }
            
            drawable.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            
            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }
            
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            } else {
                return null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to create themed icon", e);
            return null;
        }
    }
    
    // ========================================================================
    // Notification Channel Methods
    // ========================================================================
    
    /**
     * Creates the notification channel for Android O and above.
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                NotificationChannel existing = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (existing == null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "Llama",
                        NotificationManager.IMPORTANCE_LOW
                    );
                    channel.setDescription("Playback controls");
                    channel.setShowBadge(false);
                    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    channel.setSound(null, null);
                    channel.enableVibration(false);
                    mNotificationManager.createNotificationChannel(channel);
                    Log.d(TAG, "Created notification channel");
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to create notification channel", e);
            }
        }
    }
    
    /**
     * Updates the notification channel name based on current state.
     *
     * @param newState The new channel state
     */
    private void updateChannel(String newState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mNotificationManager != null) {
            try {
                NotificationChannel channel = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (channel != null) {
                    String newName = "Llama • " + newState;
                    if (!newName.equals(channel.getName())) {
                        channel.setName(newName);
                        Log.d(TAG, "Updated channel: " + newName);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "updateChannel failed", e);
            }
        }
    }
    
    /**
     * Updates the group summary notification.
     *
     * @param state The current notification state
     */
    private void updateGroupSummary(NotificationState state) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && mNotificationManager != null) {
            try {
                int themeColor;
                try {
                    ThemeManager themeManager = ThemeManager.getInstance(mContext);
                    themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
                } catch (Exception e) {
                    themeColor = ThemeHelper.getDefaultColor();
                }
                
                String displayText = "Llama • " + state.channelState;
                
                Notification.Builder summaryBuilder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    summaryBuilder = new Notification.Builder(mContext, CHANNEL_ID);
                } else {
                    @SuppressWarnings("deprecation")
                    Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
                    summaryBuilder = deprecatedBuilder;
                }
                
                summaryBuilder.setSmallIcon(R.drawable.ic_notification)
                    .setGroup(GROUP_KEY)
                    .setGroupSummary(true)
                    .setContentTitle(displayText)
                    .setContentText(getChannelDescription(state.channelState))
                    .setColor(themeColor)
                    .setOngoing(true)
                    .setShowWhen(false);
                    
                mNotificationManager.notify(GROUP_SUMMARY_ID, summaryBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update group summary", e);
            }
        }
    }
    
    /**
     * Gets the channel description based on current state.
     *
     * @param state The current channel state
     * @return The channel description string
     */
    private String getChannelDescription(String state) {
        if ("Playing".equals(state)) {
            return "Currently playing";
        } else if ("Paused".equals(state)) {
            return "Currently paused";
        } else if ("Syncing".equals(state)) {
            return "Syncing playlist...";
        } else {
            return "Playback controls";
        }
    }
}