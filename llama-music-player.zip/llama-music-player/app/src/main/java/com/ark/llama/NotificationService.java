package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Service for managing media playback notifications.
 * 
 * <p>This class provides a comprehensive notification system for music playback
 * that follows industry standards. The notification is only shown when media is
 * loaded or actively playing. It integrates with the NavigationController to
 * display sync status during playlist updates.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>Media Controls:</b> Play/pause, next, previous, and close buttons</li>
 *   <li><b>Album Art Display:</b> With caching and memory management</li>
 *   <li><b>Theme Color Integration:</b> Buttons and accents match app theme</li>
 *   <li><b>Sync Status Indication:</b> Shows "Syncing" during playlist updates</li>
 *   <li><b>Channel Name Updates:</b> Changes dynamically (Playing/Paused/Syncing)</li>
 *   <li><b>Group Summary:</b> For notification grouping on Android N+</li>
 * </ul>
 * 
 * <h3>Watchdog Protection</h3>
 * <p>When sync state is active, a watchdog timer is started. If sync does not
 * complete within SYNC_TIMEOUT_MS (30 seconds), the sync state is forcibly reset
 * and the notification is updated. This prevents the notification from getting
 * stuck in "Syncing" state indefinitely due to unhandled exceptions or bugs.</p>
 * 
 * <h3>Album Art Refresh on Sync Complete</h3>
 * <p>When a sync operation completes, album art may have changed. This fix * ensures that the notification cache is invalidated and album art is reloaded
 * when sync ends, preventing stale album art from being displayed.</p>
 * 
 * <h3>Immutable State Pattern</h3>
 * <p>The NotificationState class is immutable, using an AtomicReference for
 * thread-safe state updates. State changes create new instances rather than
 * modifying existing ones, preventing race conditions.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All delays use Handler.postDelayed() instead of Thread.sleep().
 * State updates are atomic using AtomicReference and AtomicBoolean.
 * UI updates are posted to the main thread via Handler.</p>
 * 
 * @see MusicService
 * @see PlaybackController
 * @see NavigationController
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NotificationService implements NavigationController.ButtonStateListener, PlaybackController.PlaybackControllerListener {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Tag for logging messages from this class. */
    private static final String TAG = "NotificationService";
    
    /** Notification channel ID for music playback. */
    private static final String CHANNEL_ID = "music_playback_channel";
    
    /** Group key for notification grouping. */
    private static final String GROUP_KEY = "llama_music_group";
    
    /** Notification ID for the main playback notification. */
    public static final int NOTIFICATION_ID = 1;
    
    /** Notification ID for the group summary (Android N+). */
    private static final int GROUP_SUMMARY_ID = 2;
    
    /** Maximum dimension for album art in notification (512px). */
    private static final int MAX_ART_SIZE_PX = 512;
    
    /** Maximum cache size for album art (50MB). */
    private static final int MAX_CACHE_SIZE_MB = 50;
    
    /** Neutral color for action buttons (light gray). */
    private static final int NEUTRAL_COLOR = 0xFFC0C0C0;
    
    /** Red color for close button. */
    private static final int RED_COLOR = 0xFFE53935;
    
    /** Maximum length for song title in notification. */
    private static final int MAX_TITLE_LENGTH = 20;
    
    /** Maximum length for artist name in notification. */
    private static final int MAX_ARTIST_LENGTH = 30;
    
    /** Ellipsis string for truncated text. */
    private static final String ELLIPSIS = "...";
    
    /** Default size for themed icons (96px). */
    private static final int DEFAULT_ICON_SIZE = 96;
    
    /** Timeout for sync state watchdog (30 seconds). */
    private static final long SYNC_TIMEOUT_MS = 30000;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Immutable state object representing the current notification state.
     * 
     * <p>Using an immutable state object with an AtomicReference provides
     * thread-safe state updates without locks. Each state change creates a
     * new NotificationState instance with the updated fields.</p>
     */
    private static class NotificationState {
        /** Channel state text (Resting, Syncing, Playing, Paused). */
        final String channelState;
        
        /** True if music is currently playing. */
        final boolean isPlaying;
        
        /** Song title (may be empty). */
        final String title;
        
        /** Artist name (may be empty). */
        final String artist;
        
        /** Album art bitmap (may be null). */
        final Bitmap albumArt;
        
        /** Placeholder bitmap (may be null). */
        final Bitmap placeholder;
        
        /** Cache key for album art (file path or hash). */
        final String artKey;

        /**
         * Constructs a new NotificationState.
         *
         * @param channelState The channel state text
         * @param isPlaying True if playing
         * @param title Song title
         * @param artist Artist name
         * @param albumArt Album art bitmap
         * @param placeholder Placeholder bitmap
         * @param artKey Cache key for album art
         */
        NotificationState(String channelState, boolean isPlaying, 
                         String title, String artist, 
                         Bitmap albumArt, Bitmap placeholder, String artKey) {
            this.channelState = channelState;
            this.isPlaying = isPlaying;
            this.title = title;
            this.artist = artist;
            this.albumArt = albumArt;
            this.placeholder = placeholder;
            this.artKey = artKey;
        }
        
        /**
         * Creates a copy with a new channel state.
         *
         * @param newChannelState The new channel state
         * @return A new NotificationState instance
         */
        NotificationState withChannelState(String newChannelState) {
            return new NotificationState(
                newChannelState, isPlaying, title, artist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy with new song information.
         *
         * @param newTitle The new song title
         * @param newArtist The new artist name
         * @return A new NotificationState instance
         */
        NotificationState withSongInfo(String newTitle, String newArtist) {
            return new NotificationState(
                channelState, isPlaying, newTitle, newArtist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy with a new playing state.
         *
         * @param newIsPlaying The new playing state
         * @return A new NotificationState instance
         */
        NotificationState withPlayingState(boolean newIsPlaying) {
            String newChannelState = channelState;
            if (!"Syncing".equals(channelState) && title != null && !title.isEmpty()) {
                newChannelState = newIsPlaying ? "Playing" : "Paused";
            }
            return new NotificationState(
                newChannelState, newIsPlaying, title, artist, 
                albumArt, placeholder, artKey
            );
        }
        
        /**
         * Creates a copy with new album art.
         *
         * @param newAlbumArt The new album art bitmap
         * @param newPlaceholder The new placeholder bitmap
         * @param newArtKey The new cache key
         * @return A new NotificationState instance
         */
        NotificationState withAlbumArt(Bitmap newAlbumArt, Bitmap newPlaceholder, String newArtKey) {
            return new NotificationState(
                channelState, isPlaying, title, artist, 
                newAlbumArt, newPlaceholder, newArtKey
            );
        }
        
        /**
         * Creates a resting state (no content).
         *
         * @return A resting NotificationState
         */
        static NotificationState resting() {
            return new NotificationState("Resting", false, "", "", null, null, null);
        }
        
        /**
         * Creates a syncing state (playlist update in progress).
         *
         * @return A syncing NotificationState
         */
        static NotificationState syncing() {
            return new NotificationState("Syncing", false, "", "", null, null, null);
        }
    }
    
    /**
     * Functional interface for state update operations.
     * Allows atomic state transformations.
     */
    private interface StateUpdater {
        /**
         * Updates the given state and returns the new state.
         *
         * @param current The current state
         * @return The updated state
         */
        NotificationState update(NotificationState current);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context. */
    private final Context mContext;
    
    /** Service instance for startForeground/stopForeground calls. */
    private final Service mService;
    
    /** Notification manager for posting notifications. */
    private NotificationManager mNotificationManager;
    
    /** Main thread handler for UI operations. */
    private final Handler mMainHandler;
    
    /** Handler for sync watchdog timeout. */
    private final Handler mTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable to force-reset stuck sync state. */
    private final Runnable mSyncTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsSyncActive) {
                Log.w(TAG, "Sync state stuck for " + SYNC_TIMEOUT_MS + "ms, forcing reset");
                mIsSyncActive = false;
                updateSyncState();
                forceUpdate();
            }
        }
    };
    
    /** Atomic reference to the current immutable state. */
    private final AtomicReference<NotificationState> mCurrentState = 
        new AtomicReference<NotificationState>(NotificationState.resting());
    
    /** Atomic flag indicating if foreground service has been started. */
    private final AtomicBoolean mForegroundStarted = new AtomicBoolean(false);
    
    /** Atomic flag to debounce update scheduling. */
    private final AtomicBoolean mUpdateScheduled = new AtomicBoolean(false);
    
    /** LRU cache for album art bitmaps. */
    private final LruCache<String, Bitmap> mAlbumArtCache;
    
    /** Lock for notification operations. */
    private final Object mNotificationLock = new Object();
    
    /** True if sync is currently active. */
    private volatile boolean mIsSyncActive = false;
    
    /** PlaybackController reference for listener registration. */
    private PlaybackController mPlaybackController;
    
    // ========================================================================
    // Album Art Refresh Flag
    // ========================================================================
    
    /** Flag indicating album art needs refresh after sync. */
    private volatile boolean mNeedsAlbumArtRefresh = false;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Creates a new NotificationService instance.
     * 
     * <p>Initializes:</p>
     * <ul>
     *   <li>Notification channel (Android O+)</li>
     *   <li>Album art LRU cache with 50MB limit</li>
     *   <li>Registers with NavigationController for sync state</li>
     *   <li>Registers with PlaybackController for playback state</li>
     * </ul>
     *
     * @param service The service that owns this notification service
     */
    public NotificationService(@NonNull Service service) {
        mService = service;
        mContext = service.getApplicationContext();
        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mMainHandler = new Handler(Looper.getMainLooper());
        
        final int cacheSize = MAX_CACHE_SIZE_MB * 1024 * 1024;
        mAlbumArtCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null || bitmap.isRecycled()) {
                    return 0;
                }
                return bitmap.getByteCount();
            }
            
            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && !oldValue.isRecycled()) {
                    NotificationState state = mCurrentState.get();
                    if (oldValue != state.albumArt && oldValue != state.placeholder) {
                        safeRecycleBitmap(oldValue);
                    }
                }
            }
        };
        
        createNotificationChannel();
        
        NavigationController.getInstance().registerListener(this);
        
        mPlaybackController = PlaybackController.getInstance();
        mPlaybackController.setListener(this);
    }
    
    // ========================================================================
    // PlaybackController.PlaybackControllerListener Implementation
    // ========================================================================
    
    /**
     * Called when playback position changes.
     * No action needed for notification.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Total duration of current song
     */
    @Override
    public void onPositionChanged(long positionMs, long durationMs) {
        // No action needed
    }
    
    /**
     * Called when play/pause state changes.
     * Updates the notification to reflect the new state.
     *
     * @param isPlaying True if playing, false if paused
     */
    @Override
    public void onPlayStateChanged(boolean isPlaying) {
        Log.d(TAG, "onPlayStateChanged: " + isPlaying);
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return current.withPlayingState(isPlaying);
            }
        });
        forceUpdate();
    }
    
    /**
     * Called when a new song is loaded.
     * Updates song information in the notification.
     *
     * @param title Song title
     * @param artist Artist name
     * @param path File path (for album art)
     * @param duration Duration in milliseconds
     */
    @Override
    public void onSongChanged(@NonNull String title, @NonNull String artist, 
                              @NonNull String path, long duration) {
        Log.d(TAG, "onSongChanged: " + title + " - " + artist);
        updateSongInfo(title, artist, path);
    }
    
    /**
     * Called when prepared state changes.
     * No action needed for notification.
     *
     * @param isPrepared True if a song is loaded and ready
     */
    @Override
    public void onPreparedStateChanged(boolean isPrepared) {
        Log.d(TAG, "onPreparedStateChanged: " + isPrepared);
    }
    
    /**
     * Called when a playback operation fails.
     * No notification action needed for operation failures.
     *
     * @param operation The operation that failed
     * @param reason Human-readable reason for failure
     */
    @Override
    public void onOperationFailed(@NonNull String operation, @Nullable String reason) {
        Log.d(TAG, "onOperationFailed: " + operation + " - " + reason);
    }
    
    // ========================================================================
    // NavigationController.ButtonStateListener Implementation
    // ========================================================================
    
    /**
     * Called when a button group's disabled state changes in NavigationController.
     * Signals that album art needs refresh when sync ends.
     * 
     * <p>When FOLDER_ACTIONS group is disabled, sync has started. When re-enabled,
     * sync has ended and we should invalidate album art cache to ensure fresh art.</p>
     *
     * @param group The button group that changed
     * @param disabled True if buttons in this group should be disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS) {
            mIsSyncActive = disabled;
            updateSyncState();
            
            if (disabled) {
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                mTimeoutHandler.postDelayed(mSyncTimeoutRunnable, SYNC_TIMEOUT_MS);
                Log.d(TAG, "Sync started, watchdog timer started (" + SYNC_TIMEOUT_MS + "ms)");
            } else {
                mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
                
                // Signal that album art needs refresh on next update
                mNeedsAlbumArtRefresh = true;
                
                forceUpdate();
                Log.d(TAG, "Sync ended, album art refresh flagged, watchdog cancelled");
            }
        }
    }
    
    /**
     * Updates notification state based on current sync status.
     */
    public void updateSyncState() {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                if (mIsSyncActive) {
                    return NotificationState.syncing();
                } else if (current.title != null && !current.title.isEmpty()) {
                    String newState = current.isPlaying ? "Playing" : "Paused";
                    return current.withChannelState(newState);
                } else {
                    return NotificationState.resting();
                }
            }
        });
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the sync active state externally.
     *
     * @param isSyncActive True if sync is active
     */
    public void setSyncActive(boolean isSyncActive) {
        Log.d(TAG, "setSyncActive: " + isSyncActive);
        mIsSyncActive = isSyncActive;
        updateSyncState();
        
        if (isSyncActive) {
            mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
            mTimeoutHandler.postDelayed(mSyncTimeoutRunnable, SYNC_TIMEOUT_MS);
        } else {
            mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
            // Signal album art refresh when sync manually deactivated
            mNeedsAlbumArtRefresh = true;
        }
    }
    
    /**
     * Stops the foreground notification.
     */
    public void stopForeground() {
        release();
    }
    
    /**
     * Releases all resources and unregisters listeners.
     */
    public void release() {
        mTimeoutHandler.removeCallbacks(mSyncTimeoutRunnable);
        NavigationController.getInstance().unregisterListener(this);
        if (mPlaybackController != null) {
            mPlaybackController.setListener(null);
        }
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return NotificationState.resting();
            }
        });
    }
    
    // ========================================================================
    // Core API Methods
    // ========================================================================
    
    /**
     * Updates the song information in the notification.
     *
     * @param title The song title (can be null)
     * @param artist The artist name (can be null)
     * @param artPath The file path for album art (can be null)
     */
    public void updateSongInfo(@Nullable final String title, @Nullable final String artist, @Nullable final String artPath) {
        final String newTitle = (title != null && !title.isEmpty()) ? title : "";
        final String newArtist = (artist != null && !artist.isEmpty()) ? artist : "";
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                NotificationState newState = current.withSongInfo(newTitle, newArtist);
                
                if (mIsSyncActive) {
                    return newState.withChannelState("Syncing");
                } else if (!newTitle.isEmpty()) {
                    String channelState = current.isPlaying ? "Playing" : "Paused";
                    return newState.withChannelState(channelState);
                } else {
                    return newState.withChannelState("Resting");
                }
            }
        });
    }
    
    /**
     * Sets the album art for the notification.
     * 
     * <p>Handles refresh flag by invalidating cache on sync end.
     * Creates safe copies of bitmaps to prevent recycling issues.</p>
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap for when art is missing (can be null)
     * @param artPath The file path of the album art (used for caching)
     */
    public void setAlbumArt(@Nullable final Bitmap art, @Nullable final Bitmap placeholder, @Nullable final String artPath) {
        if (mIsSyncActive && art == null) {
            mNeedsAlbumArtRefresh = true;
            return;
        }
        
        // If we're coming out of sync and need refresh, invalidate cache
        if (mNeedsAlbumArtRefresh && art != null) {
            if (artPath != null) {
                Bitmap oldCached = mAlbumArtCache.remove(artPath);
                safeRecycleBitmap(oldCached);
                Log.d(TAG, "Album art cache invalidated for: " + artPath);
            }
            mNeedsAlbumArtRefresh = false;
        }

        final Bitmap finalArt = art;
        final Bitmap finalPlaceholder = placeholder;
        final String finalArtPath = artPath;
        
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                Bitmap newPlaceholder = current.placeholder;
                if (finalPlaceholder != null && !finalPlaceholder.isRecycled()) {
                    if (newPlaceholder == null || newPlaceholder.isRecycled() || 
                        finalPlaceholder != newPlaceholder) {
                        safeRecycleBitmap(newPlaceholder);
                        newPlaceholder = createSafeCopy(finalPlaceholder, MAX_ART_SIZE_PX);
                    }
                }
                
                Bitmap newAlbumArt = null;
                String newArtKey = null;
                
                if (finalArt != null && !finalArt.isRecycled()) {
                    String cacheKey = (finalArtPath != null) ? finalArtPath : 
                                     Integer.toHexString(finalArt.hashCode());
                    Bitmap cached = mAlbumArtCache.get(cacheKey);
                    
                    if (cached != null && !cached.isRecycled()) {
                        newAlbumArt = cached;
                        newArtKey = cacheKey;
                    } else {
                        Bitmap safeCopy = createSafeCopy(finalArt, MAX_ART_SIZE_PX);
                        if (safeCopy != null) {
                            mAlbumArtCache.put(cacheKey, safeCopy);
                            newAlbumArt = safeCopy;
                            newArtKey = cacheKey;
                        }
                    }
                }
                
                if (newAlbumArt == null) {
                    newAlbumArt = (newPlaceholder != null && !newPlaceholder.isRecycled()) ? 
                                 newPlaceholder : null;
                }
                
                if (current.albumArt != newAlbumArt) {
                    safeRecycleBitmap(current.albumArt);
                }
                
                return current.withAlbumArt(newAlbumArt, newPlaceholder, newArtKey);
            }
        });
    }
    
    /**
     * Sets the playing state of the notification.
     *
     * @param playing True if music is playing
     */
    public void setPlayingState(final boolean playing) {
        updateState(new StateUpdater() {
            @Override
            public NotificationState update(NotificationState current) {
                return current.withPlayingState(playing);
            }
        });
        forceUpdate();
    }
    
    /**
     * Forces an immediate notification update.
     */
    public void forceUpdate() {
        if (mMainHandler != null) {
            mMainHandler.removeCallbacksAndMessages(null);
            mUpdateScheduled.set(false);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    performUpdateNotification();
                }
            });
        }
    }
    
    // ========================================================================
    // State Management Methods
    // ========================================================================
    
    /**
     * Updates the state atomically using the provided updater.
     *
     * @param updater The state transformation function
     */
    private void updateState(StateUpdater updater) {
        NotificationState oldState, newState;
        do {
            oldState = mCurrentState.get();
            newState = updater.update(oldState);
        } while (!mCurrentState.compareAndSet(oldState, newState));
        
        if (!oldState.channelState.equals(newState.channelState)) {
            updateChannel(newState.channelState);
        }
        
        scheduleNotificationUpdate();
    }
    
    /**
     * Schedules a notification update, debouncing multiple requests.
     */
    private void scheduleNotificationUpdate() {
        if (mUpdateScheduled.getAndSet(true)) {
            return;
        }
        
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mUpdateScheduled.set(false);
                performUpdateNotification();
            }
        });
    }
    
    /**
     * Performs the actual notification update.
     */
    private void performUpdateNotification() {
        NotificationState state = mCurrentState.get();
        
        synchronized (mNotificationLock) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                boolean hasContent = state.title != null && !state.title.isEmpty();
                boolean isValidState = !"Resting".equals(state.channelState) && hasContent;
                
                if (isValidState) {
                    Notification notification = buildNotification(state);
                    mNotificationManager.notify(NOTIFICATION_ID, notification);
                    updateGroupSummary(state);
                    
                    if (!mForegroundStarted.getAndSet(true)) {
                        mService.startForeground(NOTIFICATION_ID, notification);
                        Log.d(TAG, "Foreground service started");
                    }
                } else {
                    mNotificationManager.cancel(NOTIFICATION_ID);
                    mNotificationManager.cancel(GROUP_SUMMARY_ID);
                    
                    if (mForegroundStarted.getAndSet(false)) {
                        mService.stopForeground(true);
                        Log.d(TAG, "Foreground service stopped - no content");
                    }
                }
            } catch (SecurityException e) {
                Log.e(TAG, "Missing notification permission", e);
            } catch (Exception e) {
                Log.e(TAG, "Failed to update notification", e);
            }
        }
    }
    
    // ========================================================================
    // Notification Building Methods
    // ========================================================================
    
    /**
     * Builds the notification with all controls and metadata.
     *
     * @param state The current notification state
     * @return The built notification
     */
    @NonNull
    private Notification buildNotification(NotificationState state) {
        int themeColor;
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
        } catch (Exception e) {
            themeColor = ThemeHelper.getDefaultColor();
        }
        
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(mContext, 0,
            new Intent(mContext, MusicPlayer.class)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            flags);
        
        PendingIntent playPauseIntent = PendingIntent.getService(mContext, 1,
            new Intent(mContext, MusicService.class).setAction("ACTION_PLAY_PAUSE"),
            flags);
        
        PendingIntent nextIntent = PendingIntent.getService(mContext, 2,
            new Intent(mContext, MusicService.class).setAction("ACTION_NEXT"),
            flags);
        
        PendingIntent prevIntent = PendingIntent.getService(mContext, 3,
            new Intent(mContext, MusicService.class).setAction("ACTION_PREV"),
            flags);
        
        PendingIntent closeIntent = PendingIntent.getService(mContext, 4,
            new Intent(mContext, MusicService.class).setAction("ACTION_CLOSE"),
            flags);
        
        String title = state.title.isEmpty() ? "Title" : state.title;
        String artist = state.artist.isEmpty() ? "Artist" : state.artist;
        String subText = "";
        
        if ("Playing".equals(state.channelState)) {
            subText = "Playing";
        } else if ("Paused".equals(state.channelState)) {
            subText = "Paused";
        } else if ("Syncing".equals(state.channelState)) {
            subText = "Syncing";
        }
        
        if (title.length() > MAX_TITLE_LENGTH) {
            title = title.substring(0, MAX_TITLE_LENGTH - 3) + ELLIPSIS;
        }
        if (artist.length() > MAX_ARTIST_LENGTH) {
            artist = artist.substring(0, MAX_ARTIST_LENGTH - 3) + ELLIPSIS;
        }
        
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(mContext, CHANNEL_ID);
        } else {
            @SuppressWarnings("deprecation")
            Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
            builder = deprecatedBuilder;
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(artist)
            .setSubText(subText)
            .setColor(themeColor)
            .setColorized(true)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)
            .setGroup(GROUP_KEY);
        
        Bitmap largeIcon = getSafeLargeIcon(state);
        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon);
        }
        
        addActionButton(builder, R.drawable.ic_notification_prev, "Prev", prevIntent, NEUTRAL_COLOR);
        int playPauseRes = state.isPlaying ? R.drawable.ic_notification_pause : R.drawable.ic_notification_play;
        String playPauseLabel = state.isPlaying ? "Pause" : "Play";
        addActionButton(builder, playPauseRes, playPauseLabel, playPauseIntent, themeColor);
        addActionButton(builder, R.drawable.ic_notification_next, "Next", nextIntent, NEUTRAL_COLOR);
        addActionButton(builder, R.drawable.ic_notification_close, "Close", closeIntent, RED_COLOR);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.app.Notification.MediaStyle style = new android.app.Notification.MediaStyle();
            style.setShowActionsInCompactView(0, 1, 2);
            builder.setStyle(style);
        }
        
        return builder.build();
    }
    
    /**
     * Adds an action button to the notification.
     *
     * @param builder The notification builder
     * @param iconRes The icon resource ID
     * @param label The button label
     * @param intent The pending intent for the action
     * @param color The color for the icon (Android M+)
     */
    private void addActionButton(Notification.Builder builder, int iconRes, 
                                  String label, PendingIntent intent, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Icon icon = createThemedIcon(iconRes, color);
            if (icon != null) {
                Notification.Action action = new Notification.Action.Builder(icon, label, intent).build();
                builder.addAction(action);
                return;
            }
        }
        
        @SuppressWarnings("deprecation")
        Notification.Action action = new Notification.Action.Builder(iconRes, label, intent).build();
        builder.addAction(action);
    }
    
    /**
     * Gets a safe large icon from cache or state.
     *
     * @param state The current notification state
     * @return The large icon bitmap, or null
     */
    @Nullable
    private Bitmap getSafeLargeIcon(NotificationState state) {
        if (state.artKey != null) {
            Bitmap cached = mAlbumArtCache.get(state.artKey);
            if (cached != null && !cached.isRecycled()) {
                return cached;
            }
        }
        
        if (state.albumArt != null && !state.albumArt.isRecycled()) {
            return state.albumArt;
        }
        
        if (state.placeholder != null && !state.placeholder.isRecycled()) {
            return state.placeholder;
        }
        
        return null;
    }
    
    /**
     * Creates a safe copy of a bitmap scaled to maxSize.
     *
     * @param source The source bitmap
     * @param maxSize The maximum dimension in pixels
     * @return A scaled copy of the bitmap, or null if source is invalid
     */
    @Nullable
    private Bitmap createSafeCopy(@Nullable Bitmap source, int maxSize) {
        if (source == null || source.isRecycled()) {
            return null;
        }
        
        try {
            int width = source.getWidth();
            int height = source.getHeight();
            
            if (width <= 0 || height <= 0) {
                return null;
            }
            
            Bitmap scaled;
            if (width <= maxSize && height <= maxSize) {
                scaled = source.copy(source.getConfig() != null ? source.getConfig() : Bitmap.Config.ARGB_8888, false);
            } else {
                float scale = Math.min((float) maxSize / width, (float) maxSize / height);
                scaled = Bitmap.createScaledBitmap(source, Math.round(width * scale), Math.round(height * scale), true);
            }
            
            return scaled;
        } catch (Exception e) {
            Log.e(TAG, "Failed to create safe bitmap copy", e);
            return null;
        }
    }
    
    /**
     * Safely recycles a bitmap if it exists and is not already recycled.
     *
     * @param bitmap The bitmap to recycle
     */
    private void safeRecycleBitmap(@Nullable Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
            } catch (Exception ignored) {
            }
        }
    }
    
    /**
     * Creates a themed icon with the specified color.
     *
     * @param drawableRes The drawable resource ID
     * @param color The color to apply
     * @return The themed icon, or null on failure
     */
    @Nullable
    private Icon createThemedIcon(int drawableRes, int color) {
        try {
            Drawable drawable = ContextCompat.getDrawable(mContext, drawableRes);
            
            if (drawable == null) {
                Log.w(TAG, "Failed to load drawable: " + drawableRes);
                return null;
            }
            
            drawable.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            
            int width = drawable.getIntrinsicWidth();
            int height = drawable.getIntrinsicHeight();
            if (width <= 0 || height <= 0) {
                width = DEFAULT_ICON_SIZE;
                height = DEFAULT_ICON_SIZE;
            }
            
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Icon.createWithBitmap(bitmap);
            } else {
                return null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to create themed icon", e);
            return null;
        }
    }
    
    // ========================================================================
    // Notification Channel Methods
    // ========================================================================
    
    /**
     * Creates the notification channel for Android O and above.
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                if (mNotificationManager == null) {
                    mNotificationManager = (NotificationManager) mContext.getSystemService(
                        Context.NOTIFICATION_SERVICE);
                }
                if (mNotificationManager == null) {
                    return;
                }
                
                NotificationChannel existing = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (existing == null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "Llama",
                        NotificationManager.IMPORTANCE_LOW
                    );
                    channel.setDescription("Playback controls");
                    channel.setShowBadge(false);
                    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    channel.setSound(null, null);
                    channel.enableVibration(false);
                    mNotificationManager.createNotificationChannel(channel);
                    Log.d(TAG, "Created notification channel");
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to create notification channel", e);
            }
        }
    }
    
    /**
     * Updates the notification channel name based on current state.
     *
     * @param newState The new channel state text
     */
    private void updateChannel(String newState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mNotificationManager != null) {
            try {
                NotificationChannel channel = mNotificationManager.getNotificationChannel(CHANNEL_ID);
                if (channel != null) {
                    String newName = "Llama • " + newState;
                    if (!newName.equals(channel.getName())) {
                        channel.setName(newName);
                        Log.d(TAG, "Updated channel: " + newName);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "updateChannel failed", e);
            }
        }
    }
    
    /**
     * Updates the group summary notification for Android N+.
     *
     * @param state The current notification state
     */
    private void updateGroupSummary(NotificationState state) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && mNotificationManager != null) {
            try {
                int themeColor;
                try {
                    ThemeManager themeManager = ThemeManager.getInstance(mContext);
                    themeColor = (themeManager != null) ? themeManager.getCurrentColorInt() : ThemeHelper.getDefaultColor();
                } catch (Exception e) {
                    themeColor = ThemeHelper.getDefaultColor();
                }
                
                String displayText = "Llama • " + state.channelState;
                
                Notification.Builder summaryBuilder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    summaryBuilder = new Notification.Builder(mContext, CHANNEL_ID);
                } else {
                    @SuppressWarnings("deprecation")
                    Notification.Builder deprecatedBuilder = new Notification.Builder(mContext);
                    summaryBuilder = deprecatedBuilder;
                }
                
                summaryBuilder.setSmallIcon(R.drawable.ic_notification)
                    .setGroup(GROUP_KEY)
                    .setGroupSummary(true)
                    .setContentTitle(displayText)
                    .setContentText(getChannelDescription(state.channelState))
                    .setColor(themeColor)
                    .setOngoing(true)
                    .setShowWhen(false);
                    
                mNotificationManager.notify(GROUP_SUMMARY_ID, summaryBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update group summary", e);
            }
        }
    }
    
    /**
     * Gets the description text for the channel based on state.
     *
     * @param state The channel state
     * @return The description text
     */
    private String getChannelDescription(String state) {
        if ("Playing".equals(state)) {
            return "Currently playing";
        } else if ("Paused".equals(state)) {
            return "Currently paused";
        } else if ("Syncing".equals(state)) {
            return "Syncing playlist...";
        } else {
            return "Playback controls";
        }
    }
}