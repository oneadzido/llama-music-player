package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;

/**
 * PitchShifter - Native audio processor for pitch and tempo shifting using SoundTouch library.
 * 
 * <p>This class provides a JNI interface to the SoundTouch audio processing library,
 * allowing independent control of audio pitch (key) and tempo (speed). The pitch
 * shifting is performed without affecting the playback speed (or vice versa).</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 * </ul>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Input PCM (short[]) -> putFrames() -> SoundTouch Process -> receiveFrames() -> Output PCM (short[])
 * </pre>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * PitchShifter shifter = new PitchShifter(44100, 2);
 * shifter.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * shifter.setTempo(1.25f);  // Speed up by 25%
 * 
 * short[] input = new short[frameSize * channels];
 * shifter.putFrames(input, frames);
 * int available = shifter.numFrames();
 * short[] output = new short[available * channels];
 * shifter.receiveFrames(output, available);
 * 
 * shifter.close();
 * </pre>
 * 
 * @see AutoCloseable
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class PitchShifter implements AutoCloseable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "PitchShifter";
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Flag indicating if the native library has been loaded. */
    private static volatile boolean sNativeLibraryLoaded = false;

    // ========================================================================
    // Static Initializer
    // ========================================================================
    
    static {
        try {
            System.loadLibrary("pitch_shifter");
            sNativeLibraryLoaded = true;
            Log.d(TAG, "Pitch shifter library loaded successfully");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load pitch_shifter library", e);
        } catch (SecurityException e) {
            Log.e(TAG, "Security exception loading pitch_shifter library", e);
        }
    }

    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Native handle pointer (passed to native methods). */
    private long mNativeHandle;
    
    /** Sample rate in Hz. */
    private final int mSampleRate;
    
    /** Number of audio channels (1 for mono, 2 for stereo). */
    private final int mChannels;
    
    /** Flag indicating if the shifter has been closed. */
    private volatile boolean mIsClosed = false;

    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PitchShifter instance.
     * 
     * <p>Creates a native SoundTouch processor with the specified sample rate
     * and channel configuration.</p>
     *
     * @param sampleRate The audio sample rate in Hz (e.g., 44100)
     * @param channels Number of audio channels (1 = mono, 2 = stereo)
     * @throws IllegalStateException if the native library is not loaded
     */
    public PitchShifter(int sampleRate, int channels) {
        if (!sNativeLibraryLoaded) {
            throw new IllegalStateException("Native library not loaded");
        }
        
        this.mSampleRate = sampleRate;
        this.mChannels = channels;
        initNative();
    }

    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the native pitch shifter instance.
     * 
     * @throws IllegalStateException if native creation fails
     */
    private void initNative() {
        mNativeHandle = nativeCreate();
        
        if (mNativeHandle == 0) {
            throw new IllegalStateException("Failed to create native PitchShifter");
        }
        
        nativeSetSampleRate(mNativeHandle, mSampleRate);
        nativeSetChannels(mNativeHandle, mChannels);
        
        Log.d(TAG, "PitchShifter initialized: " + mSampleRate + "Hz, " + mChannels + "ch");
    }

    // ========================================================================
    // Parameter Control Methods
    // ========================================================================
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        checkClosed();
        nativeSetPitch(mNativeHandle, semitones);
    }

    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier (e.g., 1.25 for 125% speed)
     */
    public void setTempo(float tempo) {
        checkClosed();
        nativeSetTempo(mNativeHandle, tempo);
    }

    // ========================================================================
    // Audio Processing Methods
    // ========================================================================
    
    /**
     * Feeds audio frames into the pitch shifter for processing.
     * 
     * <p>The buffer must contain interleaved samples for multi-channel audio.
     * For stereo, the sample order is L, R, L, R, etc.</p>
     *
     * @param samples Array of short audio samples (16-bit PCM)
     * @param frames Number of stereo frames (each frame = channels samples)
     */
    public void putFrames(@NonNull short[] samples, int frames) {
        checkClosed();
        if (frames <= 0) {
            return;
        }
        nativePutFrames(mNativeHandle, samples, frames);
    }

    /**
     * Retrieves processed audio frames from the pitch shifter.
     *
     * @param output Array to receive the processed samples
     * @param maxFrames Maximum number of frames to retrieve
     * @return Number of frames actually retrieved
     */
    public int receiveFrames(@NonNull short[] output, int maxFrames) {
        checkClosed();
        if (maxFrames <= 0) {
            return 0;
        }
        return nativeReceiveFrames(mNativeHandle, output, maxFrames);
    }
    
    /**
     * Returns the number of frames currently available in the pipeline.
     * 
     * <p>This method can be used to check how much processed audio is
     * ready before calling receiveFrames().</p>
     *
     * @return Number of frames available
     */
    public int numFrames() {
        checkClosed();
        return nativeNumFrames(mNativeHandle);
    }

    /**
     * Flushes any remaining audio data from the pipeline.
     * 
     * <p>Call this method after processing all input to ensure all
     * audio data is retrieved.</p>
     */
    public void flush() {
        checkClosed();
        nativeFlush(mNativeHandle);
    }
    
    /**
     * Clears all internal buffers in the pipeline.
     * 
     * <p>This method resets the processor's internal state, discarding
     * any pending input or output.</p>
     */
    public void clear() {
        checkClosed();
        nativeClear(mNativeHandle);
    }

    // ========================================================================
    // State Query Methods
    // ========================================================================
    
    /**
     * Checks if the pitch shifter is initialized and ready for use.
     *
     * @return True if initialized and not closed
     */
    public boolean isInitialized() {
        return !mIsClosed && mNativeHandle != 0;
    }

    /**
     * Returns the number of audio channels.
     *
     * @return Number of channels (1 for mono, 2 for stereo)
     */
    public int getChannels() {
        return mChannels;
    }

    /**
     * Returns the sample rate in Hz.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }

    /**
     * Checks if the native pitch shifter library is available.
     *
     * @return True if the library was loaded successfully
     */
    public static boolean isLibraryAvailable() {
        return sNativeLibraryLoaded;
    }

    // ========================================================================
    // Resource Management Methods
    // ========================================================================
    
    /**
     * Checks if the pitch shifter has been closed and throws if so.
     *
     * @throws IllegalStateException if the shifter is closed
     */
    private void checkClosed() {
        if (mIsClosed) {
            throw new IllegalStateException("PitchShifter is closed");
        }
    }

    /**
     * Releases the native pitch shifter resources.
     * 
     * <p>This method implements the AutoCloseable interface and should be
     * called when the pitch shifter is no longer needed. It is safe to call
     * multiple times.</p>
     */
    @Override
    public void close() {
        if (!mIsClosed && mNativeHandle != 0) {
            nativeDestroy(mNativeHandle);
            mNativeHandle = 0;
            mIsClosed = true;
            Log.d(TAG, "PitchShifter closed");
        }
    }
    
    /**
     * Releases the native pitch shifter resources (alias for close()).
     * 
     * <p>Provided for backward compatibility.</p>
     */
    public void release() {
        close();
    }

    // ========================================================================
    // Native Methods
    // ========================================================================
    
    /**
     * Creates a new native PitchShifter instance.
     *
     * @return Native handle pointer (0 on failure)
     */
    private native long nativeCreate();
    
    /**
     * Sets the sample rate for the native PitchShifter.
     *
     * @param handle Native handle pointer
     * @param rate Sample rate in Hz
     */
    private native void nativeSetSampleRate(long handle, int rate);
    
    /**
     * Sets the number of channels for the native PitchShifter.
     *
     * @param handle Native handle pointer
     * @param channels Number of channels (1 or 2)
     */
    private native void nativeSetChannels(long handle, int channels);
    
    /**
     * Sets the pitch shift amount in semitones.
     *
     * @param handle Native handle pointer
     * @param pitch Pitch shift in semitones
     */
    private native void nativeSetPitch(long handle, float pitch);
    
    /**
     * Sets the tempo (speed) multiplier.
     *
     * @param handle Native handle pointer
     * @param tempo Tempo multiplier
     */
    private native void nativeSetTempo(long handle, float tempo);
    
    /**
     * Feeds audio frames into the native PitchShifter.
     *
     * @param handle Native handle pointer
     * @param samples Array of audio samples
     * @param frames Number of stereo frames
     */
    private native void nativePutFrames(long handle, @NonNull short[] samples, int frames);
    
    /**
     * Retrieves processed frames from the native PitchShifter.
     *
     * @param handle Native handle pointer
     * @param output Array to receive processed samples
     * @param maxFrames Maximum number of frames to retrieve
     * @return Number of frames actually retrieved
     */
    private native int nativeReceiveFrames(long handle, @NonNull short[] output, int maxFrames);
    
    /**
     * Returns the number of frames available in the native PitchShifter.
     *
     * @param handle Native handle pointer
     * @return Number of frames available
     */
    private native int nativeNumFrames(long handle);
    
    /**
     * Flushes any remaining data from the native PitchShifter.
     *
     * @param handle Native handle pointer
     */
    private native void nativeFlush(long handle);
    
    /**
     * Clears all buffers in the native PitchShifter.
     *
     * @param handle Native handle pointer
     */
    private native void nativeClear(long handle);
    
    /**
     * Destroys the native PitchShifter instance.
     *
     * @param handle Native handle pointer
     */
    private native void nativeDestroy(long handle);
}