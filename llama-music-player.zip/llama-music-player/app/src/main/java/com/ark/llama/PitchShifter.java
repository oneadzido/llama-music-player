/**
 * Llama Music Player – PitchShifter
 * ============================================================================
 * JNI wrapper for the SoundTouch library. Provides independent pitch shifting
 * and tempo control for 16‑bit PCM audio.
 *
 * <p>All native methods are thread‑safe. The shifter must be closed when no
 * longer needed to release native memory.</p>
 *
 * <p>Usage example:</p>
 * <pre>
 * PitchShifter shifter = new PitchShifter(44100, 2);
 * shifter.setPitch(2.5f);   // raise by 2.5 semitones
 * shifter.setTempo(1.25f);  // 25% faster
 * shifter.putFrames(inputPcm, frames);
 * int available = shifter.numFrames();
 * short[] output = new short[available * 2];
 * shifter.receiveFrames(output, available);
 * shifter.close();
 * </pre>
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
package com.ark.llama;

import android.util.Log;
import androidx.annotation.NonNull;

public class PitchShifter implements AutoCloseable {

    private static final String TAG = "PitchShifter";
    private static volatile boolean sNativeLoaded = false;

    static {
        try {
            System.loadLibrary("pitch_shifter");
            sNativeLoaded = true;
            Log.d(TAG, "Native library loaded");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load pitch_shifter", e);
        }
    }

    /**
     * Returns true if the native library is available.
     *
     * @return true if SoundTouch native library is loaded
     */
    public static boolean isLibraryAvailable() {
        return sNativeLoaded;
    }

    private long mNativeHandle;
    private final int mSampleRate;
    private final int mChannels;
    private volatile boolean mClosed = false;

    /**
     * Creates a new PitchShifter instance.
     *
     * @param sampleRate the audio sample rate in Hz (e.g. 44100)
     * @param channels   number of channels (1 for mono, 2 for stereo)
     * @throws IllegalStateException if the native library is not loaded
     */
    public PitchShifter(int sampleRate, int channels) {
        if (!sNativeLoaded) throw new IllegalStateException("Native library not loaded");
        this.mSampleRate = sampleRate;
        this.mChannels = channels;
        mNativeHandle = nativeCreate();
        if (mNativeHandle == 0) throw new IllegalStateException("Failed to create native PitchShifter");
        nativeSetSampleRate(mNativeHandle, sampleRate);
        nativeSetChannels(mNativeHandle, channels);
        Log.d(TAG, "PitchShifter created: " + sampleRate + "Hz, " + channels + "ch");
    }

    /**
     * Sets the pitch shift amount in semitones.
     *
     * @param semitones shift in semitones (range: -6.0 to +6.0)
     */
    public void setPitch(float semitones) {
        checkNotClosed();
        nativeSetPitch(mNativeHandle, semitones);
    }

    /**
     * Sets the tempo (speed) multiplier.
     *
     * @param tempo multiplier (range: 0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        checkNotClosed();
        nativeSetTempo(mNativeHandle, tempo);
    }

    /**
     * Feeds audio frames into the pitch shifter for processing.
     *
     * @param samples interleaved 16‑bit PCM samples
     * @param frames  number of stereo frames (each frame = channels samples)
     */
    public void putFrames(@NonNull short[] samples, int frames) {
        checkNotClosed();
        nativePutFrames(mNativeHandle, samples, frames);
    }

    /**
     * Retrieves processed audio frames from the pitch shifter.
     *
     * @param output    array to receive processed samples
     * @param maxFrames maximum number of frames to retrieve
     * @return number of frames actually retrieved
     */
    public int receiveFrames(@NonNull short[] output, int maxFrames) {
        checkNotClosed();
        return nativeReceiveFrames(mNativeHandle, output, maxFrames);
    }

    /**
     * Returns the number of frames currently available in the pipeline.
     *
     * @return number of frames available
     */
    public int numFrames() {
        checkNotClosed();
        return nativeNumFrames(mNativeHandle);
    }

    /**
     * Flushes any remaining audio data from the pipeline.
     * Call this after processing all input to retrieve all data.
     */
    public void flush() {
        checkNotClosed();
        nativeFlush(mNativeHandle);
    }

    /**
     * Clears all internal buffers and resets the processor's state.
     */
    public void clear() {
        checkNotClosed();
        nativeClear(mNativeHandle);
    }

    /**
     * Releases the native resources. After calling this, the shifter cannot be used.
     */
    @Override
    public void close() {
        if (!mClosed && mNativeHandle != 0) {
            nativeDestroy(mNativeHandle);
            mNativeHandle = 0;
            mClosed = true;
            Log.d(TAG, "PitchShifter closed");
        }
    }

    /**
     * Returns the number of audio channels.
     *
     * @return channel count (1 or 2)
     */
    public int getChannels() {
        return mChannels;
    }

    /**
     * Returns the sample rate in Hz.
     *
     * @return sample rate
     */
    public int getSampleRate() {
        return mSampleRate;
    }

    /**
     * Checks if the pitch shifter is initialised and not closed.
     *
     * @return true if ready for use
     */
    public boolean isInitialized() {
        return !mClosed && mNativeHandle != 0;
    }

    private void checkNotClosed() {
        if (mClosed) throw new IllegalStateException("PitchShifter is closed");
    }

    // ========================================================================
    // Native methods
    // ========================================================================

    /**
     * Creates a new native SoundTouch instance.
     *
     * @return native pointer (0 on failure)
     */
    private native long nativeCreate();

    private native void nativeSetSampleRate(long handle, int rate);
    private native void nativeSetChannels(long handle, int channels);
    private native void nativeSetPitch(long handle, float pitch);
    private native void nativeSetTempo(long handle, float tempo);
    private native void nativePutFrames(long handle, short[] samples, int frames);
    private native int nativeReceiveFrames(long handle, short[] output, int maxFrames);
    private native int nativeNumFrames(long handle);
    private native void nativeFlush(long handle);
    private native void nativeClear(long handle);
    private native void nativeDestroy(long handle);
}