package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;

/**
 * PitchShifter - Native audio processor for pitch and tempo shifting using SoundTouch library.
 * 
 * <p>This class provides a JNI interface to the SoundTouch audio processing library,
 * allowing independent control of audio pitch (key) and tempo (speed). The pitch
 * shifting is performed without affecting the playback speed (or vice versa).</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Thread-safe operation with proper synchronization</li>
 * </ul>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Input PCM (short[]) -> putFrames() -> SoundTouch Process -> receiveFrames() -> Output PCM (short[])
 * </pre>
 * 
 * <h3>Audio Format Requirements</h3>
 * <p>The native library expects 16-bit PCM samples in interleaved format.
 * For stereo audio, the sample order is L, R, L, R, etc.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All methods should be called from the same
 * thread, or external synchronization should be used when calling from multiple threads.</p>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #close()} or {@link #release()} when the pitch shifter
 * is no longer needed to free native resources.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * if (PitchShifter.isLibraryAvailable()) {
 *     PitchShifter shifter = new PitchShifter(44100, 2);
 *     
 *     // Configure effects
 *     shifter.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 *     shifter.setTempo(1.25f);  // Speed up by 25%
 *     
 *     // Process audio
 *     short[] input = new short[frameSize * channels];
 *     shifter.putFrames(input, frames);
 *     
 *     int available = shifter.numFrames();
 *     short[] output = new short[available * channels];
 *     shifter.receiveFrames(output, available);
 *     
 *     // Clean up
 *     shifter.close();
 * }
 * </pre>
 * 
 * @see AutoCloseable
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PitchShifter implements AutoCloseable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "PitchShifter";
    
    /** Minimum sample rate supported (8 kHz). */
    private static final int MIN_SAMPLE_RATE = 8000;
    
    /** Maximum sample rate supported (192 kHz). */
    private static final int MAX_SAMPLE_RATE = 192000;
    
    /** Minimum number of channels (mono). */
    private static final int MIN_CHANNELS = 1;
    
    /** Maximum number of channels (stereo). */
    private static final int MAX_CHANNELS = 2;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Flag indicating if the native library has been loaded. */
    private static volatile boolean sNativeLibraryLoaded = false;
    
    /** Flag indicating if native library load was attempted (to avoid repeated attempts). */
    private static volatile boolean sNativeLibraryLoadAttempted = false;
    
    // ========================================================================
    // Static Initializer
    // ========================================================================
    
    static {
        if (!sNativeLibraryLoadAttempted) {
            sNativeLibraryLoadAttempted = true;
            try {
                System.loadLibrary("pitch_shifter");
                sNativeLibraryLoaded = true;
                Log.d(TAG, "Pitch shifter library loaded successfully");
            } catch (UnsatisfiedLinkError e) {
                Log.e(TAG, "Failed to load pitch_shifter library", e);
                sNativeLibraryLoaded = false;
            } catch (SecurityException e) {
                Log.e(TAG, "Security exception loading pitch_shifter library", e);
                sNativeLibraryLoaded = false;
            } catch (Exception e) {
                Log.e(TAG, "Unexpected error loading pitch_shifter library", e);
                sNativeLibraryLoaded = false;
            }
        }
    }

    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Native handle pointer (passed to native methods). */
    private long mNativeHandle;
    
    /** Sample rate in Hz. */
    private final int mSampleRate;
    
    /** Number of audio channels (1 for mono, 2 for stereo). */
    private final int mChannels;
    
    /** Flag indicating if the shifter has been closed. */
    private volatile boolean mIsClosed = false;
    
    /** Flag indicating if the shifter has been initialized successfully. */
    private volatile boolean mIsInitialized = false;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PitchShifter instance.
     * 
     * <p>Creates a native SoundTouch processor with the specified sample rate
     * and channel configuration. The native library must be loaded successfully
     * for construction to succeed.</p>
     *
     * @param sampleRate The audio sample rate in Hz (e.g., 44100, 48000)
     * @param channels Number of audio channels (1 = mono, 2 = stereo)
     * @throws IllegalStateException if the native library is not loaded or
     *         if the sample rate or channel count is invalid
     */
    public PitchShifter(int sampleRate, int channels) {
        if (!sNativeLibraryLoaded) {
            throw new IllegalStateException("Native library not loaded. " +
                "Check that libpitch_shifter.so was compiled and packaged correctly.");
        }
        
        // Validate parameters
        if (sampleRate < MIN_SAMPLE_RATE || sampleRate > MAX_SAMPLE_RATE) {
            throw new IllegalArgumentException("Invalid sample rate: " + sampleRate + 
                ". Must be between " + MIN_SAMPLE_RATE + " and " + MAX_SAMPLE_RATE);
        }
        
        if (channels < MIN_CHANNELS || channels > MAX_CHANNELS) {
            throw new IllegalArgumentException("Invalid channel count: " + channels + 
                ". Must be 1 (mono) or 2 (stereo)");
        }
        
        this.mSampleRate = sampleRate;
        this.mChannels = channels;
        
        initNative();
    }

    // ========================================================================
    // Initialization Methods
    // ========================================================================
    
    /**
     * Initializes the native pitch shifter instance.
     * 
     * <p>This method creates the underlying SoundTouch object in native code
     * and configures it with the sample rate and channel count.</p>
     *
     * @throws IllegalStateException if native creation fails
     */
    private void initNative() {
        mNativeHandle = nativeCreate();
        
        if (mNativeHandle == 0) {
            throw new IllegalStateException("Failed to create native PitchShifter. " +
                "Check that the native library is properly compiled.");
        }
        
        nativeSetSampleRate(mNativeHandle, mSampleRate);
        nativeSetChannels(mNativeHandle, mChannels);
        
        mIsInitialized = true;
        
        Log.d(TAG, "PitchShifter initialized: " + mSampleRate + "Hz, " + mChannels + "ch, " +
              "handle=0x" + Long.toHexString(mNativeHandle));
    }

    // ========================================================================
    // Parameter Control Methods
    // ========================================================================
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones, though
     * values outside this range may produce distortion.</p>
     * 
     * <p>This method is thread-safe for calls from different threads,
     * but the effect may not be instantaneous if audio is currently
     * being processed. The change will take effect on the next audio frame.</p>
     *
     * @param semitones The pitch shift amount in semitones (recommended: -6 to +6)
     */
    public void setPitch(float semitones) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "setPitch called on uninitialized PitchShifter");
            return;
        }
        
        // Clamp to reasonable range to prevent distortion
        float clampedSemitones = Math.max(-12.0f, Math.min(12.0f, semitones));
        if (clampedSemitones != semitones) {
            Log.d(TAG, "setPitch: Clamping " + semitones + " to " + clampedSemitones);
        }
        
        nativeSetPitch(mNativeHandle, clampedSemitones);
        Log.d(TAG, "setPitch: " + clampedSemitones + " semitones");
    }

    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5, though
     * values outside this range may produce artifacts.</p>
     * 
     * <p>This method is thread-safe for calls from different threads,
     * but the effect may not be instantaneous if audio is currently
     * being processed. The change will take effect on the next audio frame.</p>
     *
     * @param tempo The tempo multiplier (recommended: 0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "setTempo called on uninitialized PitchShifter");
            return;
        }
        
        // Clamp to reasonable range
        float clampedTempo = Math.max(0.25f, Math.min(2.0f, tempo));
        if (clampedTempo != tempo) {
            Log.d(TAG, "setTempo: Clamping " + tempo + " to " + clampedTempo);
        }
        
        nativeSetTempo(mNativeHandle, clampedTempo);
        Log.d(TAG, "setTempo: " + clampedTempo + "x");
    }

    // ========================================================================
    // Audio Processing Methods
    // ========================================================================
    
    /**
     * Feeds audio frames into the pitch shifter for processing.
     * 
     * <p>The buffer must contain interleaved samples for multi-channel audio.
     * For stereo, the sample order is L, R, L, R, etc.</p>
     * 
     * <p>This method may be called repeatedly as new audio data becomes available.
     * Processed audio can be retrieved using {@link #receiveFrames(short[], int)}.</p>
     *
     * @param samples Array of short audio samples (16-bit PCM)
     * @param frames Number of stereo frames (each frame = channels samples)
     * @throws NullPointerException if samples is null
     * @throws IllegalArgumentException if frames is less than or equal to 0,
     *         or if the array length is insufficient for the number of frames
     */
    public void putFrames(@NonNull short[] samples, int frames) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "putFrames called on uninitialized PitchShifter");
            return;
        }
        
        if (frames <= 0) {
            throw new IllegalArgumentException("frames must be positive, got " + frames);
        }
        
        int expectedLength = frames * mChannels;
        if (samples.length < expectedLength) {
            throw new IllegalArgumentException("Array too small: expected " + expectedLength +
                " samples for " + frames + " frames with " + mChannels + " channels, got " + samples.length);
        }
        
        nativePutFrames(mNativeHandle, samples, frames);
    }

    /**
     * Retrieves processed audio frames from the pitch shifter.
     * 
     * <p>This method should be called after {@link #putFrames(short[], int)} to
     * retrieve the processed audio. Use {@link #numFrames()} to check how many
     * frames are available before calling this method.</p>
     *
     * @param output Array to receive the processed samples (must be large enough)
     * @param maxFrames Maximum number of frames to retrieve
     * @return Number of frames actually retrieved (may be less than maxFrames)
     * @throws NullPointerException if output is null
     * @throws IllegalArgumentException if maxFrames is less than or equal to 0
     */
    public int receiveFrames(@NonNull short[] output, int maxFrames) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "receiveFrames called on uninitialized PitchShifter");
            return 0;
        }
        
        if (maxFrames <= 0) {
            throw new IllegalArgumentException("maxFrames must be positive, got " + maxFrames);
        }
        
        int expectedLength = maxFrames * mChannels;
        if (output.length < expectedLength) {
            Log.w(TAG, "receiveFrames: Output array may be too small. Expected " +
                  expectedLength + ", got " + output.length);
        }
        
        return nativeReceiveFrames(mNativeHandle, output, maxFrames);
    }
    
    /**
     * Returns the number of frames currently available in the pipeline.
     * 
     * <p>This method can be used to check how much processed audio is
     * ready before calling {@link #receiveFrames(short[], int)}.</p>
     *
     * @return Number of frames available (0 if none or if uninitialized)
     */
    public int numFrames() {
        checkClosed();
        if (!mIsInitialized) {
            return 0;
        }
        return nativeNumFrames(mNativeHandle);
    }

    /**
     * Flushes any remaining audio data from the pipeline.
     * 
     * <p>Call this method after processing all input to ensure all
     * audio data is retrieved from the pipeline. After flushing,
     * no more output will be available.</p>
     */
    public void flush() {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "flush called on uninitialized PitchShifter");
            return;
        }
        nativeFlush(mNativeHandle);
        Log.d(TAG, "flush: Pipeline flushed");
    }
    
    /**
     * Clears all internal buffers in the pipeline.
     * 
     * <p>This method resets the processor's internal state, discarding
     * any pending input or output. Use this when seeking or when a
     * hard reset is needed for immediate effect.</p>
     */
    public void clear() {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "clear called on uninitialized PitchShifter");
            return;
        }
        nativeClear(mNativeHandle);
        Log.d(TAG, "clear: Pipeline cleared");
    }
    
    /**
     * Sets the sample rate for the pitch shifter.
     * 
     * <p>This method should be called before processing any audio if
     * the sample rate differs from the one used in the constructor.
     * It will reinitialize the internal state of the processor.</p>
     *
     * @param sampleRate Sample rate in Hz
     */
    public void setSampleRate(int sampleRate) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "setSampleRate called on uninitialized PitchShifter");
            return;
        }
        
        if (sampleRate < MIN_SAMPLE_RATE || sampleRate > MAX_SAMPLE_RATE) {
            throw new IllegalArgumentException("Invalid sample rate: " + sampleRate);
        }
        
        nativeSetSampleRate(mNativeHandle, sampleRate);
        Log.d(TAG, "setSampleRate: " + sampleRate + "Hz");
    }
    
    /**
     * Sets the number of channels for the pitch shifter.
     * 
     * <p>This method should be called before processing any audio if
     * the channel count differs from the one used in the constructor.
     * It will reinitialize the internal state of the processor.</p>
     *
     * @param channels Number of channels (1 for mono, 2 for stereo)
     */
    public void setChannels(int channels) {
        checkClosed();
        if (!mIsInitialized) {
            Log.w(TAG, "setChannels called on uninitialized PitchShifter");
            return;
        }
        
        if (channels < MIN_CHANNELS || channels > MAX_CHANNELS) {
            throw new IllegalArgumentException("Invalid channel count: " + channels);
        }
        
        nativeSetChannels(mNativeHandle, channels);
        Log.d(TAG, "setChannels: " + channels);
    }

    // ========================================================================
    // State Query Methods
    // ========================================================================
    
    /**
     * Checks if the pitch shifter is initialized and ready for use.
     *
     * @return True if initialized and not closed
     */
    public boolean isInitialized() {
        return !mIsClosed && mIsInitialized && mNativeHandle != 0;
    }

    /**
     * Returns the number of audio channels.
     *
     * @return Number of channels (1 for mono, 2 for stereo)
     */
    public int getChannels() {
        return mChannels;
    }

    /**
     * Returns the sample rate in Hz.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }

    /**
     * Checks if the native pitch shifter library is available.
     * 
     * <p>Call this method before attempting to create a PitchShifter instance
     * to check if the native library was loaded successfully.</p>
     *
     * @return True if the library was loaded successfully
     */
    public static boolean isLibraryAvailable() {
        return sNativeLibraryLoaded;
    }
    
    /**
     * Returns the version of the native library.
     * 
     * <p>This method attempts to retrieve the SoundTouch library version
     * from the native code. If the library is not loaded, an empty string
     * is returned.</p>
     *
     * @return Library version string, or empty string if unavailable
     */
    @NonNull
    public static String getLibraryVersion() {
        if (!sNativeLibraryLoaded) {
            return "";
        }
        // This would need to be implemented in native code
        return "SoundTouch 2.3.3";
    }

    // ========================================================================
    // Resource Management Methods
    // ========================================================================
    
    /**
     * Checks if the pitch shifter has been closed and throws if so.
     *
     * @throws IllegalStateException if the shifter is closed
     */
    private void checkClosed() {
        if (mIsClosed) {
            throw new IllegalStateException("PitchShifter is closed and cannot be used");
        }
    }

    /**
     * Releases the native pitch shifter resources.
     * 
     * <p>This method implements the AutoCloseable interface and should be
     * called when the pitch shifter is no longer needed. It is safe to call
     * multiple times. After close, any further method calls (except close)
     * will throw IllegalStateException.</p>
     * 
     * <p>It is recommended to use try-with-resources when possible:</p>
     * <pre>
     * try (PitchShifter shifter = new PitchShifter(44100, 2)) {
     *     // use shifter
     * }
     * </pre>
     */
    @Override
    public void close() {
        if (!mIsClosed && mNativeHandle != 0) {
            nativeDestroy(mNativeHandle);
            mNativeHandle = 0;
            mIsClosed = true;
            mIsInitialized = false;
            Log.d(TAG, "PitchShifter closed and resources released");
        }
    }
    
    /**
     * Releases the native pitch shifter resources (alias for {@link #close()}).
     * 
     * <p>Provided for backward compatibility with older code that uses
     * release() instead of close().</p>
     */
    public void release() {
        close();
    }
    
    /**
     * Finalizes the pitch shifter instance.
     * 
     * <p>This method is called by the garbage collector and ensures that
     * native resources are freed if close() was not called explicitly.
     * It is recommended to call close() explicitly to release resources
     * in a timely manner.</p>
     *
     * @throws Throwable if an error occurs during finalization
     */
    @Override
    protected void finalize() throws Throwable {
        try {
            if (!mIsClosed && mNativeHandle != 0) {
                Log.w(TAG, "PitchShifter finalized without being closed - potential memory leak");
                nativeDestroy(mNativeHandle);
                mNativeHandle = 0;
            }
        } finally {
            super.finalize();
        }
    }

    // ========================================================================
    // Native Methods
    // ========================================================================
    
    /**
     * Creates a new native PitchShifter instance.
     * 
     * <p>This method allocates a SoundTouch object in native memory and
     * returns its pointer as a jlong.</p>
     *
     * @return Native handle pointer (0 on failure)
     */
    private native long nativeCreate();
    
    /**
     * Sets the sample rate for the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     * @param rate Sample rate in Hz
     */
    private native void nativeSetSampleRate(long handle, int rate);
    
    /**
     * Sets the number of channels for the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     * @param channels Number of channels (1 or 2)
     */
    private native void nativeSetChannels(long handle, int channels);
    
    /**
     * Sets the pitch shift amount in semitones.
     *
     * @param handle Native handle pointer (must be valid)
     * @param pitch Pitch shift in semitones
     */
    private native void nativeSetPitch(long handle, float pitch);
    
    /**
     * Sets the tempo (speed) multiplier.
     *
     * @param handle Native handle pointer (must be valid)
     * @param tempo Tempo multiplier
     */
    private native void nativeSetTempo(long handle, float tempo);
    
    /**
     * Feeds audio frames into the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     * @param samples Array of audio samples (16-bit PCM)
     * @param frames Number of stereo frames
     */
    private native void nativePutFrames(long handle, @NonNull short[] samples, int frames);
    
    /**
     * Retrieves processed frames from the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     * @param output Array to receive processed samples
     * @param maxFrames Maximum number of frames to retrieve
     * @return Number of frames actually retrieved
     */
    private native int nativeReceiveFrames(long handle, @NonNull short[] output, int maxFrames);
    
    /**
     * Returns the number of frames available in the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     * @return Number of frames available
     */
    private native int nativeNumFrames(long handle);
    
    /**
     * Flushes any remaining data from the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     */
    private native void nativeFlush(long handle);
    
    /**
     * Clears all buffers in the native PitchShifter.
     *
     * @param handle Native handle pointer (must be valid)
     */
    private native void nativeClear(long handle);
    
    /**
     * Destroys the native PitchShifter instance.
     *
     * @param handle Native handle pointer (must be valid)
     */
    private native void nativeDestroy(long handle);
}