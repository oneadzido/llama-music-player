package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * AudioProcessor - Wrapper for SoundTouch pitch and tempo processing.
 * 
 * <p>This class provides a high-level interface to the native PitchShifter
 * library. It handles buffer management and provides a simple API for
 * processing audio frames.</p>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Input PCM -> putFrames() -> SoundTouch Process -> receiveFrames() -> Output PCM
 * </pre>
 * 
 * <h3>Pitch Range</h3>
 * <p>Pitch can be adjusted from -6 to +6 semitones. Positive values raise
 * the pitch, negative values lower it.</p>
 * 
 * <h3>Tempo Range</h3>
 * <p>Tempo can be adjusted from 0.5x to 1.5x speed.</p>
 * <ul>
 *   <li>0.5 = half speed (50% slower)</li>
 *   <li>1.0 = normal speed</li>
 *   <li>1.5 = 1.5x speed (50% faster)</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All calls should be made from the same
 * thread, or external synchronization should be used.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * AudioProcessor processor = new AudioProcessor();
 * processor.configure(44100, 2);  // 44.1kHz stereo
 * processor.setPitchSemitones(2.5f);  // Raise by 2.5 semitones
 * processor.setTempo(1.25f);  // Speed up by 25%
 * 
 * // Process audio chunks
 * short[] input = getNextAudioChunk();
 * short[] output = processor.process(input, frames);
 * playOutput(output);
 * 
 * processor.release();
 * </pre>
 * 
 * @see PitchShifter
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class AudioProcessor {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "AudioProcessor";
    
    /** Minimum tempo (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch in semitones. */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch in semitones. */
    private static final float MAX_PITCH = 6.0f;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Native SoundTouch processor instance. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Sample rate in Hz (e.g., 44100). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Current pitch in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Flag indicating if processor is initialized. */
    private boolean mIsInitialized = false;
    
    // ========================================================================
    // Public API
    // ========================================================================
    
    /**
     * Configures the audio processor with sample rate and channel count.
     * 
     * <p>This method must be called before processing any audio. It creates
     * the native SoundTouch instance and configures it for the specified
     * audio format.</p>
     * 
     * <p><b>Note:</b> The processor expects 16-bit PCM audio in little-endian
     * byte order. For stereo, samples are interleaved (L, R, L, R, ...).</p>
     *
     * @param sampleRate Sample rate in Hz (e.g., 44100 for CD quality)
     * @param channels Number of channels (1 = mono, 2 = stereo)
     * @return true if configuration was successful, false otherwise
     */
    public boolean configure(int sampleRate, int channels) {
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "PitchShifter library not available");
            return false;
        }
        
        try {
            // Release previous instance if exists
            if (mPitchShifter != null) {
                mPitchShifter.close();
            }
            
            // Create new SoundTouch instance
            mPitchShifter = new PitchShifter(sampleRate, channels);
            mSampleRate = sampleRate;
            mChannels = channels;
            mIsInitialized = true;
            
            // Apply current settings
            if (mCurrentPitch != 0f) {
                mPitchShifter.setPitch(mCurrentPitch);
            }
            if (mCurrentTempo != 1.0f) {
                mPitchShifter.setTempo(mCurrentTempo);
            }
            
            Log.d(TAG, "AudioProcessor configured: " + sampleRate + "Hz, " + channels + "ch");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure AudioProcessor", e);
            return false;
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Range: -6.0 to +6.0 semitones</p>
     * 
     * <p>The pitch change is independent of tempo - adjusting pitch does not
     * affect playback speed.</p>
     *
     * @param semitones Pitch shift in semitones (positive = higher pitch)
     */
    public void setPitchSemitones(float semitones) {
        // Clamp to valid range
        if (semitones < MIN_PITCH) {
            semitones = MIN_PITCH;
        }
        if (semitones > MAX_PITCH) {
            semitones = MAX_PITCH;
        }
        mCurrentPitch = semitones;
        
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Range: 0.5 to 1.5</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower)</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     * 
     * <p>The tempo change is independent of pitch - adjusting speed does not
     * affect the pitch.</p>
     *
     * @param tempo Tempo multiplier
     */
    public void setTempo(float tempo) {
        // Clamp to valid range
        if (tempo < MIN_TEMPO) {
            tempo = MIN_TEMPO;
        }
        if (tempo > MAX_TEMPO) {
            tempo = MAX_TEMPO;
        }
        mCurrentTempo = tempo;
        
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
        }
    }
    
    /**
     * Processes audio frames through the pitch shifter.
     * 
     * <p>This is a streaming API that processes input audio and returns
     * processed output. The amount of output may differ from input due
     * to tempo changes.</p>
     * 
     * <p><b>Note:</b> For tempo > 1.0, output may be shorter than input.
     * For tempo < 1.0, output may be longer than input.</p>
     *
     * @param input Array of 16-bit PCM samples (interleaved for stereo)
     * @param frames Number of frames (each frame = channels samples)
     * @return Processed audio output, or input if no processing needed
     */
    @NonNull
    public short[] process(@NonNull short[] input, int frames) {
        if (!mIsInitialized || mPitchShifter == null) {
            return input;
        }
        
        try {
            // Feed input to SoundTouch
            mPitchShifter.putFrames(input, frames);
            
            // Check how many frames are available for output
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return new short[0];
            }
            
            // Receive processed frames
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                // Trim to actual received size if necessary
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
            
            return new short[0];
            
        } catch (Exception e) {
            Log.e(TAG, "Process error", e);
            return input;
        }
    }
    
    /**
     * Returns the number of available frames in the processor output buffer.
     * 
     * <p>This method can be used to check how much processed audio is
     * ready before calling receive().</p>
     *
     * @return Number of frames available, or 0 if not initialized
     */
    public int numAvailableFrames() {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        return mPitchShifter.numFrames();
    }
    
    /**
     * Receives processed audio into the provided buffer.
     * 
     * <p>This method copies processed samples from SoundTouch into the
     * output buffer. The buffer should be large enough to hold the
     * number of frames returned by numAvailableFrames().</p>
     *
     * @param output Buffer to receive processed samples
     * @return Number of frames actually received
     */
    public int receive(@NonNull short[] output) {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        int frames = output.length / mChannels;
        return mPitchShifter.receiveFrames(output, frames);
    }
    
    /**
     * Flushes any remaining audio from the processor.
     * 
     * <p>Call this method after all input has been processed to ensure
     * any remaining audio is retrieved.</p>
     */
    public void flush() {
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.flush();
        }
    }
    
    /**
     * Clears all internal buffers.
     * 
     * <p>This method resets the processor's internal state, discarding
     * any pending input or output.</p>
     */
    public void clear() {
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
        }
    }
    
    /**
     * Checks if the processor is initialized and ready.
     *
     * @return true if initialized, false otherwise
     */
    public boolean isInitialized() {
        return mIsInitialized && mPitchShifter != null;
    }
    
    /**
     * Returns the current sample rate.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the number of channels.
     *
     * @return Channel count (1 = mono, 2 = stereo)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Returns the current pitch in semitones.
     *
     * @return Pitch shift amount
     */
    public float getCurrentPitch() {
        return mCurrentPitch;
    }
    
    /**
     * Returns the current tempo multiplier.
     *
     * @return Tempo multiplier
     */
    public float getCurrentTempo() {
        return mCurrentTempo;
    }
    
    /**
     * Releases native resources.
     * 
     * <p>This method should be called when the processor is no longer needed.
     * After release, the processor cannot be used again.</p>
     */
    public void release() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        mIsInitialized = false;
        Log.d(TAG, "AudioProcessor released");
    }
}