package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * AudioProcessor - Wrapper for SoundTouch pitch and tempo processing.
 * 
 * <p>This class provides a high-level interface to the native PitchShifter
 * library. It handles buffer management and provides a simple API for
 * processing audio frames.</p>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Input PCM -> putFrames() -> SoundTouch Process -> receiveFrames() -> Output PCM
 * </pre>
 * 
 * <h3>Pitch Range</h3>
 * <p>Pitch can be adjusted from -6 to +6 semitones. Positive values raise
 * the pitch, negative values lower it.</p>
 * 
 * <h3>Tempo Range</h3>
 * <p>Tempo can be adjusted from 0.5x to 1.5x speed.</p>
 * <ul>
 *   <li>0.5 = half speed (50% slower)</li>
 *   <li>1.0 = normal speed</li>
 *   <li>1.5 = 1.5x speed (50% faster)</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All calls should be made from the same
 * thread, or external synchronization should be used.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * AudioProcessor processor = new AudioProcessor();
 * processor.configure(44100, 2);  // 44.1kHz stereo
 * processor.setPitchSemitones(2.5f);  // Raise by 2.5 semitones
 * processor.setTempo(1.25f);  // Speed up by 25%
 * 
 * // Process audio chunks
 * short[] input = getNextAudioChunk();
 * short[] output = processor.process(input, frames);
 * playOutput(output);
 * 
 * processor.release();
 * </pre>
 * 
 * @see PitchShifter
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class AudioProcessor {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "AudioProcessor";
    
    /** Minimum tempo (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch in semitones. */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch in semitones. */
    private static final float MAX_PITCH = 6.0f;
    
    /** Maximum frames to process in one batch. */
    private static final int MAX_FRAMES_PER_BATCH = 4096;
    
    /** Default frames per buffer for processing. */
    private static final int DEFAULT_FRAMES_PER_BUFFER = 1024;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Native SoundTouch processor instance. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Sample rate in Hz (e.g., 44100). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Current pitch in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Flag indicating if processor is initialized. */
    private boolean mIsInitialized = false;
    
    /** Temporary buffer for processing. */
    @Nullable
    private short[] mTempBuffer;
    
    /** Buffer size in frames. */
    private int mBufferFrames = DEFAULT_FRAMES_PER_BUFFER;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new AudioProcessor instance.
     */
    public AudioProcessor() {
        Log.d(TAG, "AudioProcessor created");
    }
    
    // ========================================================================
    // Public API - Configuration
    // ========================================================================
    
    /**
     * Configures the audio processor with sample rate and channel count.
     * 
     * <p>This method must be called before processing any audio. It creates
     * the native SoundTouch instance and configures it for the specified
     * audio format.</p>
     * 
     * <p><b>Note:</b> The processor expects 16-bit PCM audio in little-endian
     * byte order. For stereo, samples are interleaved (L, R, L, R, ...).</p>
     *
     * @param sampleRate Sample rate in Hz (e.g., 44100 for CD quality)
     * @param channels Number of channels (1 = mono, 2 = stereo)
     * @return true if configuration was successful, false otherwise
     */
    public boolean configure(int sampleRate, int channels) {
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "PitchShifter library not available");
            return false;
        }
        
        // Validate parameters
        if (sampleRate <= 0) {
            Log.e(TAG, "Invalid sample rate: " + sampleRate);
            return false;
        }
        
        if (channels != 1 && channels != 2) {
            Log.e(TAG, "Invalid channel count: " + channels + " (only 1 or 2 supported)");
            return false;
        }
        
        try {
            // Release previous instance if exists
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            // Create new SoundTouch instance
            mPitchShifter = new PitchShifter(sampleRate, channels);
            mSampleRate = sampleRate;
            mChannels = channels;
            
            // Calculate optimal buffer size (aim for ~20ms of audio)
            mBufferFrames = (sampleRate * 20 / 1000) * channels;
            mBufferFrames = Math.max(DEFAULT_FRAMES_PER_BUFFER, 
                Math.min(MAX_FRAMES_PER_BATCH, mBufferFrames));
            
            // Allocate temporary buffer
            mTempBuffer = new short[mBufferFrames * channels];
            
            // Apply current settings
            if (mCurrentPitch != 0f) {
                mPitchShifter.setPitch(mCurrentPitch);
            }
            if (mCurrentTempo != 1.0f) {
                mPitchShifter.setTempo(mCurrentTempo);
            }
            
            mIsInitialized = true;
            
            Log.d(TAG, "AudioProcessor configured: " + sampleRate + "Hz, " + channels + "ch, " +
                  "buffer=" + mBufferFrames + " frames");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure AudioProcessor", e);
            mIsInitialized = false;
            return false;
        }
    }
    
    // ========================================================================
    // Public API - Parameter Control
    // ========================================================================
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Range: -6.0 to +6.0 semitones</p>
     * 
     * <p>The pitch change is independent of tempo - adjusting pitch does not
     * affect playback speed.</p>
     *
     * @param semitones Pitch shift in semitones (positive = higher pitch)
     */
    public void setPitchSemitones(float semitones) {
        // Clamp to valid range
        float clamped = semitones;
        if (clamped < MIN_PITCH) {
            clamped = MIN_PITCH;
        }
        if (clamped > MAX_PITCH) {
            clamped = MAX_PITCH;
        }
        mCurrentPitch = clamped;
        
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.setPitch(clamped);
            Log.v(TAG, "Pitch set to: " + clamped + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Range: 0.5 to 1.5</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower)</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     * 
     * <p>The tempo change is independent of pitch - adjusting speed does not
     * affect the pitch.</p>
     *
     * @param tempo Tempo multiplier
     */
    public void setTempo(float tempo) {
        // Clamp to valid range
        float clamped = tempo;
        if (clamped < MIN_TEMPO) {
            clamped = MIN_TEMPO;
        }
        if (clamped > MAX_TEMPO) {
            clamped = MAX_TEMPO;
        }
        mCurrentTempo = clamped;
        
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.setTempo(clamped);
            Log.v(TAG, "Tempo set to: " + clamped + "x");
        }
    }
    
    // ========================================================================
    // Public API - Processing Methods
    // ========================================================================
    
    /**
     * Processes audio frames through the pitch shifter.
     * 
     * <p>This is a streaming API that processes input audio and returns
     * processed output. The amount of output may differ from input due
     * to tempo changes.</p>
     * 
     * <p><b>Note:</b> For tempo > 1.0, output may be shorter than input.
     * For tempo < 1.0, output may be longer than input.</p>
     *
     * @param input Array of 16-bit PCM samples (interleaved for stereo)
     * @param frames Number of frames (each frame = channels samples)
     * @return Processed audio output, or input if no processing needed
     */
    @NonNull
    public short[] process(@NonNull short[] input, int frames) {
        if (!mIsInitialized || mPitchShifter == null) {
            return input;
        }
        
        if (frames <= 0 || input.length < frames * mChannels) {
            return new short[0];
        }
        
        try {
            // Feed input to SoundTouch
            mPitchShifter.putFrames(input, frames);
            
            // Check how many frames are available for output
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return new short[0];
            }
            
            // Receive processed frames
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                // Trim to actual received size if necessary
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
            
            return new short[0];
            
        } catch (Exception e) {
            Log.e(TAG, "Process error", e);
            return input;
        }
    }
    
    /**
     * Processes audio frames with automatic batching for efficiency.
     * 
     * <p>This method automatically splits large inputs into optimal batch sizes
     * to prevent buffer overflow in the native SoundTouch processor.</p>
     *
     * @param input Array of 16-bit PCM samples (interleaved for stereo)
     * @param frames Number of frames (each frame = channels samples)
     * @return Processed audio output
     */
    @NonNull
    public short[] processBatched(@NonNull short[] input, int frames) {
        if (!mIsInitialized || mPitchShifter == null) {
            return input;
        }
        
        if (frames <= 0 || input.length < frames * mChannels) {
            return new short[0];
        }
        
        // If input is small enough, process directly
        if (frames <= mBufferFrames) {
            return process(input, frames);
        }
        
        // Process in batches
        int framesProcessed = 0;
        java.util.ArrayList<short[]> outputChunks = new java.util.ArrayList<>();
        int totalOutputFrames = 0;
        
        while (framesProcessed < frames) {
            int batchFrames = Math.min(mBufferFrames, frames - framesProcessed);
            int batchSamples = batchFrames * mChannels;
            
            // Create batch input buffer
            short[] batchInput = new short[batchSamples];
            System.arraycopy(input, framesProcessed * mChannels, batchInput, 0, batchSamples);
            
            // Process batch
            short[] batchOutput = process(batchInput, batchFrames);
            
            if (batchOutput.length > 0) {
                outputChunks.add(batchOutput);
                totalOutputFrames += batchOutput.length / mChannels;
            }
            
            framesProcessed += batchFrames;
        }
        
        // Combine all output chunks
        if (outputChunks.isEmpty()) {
            return new short[0];
        }
        
        short[] combined = new short[totalOutputFrames * mChannels];
        int offset = 0;
        for (short[] chunk : outputChunks) {
            System.arraycopy(chunk, 0, combined, offset, chunk.length);
            offset += chunk.length;
        }
        
        return combined;
    }
    
    /**
     * Non-blocking receive - attempts to get processed audio once.
     * 
     * <p>This method is useful for real-time processing loops where
     * you don't want to block waiting for output.</p>
     *
     * @return Processed audio buffer, or null if none available
     */
    @Nullable
    public short[] tryReceiveOnce() {
        if (!mIsInitialized || mPitchShifter == null) {
            return null;
        }
        
        try {
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return null;
            }
            
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
        } catch (Exception e) {
            Log.w(TAG, "tryReceiveOnce error", e);
        }
        
        return null;
    }
    
    /**
     * Processes a single frame of audio (convenience method).
     *
     * @param left Left channel sample
     * @param right Right channel sample (ignored for mono)
     * @return Processed sample pair (left, right) or null if not enough output
     */
    @Nullable
    public short[] processFrame(short left, short right) {
        if (!mIsInitialized || mPitchShifter == null) {
            return null;
        }
        
        short[] input = mChannels == 1 ? new short[]{left} : new short[]{left, right};
        
        try {
            mPitchShifter.putFrames(input, 1);
            
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return null;
            }
            
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
        } catch (Exception e) {
            Log.w(TAG, "processFrame error", e);
        }
        
        return null;
    }
    
    // ========================================================================
    // Public API - Buffer Management
    // ========================================================================
    
    /**
     * Returns the number of available frames in the processor output buffer.
     * 
     * <p>This method can be used to check how much processed audio is
     * ready before calling receive().</p>
     *
     * @return Number of frames available, or 0 if not initialized
     */
    public int numAvailableFrames() {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        return mPitchShifter.numFrames();
    }
    
    /**
     * Receives processed audio into the provided buffer.
     * 
     * <p>This method copies processed samples from SoundTouch into the
     * output buffer. The buffer should be large enough to hold the
     * number of frames returned by numAvailableFrames().</p>
     *
     * @param output Buffer to receive processed samples
     * @return Number of frames actually received
     */
    public int receive(@NonNull short[] output) {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        int frames = output.length / mChannels;
        return mPitchShifter.receiveFrames(output, frames);
    }
    
    /**
     * Flushes any remaining audio from the processor.
     * 
     * <p>Call this method after all input has been processed to ensure
     * any remaining audio is retrieved. The processor will continue to
     * produce output for a short time after flush.</p>
     */
    public void flush() {
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.flush();
            Log.v(TAG, "Processor flushed");
        }
    }
    
    /**
     * Clears all internal buffers immediately.
     * 
     * <p>This method resets the processor's internal state, discarding
     * any pending input or output. Unlike flush(), this does not
     * produce any remaining output.</p>
     */
    public void clear() {
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
            Log.v(TAG, "Processor cleared");
        }
    }
    
    /**
     * Resets the processor to its initial state.
     * 
     * <p>This method clears all buffers and resets pitch/tempo to defaults.
     * The processor remains configured with the same sample rate and channels.</p>
     */
    public void reset() {
        if (mIsInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
            
            // Reset parameters to defaults
            mCurrentPitch = 0f;
            mCurrentTempo = 1.0f;
            mPitchShifter.setPitch(0f);
            mPitchShifter.setTempo(1.0f);
            
            Log.d(TAG, "Processor reset");
        }
    }
    
    // ========================================================================
    // Public API - State Queries
    // ========================================================================
    
    /**
     * Checks if the processor is initialized and ready.
     *
     * @return true if initialized, false otherwise
     */
    public boolean isInitialized() {
        return mIsInitialized && mPitchShifter != null;
    }
    
    /**
     * Returns the current sample rate.
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the number of channels.
     *
     * @return Channel count (1 = mono, 2 = stereo)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Returns the current pitch in semitones.
     *
     * @return Pitch shift amount
     */
    public float getCurrentPitch() {
        return mCurrentPitch;
    }
    
    /**
     * Returns the current tempo multiplier.
     *
     * @return Tempo multiplier
     */
    public float getCurrentTempo() {
        return mCurrentTempo;
    }
    
    /**
     * Returns the recommended buffer size in frames.
     *
     * @return Buffer size in frames
     */
    public int getRecommendedBufferFrames() {
        return mBufferFrames;
    }
    
    /**
     * Calculates the expected output frame count for a given input.
     * 
     * <p>This is an estimate based on the current tempo. Actual output
     * may vary due to internal buffering.</p>
     *
     * @param inputFrames Number of input frames
     * @return Estimated output frames
     */
    public int estimateOutputFrames(int inputFrames) {
        if (!mIsInitialized) {
            return inputFrames;
        }
        return Math.round(inputFrames / mCurrentTempo);
    }
    
    // ========================================================================
    // Public API - Resource Management
    // ========================================================================
    
    /**
     * Releases native resources.
     * 
     * <p>This method should be called when the processor is no longer needed.
     * After release, the processor cannot be used again without calling
     * configure() again.</p>
     */
    public void release() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        
        mTempBuffer = null;
        mIsInitialized = false;
        
        Log.d(TAG, "AudioProcessor released");
    }
    
    // ========================================================================
    // Package-Private Methods for SoundTouchPlayer Integration
    // ========================================================================
    
    /**
     * Processes audio frames and returns output, keeping internal state.
     * This is a lower-level method for use by SoundTouchPlayer.
     *
     * @param input Input PCM samples
     * @param frames Number of frames
     * @param output Buffer to receive output
     * @return Number of output samples written
     */
    int processToBuffer(@NonNull short[] input, int frames, @NonNull short[] output) {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        
        try {
            mPitchShifter.putFrames(input, frames);
            
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return 0;
            }
            
            int maxReceiveFrames = output.length / mChannels;
            int receiveFrames = Math.min(availableFrames, maxReceiveFrames);
            int received = mPitchShifter.receiveFrames(output, receiveFrames);
            
            return received * mChannels;
            
        } catch (Exception e) {
            Log.e(TAG, "processToBuffer error", e);
            return 0;
        }
    }
    
    /**
     * Checks if the processor has any pending output.
     *
     * @return True if there are frames available
     */
    boolean hasOutput() {
        return mIsInitialized && mPitchShifter != null && mPitchShifter.numFrames() > 0;
    }
    
    /**
     * Gets the number of frames of pending output.
     *
     * @return Number of pending frames
     */
    int getPendingFrames() {
        if (!mIsInitialized || mPitchShifter == null) {
            return 0;
        }
        return mPitchShifter.numFrames();
    }
}