package com.ark.llama;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Activity for editing audio file metadata including ID3 tags and album art.
 * 
 * <p>This activity provides a comprehensive interface for viewing and modifying
 * audio file metadata. It supports editing of ID3 tags (title, artist, album,
 * year, genre, track number, lyrics) and album art for various audio formats
 * including MP3, FLAC, OGG, M4A, and WMA.</p>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The MetadataEditor follows a two-mode design pattern:</p>
 * <ul>
 *   <li><b>VIEW MODE</b> - Read-only display of metadata with "MODIFY" button</li>
 *   <li><b>EDIT MODE</b> - Editable fields with "UPDATE" button to save changes</li>
 * </ul>
 * 
 * <p>The activity integrates with the Storage Access Framework (SAF) to obtain
 * write permissions for audio files, as direct file system access is restricted
 * on modern Android versions (Scoped Storage).</p>
 * 
 * <h3>Integration Points</h3>
 * <ul>
 *   <li>{@link MetadataReader} - Extracts metadata from audio files</li>
 *   <li>{@link MetadataWriter} - Writes metadata back to audio files with backup/restore</li>
 *   <li>{@link StorageAccessHelper} - Manages SAF URI permissions</li>
 *   <li>{@link SongDatabase} - Caches song metadata and URIs</li>
 *   <li>{@link NavigationController} - Coordinates global button state during sync</li>
 *   <li>{@link ThemeHelper} / {@link ThemeManager} - Dynamic theme color application</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MetadataEditor extends Activity implements NavigationController.ButtonStateListener {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MetadataEditor";
    
    /** Request code for gallery image selection. */
    private static final int GALLERY_REQUEST_CODE = 400;
    
    /** Request code for gallery permission request. */
    private static final int PERMISSION_GALLERY_REQUEST = 401;
    
    /** Request code for SAF file picker. */
    private static final int REQUEST_SAF_FILE_PICKER = 402;
    
    /** UI mode: view-only (read metadata). */
    private static final int MODE_VIEW = 0;
    
    /** UI mode: editable (modify metadata). */
    private static final int MODE_EDIT = 1;
    
    /** State: song is not currently playing. */
    private static final int SONG_STATE_NOT_CURRENT = 0;
    
    /** State: song was playing before edit. */
    private static final int SONG_STATE_WAS_PLAYING = 1;
    
    /** State: song was paused before edit. */
    private static final int SONG_STATE_WAS_PAUSED = 2;
    
    /** Duration of button press animation in milliseconds. */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Maximum dimension for album art in pixels. */
    private static final int MAX_ALBUM_ART_SIZE_PX = 1024;
    
    /** JPEG compression quality for album art (0-100). */
    private static final int ALBUM_ART_QUALITY = 95;
    
    /** Maximum length for title field. */
    private static final int MAX_TITLE_LENGTH = 200;
    
    /** Maximum length for artist field. */
    private static final int MAX_ARTIST_LENGTH = 200;
    
    /** Maximum length for album field. */
    private static final int MAX_ALBUM_LENGTH = 200;
    
    /** Maximum length for year field. */
    private static final int MAX_YEAR_LENGTH = 4;
    
    /** Maximum length for genre field. */
    private static final int MAX_GENRE_LENGTH = 50;
    
    /** Maximum length for track number field. */
    private static final int MAX_TRACK_LENGTH = 3;
    
    /** Maximum length for lyrics field. */
    private static final int MAX_LYRICS_LENGTH = 5000;
    
    /** Debounce delay for button clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 500;
    
    /** Delay for button click actions in milliseconds. */
    private static final long CLICK_ACTION_DELAY_MS = 1000;
    
    /** Corner radius for album art in density-independent pixels. */
    private static final int ALBUM_ART_CORNER_RADIUS_DP = 10;
    
    /** Size of progress bar in density-independent pixels. */
    private static final int PROGRESS_BAR_SIZE_DP = 48;
    
    /** Alpha value for loading overlay dimming (0-255). */
    private static final int DIM_ALPHA = 180;
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Delay before showing keyboard when entering edit mode. */
    private static final int KEYBOARD_SHOW_DELAY_MS = 1000;
    
    /** Delay before hiding keyboard during update. */
    private static final int KEYBOARD_HIDE_DELAY_MS = 500;
    
    /** Intent extra key for awaiting file selection flag. */
    private static final String EXTRA_AWAITING_FILE_SELECTION = "awaiting_file_selection";
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    /** Button to cancel and exit. */
    @Nullable private Button mCancelButton;
    
    /** Button that changes between SELECT/MODIFY/UPDATE based on state. */
    @Nullable private Button mActionButton;
    
    /** Header title showing current mode (VIEW MODE / EDIT MODE). */
    @Nullable private TextView mHeaderTitle;
    
    /** Text showing file format (e.g., "MP3 file"). */
    @Nullable private TextView mFormatText;
    
    /** ImageView for displaying album art. */
    @Nullable private ImageView mAlbumArtView;
    
    /** Hint text for album art interaction (tap to add / long press to remove). */
    @Nullable private TextView mAlbumArtHint;
    
    /** EditText for song title. */
    @Nullable private EditText mTitleEdit;
    
    /** EditText for artist name. */
    @Nullable private EditText mArtistEdit;
    
    /** EditText for album name. */
    @Nullable private EditText mAlbumEdit;
    
    /** EditText for release year (numeric only). */
    @Nullable private EditText mYearEdit;
    
    /** EditText for music genre. */
    @Nullable private EditText mGenreEdit;
    
    /** EditText for track number (numeric only). */
    @Nullable private EditText mTrackEdit;
    
    /** EditText for song lyrics (multi-line). */
    @Nullable private EditText mLyricsEdit;
    
    /** EditText showing file info (size, bitrate, duration). */
    @Nullable private EditText mFileInfoText;
    
    /** ScrollView containing the metadata form. */
    @Nullable private ScrollView mScrollView;
    
    /** Root layout for touch event handling. */
    @Nullable private LinearLayout mRootLayout;
    
    /** Container for album art with rounded corners. */
    @Nullable private FrameLayout mAlbumArtContainer;
    
    // ========================================================================
    // Data Components
    // ========================================================================
    
    /** Absolute file path of the audio file. */
    @Nullable private String mFilePath;
    
    /** Original Song object from database (cached). */
    @Nullable private Song mOriginalSong;
    
    /** Original metadata bundle loaded from file. */
    @Nullable private MetadataReader.MetadataBundle mOriginalData;
    
    /** Current UI mode (VIEW or EDIT). */
    private int mCurrentMode = MODE_VIEW;
    
    /** Flag indicating if text fields have been modified. */
    private boolean mHasTextChanges = false;
    
    /** Flag indicating if album art has been modified (added/removed). */
    private boolean mAlbumArtChanged = false;
    
    /** New album art bytes to save (null if unchanged). */
    @Nullable private byte[] mNewAlbumArt = null;
    
    /** Flag indicating if album art was deleted. */
    private boolean mAlbumArtDeleted = false;
    
    /** SAF URI with write permission for the file. */
    @Nullable private Uri mGrantedFileUri = null;
    
    /** Flag indicating activity is waiting for file selection result. */
    private boolean mAwaitingFileSelection = false;
    
    /** Original title value for change detection. */
    @Nullable private String mOriginalTitle;
    
    /** Original artist value for change detection. */
    @Nullable private String mOriginalArtist;
    
    /** Original album value for change detection. */
    @Nullable private String mOriginalAlbum;
    
    /** Original year value for change detection. */
    @Nullable private String mOriginalYear;
    
    /** Original genre value for change detection. */
    @Nullable private String mOriginalGenre;
    
    /** Original track number value for change detection. */
    @Nullable private String mOriginalTrack;
    
    /** Original lyrics value for change detection. */
    @Nullable private String mOriginalLyrics;
    
    /** Previous playback state of the song before editing. */
    private int mPreviousSongState = SONG_STATE_NOT_CURRENT;
    
    // ========================================================================
    // Managers and Helpers
    // ========================================================================
    
    /** Helper for Storage Access Framework operations. */
    @Nullable private StorageAccessHelper mStorageHelper;
    
    /** Atomic flag to prevent concurrent save operations. */
    @NonNull private final AtomicBoolean mIsSaving = new AtomicBoolean(false);
    
    /** Main thread handler for UI operations. */
    @NonNull private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Handler for delayed actions (debouncing). */
    @NonNull private final Handler mActionHandler = new Handler(Looper.getMainLooper());
    
    /** Executor service for background operations (metadata reading/writing). */
    @Nullable private ExecutorService mExecutor;
    
    /** Executor service for album art loading (replaces AsyncTask). */
    @Nullable private ExecutorService mAlbumArtExecutor;
    
    /** Theme manager for accessing current theme color. */
    @Nullable private ThemeManager mThemeManager;
    
    /** Theme helper for applying theme to UI components. */
    @Nullable private ThemeHelper mThemeHelper;
    
    /** Timestamp of last action button click for debouncing. */
    private long mLastActionClickTime = 0;
    
    /** Timestamp of last cancel button click for debouncing. */
    private long mLastCancelClickTime = 0;
    
    /** Timestamp of last modify click for debouncing. */
    private long mLastModifyClickTime = 0;
    
    /** Timestamp of last select click for debouncing. */
    private long mLastSelectClickTime = 0;
    
    /** Flag indicating a file selection request is in progress. */
    private volatile boolean mRequestInProgress = false;
    
    /** Loading overlay view (shown during async operations). */
    @Nullable private FrameLayout mLoadingOverlay;
    
    /** Flag for tracking album art loading task cancellation. */
    private volatile boolean mCurrentAlbumArtTaskCancelled = false;
    
    /** Current album art loading task file path. */
    @Nullable private String mCurrentLoadingArtPath = null;
    
    // ========================================================================
    // Activity Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>Initializes managers, sets up UI components, and loads metadata
     * either from a provided file path or URI. Handles two scenarios:</p>
     * <ul>
     *   <li>File specified via intent extras - loads metadata directly</li>
     *   <li>No file selected - shows placeholder UI and awaits file selection</li>
     * </ul>
     * 
     * @param savedInstanceState Previously saved state (not used)
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreen();
        setContentView(R.layout.activity_metadata_editor);
        
        mThemeManager = ThemeManager.getInstance(this);
        mThemeHelper = ThemeHelper.getInstance(this);
        mStorageHelper = StorageAccessHelper.getInstance(this);
        mExecutor = Executors.newSingleThreadExecutor();
        mAlbumArtExecutor = Executors.newSingleThreadExecutor();
        
        NavigationController.getInstance().registerListener(this);
        
        mFilePath = getIntent().getStringExtra("song_path");
        String songUri = getIntent().getStringExtra("song_uri");
        
        if (songUri != null) {
            mGrantedFileUri = Uri.parse(songUri);
        }
        
        if (mFilePath != null && mGrantedFileUri == null) {
            Song cachedSong = SongDatabase.getInstance(this).getSong(mFilePath);
            if (cachedSong != null && cachedSong.getUri() != null) {
                mGrantedFileUri = cachedSong.getContentUri();
                Log.d(TAG, "Retrieved URI from database cache: " + mGrantedFileUri);
            }
        }
        
        mAwaitingFileSelection = getIntent().getBooleanExtra(EXTRA_AWAITING_FILE_SELECTION, false);
        
        initializeViews();
        setupInputFilters();
        setupTextWatchers();
        
        if (mAwaitingFileSelection && mFilePath == null && mGrantedFileUri == null) {
            setPlaceholderUI();
        } else if (mFilePath == null && mGrantedFileUri == null) {
            ToastManager.showToast(this, "No file selected", ToastManager.LENGTH_NORMAL);
            finish();
            return;
        } else {
            if (mFilePath != null) {
                mOriginalSong = CharacterMapper.getSongFromFile(mFilePath);
            }
            loadMetadataAsync();
        }
        
        applyThemeToUI();
    }
    
    /**
     * Called when the activity is destroyed.
     * Cleans up resources, cancels async tasks, and shuts down executor.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        NavigationController.getInstance().unregisterListener(this);
        
        mCurrentAlbumArtTaskCancelled = true;
        if (mExecutor != null && !mExecutor.isShutdown()) {
            mExecutor.shutdown();
        }
        if (mAlbumArtExecutor != null && !mAlbumArtExecutor.isShutdown()) {
            mAlbumArtExecutor.shutdown();
        }
        mMainHandler.removeCallbacksAndMessages(null);
        mActionHandler.removeCallbacksAndMessages(null);
    }
    
    /**
     * Called when the activity resumes.
     * Re-applies theme colors to ensure consistency.
     */
    @Override
    protected void onResume() {
        super.onResume();
        
        // Sync button state with NavigationController
        onButtonStateChanged(NavigationController.ButtonGroup.FOLDER_ACTIONS, 
            NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.FOLDER_ACTIONS));
        
        applyThemeToUI();
    }
    
    /**
     * Handles the back button press.
     * Hides keyboard and applies slide-down animation.
     */
    @Override
    public void onBackPressed() {
        hideKeyboard();
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
    
    /**
     * Called when the window gains or loses focus.
     * Re-applies immersive mode when window has focus.
     * 
     * @param hasFocus True if the window has focus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            applyImmersiveMode();
        }
    }
    
    /**
     * Applies immersive mode for full-screen experience.
     * Uses modern API for Android 11+ and legacy for older versions.
     */
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(android.view.WindowInsets.Type.statusBars() | 
                               android.view.WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    
    // ========================================================================
    // NavigationController Listener Implementation
    // ========================================================================
    
    /**
     * Called when the state of a button group changes in NavigationController.
     * Disables the MODIFY/UPDATE button during playlist sync operations.
     * 
     * @param group The button group that changed
     * @param disabled True if the group is now disabled
     */
    @Override
    public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
        if (group == NavigationController.ButtonGroup.METADATA_ACTIONS) {
            final boolean finalDisabled = disabled;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mActionButton == null) {
                        return;
                    }
                    
                    String buttonText = mActionButton.getText().toString();
                    
                    // SELECT button remains enabled even during sync
                    if ("SELECT".equals(buttonText)) {
                        mActionButton.setEnabled(true);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mActionButton, true);
                        }
                    } else {
                        mActionButton.setEnabled(!finalDisabled);
                        if (mThemeHelper != null) {
                            mThemeHelper.updateButton(mActionButton, !finalDisabled);
                        }
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Full Screen Configuration
    // ========================================================================
    
    /**
     * Configures the activity for full-screen immersive mode.
     * Sets appropriate status bar and navigation bar colors based on Android version.
     * Uses modern API for Android 11+ and legacy for older versions.
     */
    @SuppressWarnings("deprecation")
    private void setFullScreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark, null));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark, null));
            } else {
                getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundDark));
                getWindow().setNavigationBarColor(getResources().getColor(R.color.backgroundDark));
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            applyImmersiveMode();
        }
        
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
    
    // ========================================================================
    // UI Initialization Methods
    // ========================================================================
    
    /**
     * Initializes all UI components, sets up click listeners,
     * and configures text field behavior.
     */
    private void initializeViews() {
        mCancelButton = findViewById(R.id.cancelButton);
        mActionButton = findViewById(R.id.actionButton);
        mHeaderTitle = findViewById(R.id.headerTitle);
        mFormatText = findViewById(R.id.formatText);
        mAlbumArtView = findViewById(R.id.albumArtView);
        mAlbumArtHint = findViewById(R.id.albumArtHint);
        mTitleEdit = findViewById(R.id.titleEdit);
        mArtistEdit = findViewById(R.id.artistEdit);
        mAlbumEdit = findViewById(R.id.albumEdit);
        mYearEdit = findViewById(R.id.yearEdit);
        mGenreEdit = findViewById(R.id.genreEdit);
        mTrackEdit = findViewById(R.id.trackEdit);
        mLyricsEdit = findViewById(R.id.lyricsEdit);
        mFileInfoText = findViewById(R.id.fileInfoText);
        mScrollView = findViewById(R.id.scrollView);
        mRootLayout = findViewById(R.id.rootLayout);
        mAlbumArtContainer = findViewById(R.id.albumArtContainer);
        
        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
        }
        
        // Configure Cancel button
        if (mCancelButton != null) {
            mCancelButton.setText("CANCEL");
            mCancelButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        
        // Configure Action button (SELECT / MODIFY / UPDATE)
        if (mActionButton != null) {
            if (mFilePath != null || mGrantedFileUri != null) {
                mActionButton.setText("MODIFY");
            } else {
                mActionButton.setText("SELECT");
            }
            mActionButton.setBackgroundResource(R.drawable.button_border_selector);
        }
        
        if (mAlbumArtView != null) {
            mAlbumArtView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }
        
        // Apply button animations
        animateButton(mCancelButton);
        animateButton(mActionButton);
        
        // Cancel button click listener
        if (mCancelButton != null) {
            mCancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastCancelClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastCancelClickTime = now;
                        handleCancelClick();
                    }
                }
            });
        }
        
        // Action button click listener (handles SELECT/MODIFY/UPDATE)
        if (mActionButton != null) {
            mActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastActionClickTime >= CLICK_DEBOUNCE_DELAY_MS) {
                        mLastActionClickTime = now;
                        handleModifyClick();
                    }
                }
            });
        }
        
        // Album art click listener (add album art in edit mode)
        if (mAlbumArtView != null) {
            mAlbumArtView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) {
                        checkGalleryPermissionAndOpen();
                    }
                }
            });
        }
        
        // Album art long-click listener (remove album art in edit mode)
        if (mAlbumArtView != null) {
            mAlbumArtView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (mCurrentMode == MODE_EDIT && !mIsSaving.get()) {
                        removeAlbumArt();
                        return true;
                    }
                    return false;
                }
            });
        }
        
        // Hide keyboard when touching outside edit fields
        if (mRootLayout != null) {
            mRootLayout.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        hideKeyboard();
                    }
                    return false;
                }
            });
        }
        
        setupLyricsScrolling();
        setFieldsEnabled(false);
        
        if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }
    }
    
    /**
     * Sets up placeholder UI when no file is initially selected.
     * Shows empty fields and changes action button to "SELECT".
     */
    private void setPlaceholderUI() {
        setPlaceholderAlbumArt();
        if (mTitleEdit != null) mTitleEdit.setText("");
        if (mArtistEdit != null) mArtistEdit.setText("");
        if (mAlbumEdit != null) mAlbumEdit.setText("");
        if (mYearEdit != null) mYearEdit.setText("");
        if (mGenreEdit != null) mGenreEdit.setText("");
        if (mTrackEdit != null) mTrackEdit.setText("");
        if (mLyricsEdit != null) mLyricsEdit.setText("");
        if (mFormatText != null) mFormatText.setText("No file");
        if (mHeaderTitle != null) mHeaderTitle.setText("VIEW MODE");
        
        // Clear text so hint "No file selected" shows
        if (mFileInfoText != null) {
            mFileInfoText.setText(null);
            mFileInfoText.setTextColor(Color.parseColor("#5A5A5A"));
        }
        
        if (mActionButton != null) {
            mActionButton.setText("SELECT");
            setActionButtonEnabled(true);
        }
    }
    
    /**
     * Configures the lyrics EditText to support smooth scrolling
     * within the parent ScrollView without conflict.
     */
    private void setupLyricsScrolling() {
        if (mLyricsEdit == null) {
            return;
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            mLyricsEdit.setMovementMethod(new android.text.method.ScrollingMovementMethod());
        }
        
        mLyricsEdit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN && mScrollView != null) {
                    mScrollView.requestDisallowInterceptTouchEvent(true);
                }
                return false;
            }
        });
        
        mLyricsEdit.setTextIsSelectable(false);
        mLyricsEdit.setFocusable(false);
        mLyricsEdit.setFocusableInTouchMode(false);
        mLyricsEdit.setLongClickable(false);
        mLyricsEdit.setCustomSelectionActionModeCallback(null);
        mLyricsEdit.setCustomInsertionActionModeCallback(null);
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * The button scales down to 97% on touch and returns to normal on release.
     * 
     * @param button The button to animate (can be null)
     */
    private void animateButton(@Nullable final Button button) {
        if (button == null) {
            return;
        }
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(ANIMATION_SCALE_DOWN).scaleY(ANIMATION_SCALE_DOWN)
                                .setDuration(ANIMATION_DURATION_MS).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(ANIMATION_SCALE_NORMAL).scaleY(ANIMATION_SCALE_NORMAL)
                                .setDuration(ANIMATION_DURATION_MS).start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }
    
    // ========================================================================
    // Handle Select/Modify/Update Button Clicks
    // ========================================================================
    
    /**
     * Handles clicks on the main action button.
     * Behavior changes based on current button text:
     * <ul>
     *   <li><b>SELECT</b> - Opens SAF file picker to choose an audio file</li>
     *   <li><b>MODIFY</b> - Validates write permission and enters edit mode</li>
     *   <li><b>UPDATE</b> - Saves metadata changes</li>
     * </ul>
     */
    private void handleModifyClick() {
        String buttonText = mActionButton != null ? mActionButton.getText().toString() : "";
        
        // SELECT BUTTON - Choose a file
        if ("SELECT".equals(buttonText)) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - mLastSelectClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                return;
            }
            mLastSelectClickTime = currentTime;
            
            ToastManager.showToast(this, "Please select an audio file", ToastManager.LENGTH_NORMAL);
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        openFilePicker();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }
        
        // UPDATE BUTTON (Save Changes)
        if (mCurrentMode == MODE_EDIT) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                return;
            }
            mLastModifyClickTime = currentTime;
            
            if (NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.METADATA_ACTIONS)) {
                ToastManager.showToast(this, "Please wait, playlist is syncing...", ToastManager.LENGTH_NORMAL);
                return;
            }
            hideKeyboard();
            
            ToastManager.showToast(this, "Saving metadata...", ToastManager.LENGTH_NORMAL);
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        saveChanges();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }
        
        // MODIFY BUTTON (Enter Edit Mode)
        long currentTime = System.currentTimeMillis();
        if (currentTime - mLastModifyClickTime < CLICK_DEBOUNCE_DELAY_MS) {
            return;
        }
        mLastModifyClickTime = currentTime;
        
        if (NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(this, "Please wait, playlist is syncing...", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        boolean hasValidUri = false;
        
        // Try to get URI from database
        if (mFilePath != null) {
            hasValidUri = getStoredUri(mFilePath);
        }
        
        // Check if existing URI has write permission
        if (!hasValidUri && mGrantedFileUri != null && hasWritePermission(mGrantedFileUri)) {
            hasValidUri = true;
            saveUriToDatabase();
            Log.d(TAG, "MODIFY: Using existing mGrantedFileUri with write permission");
        }
        
        if (hasValidUri) {
            Log.d(TAG, "MODIFY: Successfully resolved URI, entering edit mode");
            mActionHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing() && !isDestroyed()) {
                        enterEditMode();
                    }
                }
            }, CLICK_ACTION_DELAY_MS);
            return;
        }
        
        // No valid URI - request SAF access
        Log.d(TAG, "MODIFY: No valid URI found, requesting SAF access");
        ToastManager.showToast(this, "Please reselect the file to enable editing", ToastManager.LENGTH_NORMAL);
        mActionHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    requestSafFileAccess();
                }
            }
        }, CLICK_ACTION_DELAY_MS);
    }
    
    /**
     * Opens the system file picker for audio file selection.
     * Uses ACTION_OPEN_DOCUMENT intent with audio MIME type.
     */
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        
        try {
            startActivityForResult(intent, REQUEST_SAF_FILE_PICKER);
        } catch (Exception e) {
            ToastManager.showToast(this, "No file manager found", ToastManager.LENGTH_NORMAL);
            mRequestInProgress = false;
        }
    }
    
    /**
     * Requests SAF file access when write permission is needed.
     * Prevents multiple concurrent requests using mRequestInProgress flag.
     */
    private void requestSafFileAccess() {
        if (mIsSaving.get()) {
            ToastManager.showToast(this, "Please wait, saving in progress...", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        if (mRequestInProgress) {
            return;
        }
        mRequestInProgress = true;
        
        openFilePicker();
        
        // Reset flag after timeout
        mActionHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mRequestInProgress = false;
            }
        }, CLICK_ACTION_DELAY_MS);
    }
    
    // ========================================================================
    // Handle Cancel Button Clicks
    // ========================================================================
    
    /**
     * Handles cancel button click based on current mode.
     * - EDIT MODE: Exits edit mode without saving, shows "No changes saved" toast
     * - VIEW MODE: Closes activity and returns to MusicPlayer
     */
    private void handleCancelClick() {
        if (mCurrentMode == MODE_EDIT) {
            // Hide keyboard first for clean transition
            hideKeyboard();
            
            // In edit mode - exit without saving, return to view mode
            exitEditMode();
            ToastManager.showToast(this, "No changes saved", ToastManager.LENGTH_NORMAL);
        } else {
            // In view mode - close activity, return to MusicPlayer
            onBackPressed();
        }
    }
    
    // ========================================================================
    // Input Setup Methods
    // ========================================================================
    
    /**
     * Sets up input filters and constraints for all EditText fields.
     * Applies length limits and numeric-only validation where appropriate.
     */
    private void setupInputFilters() {
        // Title length limit
        if (mTitleEdit != null) {
            mTitleEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_TITLE_LENGTH)});
        }
        
        // Artist length limit
        if (mArtistEdit != null) {
            mArtistEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_ARTIST_LENGTH)});
        }
        
        // Album length limit
        if (mAlbumEdit != null) {
            mAlbumEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_ALBUM_LENGTH)});
        }
        
        // Year field: numeric only, 4 digits max
        if (mYearEdit != null) {
            mYearEdit.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_YEAR_LENGTH),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end,
                                               android.text.Spanned dest, int dstart, int dend) {
                        for (int i = start; i < end; i++) {
                            if (!Character.isDigit(source.charAt(i))) {
                                return "";
                            }
                        }
                        return null;
                    }
                }
            });
            mYearEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        }
        
        // Genre length limit
        if (mGenreEdit != null) {
            mGenreEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_GENRE_LENGTH)});
        }
        
        // Track number: numeric only, 3 digits max
        if (mTrackEdit != null) {
            mTrackEdit.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_TRACK_LENGTH),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end,
                                               android.text.Spanned dest, int dstart, int dend) {
                        for (int i = start; i < end; i++) {
                            if (!Character.isDigit(source.charAt(i))) {
                                return "";
                            }
                        }
                        return null;
                    }
                }
            });
            mTrackEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        }
        
        // Lyrics length limit
        if (mLyricsEdit != null) {
            mLyricsEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_LYRICS_LENGTH)});
            mLyricsEdit.setInputType(android.text.InputType.TYPE_CLASS_TEXT | 
                                     android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
    }
    
    /**
     * Sets up TextWatchers to detect changes in edit fields.
     * Updates mHasTextChanges flag when content differs from original.
     */
    private void setupTextWatchers() {
        TextWatcher watcher = new TextWatcher() {
            @Override 
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            
            @Override 
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (mCurrentMode == MODE_EDIT) {
                    detectTextChanges();
                }
            }
            
            @Override 
            public void afterTextChanged(Editable s) {}
        };
        
        if (mTitleEdit != null) mTitleEdit.addTextChangedListener(watcher);
        if (mArtistEdit != null) mArtistEdit.addTextChangedListener(watcher);
        if (mAlbumEdit != null) mAlbumEdit.addTextChangedListener(watcher);
        if (mYearEdit != null) mYearEdit.addTextChangedListener(watcher);
        if (mGenreEdit != null) mGenreEdit.addTextChangedListener(watcher);
        if (mTrackEdit != null) mTrackEdit.addTextChangedListener(watcher);
        if (mLyricsEdit != null) mLyricsEdit.addTextChangedListener(watcher);
    }
    
    /**
     * Compares current edit field values with original values
     * to determine if text changes exist.
     */
    private void detectTextChanges() {
        String currentTitle = getEditTextDisplayValue(mTitleEdit);
        String currentArtist = getEditTextDisplayValue(mArtistEdit);
        String currentAlbum = getEditTextDisplayValue(mAlbumEdit);
        String currentYear = getEditTextDisplayValue(mYearEdit);
        String currentGenre = getEditTextDisplayValue(mGenreEdit);
        String currentTrack = getEditTextDisplayValue(mTrackEdit);
        String currentLyrics = getEditTextDisplayValue(mLyricsEdit);
        
        String titleToCompare = (currentTitle != null) ? currentTitle : "";
        String artistToCompare = (currentArtist != null) ? currentArtist : "";
        String albumToCompare = (currentAlbum != null) ? currentAlbum : "";
        String yearToCompare = (currentYear != null) ? currentYear : "";
        String genreToCompare = (currentGenre != null) ? currentGenre : "";
        String trackToCompare = (currentTrack != null) ? currentTrack : "";
        String lyricsToCompare = (currentLyrics != null) ? currentLyrics : "";
        
        String originalTitleToCompare = (mOriginalTitle != null) ? mOriginalTitle : "";
        String originalArtistToCompare = (mOriginalArtist != null) ? mOriginalArtist : "";
        String originalAlbumToCompare = (mOriginalAlbum != null) ? mOriginalAlbum : "";
        String originalYearToCompare = (mOriginalYear != null) ? mOriginalYear : "";
        String originalGenreToCompare = (mOriginalGenre != null) ? mOriginalGenre : "";
        String originalTrackToCompare = (mOriginalTrack != null) ? mOriginalTrack : "";
        String originalLyricsToCompare = (mOriginalLyrics != null) ? mOriginalLyrics : "";
        
        mHasTextChanges = !titleToCompare.equals(originalTitleToCompare) ||
                          !artistToCompare.equals(originalArtistToCompare) ||
                          !albumToCompare.equals(originalAlbumToCompare) ||
                          !yearToCompare.equals(originalYearToCompare) ||
                          !genreToCompare.equals(originalGenreToCompare) ||
                          !trackToCompare.equals(originalTrackToCompare) ||
                          !lyricsToCompare.equals(originalLyricsToCompare);
    }
    
    /**
     * Gets the trimmed text value from an EditText.
     * Returns null if the field is empty.
     * 
     * @param editText The EditText to read (can be null)
     * @return Trimmed string or null if empty
     */
    @Nullable
    private String getEditTextDisplayValue(@Nullable EditText editText) {
        if (editText == null) {
            return null;
        }
        String val = editText.getText().toString().trim();
        return val.isEmpty() ? null : val;
    }
    
    /**
     * Determines the changed value for a field.
     * Returns null if unchanged, empty string if cleared, or new value if changed.
     * 
     * @param editText The EditText to check
     * @param originalValue The original value
     * @return Changed value, null if unchanged
     */
    @Nullable
    private String getEditTextChangeValue(@Nullable EditText editText, @Nullable String originalValue) {
        if (editText == null) {
            return null;
        }
        String currentValue = editText.getText().toString().trim();
        String original = (originalValue != null) ? originalValue : "";
        
        // Field was cleared
        if (currentValue.isEmpty() && !original.isEmpty()) {
            return "";
        }
        
        // No change
        if (currentValue.equals(original)) {
            return null;
        }
        
        // Changed but not empty
        return currentValue.isEmpty() ? null : currentValue;
    }
    
    // ========================================================================
    // Song State Tracking
    // ========================================================================
    
    /**
     * Checks if the current song is playing and captures its state.
     * Used to resume playback after metadata editing is complete.
     * 
     * @return State constant: SONG_STATE_NOT_CURRENT, SONG_STATE_WAS_PLAYING,
     *         or SONG_STATE_WAS_PAUSED
     */
    private int checkCurrentSongState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String lastPath = prefs.getString(KEY_LAST_SONG_PATH, null);
        
        if (mFilePath != null && mFilePath.equals(lastPath)) {
            final CountDownLatch latch = new CountDownLatch(1);
            final boolean[] wasPlaying = {false};
            
            // Create a receiver to get the response
            BroadcastReceiver stateReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if ("PLAYING_STATE_RESPONSE".equals(intent.getAction())) {
                        wasPlaying[0] = intent.getBooleanExtra("is_playing", false);
                        latch.countDown();
                    }
                }
            };
            
            // Register temporary receiver
            IntentFilter filter = new IntentFilter("PLAYING_STATE_RESPONSE");
            registerReceiver(stateReceiver, filter);
            
            // Request the state
            Intent getStateIntent = new Intent("GET_PLAYING_STATE");
            sendBroadcast(getStateIntent);
            
            // Wait for response with timeout
            try {
                latch.await(150, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                try {
                    unregisterReceiver(stateReceiver);
                } catch (IllegalArgumentException e) {
                    // Receiver already unregistered
                }
            }
            
            if (wasPlaying[0]) {
                // Pause playback before editing
                sendBroadcast(new Intent("BLUETOOTH_PAUSE"));
                
                // Give time for pause to take effect
                final CountDownLatch pauseLatch = new CountDownLatch(1);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        pauseLatch.countDown();
                    }
                }, 100);
                
                try {
                    pauseLatch.await(150, TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                return SONG_STATE_WAS_PLAYING;
            } else {
                return SONG_STATE_WAS_PAUSED;
            }
        }
        
        return SONG_STATE_NOT_CURRENT;
    }
    
    // ========================================================================
    // Metadata Loading Methods
    // ========================================================================
    
    /**
     * Asynchronously loads metadata from the file.
     * Shows loading overlay during the operation.
     */
    private void loadMetadataAsync() {
        showLoadingOverlay();
        if (mExecutor == null) {
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataReader.MetadataBundle bundle;
                
                if (mGrantedFileUri != null) {
                    bundle = MetadataReader.readMetadataFromUri(MetadataEditor.this, mGrantedFileUri);
                    if (bundle != null && mFilePath == null) {
                        String path = getFilePathFromUri(mGrantedFileUri);
                        if (path != null) {
                            mFilePath = path;
                        }
                    }
                } else if (mFilePath != null) {
                    bundle = MetadataReader.readMetadata(mFilePath);
                } else {
                    bundle = new MetadataReader.MetadataBundle();
                    bundle.format = "Unknown";
                }
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        hideLoadingOverlay();
                        mOriginalData = bundle;
                        displayMetadata();
                        updateFileInfo();
                        
                        if (bundle != null && !bundle.isWriteSupported) {
                            setActionButtonEnabled(false);
                            ToastManager.showToast(MetadataEditor.this,
                                    "Cannot edit: " + bundle.format + " format", ToastManager.LENGTH_NORMAL);
                        } else {
                            setActionButtonEnabled(true);
                            if (mActionButton != null && mCurrentMode == MODE_VIEW) {
                                mActionButton.setText("MODIFY");
                            }
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Extracts the absolute file path from a content URI.
     * Handles both file scheme and content scheme URIs.
     * 
     * @param uri The content URI
     * @return File path or null if extraction fails
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Uri uri) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            path = uri.getPath();
            return path;
        }
        if ("content".equals(uri.getScheme())) {
            android.database.Cursor cursor = null;
            try {
                String[] projection = {android.provider.MediaStore.Audio.Media.DATA};
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    try {
                        int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                        path = cursor.getString(columnIndex);
                    } catch (IllegalArgumentException e) {
                        Log.w(TAG, "DATA column not found", e);
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Could not get file path from URI", e);
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return path;
    }
    
    /**
     * Displays loaded metadata in the UI fields.
     * Stores original values for change detection.
     * Handles album art display and placeholder images.
     */
    private void displayMetadata() {
        if (mOriginalData == null) {
            return;
        }
        
        // Store original values for change detection
        mOriginalTitle = mOriginalData.title;
        mOriginalArtist = mOriginalData.artist;
        mOriginalAlbum = mOriginalData.album;
        mOriginalYear = mOriginalData.year;
        mOriginalGenre = mOriginalData.genre;
        mOriginalTrack = mOriginalData.trackNumber;
        mOriginalLyrics = mOriginalData.lyrics;
        
        // Populate text fields
        if (mTitleEdit != null) mTitleEdit.setText(mOriginalTitle != null ? mOriginalTitle : "");
        if (mArtistEdit != null) mArtistEdit.setText(mOriginalArtist != null ? mOriginalArtist : "");
        if (mAlbumEdit != null) mAlbumEdit.setText(mOriginalAlbum != null ? mOriginalAlbum : "");
        if (mYearEdit != null) mYearEdit.setText(mOriginalYear != null ? mOriginalYear : "");
        if (mGenreEdit != null) mGenreEdit.setText(mOriginalGenre != null ? mOriginalGenre : "");
        if (mTrackEdit != null) mTrackEdit.setText(mOriginalTrack != null ? mOriginalTrack : "");
        if (mLyricsEdit != null) mLyricsEdit.setText(mOriginalLyrics != null ? mOriginalLyrics : "");
        
        // Only refresh colors in VIEW MODE
        if (mCurrentMode == MODE_VIEW) {
            refreshTextColors();
        }
        
        // Handle album art
        if (mOriginalData.albumArt != null && mOriginalData.albumArt.length > 0) {
            loadAlbumArtFromBytes(mOriginalData.albumArt);
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Long press to remove");
            } else if (mAlbumArtHint != null) {
                mAlbumArtHint.setVisibility(View.GONE);
            }
        } else {
            setPlaceholderAlbumArt();
            if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Tap to add album art");
            } else if (mAlbumArtHint != null) {
                mAlbumArtHint.setVisibility(View.GONE);
            }
        }
        applyAlbumArtClipping();
        updateHeaderForMode();
    }
    
    /**
     * Refreshes text colors based on current content.
     * Called after metadata is loaded or when returning to view mode.
     * Real data fields get #C0C0C0, placeholder/empty fields get #808080.
     * This method only runs in VIEW MODE.
     */
    private void refreshTextColors() {
        // Only refresh colors in VIEW MODE
        if (mCurrentMode != MODE_VIEW) {
            return;
        }
        
        EditText[] fields = {mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit, mGenreEdit, mTrackEdit, mLyricsEdit};
        
        for (EditText field : fields) {
            if (field == null) continue;
            
            String text = field.getText().toString();
            boolean isPlaceholder = (text == null || text.isEmpty() || 
                "Unknown".equals(text) || "Unknown Title".equals(text) ||
                "Unknown Artist".equals(text) || "Unknown Album".equals(text));
            
            if (isPlaceholder) {
                field.setTextColor(Color.parseColor("#808080"));
            } else {
                field.setTextColor(Color.parseColor("#C0C0C0"));
            }
        }
    }
    
    /**
     * Loads album art from byte array and displays in ImageView.
     * 
     * @param albumArtBytes The JPEG/PNG album art bytes
     */
    private void loadAlbumArtFromBytes(@NonNull final byte[] albumArtBytes) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(albumArtBytes, 0, albumArtBytes.length);
                    if (bitmap != null && mAlbumArtView != null) {
                        mAlbumArtView.setImageBitmap(bitmap);
                        mAlbumArtView.setColorFilter(null);
                        applyAlbumArtClipping();
                    } else {
                        setPlaceholderAlbumArt();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Failed to decode album art", e);
                    setPlaceholderAlbumArt();
                }
            }
        });
    }
    
    /**
     * Sets a themed placeholder image for album art.
     * Uses theme color for tint when applicable.
     */
    private void setPlaceholderAlbumArt() {
        if (mThemeHelper == null || mAlbumArtView == null) {
            return;
        }
        Drawable placeholder = mThemeHelper.createThemedAlbumArtPlaceholder();
        if (placeholder != null) {
            mAlbumArtView.setImageDrawable(placeholder);
        } else {
            mAlbumArtView.setImageResource(R.drawable.album_art_placeholder);
            mAlbumArtView.setColorFilter(mThemeHelper.getThemeColorInt(), PorterDuff.Mode.SRC_IN);
        }
        applyAlbumArtClipping();
    }
    
    /**
     * Updates the file information display (size, bitrate, duration).
     */
    private void updateFileInfo() {
        if (mOriginalData == null || mFileInfoText == null) {
            return;
        }
        
        StringBuilder info = new StringBuilder();
        
        // File size
        long bytes = mOriginalData.fileSize;
        if (bytes < 1024 * 1024) {
            float kb = bytes / 1024.0f;
            info.append(String.format("%.0f KB", kb));
        } else {
            float mb = bytes / (1024.0f * 1024.0f);
            info.append(String.format("%.1f MB", mb));
        }
        
        // Bitrate (from MediaMetadataRetriever)
        if (mGrantedFileUri != null || mFilePath != null) {
            MediaMetadataRetriever retriever = null;
            try {
                retriever = new MediaMetadataRetriever();
                if (mGrantedFileUri != null) {
                    retriever.setDataSource(this, mGrantedFileUri);
                } else if (mFilePath != null) {
                    retriever.setDataSource(mFilePath);
                }
                
                String bitrate = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_BITRATE);
                if (bitrate != null && !bitrate.isEmpty()) {
                    int kbps = Integer.parseInt(bitrate) / 1000;
                    info.append(" • ").append(kbps).append(" kbps");
                }
                
            } catch (Exception e) {
                Log.w(TAG, "Could not read audio properties: " + e.getMessage());
            } finally {
                if (retriever != null) {
                    try {
                        retriever.release();
                    } catch (Exception e) {
                    }
                }
            }
        }
        
        // Duration
        long durationMs = mOriginalData.duration;
        int totalSeconds = (int) (durationMs / 1000);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        String duration;
        if (hours > 0) {
            duration = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            duration = String.format("%02d:%02d", minutes, seconds);
        }
        info.append(" • ").append(duration);
        
        mFileInfoText.setText(info.toString());
        mFileInfoText.setSelected(false);
        mFileInfoText.setLongClickable(false);
        mFileInfoText.setTextIsSelectable(false);
        mFileInfoText.setTextColor(Color.parseColor("#C0C0C0"));
        
        if (mFormatText != null) {
            mFormatText.setText(mOriginalData.format.toUpperCase() + " file");
        }
    }
    
    /**
     * Applies rounded corner clipping to the album art container.
     */
    private void applyAlbumArtClipping() {
        if (mAlbumArtContainer == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mAlbumArtContainer.setClipToOutline(true);
            mAlbumArtContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    int radius = dpToPx(ALBUM_ART_CORNER_RADIUS_DP);
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
        }
    }
    
    // ========================================================================
    // URI Resolution Methods
    // ========================================================================
    
    /**
     * Retrieves the stored URI for a file path from the database.
     * Attempts to reacquire permissions for the URI.
     * 
     * @param filePath The absolute file path
     * @return True if valid URI with permission was found
     */
    private boolean getStoredUri(@NonNull String filePath) {
        Song cached = SongDatabase.getInstance(this).getSong(filePath);
        if (cached != null && cached.getUri() != null) {
            mGrantedFileUri = cached.getContentUri();
            Log.d(TAG, "Found stored URI in database: " + mGrantedFileUri);
            
            if (mStorageHelper != null && mStorageHelper.reacquirePermission(mGrantedFileUri)) {
                Log.d(TAG, "Successfully reacquired permission for URI");
                return true;
            }
            
            if (hasWritePermission(mGrantedFileUri)) {
                Log.d(TAG, "URI has write permission");
                return true;
            }
            
            Log.w(TAG, "Cannot reacquire permission for URI, will need to reselect file");
            ToastManager.showToast(this, "Permission lost. Please select the file again", ToastManager.LENGTH_NORMAL);
            
            // Clear the invalid URI from database
            SongDatabase.getInstance(this).insertSong(new Song(
                cached.getTitle(), cached.getArtist(), cached.getAlbum(),
                cached.getGenre(),
                filePath, cached.getDuration(), null));
            
            mGrantedFileUri = null;
            return false;
        }
        return false;
    }
    
    /**
     * Saves the granted URI to the database for future permission reacquisition.
     */
    private void saveUriToDatabase() {
        if (mFilePath == null || mGrantedFileUri == null) {
            return;
        }
        
        Song existingSong = SongDatabase.getInstance(this).getSong(mFilePath);
        if (existingSong != null) {
            Song updatedSong = new Song(
                existingSong.getTitle(),
                existingSong.getArtist(),
                existingSong.getAlbum(),
                existingSong.getGenre(),
                mFilePath,
                existingSong.getDuration(),
                mGrantedFileUri.toString()
            );
            SongDatabase.getInstance(this).insertSong(updatedSong);
            Log.d(TAG, "Updated existing song with URI: " + mFilePath);
        } else {
            Song newSong = new Song(
                mOriginalData != null && mOriginalData.title != null ? mOriginalData.title : "Unknown Title",
                mOriginalData != null && mOriginalData.artist != null ? mOriginalData.artist : "Unknown Artist",
                mOriginalData != null && mOriginalData.album != null ? mOriginalData.album : "Unknown Album",
                mOriginalData != null && mOriginalData.genre != null ? mOriginalData.genre : "Unknown Genre",
                mFilePath,
                mOriginalData != null ? mOriginalData.duration : 0,
                mGrantedFileUri.toString()
            );
            SongDatabase.getInstance(this).insertSong(newSong);
            Log.d(TAG, "Created new song with URI: " + mFilePath);
        }
    }
    
    /**
     * Checks if write permission is available for a URI.
     * Uses DocumentFile API to verify canWrite().
     * 
     * @param uri The URI to check
     * @return True if write permission is available
     */
    private boolean hasWritePermission(@NonNull Uri uri) {
        try {
            DocumentFile doc = DocumentFile.fromSingleUri(getApplicationContext(), uri);
            return doc != null && doc.canWrite();
        } catch (Exception e) {
            Log.w(TAG, "hasWritePermission check failed", e);
            return false;
        }
    }
    
    // ========================================================================
    // Edit Mode Management
    // ========================================================================
    
    /**
     * Enters edit mode, enabling all input fields.
     * Validates write permission and file format support before entering.
     */
    private void enterEditMode() {
        // Check if file format supports writing
        if (mOriginalData == null || !mOriginalData.isWriteSupported) {
            ToastManager.showToast(this, "Cannot edit: " + (mOriginalData != null ? mOriginalData.format : "this file format"), ToastManager.LENGTH_NORMAL);
            return;
        }
        
        // Ensure we have a URI
        if (mGrantedFileUri == null && mFilePath != null) {
            getStoredUri(mFilePath);
        }
        
        // Request URI if missing
        if (mGrantedFileUri == null) {
            ToastManager.showToast(this, "File access needed. Please reselect the file", ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }
        
        // Verify write permission
        if (!hasWritePermission(mGrantedFileUri)) {
            ToastManager.showToast(this, "Write permission needed. Please reselect the file", ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }
        
        mCurrentMode = MODE_EDIT;
        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;
        
        // Update UI for edit mode
        if (mActionButton != null) {
            mActionButton.setText("UPDATE");
        }
        setFieldsEnabled(true);
        
        // Show album art hints
        if (mAlbumArtHint != null) {
            if (mOriginalData.albumArt == null || mOriginalData.albumArt.length == 0) {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Tap to add album art");
            } else {
                mAlbumArtHint.setVisibility(View.VISIBLE);
                mAlbumArtHint.setText("Long press to remove");
            }
        }
        
        updateHeaderForMode();
        
        // Show keyboard and focus on title field
        if (mTitleEdit != null) {
            mTitleEdit.requestFocus();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.showSoftInput(mTitleEdit, InputMethodManager.SHOW_IMPLICIT);
                    }
                }
            }, KEYBOARD_SHOW_DELAY_MS);
        }
        
        ToastManager.showToast(this, "Please tap UPDATE to save changes", ToastManager.LENGTH_NORMAL);
    }
    
    /**
     * Exits edit mode and returns to view mode.
     * Discards any pending changes.
     */
    private void exitEditMode() {
        mCurrentMode = MODE_VIEW;
        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;
        
        if (mActionButton != null) {
            mActionButton.setText("MODIFY");
        }
        setFieldsEnabled(false);
        
        if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }
        
        updateHeaderForMode();
        
        hideKeyboard();
        if (mOriginalData != null) {
            displayMetadata();  // Restore original data (colors will be refreshed since mode is now VIEW)
        }
    }
    
    /**
     * Enables or disables all input fields.
     * 
     * @param enabled True to enable fields, false to disable
     */
    private void setFieldsEnabled(boolean enabled) {
        EditText[] fields = {mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit, mGenreEdit, mTrackEdit};
        
        for (EditText field : fields) {
            if (field == null) {
                continue;
            }
            
            if (!enabled) {
                // VIEW MODE - Keep enabled so hints show, but prevent editing
                field.setEnabled(true);
                field.setFocusable(false);
                field.setFocusableInTouchMode(false);
                field.setClickable(false);
                field.setCursorVisible(false);
                field.setLongClickable(false);
                field.setTextIsSelectable(false);
                field.setOnFocusChangeListener(null);
                
                // Set appropriate text color based on whether field has content
                String text = field.getText().toString();
                if (text == null || text.isEmpty() || "Unknown".equals(text) || 
                    "Unknown Title".equals(text) || "Unknown Artist".equals(text) || 
                    "Unknown Album".equals(text)) {
                    // Empty or placeholder text - use muted gray
                    field.setTextColor(Color.parseColor("#808080"));
                } else {
                    // Has actual content - use light gray
                    field.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                // Use muted themed color for hints in VIEW MODE
                if (mThemeHelper != null) {
                    field.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                } else {
                    field.setHintTextColor(Color.parseColor("#5A5A5A"));
                }
                
                if (mThemeHelper != null) {
                    mThemeHelper.updateEditText(field);
                }
            } else {
                // EDIT MODE - Fully editable
                field.setEnabled(true);
                field.setFocusable(true);
                field.setFocusableInTouchMode(true);
                field.setClickable(true);
                field.setCursorVisible(true);
                field.setLongClickable(true);
                field.setTextIsSelectable(true);
                
                if (mThemeHelper != null) {
                    mThemeHelper.updateEditTextCursor(field);
                }
                
                // Set initial colors for all fields based on their content (not focused yet)
                String currentText = field.getText().toString();
                boolean isPlaceholder = (currentText == null || currentText.isEmpty() || 
                    "Unknown".equals(currentText) || "Unknown Title".equals(currentText) ||
                    "Unknown Artist".equals(currentText) || "Unknown Album".equals(currentText));
                
                if (isPlaceholder) {
                    field.setTextColor(Color.parseColor("#808080"));
                } else {
                    field.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                field.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        EditText et = (EditText) v;
                        if (hasFocus) {
                            // When focused - use theme color
                            if (mThemeManager != null) {
                                et.setTextColor(mThemeManager.getCurrentColorInt());
                            } else if (mThemeHelper != null) {
                                et.setTextColor(mThemeHelper.getThemeColorInt());
                            } else {
                                et.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        } else {
                            // When focus is lost - revert to original display color
                            String text = et.getText().toString();
                            boolean isEmptyOrPlaceholder = (text == null || text.isEmpty() || 
                                "Unknown".equals(text) || "Unknown Title".equals(text) ||
                                "Unknown Artist".equals(text) || "Unknown Album".equals(text));
                            
                            if (isEmptyOrPlaceholder) {
                                // Empty or placeholder - use muted gray
                                et.setTextColor(Color.parseColor("#808080"));
                            } else {
                                // Has real data - use light gray
                                et.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        }
                    }
                });
            }
        }
        
        // Lyrics field special handling
        if (mLyricsEdit != null) {
            if (!enabled) {
                // VIEW MODE
                mLyricsEdit.setEnabled(true);
                mLyricsEdit.setFocusable(false);
                mLyricsEdit.setFocusableInTouchMode(false);
                mLyricsEdit.setClickable(false);
                mLyricsEdit.setCursorVisible(false);
                mLyricsEdit.setLongClickable(false);
                mLyricsEdit.setTextIsSelectable(false);
                mLyricsEdit.setOnFocusChangeListener(null);
                mLyricsEdit.setCustomSelectionActionModeCallback(null);
                mLyricsEdit.setCustomInsertionActionModeCallback(null);
                
                String text = mLyricsEdit.getText().toString();
                if (text == null || text.isEmpty()) {
                    mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                } else {
                    mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                // Use muted themed color for hints in VIEW MODE
                if (mThemeHelper != null) {
                    mLyricsEdit.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                } else {
                    mLyricsEdit.setHintTextColor(Color.parseColor("#5A5A5A"));
                }
                
                if (mThemeHelper != null) {
                    mThemeHelper.updateEditText(mLyricsEdit);
                }
            } else {
                // EDIT MODE
                mLyricsEdit.setEnabled(true);
                mLyricsEdit.setFocusable(true);
                mLyricsEdit.setFocusableInTouchMode(true);
                mLyricsEdit.setClickable(true);
                mLyricsEdit.setCursorVisible(true);
                mLyricsEdit.setLongClickable(true);
                mLyricsEdit.setTextIsSelectable(true);
                
                if (mThemeHelper != null) {
                    mThemeHelper.updateEditTextCursor(mLyricsEdit);
                }
                
                // Set initial color based on whether lyrics are empty
                String currentLyrics = mLyricsEdit.getText().toString();
                if (currentLyrics == null || currentLyrics.isEmpty()) {
                    mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                } else {
                    mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                }
                
                mLyricsEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (hasFocus) {
                            if (mThemeManager != null) {
                                mLyricsEdit.setTextColor(mThemeManager.getCurrentColorInt());
                            } else if (mThemeHelper != null) {
                                mLyricsEdit.setTextColor(mThemeHelper.getThemeColorInt());
                            }
                        } else {
                            String text = mLyricsEdit.getText().toString();
                            if (text == null || text.isEmpty()) {
                                mLyricsEdit.setTextColor(Color.parseColor("#808080"));
                            } else {
                                mLyricsEdit.setTextColor(Color.parseColor("#C0C0C0"));
                            }
                        }
                    }
                });
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mLyricsEdit.setCustomSelectionActionModeCallback(new android.view.ActionMode.Callback() {
                        @Override
                        public boolean onCreateActionMode(android.view.ActionMode mode, android.view.Menu menu) {
                            return true;
                        }
                        @Override
                        public boolean onPrepareActionMode(android.view.ActionMode mode, android.view.Menu menu) {
                            return false;
                        }
                        @Override
                        public boolean onActionItemClicked(android.view.ActionMode mode, android.view.MenuItem item) {
                            return false;
                        }
                        @Override
                        public void onDestroyActionMode(android.view.ActionMode mode) {
                        }
                    });
                }
            }
        }
        
        // File info - always enabled so hint shows, but non-editable
        if (mFileInfoText != null) {
            mFileInfoText.setEnabled(true);
            mFileInfoText.setFocusable(false);
            mFileInfoText.setFocusableInTouchMode(false);
            mFileInfoText.setClickable(false);
            mFileInfoText.setCursorVisible(false);
            mFileInfoText.setLongClickable(false);
            mFileInfoText.setTextIsSelectable(false);
        }
    }
    
    /**
     * Updates the header title based on current mode.
     */
    private void updateHeaderForMode() {
        if (mHeaderTitle != null) {
            mHeaderTitle.setText(mCurrentMode == MODE_VIEW ? "VIEW MODE" : "EDIT MODE");
            mHeaderTitle.setTextColor(Color.parseColor("#C0C0C0"));
            mHeaderTitle.setLetterSpacing(0.1f);
        }
        
        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
            mFormatText.setTextColor(Color.parseColor("#C0C0C0"));
        }
    }
    
    /**
     * Sets the enabled state of the action button with theme update.
     * 
     * @param enabled True to enable, false to disable
     */
    private void setActionButtonEnabled(boolean enabled) {
        if (mActionButton != null && mThemeHelper != null) {
            mActionButton.setEnabled(enabled);
            mThemeHelper.updateButton(mActionButton, enabled);
        }
    }
    
    /**
     * Removes the current album art and marks it for deletion.
     */
    private void removeAlbumArt() {
        ToastManager.showToast(this, "Album art removed", ToastManager.LENGTH_NORMAL);
        mNewAlbumArt = null;
        mAlbumArtChanged = true;
        mAlbumArtDeleted = true;
        setPlaceholderAlbumArt();
        
        if (mAlbumArtHint != null && mCurrentMode == MODE_EDIT) {
            mAlbumArtHint.setVisibility(View.VISIBLE);
            mAlbumArtHint.setText("Tap to add album art");
        } else if (mAlbumArtHint != null) {
            mAlbumArtHint.setVisibility(View.GONE);
        }
    }
    
    // ========================================================================
    // Save Changes Methods
    // ========================================================================
    
    /**
     * Initiates the save process with a delay to allow keyboard to hide.
     */
    private void saveChanges() {
        hideKeyboard();
        
        mMainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                performSaveChanges();
            }
        }, KEYBOARD_HIDE_DELAY_MS);
    }
    
    /**
     * Performs the actual metadata save operation.
     * Validates changes, captures playback state, and executes async write.
     */
    private void performSaveChanges() {
        boolean hasAnyChanges = mHasTextChanges || mAlbumArtChanged;
        
        if (!hasAnyChanges) {
            ToastManager.showToast(this, "No changes to save", ToastManager.LENGTH_NORMAL);
            return;
        }
        if (mIsSaving.get()) {
            return;
        }
        if (mGrantedFileUri == null) {
            ToastManager.showToast(this, "No write permission", ToastManager.LENGTH_NORMAL);
            requestSafFileAccess();
            return;
        }
        
        if (NavigationController.getInstance().isGroupDisabled(NavigationController.ButtonGroup.METADATA_ACTIONS)) {
            ToastManager.showToast(this, "Please wait, playlist is syncing...", ToastManager.LENGTH_NORMAL);
            return;
        }
        
        // Prepare update bundle
        final MetadataWriter.UpdateBundle update = new MetadataWriter.UpdateBundle();
        
        if (mHasTextChanges) {
            String currentTitleChange = getEditTextChangeValue(mTitleEdit, mOriginalTitle);
            String currentArtistChange = getEditTextChangeValue(mArtistEdit, mOriginalArtist);
            String currentAlbumChange = getEditTextChangeValue(mAlbumEdit, mOriginalAlbum);
            String currentYearChange = getEditTextChangeValue(mYearEdit, mOriginalYear);
            String currentGenreChange = getEditTextChangeValue(mGenreEdit, mOriginalGenre);
            String currentTrackChange = getEditTextChangeValue(mTrackEdit, mOriginalTrack);
            String currentLyricsChange = getEditTextChangeValue(mLyricsEdit, mOriginalLyrics);
            
            update.title = currentTitleChange;
            update.artist = currentArtistChange;
            update.album = currentAlbumChange;
            update.year = currentYearChange;
            update.genre = currentGenreChange;
            update.trackNumber = currentTrackChange;
            update.lyrics = currentLyricsChange;
        }
        
        if (mAlbumArtChanged) {
            if (mAlbumArtDeleted) {
                update.albumArt = new byte[0];  // Empty array signals deletion
            } else if (mNewAlbumArt != null) {
                update.albumArt = mNewAlbumArt;
            }
        } else {
            update.albumArt = null;
        }
        
        // Capture playback state before editing
        mPreviousSongState = checkCurrentSongState();
        
        mIsSaving.set(true);
        setActionButtonEnabled(false);
        
        if (mExecutor == null) {
            return;
        }
        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final MetadataWriter.WriteResult result = MetadataWriter.writeMetadataToUri(
                        MetadataEditor.this, mGrantedFileUri, update);
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ToastManager.hidePersistentOverlay();
                        mIsSaving.set(false);
                        setActionButtonEnabled(true);
                        if (result.success) {
                            onSaveSuccess();
                        } else {
                            onSaveFailure(result);
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Handles successful save completion.
     * Reloads metadata, updates database, broadcasts changes, and resumes playback.
     */
    private void onSaveSuccess() {
        // Reload metadata from file
        if (mGrantedFileUri != null) {
            mOriginalData = MetadataReader.readMetadataFromUri(this, mGrantedFileUri);
        } else if (mFilePath != null) {
            mOriginalData = MetadataReader.readMetadata(mFilePath);
        }
        
        // Update database with new metadata
        if (mOriginalData != null && (mFilePath != null || mGrantedFileUri != null)) {
            String path = mFilePath;
            if (path == null && mGrantedFileUri != null) {
                path = getFilePathFromUri(mGrantedFileUri);
            }
            if (path != null) {
                Song updatedSong = new Song(
                    mOriginalData.title != null ? mOriginalData.title : "Unknown Title",
                    mOriginalData.artist != null ? mOriginalData.artist : "Unknown Artist",
                    mOriginalData.album != null ? mOriginalData.album : "Unknown Album",
                    mOriginalData.genre != null ? mOriginalData.genre : "Unknown Genre",
                    path,
                    mOriginalData.duration,
                    mGrantedFileUri != null ? mGrantedFileUri.toString() : null
                );
                SongDatabase.getInstance(this).insertSong(updatedSong);
                Log.d(TAG, "Saved updated song to database: " + path);
            }
        }
        
        // Reset change flags
        mHasTextChanges = false;
        mAlbumArtChanged = false;
        mAlbumArtDeleted = false;
        mNewAlbumArt = null;
        
        exitEditMode();
        
        // Broadcast updates to MusicPlayer
        if (mFilePath != null) {
            Intent updateIntent = new Intent("UPDATE_SONG_IN_PLAYLIST");
            updateIntent.putExtra("song_path", mFilePath);
            updateIntent.putExtra("title", mOriginalData.title);
            updateIntent.putExtra("artist", mOriginalData.artist);
            updateIntent.putExtra("album", mOriginalData.album);
            updateIntent.putExtra("genre", mOriginalData.genre);
            boolean hasAlbumArt = (mOriginalData.albumArt != null && mOriginalData.albumArt.length > 0);
            updateIntent.putExtra("has_album_art", hasAlbumArt);
            updateIntent.putExtra("album_art_removed", mAlbumArtDeleted);
            if (hasAlbumArt) {
                updateIntent.putExtra("album_art_bytes", mOriginalData.albumArt);
            }
            sendBroadcast(updateIntent);
            
            Intent forceUpdateIntent = new Intent("FORCE_UPDATE_PLAYER");
            forceUpdateIntent.putExtra("refresh_metadata", true);
            forceUpdateIntent.putExtra("refresh_album_art", true);
            forceUpdateIntent.putExtra("album_art_removed", mAlbumArtDeleted);
            forceUpdateIntent.putExtra("song_path", mFilePath);
            sendBroadcast(forceUpdateIntent);
        }
        
        // Resume playback if it was playing before edit
        if (mPreviousSongState == SONG_STATE_WAS_PLAYING) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    sendBroadcast(new Intent("BLUETOOTH_PLAY"));
                }
            }, 500);
        }
        
        applyThemeToUI();
        
        ToastManager.showToast(this, "Metadata updated", ToastManager.LENGTH_NORMAL);
    }
    
    /**
     * Handles save failure.
     * Shows error message and handles permission issues.
     * 
     * @param result The WriteResult containing error details
     */
    private void onSaveFailure(@NonNull MetadataWriter.WriteResult result) {
        String msg = result.backupRestored ? "Update failed - restored original" : "Update failed";
        ToastManager.showToast(this, msg, ToastManager.LENGTH_NORMAL);
        Log.e(TAG, "Save failed: " + result.errorMessage);
        
        if (result.errorMessage != null && result.errorMessage.contains("permission")) {
            if (mFilePath != null) {
                SongDatabase.getInstance(this).insertSong(new Song(
                    mOriginalTitle != null ? mOriginalTitle : "Unknown Title",
                    mOriginalArtist != null ? mOriginalArtist : "Unknown Artist",
                    mOriginalAlbum != null ? mOriginalAlbum : "Unknown Album",
                    mOriginalGenre != null ? mOriginalGenre : "Unknown Genre",
                    mFilePath, 0, null));
            }
            mGrantedFileUri = null;
            ToastManager.showToast(this, "Permission lost. Please reselect the file", ToastManager.LENGTH_NORMAL);
        }
    }
    
    // ========================================================================
    // Album Art Selection (Replaces AsyncTask with ExecutorService)
    // ========================================================================
    
    /**
     * Checks for gallery read permission and opens gallery if granted.
     * Handles Android 13+ READ_MEDIA_IMAGES permission.
     */
    private void checkGalleryPermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.READ_MEDIA_IMAGES"}, PERMISSION_GALLERY_REQUEST);
                return;
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_GALLERY_REQUEST);
                return;
            }
        }
        openGalleryForAlbumArt();
    }
    
    /**
     * Opens the system image picker for album art selection.
     */
    private void openGalleryForAlbumArt() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, GALLERY_REQUEST_CODE);
    }
    
    /**
     * Processes the selected image for album art asynchronously.
     * Uses ExecutorService instead of AsyncTask.
     * 
     * @param uri The URI of the selected image
     */
    private void processSelectedAlbumArt(@Nullable final Uri uri) {
        if (mIsSaving.get()) {
            ToastManager.showToast(this, "Please wait... Saving changes", ToastManager.LENGTH_NORMAL);
            return;
        }
        if (uri == null) {
            return;
        }
        
        // Cancel any ongoing task
        mCurrentAlbumArtTaskCancelled = true;
        
        setPlaceholderAlbumArt();
        
        final String taskId = String.valueOf(System.currentTimeMillis());
        final String currentTaskId = taskId;
        mCurrentAlbumArtTaskCancelled = false;
        mCurrentLoadingArtPath = uri.toString();
        
        if (mAlbumArtExecutor == null) {
            mAlbumArtExecutor = Executors.newSingleThreadExecutor();
        }
        
        mAlbumArtExecutor.execute(new Runnable() {
            @Override
            public void run() {
                // Check if cancelled
                if (mCurrentAlbumArtTaskCancelled || !taskId.equals(currentTaskId)) {
                    return;
                }
                
                final byte[] imageData = processAlbumArtInBackground(uri);
                
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mCurrentAlbumArtTaskCancelled || !taskId.equals(currentTaskId)) {
                            return;
                        }
                        mCurrentAlbumArtTaskCancelled = false;
                        mCurrentLoadingArtPath = null;
                        
                        if (imageData == null || imageData.length == 0) {
                            ToastManager.showToast(MetadataEditor.this, "Failed to load image", ToastManager.LENGTH_NORMAL);
                            if (mOriginalData != null && mOriginalData.albumArt != null && mOriginalData.albumArt.length > 0) {
                                loadAlbumArtFromBytes(mOriginalData.albumArt);
                            } else {
                                setPlaceholderAlbumArt();
                            }
                            return;
                        }
                        
                        mNewAlbumArt = imageData;
                        mAlbumArtChanged = true;
                        mAlbumArtDeleted = false;
                        
                        Bitmap displayBitmap = BitmapFactory.decodeByteArray(mNewAlbumArt, 0, mNewAlbumArt.length);
                        if (displayBitmap != null && mAlbumArtView != null) {
                            mAlbumArtView.setImageBitmap(displayBitmap);
                            mAlbumArtView.setColorFilter(null);
                            applyAlbumArtClipping();
                            if (mAlbumArtHint != null) {
                                mAlbumArtHint.setVisibility(View.VISIBLE);
                                mAlbumArtHint.setText("Long press to remove");
                            }
                            ToastManager.showToast(MetadataEditor.this, "Album art changed", ToastManager.LENGTH_NORMAL);
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Processes album art in background thread.
     * 
     * @param imageUri The URI of the selected image
     * @return Processed album art bytes, or null if failed
     */
    @Nullable
    private byte[] processAlbumArtInBackground(@NonNull Uri imageUri) {
        InputStream inputStream = null;
        try {
            inputStream = getContentResolver().openInputStream(imageUri);
            if (inputStream == null) {
                return null;
            }
            
            // First pass: get dimensions
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(inputStream, null, options);
            inputStream.close();
            
            // Calculate sampling ratio
            options.inSampleSize = calculateInSampleSize(options, MAX_ALBUM_ART_SIZE_PX, MAX_ALBUM_ART_SIZE_PX);
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            
            // Second pass: decode
            inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, options);
            if (bitmap == null) {
                return null;
            }
            
            // Scale if necessary
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            if (width > MAX_ALBUM_ART_SIZE_PX || height > MAX_ALBUM_ART_SIZE_PX) {
                float ratio = Math.min((float) MAX_ALBUM_ART_SIZE_PX / width,
                                       (float) MAX_ALBUM_ART_SIZE_PX / height);
                int newWidth = Math.round(width * ratio);
                int newHeight = Math.round(height * ratio);
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
                bitmap.recycle();
                bitmap = scaled;
            }
            
            // Convert to JPEG byte array
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, ALBUM_ART_QUALITY, baos);
            bitmap.recycle();
            return baos.toByteArray();
            
        } catch (Exception e) {
            Log.e(TAG, "Error loading album art", e);
            return null;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }
    
    /**
     * Calculates the appropriate sample size for loading a large image.
     * 
     * @param options BitmapFactory.Options with outWidth and outHeight set
     * @param reqWidth Requested width in pixels
     * @param reqHeight Requested height in pixels
     * @return The calculated sample size (power of 2)
     */
    private int calculateInSampleSize(@NonNull BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
    // ========================================================================
    // Theme & UI Helper Methods
    // ========================================================================
    
    /**
     * Applies the current theme color to all UI components.
     */
    private void applyThemeToUI() {
        if (mThemeHelper == null || mThemeManager == null) {
            return;
        }
        mThemeHelper.setThemeColor(mThemeManager.getCurrentColor());
        
        if (mCancelButton != null) {
            mThemeHelper.updateButton(mCancelButton, true);
        }
        setActionButtonEnabled(mActionButton != null && mActionButton.isEnabled());
        
        EditText[] editTexts = {mTitleEdit, mArtistEdit, mAlbumEdit, mYearEdit, mGenreEdit, mTrackEdit, mLyricsEdit};
        for (EditText et : editTexts) {
            if (et != null) {
                mThemeHelper.updateEditText(et);
                
                if (mCurrentMode == MODE_EDIT) {
                    mThemeHelper.updateEditTextCursor(et);
                    
                    if (et.hasFocus()) {
                        // Only the actively focused field gets theme color
                        et.setTextColor(mThemeManager.getCurrentColorInt());
                        et.setHintTextColor(mThemeManager.getCurrentColorInt());
                    } else {
                        // Non-focused fields: restore view mode appearance
                        String text = et.getText().toString();
                        boolean isPlaceholder = (text == null || text.isEmpty() || 
                            "Unknown".equals(text) || "Unknown Title".equals(text) ||
                            "Unknown Artist".equals(text) || "Unknown Album".equals(text));
                        et.setTextColor(isPlaceholder ? Color.parseColor("#808080") : Color.parseColor("#C0C0C0"));
                        et.setHintTextColor(Color.parseColor("#5A5A5A"));
                    }
                } else {
                    // View mode: standard colors
                    String text = et.getText().toString();
                    boolean isPlaceholder = (text == null || text.isEmpty() || 
                        "Unknown".equals(text) || "Unknown Title".equals(text) ||
                        "Unknown Artist".equals(text) || "Unknown Album".equals(text));
                    et.setTextColor(isPlaceholder ? Color.parseColor("#808080") : Color.parseColor("#C0C0C0"));
                    // Use muted themed color for hints in VIEW MODE
                    if (mThemeHelper != null) {
                        et.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
                    } else {
                        et.setHintTextColor(Color.parseColor("#5A5A5A"));
                    }
                }
            }
        }
        
        // File info: always shows real data or hint "No file selected"
        if (mFileInfoText != null) {
            mThemeHelper.updateEditText(mFileInfoText);
            String text = mFileInfoText.getText().toString();
            if (text == null || text.isEmpty()) {
                mFileInfoText.setTextColor(Color.parseColor("#5A5A5A"));  // Hint color when empty
            } else {
                mFileInfoText.setTextColor(Color.parseColor("#C0C0C0"));  // Real data color
            }
            // Use muted themed color for hint in VIEW MODE
            if (mCurrentMode == MODE_VIEW && mThemeHelper != null) {
                mFileInfoText.setHintTextColor(mThemeHelper.getMutedThemeColorInt());
            } else {
                mFileInfoText.setHintTextColor(Color.parseColor("#5A5A5A"));
            }
        }
        
        if (mAlbumArtHint != null) {
            mAlbumArtHint.setTextColor(Color.parseColor("#808080"));
        }
        if (mHeaderTitle != null) {
            mHeaderTitle.setTextColor(Color.parseColor("#C0C0C0"));
            mHeaderTitle.setLetterSpacing(0.1f);
        }
        
        if (mFormatText != null) {
            mFormatText.setLetterSpacing(0.1f);
            mFormatText.setTextColor(Color.parseColor("#C0C0C0"));
        }
        
        if (mOriginalData == null || mOriginalData.albumArt == null) {
            setPlaceholderAlbumArt();
        }
    }
    
    /**
     * Shows a loading overlay with a progress spinner.
     */
    private void showLoadingOverlay() {
        if (mLoadingOverlay != null) {
            return;
        }
        ViewGroup rootView = (ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content);
        if (rootView == null) {
            return;
        }
        mLoadingOverlay = new FrameLayout(this);
        mLoadingOverlay.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mLoadingOverlay.setBackgroundColor(Color.argb(DIM_ALPHA, 18, 18, 18));
        ProgressBar spinner = new ProgressBar(this);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                dpToPx(PROGRESS_BAR_SIZE_DP), dpToPx(PROGRESS_BAR_SIZE_DP));
        params.gravity = Gravity.CENTER;
        spinner.setLayoutParams(params);
        mLoadingOverlay.addView(spinner);
        rootView.addView(mLoadingOverlay);
        
        if (mThemeHelper != null && spinner != null) {
            mThemeHelper.updateProgressBar(spinner);
        }
    }
    
    /**
     * Hides the loading overlay.
     */
    private void hideLoadingOverlay() {
        if (mLoadingOverlay != null && mLoadingOverlay.getParent() != null) {
            ((ViewGroup) mLoadingOverlay.getParent()).removeView(mLoadingOverlay);
        }
        mLoadingOverlay = null;
    }
    
    /**
     * Hides the soft keyboard if it is currently shown.
     */
    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }
    
    /**
     * Converts density-independent pixels to actual pixels.
     * 
     * @param dp The value in dp
     * @return The equivalent value in pixels
     */
    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
    
    // ========================================================================
    // Activity Results & Permissions
    // ========================================================================
    
    /**
     * Handles results from SAF file picker and gallery image selection.
     * 
     * @param requestCode The request code (REQUEST_SAF_FILE_PICKER or GALLERY_REQUEST_CODE)
     * @param resultCode RESULT_OK or RESULT_CANCELED
     * @param data Intent containing result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        // SAF File Picker result
        if (requestCode == REQUEST_SAF_FILE_PICKER) {
            mRequestInProgress = false;
            
            if (resultCode == RESULT_OK && data != null) {
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    mAwaitingFileSelection = false;
                    
                    // Take persistent permission
                    if (mStorageHelper != null) {
                        mStorageHelper.takeFilePermission(selectedUri);
                    } else {
                        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                              Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                        try {
                            getContentResolver().takePersistableUriPermission(selectedUri, takeFlags);
                        } catch (SecurityException e) {
                            Log.e(TAG, "Failed to take URI permission", e);
                        }
                    }
                    
                    mGrantedFileUri = selectedUri;
                    
                    String path = getFilePathFromUri(selectedUri);
                    if (path != null) {
                        mFilePath = path;
                    }
                    
                    if (mHeaderTitle != null) {
                        mHeaderTitle.setText("LOADING");
                    }
                    
                    showLoadingOverlay();
                    
                    // Load metadata from selected file
                    if (mExecutor != null) {
                        mExecutor.execute(new Runnable() {
                            @Override
                            public void run() {
                                final MetadataReader.MetadataBundle bundle = 
                                    MetadataReader.readMetadataFromUri(MetadataEditor.this, selectedUri);
                                
                                mMainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        hideLoadingOverlay();
                                        mOriginalData = bundle;
                                        
                                        displayMetadata();
                                        updateFileInfo();
                                        
                                        if (mHeaderTitle != null) {
                                            mHeaderTitle.setText("VIEW MODE");
                                        }
                                        
                                        if (bundle != null && !bundle.isWriteSupported) {
                                            setActionButtonEnabled(false);
                                            ToastManager.showToast(MetadataEditor.this,
                                                "Cannot edit: " + bundle.format + " format", 
                                                ToastManager.LENGTH_NORMAL);
                                        } else {
                                            setActionButtonEnabled(true);
                                            if (mActionButton != null) {
                                                mActionButton.setText("MODIFY");
                                            }
                                        }
                                        
                                        saveUriToDatabase();
                                        enterEditMode();
                                    }
                                });
                            }
                        });
                    }
                }
                return;
            } else if (resultCode == RESULT_CANCELED && mAwaitingFileSelection) {
                finish();
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
                return;
            }
            return;
        }
        
        // Gallery image selection result
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            processSelectedAlbumArt(data.getData());
        }
    }
    
    /**
     * Handles permission request results for gallery access.
     * 
     * @param requestCode PERMISSION_GALLERY_REQUEST
     * @param permissions Requested permissions
     * @param grantResults Grant results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_GALLERY_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGalleryForAlbumArt();
            } else {
                ToastManager.showToast(this, "Permission needed to load album art", ToastManager.LENGTH_NORMAL);
            }
        }
    }
}