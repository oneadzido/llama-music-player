package com.ark.llama;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.EnumSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Centralized controller for managing button states across all activities.
 * 
 * <p>This controller tracks active operations and manages which button groups
 * should be disabled. It does NOT persist state to SharedPreferences - on app
 * restart, all buttons start enabled. This is the single source of truth for
 * button states during playlist synchronization.</p>
 * 
 * <p><b>Button Groups:</b></p>
 * <ul>
 *   <li>{@link ButtonGroup#DATABASE_ACTIONS} - PLAYLIST, METADATA buttons (MusicPlayer)</li>
 *   <li>{@link ButtonGroup#FOLDER_ACTIONS} - UPDATE, IMPORT, REMOVE buttons (FolderManager)</li>
 *   <li>{@link ButtonGroup#METADATA_ACTIONS} - MODIFY, UPDATE buttons (MetadataEditor)</li>
 * </ul>
 * 
 * <p><b>Note:</b> The MANAGER button in MusicPlayer is NOT controlled by this
 * system. It remains enabled during sync so users can view progress in
 * FolderManager, but destructive actions there are disabled via FOLDER_ACTIONS.</p>
 * 
 * <p><b>Usage Example:</b></p>
 * <pre>
 * // Start a playlist sync operation
 * NavigationController.getInstance().beginPlaylistSync();
 * 
 * // End a playlist sync operation
 * NavigationController.getInstance().endPlaylistSync();
 * 
 * // Register as a listener (in Activity.onCreate)
 * NavigationController.getInstance().registerListener(this);
 * 
 * // Unregister as a listener (in Activity.onDestroy)
 * NavigationController.getInstance().unregisterListener(this);
 * 
 * // Implement the listener interface
 * &#64;Override
 * public void onButtonStateChanged(ButtonGroup group, boolean disabled) {
 *     if (group == ButtonGroup.DATABASE_ACTIONS) {
 *         final boolean finalDisabled = disabled;
 *         runOnUiThread(new Runnable() {
 *             &#64;Override
 *             public void run() {
 *                 if (finalDisabled) {
 *                     disableMyButtons();
 *                 } else {
 *                     enableMyButtons();
 *                 }
 *             }
 *         });
 *     }
 * }
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class NavigationController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "NavigationController";
    
    /**
     * Timeout in milliseconds for watchdog timer. If an operation's endOperation()
     * is not called within this time, the operation will be forcibly ended to
     * prevent buttons from staying disabled indefinitely. Value: 60 seconds.
     */
    private static final long OPERATION_WATCHDOG_TIMEOUT_MS = 60000;
    
    // ========================================================================
    // Enums
    // ========================================================================
    
    /**
     * Button groups that can be independently disabled.
     * 
     * <p>Each group represents a set of buttons that should be disabled
     * together during specific operations.</p>
     */
    public enum ButtonGroup {
        
        /**
         * PLAYLIST and METADATA buttons in MusicPlayer.
         * The MANAGER button is excluded from this group.
         */
        DATABASE_ACTIONS,
        
        /**
         * UPDATE, IMPORT, and REMOVE (X) buttons in FolderManager.
         * These buttons modify the folder list and playlist.
         */
        FOLDER_ACTIONS,
        
        /**
         * MODIFY and UPDATE buttons in MetadataEditor.
         * These buttons modify audio file metadata.
         */
        METADATA_ACTIONS
    }
    
    /**
     * Operation types that affect button groups.
     * 
     * <p>Each operation defines which button groups should be disabled
     * while the operation is in progress.</p>
     */
    public enum Operation {
        
        /**
         * Playlist synchronization operation.
         * Affects DATABASE_ACTIONS and FOLDER_ACTIONS button groups.
         */
        PLAYLIST_SYNC(EnumSet.of(ButtonGroup.DATABASE_ACTIONS, ButtonGroup.FOLDER_ACTIONS)),
        
        /**
         * Metadata save operation.
         * Affects METADATA_ACTIONS button group.
         */
        METADATA_SAVE(EnumSet.of(ButtonGroup.METADATA_ACTIONS)),
        
        /**
         * Folder management operation (add/remove folders).
         * Affects FOLDER_ACTIONS button group.
         */
        FOLDER_UPDATE(EnumSet.of(ButtonGroup.FOLDER_ACTIONS));
        
        /** The button groups affected by this operation. */
        private final EnumSet<ButtonGroup> mAffectedGroups;
        
        /**
         * Constructs an Operation with the specified affected button groups.
         *
         * @param affectedGroups The button groups affected by this operation
         */
        Operation(EnumSet<ButtonGroup> affectedGroups) {
            this.mAffectedGroups = affectedGroups;
        }
        
        /**
         * Returns the button groups affected by this operation.
         *
         * @return The affected button groups
         */
        @NonNull
        public EnumSet<ButtonGroup> getAffectedGroups() {
            return mAffectedGroups;
        }
    }
    
    /**
     * Listener interface for button state changes.
     * 
     * <p>Activities that have buttons controlled by this manager should
     * implement this interface and register as listeners.</p>
     */
    public interface ButtonStateListener {
        
        /**
         * Called when a button group's disabled state changes.
         *
         * @param group The button group that changed
         * @param disabled True if buttons in this group should be disabled,
         *                 false if they should be enabled
         */
        void onButtonStateChanged(@NonNull ButtonGroup group, boolean disabled);
    }
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance. */
    @Nullable
    private static NavigationController sInstance;
    
    /** Handler for main thread operations. */
    @NonNull
    private final Handler mMainHandler;
    
    /**
     * Private constructor for singleton pattern.
     * No persistence is loaded - all buttons start enabled.
     */
    private NavigationController() {
        mMainHandler = new Handler(Looper.getMainLooper());
    }
    
    /**
     * Returns the singleton instance of NavigationController.
     * No context parameter is needed as there is no persistence.
     *
     * @return The singleton instance
     */
    @NonNull
    public static synchronized NavigationController getInstance() {
        if (sInstance == null) {
            sInstance = new NavigationController();
        }
        return sInstance;
    }
    
    // ========================================================================
    // Operation Tracking
    // ========================================================================
    
    /** Count of active operations for each button group. */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Integer> mGroupOperationCounts = 
        new ConcurrentHashMap<ButtonGroup, Integer>();
    
    /** Current disabled state for each button group (cached for performance). */
    @NonNull
    private final ConcurrentHashMap<ButtonGroup, Boolean> mGroupDisabledState = 
        new ConcurrentHashMap<ButtonGroup, Boolean>();
    
    /** Registered listeners. */
    @NonNull
    private final CopyOnWriteArrayList<ButtonStateListener> mListeners = 
        new CopyOnWriteArrayList<ButtonStateListener>();
    
    /** Watchdog handler for stuck operations. */
    @NonNull
    private final Handler mWatchdogHandler = new Handler(Looper.getMainLooper());
    
    /** Watchdog runnable for each operation. */
    @NonNull
    private final ConcurrentHashMap<Operation, Runnable> mWatchdogRunnables = 
        new ConcurrentHashMap<Operation, Runnable>();
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Begins an operation. Increments counters for all affected button groups.
     * If a group's counter goes from 0 to 1, that group becomes disabled.
     * 
     * <p><b>Watchdog Protection:</b> A watchdog timer is started for this
     * operation. If endOperation() is not called within OPERATION_WATCHDOG_TIMEOUT_MS,
     * the operation is forcibly ended to prevent buttons from staying disabled
     * indefinitely due to unhandled exceptions or bugs.</p>
     *
     * @param operation The operation to begin
     */
    public void beginOperation(@NonNull final Operation operation) {
        android.util.Log.d(TAG, "beginOperation: " + operation.name());
        
        final EnumSet<ButtonGroup> affectedGroups = operation.getAffectedGroups();
        for (final ButtonGroup group : affectedGroups) {
            final int newCount = incrementGroupCount(group);
            android.util.Log.d(TAG, "  Group " + group.name() + " count = " + newCount);
            
            if (newCount == 1) {
                setGroupDisabled(group, true);
            }
        }
        
        // Start watchdog timer for this operation
        startWatchdog(operation);
    }
    
    /**
     * Ends an operation. Decrements counters for all affected button groups.
     * If a group's counter goes from 1 to 0, that group becomes enabled.
     * 
     * <p>The watchdog timer for this operation is cancelled upon successful
     * completion.</p>
     *
     * @param operation The operation to end
     */
    public void endOperation(@NonNull final Operation operation) {
        android.util.Log.d(TAG, "endOperation: " + operation.name());
        
        // Cancel watchdog timer for this operation
        cancelWatchdog(operation);
        
        final EnumSet<ButtonGroup> affectedGroups = operation.getAffectedGroups();
        for (final ButtonGroup group : affectedGroups) {
            final int newCount = decrementGroupCount(group);
            android.util.Log.d(TAG, "  Group " + group.name() + " count = " + newCount);
            
            if (newCount == 0) {
                setGroupDisabled(group, false);
            } else if (newCount < 0) {
                android.util.Log.w(TAG, "Group " + group.name() + " count below zero, resetting");
                mGroupOperationCounts.put(group, 0);
                setGroupDisabled(group, false);
            }
        }
    }
    
    /**
     * Checks if a button group is currently disabled.
     *
     * @param group The button group to check
     * @return True if the group should be disabled
     */
    public boolean isGroupDisabled(@NonNull ButtonGroup group) {
        final Boolean cached = mGroupDisabledState.get(group);
        if (cached != null) {
            return cached;
        }
        return false;
    }
    
    // ========================================================================
    // Watchdog Methods
    // ========================================================================
    
    /**
     * Starts a watchdog timer for the specified operation.
     * If the operation is not ended within OPERATION_WATCHDOG_TIMEOUT_MS,
     * endOperation() is called automatically to prevent stuck state.
     *
     * @param operation The operation to monitor
     */
    private void startWatchdog(@NonNull final Operation operation) {
        final Runnable watchdogRunnable = new Runnable() {
            @Override
            public void run() {
                android.util.Log.w(TAG, "Watchdog triggered for " + operation.name() + 
                    " - forcing endOperation after " + OPERATION_WATCHDOG_TIMEOUT_MS + "ms");
                endOperation(operation);
            }
        };
        
        mWatchdogRunnables.put(operation, watchdogRunnable);
        mWatchdogHandler.postDelayed(watchdogRunnable, OPERATION_WATCHDOG_TIMEOUT_MS);
        android.util.Log.d(TAG, "Watchdog started for " + operation.name());
    }
    
    /**
     * Cancels the watchdog timer for the specified operation.
     *
     * @param operation The operation to stop monitoring
     */
    private void cancelWatchdog(@NonNull final Operation operation) {
        final Runnable watchdogRunnable = mWatchdogRunnables.remove(operation);
        if (watchdogRunnable != null) {
            mWatchdogHandler.removeCallbacks(watchdogRunnable);
            android.util.Log.d(TAG, "Watchdog cancelled for " + operation.name());
        }
    }
    
    // ========================================================================
    // Private State Management Methods
    // ========================================================================
    
    /**
     * Increments the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after increment
     */
    private int incrementGroupCount(@NonNull ButtonGroup group) {
        final Integer current = mGroupOperationCounts.get(group);
        final int newCount = (current == null ? 0 : current) + 1;
        mGroupOperationCounts.put(group, newCount);
        return newCount;
    }
    
    /**
     * Decrements the operation count for a button group.
     *
     * @param group The button group
     * @return The new count after decrement
     */
    private int decrementGroupCount(@NonNull ButtonGroup group) {
        final Integer current = mGroupOperationCounts.get(group);
        final int newCount = (current == null ? 0 : current) - 1;
        if (newCount >= 0) {
            mGroupOperationCounts.put(group, newCount);
        }
        return newCount;
    }
    
    /**
     * Sets the disabled state for a button group and notifies all listeners.
     * State is NOT persisted to SharedPreferences.
     *
     * @param group The button group
     * @param disabled True to disable, false to enable
     */
    private void setGroupDisabled(@NonNull final ButtonGroup group, final boolean disabled) {
        final Boolean current = mGroupDisabledState.get(group);
        if (current != null && current == disabled) {
            return;
        }
        
        mGroupDisabledState.put(group, disabled);
        android.util.Log.d(TAG, "Group " + group.name() + " " + (disabled ? "DISABLED" : "ENABLED"));
        
        notifyListeners(group, disabled);
    }
    
    /**
     * Notifies all registered listeners of a button state change.
     *
     * @param group The button group that changed
     * @param disabled The new disabled state
     */
    private void notifyListeners(final ButtonGroup group, final boolean disabled) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (final ButtonStateListener listener : mListeners) {
                    try {
                        listener.onButtonStateChanged(group, disabled);
                    } catch (Exception e) {
                        android.util.Log.e(TAG, "Error notifying listener", e);
                    }
                }
            }
        });
    }
    
    // ========================================================================
    // Listener Management Methods
    // ========================================================================
    
    /**
     * Registers a listener to receive button state notifications.
     * 
     * <p>The listener will immediately receive the current state for all
     * button groups upon registration.</p>
     *
     * @param listener The listener to register
     */
    public void registerListener(@NonNull final ButtonStateListener listener) {
        if (!mListeners.contains(listener)) {
            mListeners.add(listener);
            
            for (final ButtonGroup group : ButtonGroup.values()) {
                final boolean disabled = isGroupDisabled(group);
                listener.onButtonStateChanged(group, disabled);
            }
        }
    }
    
    /**
     * Unregisters a listener.
     *
     * @param listener The listener to unregister
     */
    public void unregisterListener(@NonNull final ButtonStateListener listener) {
        mListeners.remove(listener);
    }
    
    // ========================================================================
    // Convenience Methods for Specific Operations
    // ========================================================================
    
    /**
     * Convenience method to begin a playlist sync operation.
     * 
     * <p>Disables DATABASE_ACTIONS (PLAYLIST, METADATA) and
     * FOLDER_ACTIONS (UPDATE, IMPORT, REMOVE) button groups.</p>
     * 
     * <p>A watchdog timer is started. If endPlaylistSync() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginPlaylistSync() {
        beginOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to end a playlist sync operation.
     * 
     * <p>Re-enables DATABASE_ACTIONS and FOLDER_ACTIONS button groups
     * if no other operations are affecting them.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endPlaylistSync() {
        endOperation(Operation.PLAYLIST_SYNC);
    }
    
    /**
     * Convenience method to begin a metadata save operation.
     * 
     * <p>Disables METADATA_ACTIONS (MODIFY, UPDATE) button group.</p>
     * 
     * <p>A watchdog timer is started. If endMetadataSave() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginMetadataSave() {
        beginOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to end a metadata save operation.
     * 
     * <p>Re-enables METADATA_ACTIONS button group if no other operations
     * are affecting it.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endMetadataSave() {
        endOperation(Operation.METADATA_SAVE);
    }
    
    /**
     * Convenience method to begin a folder update operation.
     * 
     * <p>Disables FOLDER_ACTIONS (UPDATE, IMPORT, REMOVE) button group.</p>
     * 
     * <p>A watchdog timer is started. If endFolderUpdate() is not called within
     * OPERATION_WATCHDOG_TIMEOUT_MS, it will be called automatically.</p>
     */
    public void beginFolderUpdate() {
        beginOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Convenience method to end a folder update operation.
     * 
     * <p>Re-enables FOLDER_ACTIONS button group if no other operations
     * are affecting it.</p>
     * 
     * <p>The watchdog timer for this operation is cancelled.</p>
     */
    public void endFolderUpdate() {
        endOperation(Operation.FOLDER_UPDATE);
    }
    
    /**
     * Forces end of all active operations and clears all state.
     * 
     * <p>This method should be used as a last resort when operations are stuck.
     * It cancels all watchdog timers, resets all operation counts to zero,
     * re-enables all button groups, and notifies all listeners of the state change.</p>
     * 
     * <p>This is called automatically by the watchdog system but can also be
     * called manually if needed (e.g., on app shutdown or catastrophic error recovery).</p>
     */
    public void forceEndAllOperations() {
        android.util.Log.w(TAG, "forceEndAllOperations - resetting all button states");
        
        // Cancel all watchdog timers
        for (Operation op : Operation.values()) {
            cancelWatchdog(op);
        }
        
        // Reset all operation counts to zero
        for (ButtonGroup group : ButtonGroup.values()) {
            mGroupOperationCounts.put(group, 0);
            if (isGroupDisabled(group)) {
                setGroupDisabled(group, false);
            }
        }
    }
}