package com.ark.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Adapter for displaying the playlist in a RecyclerView.
 * 
 * <p>This adapter provides efficient recycling of song item views,
 * visual indication of the currently playing song, touch feedback animations,
 * and theme color support.</p>
 * 
 * <p>Features:
 * <ul>
 *   <li>Efficient view recycling via ViewHolder pattern</li>
 *   <li>Visual highlighting for the currently playing song</li>
 *   <li>Display format: Title on first line, Artist • Album • Genre on second line</li>
 *   <li>Touch feedback animations for better UX</li>
 *   <li>Theme color integration for currently playing song title only</li>
 *   <li>Standard #C0C0C0 color for non-playing song titles</li>
 *   <li>Debounced click handling to prevent rapid taps</li>
 *   <li>Progressive genre update support for async ID3 tag reading</li>
 *   <li>Divider hidden for currently playing song to eliminate visual gap</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>Click debouncing uses timestamp comparison.
 * All UI operations are on the main thread.</p>
 * 
 * @see RecyclerView.Adapter
 * @see Song
 * @see ThemeManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Animation duration for button press effects (milliseconds). */
    private static final int ANIMATION_DURATION_MS = 80;
    
    /** Scale factor for button press animation (97% of normal size). */
    private static final float ANIMATION_SCALE_DOWN = 0.97f;
    
    /** Normal scale factor for buttons. */
    private static final float ANIMATION_SCALE_NORMAL = 1.0f;
    
    /** Default theme color (Royal Llama - gold/bronze). */
    private static final String DEFAULT_THEME_COLOR = "#B8A86E";
    
    /** Dark background for currently playing song. */
    private static final String CURRENT_SONG_BACKGROUND = "#1E1E1E";
    
    /** Highlight color for touch feedback (dark gray). */
    private static final String TOUCH_HIGHLIGHT_COLOR = "#2A2A2A";
    
    /** Light text color for primary text (silver/gray) - used for non-playing song titles. */
    private static final String TEXT_COLOR_LIGHT = "#C0C0C0";
    
    /** Darker text color for secondary text (dim gray) - used for subtitle text. */
    private static final String TEXT_COLOR_DARK = "#808080";
    
    /** Separator character for metadata display. */
    private static final String METADATA_SEPARATOR = " • ";
    
    /** Debounce delay for item clicks in milliseconds. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 300;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** List of songs to display in the adapter. */
    private final List<Song> mSongs;
    
    /** Application context for accessing resources and preferences. */
    private final Context mContext;
    
    /** Click listener for song item clicks (can be null). */
    @Nullable
    private final OnSongClickListener mListener;
    
    /** Index of the currently playing song (-1 if none). */
    private int mCurrentPlayingIndex = -1;
    
    /** Cached theme color for performance (avoids repeated preference reads). */
    private String mCachedThemeColor = DEFAULT_THEME_COLOR;
    
    /** Last click time for debouncing (per-item, not global). */
    private long mLastClickTime = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for song click events.
     * 
     * <p>Activities and fragments using this adapter must implement this
     * interface to handle song selection.</p>
     */
    public interface OnSongClickListener {
        
        /**
         * Called when a song item is clicked.
         *
         * @param position The position of the clicked song in the list
         * @param song The song that was clicked
         */
        void onSongClick(int position, @NonNull Song song);
    }
    
    // ========================================================================
    // ViewHolder Class
    // ========================================================================
    
    /**
     * ViewHolder for playlist items.
     * 
     * <p>Caches references to views within each item layout for efficient
     * recycling during scrolling.</p>
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        
        /** Container layout for the content area (where background is applied). */
        final LinearLayout mContentLayout;
        
        /** TextView for displaying the song title (android.R.id.text1). */
        final TextView mTitle;
        
        /** TextView for displaying artist, album, and genre (android.R.id.text2). */
        final TextView mSubtitle;
        
        /** Divider view at the bottom of each item (hidden for currently playing song). */
        final View mDivider;
        
        /**
         * Constructs a new ViewHolder.
         *
         * @param view The item view inflated from layout
         */
        public ViewHolder(@NonNull View view) {
            super(view);
            mContentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
            mTitle = (TextView) view.findViewById(android.R.id.text1);
            mSubtitle = (TextView) view.findViewById(android.R.id.text2);
            mDivider = view.findViewById(R.id.itemDivider);
        }
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new PlaylistAdapter.
     *
     * @param context Application context
     * @param songs List of songs to display
     * @param listener Click listener for song items (can be null)
     */
    public PlaylistAdapter(@NonNull Context context, @NonNull List<Song> songs, 
                           @Nullable OnSongClickListener listener) {
        mContext = context;
        mSongs = new ArrayList<Song>(songs);
        mListener = listener;
        loadCurrentPlayingIndex();
        loadThemeColor();
    }
    
    // ========================================================================
    // RecyclerView.Adapter Methods
    // ========================================================================
    
    /**
     * Creates a new ViewHolder for a song item by inflating the layout.
     *
     * @param parent The parent ViewGroup
     * @param viewType The view type (not used)
     * @return A new ViewHolder instance
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_song, parent, false);
        return new ViewHolder(view);
    }
    
    /**
     * Binds data to a ViewHolder at the specified position.
     * 
     * <p>Sets the song title and builds the subtitle string in the format:
     * "Artist • Album • Genre". Missing values are replaced with appropriate
     * placeholders ("Unknown Artist", "Unknown Album", "Unknown Genre").</p>
     * 
     * <p>Styling rules:
     * <ul>
     *   <li>Currently playing song: Dark background (#1E1E1E), themed title color, light subtitle</li>
     *   <li>Non-playing songs: Transparent background, light gray title (#C0C0C0), dark gray subtitle</li>
     *   <li>Divider is hidden for currently playing song to eliminate visual gap</li>
     * </ul>
     * </p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        // Bounds check - prevent index errors
        if (position < 0 || position >= mSongs.size()) {
            return;
        }
        
        final Song song = mSongs.get(position);
        if (song == null) {
            return;
        }
        
        // Set song title with fallback for missing metadata
        String title = song.getTitle();
        holder.mTitle.setText((title != null && !title.isEmpty()) ? title : "Unknown Title");
        
        // Build subtitle string: Artist • Album • Genre
        StringBuilder subtitle = new StringBuilder();
        
        // Artist (always show)
        String artist = song.getArtist();
        if (artist != null && !artist.isEmpty() && !"Unknown Artist".equals(artist)) {
            subtitle.append(artist);
        } else {
            subtitle.append("Unknown Artist");
        }
        
        // Album (always show)
        String album = song.getAlbum();
        if (album != null && !album.isEmpty() && !"Unknown Album".equals(album)) {
            subtitle.append(METADATA_SEPARATOR).append(album);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Album");
        }
        
        // Genre (always show)
        String genre = song.getGenre();
        if (genre != null && !genre.isEmpty() && !"Unknown Genre".equals(genre)) {
            subtitle.append(METADATA_SEPARATOR).append(genre);
        } else {
            subtitle.append(METADATA_SEPARATOR).append("Unknown Genre");
        }
        
        holder.mSubtitle.setText(subtitle.toString());
        
        // Check if this is the currently playing song
        final boolean isCurrent = (position == mCurrentPlayingIndex);
        
        // Update theme color (cached for performance)
        updateThemeColor();
        String themeColor = mCachedThemeColor;
        
        // Apply styling based on playing state
        if (isCurrent) {
            // Currently playing song: dark background, themed title, light subtitle
            holder.mContentLayout.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
            holder.mTitle.setTextColor(Color.parseColor(themeColor));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            // Hide divider for currently playing song - eliminates visual gap
            holder.mDivider.setVisibility(View.GONE);
        } else {
            // Non-playing song: transparent background, standard light gray title, dark subtitle
            holder.mContentLayout.setBackgroundColor(Color.TRANSPARENT);
            // IMPORTANT: Non-playing songs use standard #C0C0C0, NOT theme color
            holder.mTitle.setTextColor(Color.parseColor(TEXT_COLOR_LIGHT));
            holder.mSubtitle.setTextColor(Color.parseColor(TEXT_COLOR_DARK));
            // Show divider for non-playing songs
            holder.mDivider.setVisibility(View.VISIBLE);
        }
        
        // Touch feedback - restores correct state after touch
        holder.mContentLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setBackgroundColor(Color.parseColor(TOUCH_HIGHLIGHT_COLOR));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isCurrent) {
                            v.setBackgroundColor(Color.parseColor(CURRENT_SONG_BACKGROUND));
                        } else {
                            v.setBackgroundColor(Color.TRANSPARENT);
                        }
                        break;
                }
                return false;
            }
        });
        
        // Click listener with scale animation and debouncing
        holder.mContentLayout.setOnClickListener(new View.OnClickListener() {
            private long lastClickTime = 0;
            
            @Override
            public void onClick(final View v) {
                long currentTime = SystemClock.elapsedRealtime();
                if (currentTime - lastClickTime < CLICK_DEBOUNCE_DELAY_MS) {
                    return; // Debounce rapid clicks
                }
                lastClickTime = currentTime;
                
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION || pos >= mSongs.size()) {
                    return;
                }
                
                final Song clickedSong = mSongs.get(pos);
                if (clickedSong == null) {
                    return;
                }
                
                // Animate the click (scale down then back up)
                v.animate().scaleX(ANIMATION_SCALE_DOWN)
                           .scaleY(ANIMATION_SCALE_DOWN)
                           .setDuration(ANIMATION_DURATION_MS)
                           .withEndAction(new Runnable() {
                               @Override
                               public void run() {
                                   v.animate().scaleX(ANIMATION_SCALE_NORMAL)
                                             .scaleY(ANIMATION_SCALE_NORMAL)
                                             .setDuration(ANIMATION_DURATION_MS)
                                             .start();
                               }
                           })
                           .start();
                
                // Notify listener
                if (mListener != null) {
                    mListener.onSongClick(pos, clickedSong);
                }
            }
        });
    }
    
    /**
     * Returns the total number of items in the list.
     *
     * @return The number of songs
     */
    @Override
    public int getItemCount() {
        return mSongs.size();
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Updates the list of songs and refreshes the display.
     *
     * @param newSongs The new list of songs
     */
    public void updateList(@NonNull List<Song> newSongs) {
        mSongs.clear();
        mSongs.addAll(newSongs);
        notifyDataSetChanged();
    }
    
    /**
     * Sets the currently playing song index.
     * 
     * <p>Only notifies the changed items (old and new indices) for efficiency,
     * rather than refreshing the entire list.</p>
     *
     * @param index The new playing index (-1 for no song playing)
     */
    public void setCurrentPlayingIndex(int index) {
        int oldIndex = mCurrentPlayingIndex;
        mCurrentPlayingIndex = index;
        
        // Save to SharedPreferences for persistence
        saveCurrentPlayingIndex(index);
        
        // Only notify changed items for better performance
        if (oldIndex >= 0 && oldIndex < mSongs.size()) {
            notifyItemChanged(oldIndex);
        }
        if (index >= 0 && index < mSongs.size()) {
            notifyItemChanged(index);
        }
    }
    
    /**
     * Returns the currently playing song index.
     *
     * @return The current playing index (-1 if none)
     */
    public int getCurrentPlayingIndex() {
        return mCurrentPlayingIndex;
    }
    
    /**
     * Returns a song at the specified position.
     *
     * @param position The position in the list
     * @return The song, or null if position is invalid
     */
    @Nullable
    public Song getSongAt(int position) {
        if (position >= 0 && position < mSongs.size()) {
            return mSongs.get(position);
        }
        return null;
    }
    
    /**
     * Updates the cached theme color.
     * 
     * <p>Note: Theme color is only applied to the currently playing song's title.
     * Non-playing songs always use #C0C0C0 regardless of theme.</p>
     */
    public void updateThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            String newColor = themeManager.getCurrentColor();
            if (!newColor.equals(mCachedThemeColor)) {
                mCachedThemeColor = newColor;
                // Only need to refresh items that might be affected (the current playing song)
                if (mCurrentPlayingIndex >= 0 && mCurrentPlayingIndex < mSongs.size()) {
                    notifyItemChanged(mCurrentPlayingIndex);
                }
            }
        } catch (Exception e) {
            // Keep cached color on error - app continues to function
        }
    }
    
    /**
     * Updates a single song's genre and refreshes only that item.
     * 
     * <p>This method is called during async genre enrichment when a song's
     * genre has been read from ID3 tags. Unlike a full notifyDataSetChanged(),
     * this only refreshes the specific item that changed, which is more
     * efficient and provides smoother visual feedback as genres appear
     * progressively.</p>
     * 
     * <p>The method finds the song by file path (unique identifier), compares
     * the new genre with the existing one, and only updates if different.
     * This prevents unnecessary UI refreshes when the genre hasn't changed.</p>
     *
     * @param songPath The absolute file path of the song to update
     * @param newGenre The new genre string from ID3 tags
     */
    public void updateSongGenre(String songPath, String newGenre) {
        for (int i = 0; i < mSongs.size(); i++) {
            Song song = mSongs.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                String oldGenre = song.getGenre();
                if (!newGenre.equals(oldGenre)) {
                    song.setGenre(newGenre);
                    notifyItemChanged(i);
                }
                break;
            }
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Loads the current playing index from SharedPreferences.
     */
    private void loadCurrentPlayingIndex() {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mCurrentPlayingIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     *
     * @param index The index to save
     */
    private void saveCurrentPlayingIndex(int index) {
        SharedPreferences prefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply();
    }
    
    /**
     * Loads the current theme color from ThemeManager and caches it.
     */
    private void loadThemeColor() {
        try {
            ThemeManager themeManager = ThemeManager.getInstance(mContext);
            mCachedThemeColor = themeManager.getCurrentColor();
        } catch (Exception e) {
            mCachedThemeColor = DEFAULT_THEME_COLOR;
        }
    }
}