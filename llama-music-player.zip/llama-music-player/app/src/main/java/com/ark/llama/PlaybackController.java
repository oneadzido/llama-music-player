package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackController - Single Source of Truth for all playback state
 * 
 * <p>This class eliminates race conditions by providing a centralized, thread-safe
 * controller for all playback-related state. Every component (MusicService,
 * MusicPlayer, NotificationService, EqualizerActivity) MUST query or modify
 * playback state through this controller.</p>
 * 
 * <h3>Why a Centralized Controller?</h3>
 * <p>Before this controller, state was scattered across multiple components:</p>
 * <ul>
 *   <li>MusicService had mIsPlaying, mCurrentIndex, mCurrentPosition</li>
 *   <li>MusicPlayer had its own copy of position and playing state</li>
 *   <li>NotificationService maintained separate play state</li>
 *   <li>EqualizerActivity queried MusicService directly</li>
 * </ul>
 * <p>This duplication caused race conditions where components disagreed on
 * whether a song was playing, paused, or what position it was at.</p>
 * 
 * <h3>Architecture</h3>
 * <p><b>MusicService WRITES state.</b> <b>MusicPlayer READS state.</b>
 * This class does NOT perform any playback actions (play, pause, seek, next, previous).
 * All actions go directly to MusicService.</p>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All state variables are atomic (lock-free)</li>
 *   <li>Listener callbacks are posted to UI thread (no threading issues)</li>
 *   <li>Position updates are ignored during user interaction</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaybackController {
    
    private static final String TAG = "PlaybackController";
    
    // ========================================================================
    // Constants - Timing Configuration
    // ========================================================================
    
    /** 
     * Minimum time between UI position updates (milliseconds).
     * Throttling prevents UI flooding while maintaining smooth animation.
     * 150ms = ~6-7 updates per second, which is plenty smooth for a seek bar.
     */
    private static final int POSITION_UPDATE_INTERVAL_MS = 150;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    private static PlaybackController sInstance;
    
    /**
     * Returns the singleton instance of PlaybackController.
     * Thread-safe via synchronized.
     */
    @NonNull
    public static synchronized PlaybackController getInstance() {
        if (sInstance == null) {
            sInstance = new PlaybackController();
        }
        return sInstance;
    }
    
    private PlaybackController() {
        // Private constructor for singleton
    }
    
    // ========================================================================
    // Atomic State Variables (Thread-Safe, Lock-Free)
    // ========================================================================
    
    /** 
     * Current playback position in milliseconds.
     * Updated by MusicService from LlamaPlayer's playback loop.
     * AtomicLong provides safe reads/writes across threads.
     */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** 
     * Duration of current song in milliseconds.
     * Set when song is prepared (from decoder or MediaPlayer).
     */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** 
     * Flag indicating if audio is currently playing.
     * True = actively playing, False = paused or stopped.
     */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if player is prepared (song loaded, ready to play).
     * True = a song is loaded and can be played immediately.
     */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /**
     * Flag indicating if user is actively dragging the seek bar.
     * When true, automatic position updates from the player are IGNORED.
     * This prevents the seek bar from jumping while the user is dragging.
     */
    private final AtomicBoolean mIsUserSeeking = new AtomicBoolean(false);
    
    // ========================================================================
    // Current Song Metadata
    // ========================================================================
    
    /** Absolute file path of the currently playing song. */
    private String mCurrentSongPath = null;
    
    /** Title of the currently playing song. */
    private String mCurrentSongTitle = "";
    
    /** Artist of the currently playing song. */
    private String mCurrentArtist = "";
    
    /** Album of the currently playing song. */
    private String mCurrentAlbum = "";
    
    // ========================================================================
    // UI Thread Components
    // ========================================================================
    
    /** Handler for posting callbacks to UI thread. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** Listener for state change callbacks. */
    @Nullable
    private PlaybackControllerListener mListener;
    
    /** Last time we sent a position update (for throttling). */
    private long mLastNotifyTime = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     */
    public interface PlaybackControllerListener {
        
        /**
         * Called when playback position changes (throttled to 150ms intervals).
         * Use this to update the seek bar and time display.
         * 
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when play/pause state changes.
         * Use this to update the play button icon.
         * 
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when a new song is loaded (complete metadata).
         * Use this to update the song title, artist, and total time.
         * 
         * @param title Song title
         * @param artist Artist name
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when prepared state changes (song loaded and ready to play).
         * Use this to enable play button and update duration display.
         * 
         * @param isPrepared True if a song is loaded and ready
         */
        void onPreparedStateChanged(boolean isPrepared);
    }
    
    // ========================================================================
    // Public API - Listener Management
    // ========================================================================
    
    /**
     * Sets the listener for state change callbacks.
     * Only one listener can be active at a time (typically MusicPlayer).
     * Other components (NotificationService) should also register.
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackControllerListener listener) {
        mListener = listener;
        if (listener != null) {
            // Immediately send current state to new listener
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(mCurrentPosition.get(), mDuration.get());
                    currentListener.onPlayStateChanged(mIsPlaying.get());
                    currentListener.onPreparedStateChanged(mIsPrepared.get());
                    if (mCurrentSongPath != null) {
                        currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                            mCurrentSongPath, mDuration.get());
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // WRITE Methods - Called ONLY by MusicService
    // ========================================================================
    
    /**
     * Updates the current playback position.
     * Called by MusicService from LlamaPlayer's playback loop.
     * 
     * <p><b>Important:</b> Updates are IGNORED if:
     * <ul>
     *   <li>User is actively dragging the seek bar (mIsUserSeeking = true)</li>
     *   <li>The new position jumps backward significantly (stale data from AudioTrack)</li>
     * </ul>
     * This prevents UI jitter during user interaction and ensures smooth seek behavior.
     * 
     * @param positionMs Current position in milliseconds
     */
    public void updatePosition(long positionMs) {
        // Don't update if user is dragging the seek bar
        if (mIsUserSeeking.get()) {
            return;
        }
        
        // Don't update if position jumps backward significantly (stale data from AudioTrack)
        long currentPos = mCurrentPosition.get();
        if (positionMs < currentPos - 500) {
            Log.d(TAG, "updatePosition: ignoring backward jump from " + currentPos + " to " + positionMs);
            return;
        }
        
        mCurrentPosition.set(positionMs);
        
        // Throttle UI updates to prevent flooding
        long now = System.currentTimeMillis();
        if (mListener != null && (now - mLastNotifyTime) >= POSITION_UPDATE_INTERVAL_MS) {
            mLastNotifyTime = now;
            final long finalPosition = positionMs;
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(finalPosition, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Updates the play state.
     * Called by MusicService when play/pause occurs.
     * 
     * @param isPlaying True if playing, false if paused
     */
    public void setPlaying(boolean isPlaying) {
        boolean oldState = mIsPlaying.getAndSet(isPlaying);
        if (oldState != isPlaying) {
            Log.d(TAG, "setPlaying: " + isPlaying);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPlayStateChanged(isPlaying);
                    }
                });
            }
        }
    }
    
    /**
     * Updates the prepared state.
     * Called when a song is fully loaded and ready to play.
     * 
     * @param isPrepared True if a song is loaded and ready
     */
    public void setPrepared(boolean isPrepared) {
        boolean oldState = mIsPrepared.getAndSet(isPrepared);
        if (oldState != isPrepared) {
            Log.d(TAG, "setPrepared: " + isPrepared);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPreparedStateChanged(isPrepared);
                    }
                });
            }
        }
    }
    
    /**
     * Updates the duration (called when song is prepared).
     * 
     * @param durationMs Duration in milliseconds
     */
    public void setDuration(long durationMs) {
        long oldDuration = mDuration.getAndSet(durationMs);
        if (oldDuration != durationMs) {
            Log.d(TAG, "setDuration: " + durationMs + "ms");
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPositionChanged(mCurrentPosition.get(), durationMs);
                    }
                });
            }
        }
    }
    
    /**
     * Updates the current song information.
     * Called when a new song starts loading or playing.
     * 
     * @param song The new song, or null to clear
     */
    public void updateSong(@Nullable Song song) {
        if (song == null) {
            mCurrentSongPath = null;
            mCurrentSongTitle = "";
            mCurrentArtist = "";
            mCurrentAlbum = "";
            mDuration.set(0);
            mCurrentPosition.set(0);
            Log.d(TAG, "updateSong: cleared");
            return;
        }
        
        String newPath = song.getPath();
        String newTitle = song.getTitle() != null ? song.getTitle() : "";
        String newArtist = song.getArtist() != null ? song.getArtist() : "";
        String newAlbum = song.getAlbum() != null ? song.getAlbum() : "";
        long newDuration = song.getDuration();
        
        mCurrentSongPath = newPath;
        mCurrentSongTitle = newTitle;
        mCurrentArtist = newArtist;
        mCurrentAlbum = newAlbum;
        mDuration.set(newDuration);
        mCurrentPosition.set(0);
        
        Log.d(TAG, "updateSong: " + newTitle + " - " + newArtist);
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                        mCurrentSongPath, mDuration.get());
                }
            });
        }
    }
    
    // ========================================================================
    // UI Helper Methods - Called ONLY by MusicPlayer
    // ========================================================================
    
    /**
     * Called when user starts dragging the seek bar.
     * This pauses automatic position updates from the player.
     */
    public void onSeekStart() {
        Log.d(TAG, "onSeekStart - user started dragging");
        mIsUserSeeking.set(true);
    }
    
    /**
     * Called when user stops dragging the seek bar.
     * This resumes automatic position updates from the player.
     */
    public void onSeekStop() {
        Log.d(TAG, "onSeekStop - user stopped dragging");
        mIsUserSeeking.set(false);
    }
    
    /**
     * Force resets the user seeking flag (safety timeout).
     * Called when seek operation times out to prevent stuck state.
     * This ensures the UI doesn't get stuck waiting for a seek
     * completion that never arrives.
     */
    public void forceResetSeeking() {
        Log.d(TAG, "forceResetSeeking - safety timeout");
        mIsUserSeeking.set(false);
    }
    
    // ========================================================================
    // READ Methods - Called by ANY component
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     * 
     * @return Duration in milliseconds, or 0 if not loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns true if audio is currently playing.
     * 
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns true if a song is loaded and ready to play.
     * 
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns true if user is currently dragging the seek bar.
     * Used by UI to determine if it should show the seek target.
     * 
     * @return True if user is seeking
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking.get();
    }
    
    /**
     * Returns the current song's file path.
     * 
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentSongPath() {
        return mCurrentSongPath;
    }
    
    /**
     * Returns the current song title.
     * 
     * @return Song title, or empty string if none
     */
    @NonNull
    public String getCurrentSongTitle() {
        return mCurrentSongTitle;
    }
    
    /**
     * Returns the current artist name.
     * 
     * @return Artist name, or empty string if none
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist;
    }
    
    /**
     * Returns the current album name.
     * 
     * @return Album name, or empty string if none
     */
    @NonNull
    public String getCurrentAlbum() {
        return mCurrentAlbum;
    }
    
    // ========================================================================
    // Reset Method
    // ========================================================================
    
    /**
     * Resets all state (called when playlist changes or service stops).
     * This clears all playback information and notifies listeners.
     */
    public void reset() {
        Log.d(TAG, "reset - clearing all state");
        
        mCurrentPosition.set(0);
        mDuration.set(0);
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mIsUserSeeking.set(false);
        mCurrentSongPath = null;
        mCurrentSongTitle = "";
        mCurrentArtist = "";
        mCurrentAlbum = "";
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(0, 0);
                    currentListener.onPlayStateChanged(false);
                    currentListener.onPreparedStateChanged(false);
                }
            });
        }
    }
}