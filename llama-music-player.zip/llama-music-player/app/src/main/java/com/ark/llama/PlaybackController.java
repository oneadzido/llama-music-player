package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackController - Single Source of Truth for all playback state
 * 
 * <p>This class eliminates race conditions by providing a centralized, thread-safe
 * controller for all playback-related state. Every component (MusicService,
 * MusicPlayer, NotificationService, EqualizerActivity) MUST query or modify
 * playback state through this controller.</p>
 * 
 * <h3>Architecture</h3>
 * <p><b>MusicService WRITES state.</b> <b>MusicPlayer READS state.</b>
 * This class does NOT perform any playback actions (play, pause, seek, next, previous).
 * All actions go directly to MusicService.</p>
 * 
 * <p>The PlaybackController solves several critical problems:</p>
 * <ul>
 *   <li><b>Race Conditions:</b> Multiple components (MediaPlayer polling, LlamaPlayer
 *       callbacks, user interaction) were updating the UI simultaneously, causing
 *       seek bar jitter and inconsistent state.</li>
 *   <li><b>Thread Safety:</b> Playback updates come from background threads (polling,
 *       callbacks) while UI updates occur on the main thread. This controller
 *       provides atomic state management.</li>
 *   <li><b>User Seeking:</b> When the user drags the seek bar, automatic position
 *       updates are ignored to prevent conflict. A safety timeout prevents stuck
 *       states.</li>
 *   <li><b>Stale Updates:</b> Position updates that jump backward significantly
 *       (more than 500ms) are ignored as stale data from AudioTrack.</li>
 *   <li><b>Position Caching on Pause:</b> When pausing, the current position is cached
 *       and restored on resume, preventing the seek bar from resetting to 0.</li>
 * </ul>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All state variables are atomic (lock-free): AtomicLong, AtomicBoolean</li>
 *   <li>Listener callbacks are posted to UI thread via Handler (no threading issues)</li>
 *   <li>Position updates are throttled to prevent UI flooding (150ms interval)</li>
 *   <li>No Thread.sleep() used - all delays via Handler.postDelayed()</li>
 *   <li>Read operations are lock-free and thread-safe due to atomic variables</li>
 * </ul>
 * 
 * <h3>Operation Failure Callback</h3>
 * <p>onOperationFailed callback notifies UI when playback operations fail.
 * This allows MusicPlayer to show error messages without changing the UI state
 * optimistically. For example, if MusicService.pause() fails due to IllegalStateException,
 * the play button remains in its current state and an error toast is shown.</p>
 * 
 * <h3>Position Update Validation</h3>
 * <p>When a position update is received:</p>
 * <ol>
 *   <li>If user is seeking -> ignore update entirely</li>
 *   <li>If position jumps backward more than 500ms -> ignore (stale data)</li>
 *   <li>If enough time has passed since last UI update -> notify listener</li>
 *   <li>Otherwise -> store value but throttle UI update</li>
 * </ol>
 * 
 * <h3>Source Tracking</h3>
 * <p>Each update includes a source string (e.g., "LlamaPlayer.onPositionUpdate",
 * "MediaPlayer.polling") for debugging. This helps identify where stale or
 * incorrect updates originate.</p>
 * 
 * @see MusicService
 * @see MusicPlayer
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaybackController {
    
    private static final String TAG = "PlaybackController";
    
    // ========================================================================
    // Constants - Timing Configuration
    // ========================================================================
    
    /** 
     * Minimum time between UI position updates (milliseconds).
     * Throttling prevents UI flooding while maintaining smooth animation.
     * 150ms = ~6-7 updates per second, which is plenty smooth for a seek bar.
     * Human eye cannot perceive differences beyond ~60fps (16ms), but 150ms
     * is sufficient for a seek bar and reduces unnecessary UI thread work.
     */
    private static final int POSITION_UPDATE_INTERVAL_MS = 150;
    
    /**
     * Maximum acceptable backward jump in milliseconds.
     * Jumps larger than this are considered stale data and ignored.
     * 
     * <p>AudioTrack can sometimes report outdated positions when seeking or
     * when the player is recovering from a stall. A backward jump of less
     * than 500ms is usually just normal variation; larger jumps indicate
     * stale data from a previous playback state.</p>
     */
    private static final int MAX_BACKWARD_JUMP_MS = 500;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance of PlaybackController. */
    private static PlaybackController sInstance;
    
    /**
     * Returns the singleton instance of PlaybackController.
     * Thread-safe via synchronized on class initialization.
     * 
     * <p>The singleton pattern ensures that all components share the same
     * source of truth for playback state.</p>
     *
     * @return The singleton PlaybackController instance
     */
    @NonNull
    public static synchronized PlaybackController getInstance() {
        if (sInstance == null) {
            sInstance = new PlaybackController();
        }
        return sInstance;
    }
    
    /**
     * Private constructor for singleton pattern.
     * Prevents instantiation from outside the class.
     */
    private PlaybackController() {
        // Private constructor for singleton
    }
    
    // ========================================================================
    // Atomic State Variables (Thread-Safe, Lock-Free)
    // ========================================================================
    
    /** 
     * Current playback position in milliseconds.
     * Updated by MusicService from LlamaPlayer's playback loop or MediaPlayer polling.
     * AtomicLong provides safe reads/writes across threads without locks.
     * 
     * <p>Why AtomicLong instead of volatile long?</p>
     * <ul>
     *   <li>AtomicLong provides atomic getAndSet operations</li>
     *   <li>Volatile only guarantees visibility, not compound operations</li>
     *   <li>AtomicLong methods are lock-free (CAS operations)</li>
     * </ul>
     */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /**
     * Cached position before pause (for restoring on resume).
     * Prevents seek bar from resetting to 0 when pausing.
     */
    private long mPositionBeforePause = 0;
    
    /** 
     * Duration of current song in milliseconds.
     * Set when song is prepared (from decoder or MediaPlayer).
     * Zero indicates no song is loaded or duration unknown.
     */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** 
     * Flag indicating if audio is currently playing.
     * True = actively playing, False = paused or stopped.
     * This is the single source of truth for play state.
     */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if player is prepared (song loaded, ready to play).
     * True = a song is loaded and can be played immediately.
     * False = no song loaded or player in error state.
     */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /**
     * Flag indicating if user is actively dragging the seek bar.
     * When true, automatic position updates from the player are IGNORED.
     * This prevents the seek bar from jumping while the user is dragging.
     * 
     * <p>The flag is set to true when onSeekStart() is called (MotionEvent.ACTION_DOWN),
     * and set to false either by onSeekStop() (MotionEvent.ACTION_UP) or by a
     * safety timeout forceResetSeeking(). The timeout prevents the UI from getting
     * stuck if the seek operation never completes normally.</p>
     */
    private final AtomicBoolean mIsUserSeeking = new AtomicBoolean(false);
    
    // ========================================================================
    // Current Song Metadata
    // ========================================================================
    
    /** Absolute file path of the currently playing song. Used for album art loading. */
    private String mCurrentSongPath = null;
    
    /** Title of the currently playing song. Displayed in UI and notification. */
    private String mCurrentSongTitle = "";
    
    /** Artist of the currently playing song. Displayed in UI and notification. */
    private String mCurrentArtist = "";
    
    /** Album of the currently playing song. Used for sorting and display. */
    private String mCurrentAlbum = "";
    
    /** 
     * Source of the last position update (for debugging).
     * Helps identify where stale or incorrect updates originate.
     * Possible values: "LlamaPlayer.onPositionUpdate", "MediaPlayer.polling",
     * "MusicService.resume", "reset", etc.
     */
    private String mLastUpdateSource = "initial";
    
    // ========================================================================
    // UI Thread Components
    // ========================================================================
    
    /** 
     * Handler for posting callbacks to UI thread.
     * All listener callbacks are posted to this handler to ensure they
     * execute on the main thread for safe UI updates.
     */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** 
     * Listener for state change callbacks.
     * Only one listener can be active at a time (typically MusicPlayer).
     * Other components like NotificationService also register to receive updates.
     * 
     * <p>The listener is nullable - components can unregister by setting null.</p>
     */
    @Nullable
    private PlaybackControllerListener mListener;
    
    /** 
     * Last time we sent a position update to the listener (for throttling).
     * Prevents UI flooding by limiting updates to POSITION_UPDATE_INTERVAL_MS.
     */
    private long mLastNotifyTime = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     * 
     * <p>Components that need to respond to playback state changes should
     * implement this interface and register with setListener().</p>
     */
    public interface PlaybackControllerListener {
        
        /**
         * Called when playback position changes (throttled to 150ms intervals).
         * Use this to update the seek bar and time display.
         * 
         * <p>Both positionMs and durationMs are provided together to ensure
         * the seek bar max is set correctly even if duration changes.</p>
         * 
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song in milliseconds
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when play/pause state changes.
         * Use this to update the play button icon (PLAY ↔ PAUSE).
         * 
         * <p>This callback is triggered when MusicService calls setPlaying().
         * The UI should update immediately to reflect the new state.</p>
         * 
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when a new song is loaded (complete metadata).
         * Use this to update the song title, artist, and total time.
         * 
         * <p>This callback includes the file path for album art loading.
         * The UI should display the metadata and load album art asynchronously.</p>
         * 
         * @param title Song title (never null, may be empty)
         * @param artist Artist name (never null, may be empty)
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when prepared state changes (song loaded and ready to play).
         * Use this to enable play button and update duration display.
         * 
         * <p>When isPrepared becomes true, the UI should enable the play button
         * and display the correct duration. When false, controls should be disabled.</p>
         * 
         * @param isPrepared True if a song is loaded and ready to play
         */
        void onPreparedStateChanged(boolean isPrepared);
        
        /**
         * Called when a playback operation fails.
         * Allows UI to show error message without having changed button optimistically.
         *
         * <p>For example, if MusicService.resume() fails because the player is not prepared,
         * this callback allows MusicPlayer to show "Cannot resume: player not prepared"
         * without changing the play button state. This prevents the UI from getting
         * out of sync with the actual player state.</p>
         *
         * @param operation The operation that failed (e.g., "play", "pause", "resume", "seek")
         * @param reason Human-readable reason for failure (can be null)
         */
        void onOperationFailed(@NonNull String operation, @Nullable String reason);
    }
    
    // ========================================================================
    // Public API - Listener Management
    // ========================================================================
    
    /**
     * Sets the listener for state change callbacks.
     * Only one listener can be active at a time (typically MusicPlayer).
     * Other components (NotificationService) should also register.
     * 
     * <p>Setting a listener immediately sends the current state to the new listener.
     * This ensures the UI is synchronized from the moment of registration.</p>
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackControllerListener listener) {
        mListener = listener;
        if (listener != null) {
            // Immediately send current state to new listener
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(mCurrentPosition.get(), mDuration.get());
                    currentListener.onPlayStateChanged(mIsPlaying.get());
                    currentListener.onPreparedStateChanged(mIsPrepared.get());
                    if (mCurrentSongPath != null) {
                        currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                            mCurrentSongPath, mDuration.get());
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // WRITE Methods - Called ONLY by MusicService
    // ========================================================================
    
    /**
     * Updates the current playback position with validation.
     * Called by MusicService from LlamaPlayer's playback loop or MediaPlayer polling.
     * 
     * <p><b>Important:</b> Updates are IGNORED if:
     * <ul>
     *   <li>User is actively dragging the seek bar (mIsUserSeeking = true)</li>
     *   <li>The new position jumps backward significantly (stale data from AudioTrack)</li>
     * </ul>
     * This prevents UI jitter during user interaction and ensures smooth seek behavior.
     * 
     * <p>Example of stale data: When LlamaPlayer.seekTo(30000) is called, the
     * onPositionUpdate callback might still report position 5000 for a few frames
     * before jumping to 30000. This 25000ms backward jump would be ignored, preventing
     * the seek bar from flickering.</p>
     * 
     * @param positionMs Current position in milliseconds
     * @param source Caller identifier for debugging (e.g., "LlamaPlayer", "MediaPlayer.polling")
     */
    public void updatePosition(long positionMs, @NonNull String source) {
        // Don't update if user is dragging the seek bar
        if (mIsUserSeeking.get()) {
            Log.v(TAG, "updatePosition from " + source + " ignored - user seeking");
            return;
        }
        
        // Don't update if position jumps backward significantly (stale data from AudioTrack)
        long currentPos = mCurrentPosition.get();
        if (positionMs < currentPos - MAX_BACKWARD_JUMP_MS && currentPos > 1000) {
            Log.d(TAG, "updatePosition: ignoring backward jump from " + currentPos + 
                  " to " + positionMs + " from " + source);
            return;
        }
        
        mCurrentPosition.set(positionMs);
        mLastUpdateSource = source;
        
        // Throttle UI updates to prevent flooding
        long now = System.currentTimeMillis();
        if (mListener != null && (now - mLastNotifyTime) >= POSITION_UPDATE_INTERVAL_MS) {
            mLastNotifyTime = now;
            final long finalPosition = positionMs;
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(finalPosition, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Convenience overload for updatePosition with default source "unspecified".
     * 
     * @param positionMs Current position in milliseconds
     */
    public void updatePosition(long positionMs) {
        updatePosition(positionMs, "unspecified");
    }
    
    /**
     * Called when the player is about to pause.
     * Caches the current position so it can be restored on resume.
     * This prevents the seek bar from resetting to 0 when paused.
     */
    public void onPause() {
        mPositionBeforePause = mCurrentPosition.get();
        Log.d(TAG, "onPause: cached position " + mPositionBeforePause + "ms");
    }
    
    /**
     * Called when the player resumes after being paused.
     * Restores the cached position if available.
     * This prevents the seek bar from resetting to 0 when resuming.
     */
    public void onResume() {
        if (mPositionBeforePause > 0) {
            Log.d(TAG, "onResume: restoring cached position " + mPositionBeforePause + "ms");
            mCurrentPosition.set(mPositionBeforePause);
            // Notify listener of restored position
            if (mListener != null) {
                final long restoredPosition = mPositionBeforePause;
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPositionChanged(restoredPosition, mDuration.get());
                    }
                });
            }
            mPositionBeforePause = 0;
        }
    }
    
    /**
     * Updates the play state.
     * Called by MusicService when play/pause occurs.
     * 
     * <p>This method notifies the listener only if the state actually changes.
     * If the new state is the same as the current state, no callback is sent.</p>
     * 
     * @param isPlaying True if playing, false if paused
     * @param source Caller identifier for debugging
     */
    public void setPlaying(boolean isPlaying, @NonNull String source) {
        boolean oldState = mIsPlaying.getAndSet(isPlaying);
        if (oldState != isPlaying) {
            Log.d(TAG, "setPlaying: " + isPlaying + " from " + source);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPlayStateChanged(isPlaying);
                    }
                });
            }
        }
    }
    
    /**
     * Convenience overload for setPlaying with default source "unspecified".
     * 
     * @param isPlaying True if playing, false if paused
     */
    public void setPlaying(boolean isPlaying) {
        setPlaying(isPlaying, "unspecified");
    }
    
    /**
     * Updates the prepared state.
     * Called when a song is fully loaded and ready to play.
     * 
     * <p>The prepared state indicates that MusicService has a valid player
     * with a song loaded. When isPrepared becomes true, the UI should enable
     * the play button. When false, the play button should be disabled.</p>
     * 
     * @param isPrepared True if a song is loaded and ready
     * @param source Caller identifier for debugging
     */
    public void setPrepared(boolean isPrepared, @NonNull String source) {
        boolean oldState = mIsPrepared.getAndSet(isPrepared);
        if (oldState != isPrepared) {
            Log.d(TAG, "setPrepared: " + isPrepared + " from " + source);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPreparedStateChanged(isPrepared);
                    }
                });
            }
        }
    }
    
    /**
     * Convenience overload for setPrepared with default source "unspecified".
     * 
     * @param isPrepared True if a song is loaded and ready
     */
    public void setPrepared(boolean isPrepared) {
        setPrepared(isPrepared, "unspecified");
    }
    
    /**
     * Updates the duration (called when song is prepared).
     * 
     * <p>Duration may be updated multiple times (e.g., when a song is first
     * loaded and again when the player is fully prepared). The UI should
     * always show the latest duration.</p>
     * 
     * @param durationMs Duration in milliseconds
     * @param source Caller identifier for debugging
     */
    public void setDuration(long durationMs, @NonNull String source) {
        long oldDuration = mDuration.getAndSet(durationMs);
        if (oldDuration != durationMs) {
            Log.d(TAG, "setDuration: " + durationMs + "ms from " + source);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPositionChanged(mCurrentPosition.get(), durationMs);
                    }
                });
            }
        }
    }
    
    /**
     * Convenience overload for setDuration with default source "unspecified".
     * 
     * @param durationMs Duration in milliseconds
     */
    public void setDuration(long durationMs) {
        setDuration(durationMs, "unspecified");
    }
    
    /**
     * Updates the current song information.
     * Called when a new song starts loading or playing.
     * 
     * <p>This method clears position and duration when song is null.
     * When a valid song is provided, all metadata fields are updated.</p>
     * 
     * @param song The new song, or null to clear
     * @param source Caller identifier for debugging
     */
    public void updateSong(@Nullable Song song, @NonNull String source) {
        if (song == null) {
            mCurrentSongPath = null;
            mCurrentSongTitle = "";
            mCurrentArtist = "";
            mCurrentAlbum = "";
            mDuration.set(0);
            mCurrentPosition.set(0);
            mPositionBeforePause = 0;
            Log.d(TAG, "updateSong: cleared from " + source);
            return;
        }
        
        String newPath = song.getPath();
        String newTitle = song.getTitle() != null ? song.getTitle() : "";
        String newArtist = song.getArtist() != null ? song.getArtist() : "";
        String newAlbum = song.getAlbum() != null ? song.getAlbum() : "";
        long newDuration = song.getDuration();
        
        mCurrentSongPath = newPath;
        mCurrentSongTitle = newTitle;
        mCurrentArtist = newArtist;
        mCurrentAlbum = newAlbum;
        mDuration.set(newDuration);
        mCurrentPosition.set(0);
        mPositionBeforePause = 0;
        
        Log.d(TAG, "updateSong: " + newTitle + " - " + newArtist + " from " + source);
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                        mCurrentSongPath, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Convenience overload for updateSong with default source "unspecified".
     * 
     * @param song The new song, or null to clear
     */
    public void updateSong(@Nullable Song song) {
        updateSong(song, "unspecified");
    }
    
    // ========================================================================
    // Operation Failure Notification
    // ========================================================================
    
    /**
     * Notifies listeners that a playback operation failed.
     * Called by MusicService when operations like play, pause, or resume fail.
     * This allows the UI to show error messages without having optimistically
     * changed the button state.
     *
     * <p>Example usage:</p>
     * <pre>
     * if (mMediaPlayer == null) {
     *     mPlaybackController.notifyOperationFailed("pause", "No player available");
     *     return;
     * }
     * </pre>
     *
     * @param operation The operation that failed (e.g., "play", "pause", "resume", "seek")
     * @param reason Human-readable reason for failure (can be null)
     */
    public void notifyOperationFailed(@NonNull String operation, @Nullable String reason) {
        Log.w(TAG, "Operation failed: " + operation + " - " + reason);
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onOperationFailed(operation, reason);
                }
            });
        }
    }
    
    // ========================================================================
    // UI Helper Methods - Called ONLY by MusicPlayer
    // ========================================================================
    
    /**
     * Called when user starts dragging the seek bar.
     * This pauses automatic position updates from the player.
     * 
     * <p>Should be called from SeekBar.OnSeekBarChangeListener.onStartTrackingTouch().
     * The flag prevents the seek bar from being updated by the playback loop
     * while the user is dragging, preventing jitter.</p>
     */
    public void onSeekStart() {
        Log.d(TAG, "onSeekStart - user started dragging");
        mIsUserSeeking.set(true);
    }
    
    /**
     * Called when user stops dragging the seek bar.
     * This resumes automatic position updates from the player.
     * 
     * <p>Should be called from SeekBar.OnSeekBarChangeListener.onStopTrackingTouch().
     * After the user releases the seek bar, automatic updates resume normally.</p>
     */
    public void onSeekStop() {
        Log.d(TAG, "onSeekStop - user stopped dragging");
        mIsUserSeeking.set(false);
    }
    
    /**
     * Force resets the user seeking flag (safety timeout).
     * Called when seek operation times out to prevent stuck state.
     * This ensures the UI doesn't get stuck waiting for a seek
     * completion that never arrives.
     * 
     * <p>If the seek operation never completes (e.g., due to a player error),
     * the flag could remain set to true indefinitely, causing the seek bar
     * to never update again. This method provides a safety release.</p>
     */
    public void forceResetSeeking() {
        Log.d(TAG, "forceResetSeeking - safety timeout");
        mIsUserSeeking.set(false);
    }
    
    // ========================================================================
    // READ Methods - Called by ANY component
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * Thread-safe: uses AtomicLong.get() without locks.
     * 
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     * Thread-safe: uses AtomicLong.get() without locks.
     * 
     * @return Duration in milliseconds, or 0 if not loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns true if audio is currently playing.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns true if a song is loaded and ready to play.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns true if user is currently dragging the seek bar.
     * Used by UI to determine if it should show the seek target.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if user is seeking
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking.get();
    }
    
    /**
     * Returns the current song's file path.
     * 
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentSongPath() {
        return mCurrentSongPath;
    }
    
    /**
     * Returns the current song title.
     * 
     * @return Song title, or empty string if none
     */
    @NonNull
    public String getCurrentSongTitle() {
        return mCurrentSongTitle;
    }
    
    /**
     * Returns the current artist name.
     * 
     * @return Artist name, or empty string if none
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist;
    }
    
    /**
     * Returns the current album name.
     * 
     * @return Album name, or empty string if none
     */
    @NonNull
    public String getCurrentAlbum() {
        return mCurrentAlbum;
    }
    
    /**
     * Returns the source of the last position update (for debugging).
     * 
     * <p>Example outputs: "LlamaPlayer.onPositionUpdate", "MediaPlayer.polling",
     * "MusicService.resume", "reset", "initial"</p>
     * 
     * @return Source string
     */
    @NonNull
    public String getLastUpdateSource() {
        return mLastUpdateSource;
    }
    
    // ========================================================================
    // Reset Method
    // ========================================================================
    
    /**
     * Resets all state (called when playlist changes or service stops).
     * This clears all playback information and notifies listeners.
     * 
     * <p>All atomic variables are set to their default values:
     * position=0, duration=0, isPlaying=false, isPrepared=false, isUserSeeking=false.
     * Metadata fields are cleared to empty strings.</p>
     */
    public void reset() {
        Log.d(TAG, "reset - clearing all state");
        
        mCurrentPosition.set(0);
        mDuration.set(0);
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mIsUserSeeking.set(false);
        mCurrentSongPath = null;
        mCurrentSongTitle = "";
        mCurrentArtist = "";
        mCurrentAlbum = "";
        mPositionBeforePause = 0;
        mLastUpdateSource = "reset";
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(0, 0);
                    currentListener.onPlayStateChanged(false);
                    currentListener.onPreparedStateChanged(false);
                }
            });
        }
    }
}