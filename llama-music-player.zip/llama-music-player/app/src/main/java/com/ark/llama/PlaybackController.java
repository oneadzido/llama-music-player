package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackController - Single Source of Truth for all playback state
 * 
 * <p>This class eliminates race conditions by providing a centralized, thread-safe
 * controller for all playback-related state. Every component (MusicService,
 * MusicPlayer, NotificationService, EqualizerActivity) MUST query or modify
 * playback state through this controller.</p>
 * 
 * <h3>Why a Centralized Controller?</h3>
 * <p>Before this controller, state was scattered across multiple components:</p>
 * <ul>
 *   <li>MusicService had mIsPlaying, mCurrentIndex, mCurrentPosition</li>
 *   <li>MusicPlayer had its own copy of position and playing state</li>
 *   <li>NotificationService maintained separate play state</li>
 *   <li>EqualizerActivity queried MusicService directly</li>
 * </ul>
 * <p>This duplication caused race conditions where components disagreed on
 * whether a song was playing, paused, or what position it was at.</p>
 * 
 * <h3>How It Works</h3>
 * 
 * <p><b>1. Atomic State Variables</b><br>
 * All state is stored in Java Atomic* classes which provide lock-free,
 * thread-safe operations. Multiple threads can read/write without explicit
 * synchronization.</p>
 * 
 * <p><b>2. Single Writer Principle</b><br>
 * Only the active audio player (LlamaPlayer or MediaPlayer) writes
 * position updates. All other components only read or request changes
 * (like seek operations).</p>
 * 
 * <p><b>3. Seek Operation Flow</b><br>
 * <pre>
 * User drags seek bar -> onSeekStart() -> sets isUserSeeking = true
 * User releases seek bar -> onSeekStop(position) -> calls seekTo()
 *   ▼
 * seekTo() stores pendingSeek and lastSeekTime
 *   ▼
 * Notifies listener with immediate position update (SEEK_UI_DELAY_MS)
 *   ▼
 * Executes actual seek on background thread
 *   ▼
 * When position reaches target, clears isUserSeeking flag
 * </pre>
 * </p>
 * 
 * <p><b>4. Position Update Flow</b><br>
 * <pre>
 * Playback loop (every ~100ms) -> updatePosition()
 *   ▼
 * FIRST: Check pendingSeek? -> If yes, check if reached target
 *   ▼
 * If pending seek active, IGNORE all position updates
 *   ▼
 * THEN: Check isUserSeeking? -> If true, IGNORE (user dragging)
 *   ▼
 * THEN: Check if position jumped backward >500ms? -> If yes, IGNORE (stale data)
 *   ▼
 * Update mCurrentPosition
 *   ▼
 * Notifies listener (throttled to 150ms intervals)
 *   ▼
 * Listener updates UI (seek bar, time labels)
 * </pre>
 * </p>
 * 
 * <p><b>5. Listener Pattern</b><br>
 * Components register as listeners and receive callbacks on the UI thread
 * when state changes. This decouples state management from UI updates.</p>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All state variables are atomic (lock-free)</li>
 *   <li>Listener callbacks are posted to UI thread (no threading issues)</li>
 *   <li>Seek operations are serialized via the pendingSeek mechanism</li>
 *   <li>Position updates are ignored during user interaction</li>
 * </ul>
 * 
 * <h3>Integration Points</h3>
 * <ul>
 *   <li><b>MusicService</b> - Updates playing state, duration, song info</li>
 *   <li><b>LlamaPlayer</b> - Reports position updates from playback loop</li>
 *   <li><b>MusicPlayer</b> - Listens for position/state changes, updates UI</li>
 *   <li><b>NotificationService</b> - Listens for playback/metadata changes</li>
 *   <li><b>EqualizerActivity</b> - Reads current state for display</li>
 * </ul>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class PlaybackController {
    
    private static final String TAG = "PlaybackController";
    
    // ========================================================================
    // Constants - Timing Configuration
    // ========================================================================
    
    /** 
     * Minimum time between UI position updates (milliseconds).
     * Throttling prevents UI flooding while maintaining smooth animation.
     * 150ms = ~6-7 updates per second, which is plenty smooth for a seek bar.
     */
    private static final int POSITION_UPDATE_INTERVAL_MS = 150;
    
    /** 
     * Seek window for immediate UI feedback (milliseconds).
     * After a user seeks, we show the target position for this duration
     * while the audio engine catches up. This prevents the seek bar from
     * "rubber banding" back to the old position.
     * 250ms is long enough to feel immediate but short enough to not feel laggy.
     */
    private static final int SEEK_UI_DELAY_MS = 250;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    private static PlaybackController sInstance;
    
    /**
     * Returns the singleton instance of PlaybackController.
     * Thread-safe via synchronized.
     */
    @NonNull
    public static synchronized PlaybackController getInstance() {
        if (sInstance == null) {
            sInstance = new PlaybackController();
        }
        return sInstance;
    }
    
    private PlaybackController() {
        // Private constructor for singleton
    }
    
    // ========================================================================
    // Atomic State Variables (Thread-Safe, Lock-Free)
    // ========================================================================
    
    /** 
     * Current playback position in milliseconds.
     * Updated by the active player's playback loop.
     * AtomicLong provides safe reads/writes across threads.
     */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** 
     * Duration of current song in milliseconds.
     * Set when song is prepared (from decoder or MediaPlayer).
     */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** 
     * Pending seek target (-1 if none).
     * When user seeks, we store the target here. The actual seek happens
     * asynchronously, but UI immediately shows this value.
     */
    private final AtomicInteger mPendingSeek = new AtomicInteger(-1);
    
    /** 
     * Last seek target for UI feedback window.
     * Used to keep showing the seek position after the user releases the bar.
     */
    private final AtomicInteger mLastSeekTarget = new AtomicInteger(-1);
    
    /** 
     * Timestamp of last seek (milliseconds).
     * Used with SEEK_UI_DELAY_MS to determine if we're still in the UI window.
     */
    private final AtomicLong mLastSeekTime = new AtomicLong(0);
    
    /** 
     * Flag indicating if user is actively dragging the seek bar.
     * When true, automatic position updates from the player are IGNORED.
     * This prevents the seek bar from jumping while the user is dragging.
     */
    private final AtomicBoolean mIsUserSeeking = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if audio is currently playing.
     * True = actively playing, False = paused or stopped.
     */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if player is prepared (song loaded, ready to play).
     * True = a song is loaded and can be played immediately.
     */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    // ========================================================================
    // Current Song Metadata
    // ========================================================================
    
    private String mCurrentSongPath = null;
    private String mCurrentSongTitle = "";
    private String mCurrentArtist = "";
    private String mCurrentAlbum = "";
    
    // ========================================================================
    // UI Thread Components
    // ========================================================================
    
    /** Handler for posting callbacks to UI thread */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** Listener for state change callbacks */
    @Nullable
    private PlaybackControllerListener mListener;
    
    /** Last position value sent to listener (for throttling) */
    private long mLastNotifiedPosition = -1;
    
    /** Last time we sent a position update (for throttling) */
    private long mLastNotifyTime = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     */
    public interface PlaybackControllerListener {
        
        /**
         * Called when playback position changes (throttled to 150ms intervals).
         * Use this to update the seek bar and time display.
         * 
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when play/pause state changes.
         * Use this to update the play button icon.
         * 
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when a new song is loaded (complete metadata).
         * Use this to update the song title, artist, and total time.
         * 
         * @param title Song title
         * @param artist Artist name
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when a seek operation completes successfully.
         * Use this to ensure UI is exactly at the seek position.
         * 
         * @param positionMs Final position after seek
         */
        void onSeekCompleted(long positionMs);
        
        /**
         * Called when playback state (playing/prepared) changes.
         * Use this for notification and lock screen updates.
         * 
         * @param isPlaying True if playing
         * @param isPrepared True if a song is loaded and ready
         */
        void onPlaybackStateChanged(boolean isPlaying, boolean isPrepared);
        
        /**
         * Called when metadata (title, artist, album) changes.
         * Use this for notification updates without full song reload.
         * 
         * @param title Song title
         * @param artist Artist name
         * @param album Album name
         * @param duration Duration in milliseconds
         */
        void onMetadataChanged(@NonNull String title, @NonNull String artist,
                              @NonNull String album, long duration);
    }
    
    // ========================================================================
    // Public API - Listener Management
    // ========================================================================
    
    /**
     * Sets the listener for state change callbacks.
     * Only one listener can be active at a time (typically MusicPlayer).
     * Other components (NotificationService) should also register.
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackControllerListener listener) {
        mListener = listener;
        if (listener != null) {
            // Immediately send current state to new listener
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPositionChanged(mCurrentPosition.get(), mDuration.get());
                    mListener.onPlayStateChanged(mIsPlaying.get());
                    mListener.onPlaybackStateChanged(mIsPlaying.get(), mIsPrepared.get());
                    if (mCurrentSongPath != null) {
                        mListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                            mCurrentSongPath, mDuration.get());
                        mListener.onMetadataChanged(mCurrentSongTitle, mCurrentArtist,
                            mCurrentAlbum, mDuration.get());
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Public API - Position Management (Called by Audio Players)
    // ========================================================================
    
    /**
     * Updates the current playback position.
     * Called by LlamaPlayer or MediaPlayer from their playback loops.
     * 
     * <p><b>Important:</b> Updates are IGNORED if:
     * <ul>
     *   <li>A seek is pending (position updates are ignored until seek completes)</li>
     *   <li>User is actively dragging the seek bar (mIsUserSeeking = true)</li>
     *   <li>The new position jumps backward significantly (stale data)</li>
     * </ul>
     * This prevents UI jitter during user interaction and ensures smooth seek behavior.
     * 
     * @param positionMs Current position in milliseconds
     */
    public void updatePosition(long positionMs) {
        // FIRST: Check if we have a pending seek - this is the highest priority
        int pendingSeek = mPendingSeek.get();
        if (pendingSeek >= 0) {
            // If we've reached or passed the seek target (within 50ms), seek is complete
            if (Math.abs(positionMs - pendingSeek) < 50 || positionMs >= pendingSeek - 50) {
                mPendingSeek.set(-1);
                mIsUserSeeking.set(false);
                if (mListener != null) {
                    mUiHandler.post(() -> mListener.onSeekCompleted(pendingSeek));
                }
            }
            // Still seeking - ignore all position updates during seek
            return;
        }
        
        // THEN: Don't update if user is dragging the seek bar
        if (mIsUserSeeking.get()) {
            return;
        }
        
        // Don't update if position jumps backward significantly (stale data from AudioTrack)
        long currentPos = mCurrentPosition.get();
        if (positionMs < currentPos - 500) {
            Log.d(TAG, "updatePosition: ignoring backward jump from " + currentPos + " to " + positionMs);
            return;
        }
        
        mCurrentPosition.set(positionMs);
        
        // Throttle UI updates to prevent flooding
        long now = System.currentTimeMillis();
        boolean shouldNotify = (now - mLastNotifyTime) >= POSITION_UPDATE_INTERVAL_MS ||
                               Math.abs(positionMs - mLastNotifiedPosition) > 500;
        
        if (shouldNotify && mListener != null) {
            mLastNotifyTime = now;
            mLastNotifiedPosition = positionMs;
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPositionChanged(positionMs, mDuration.get());
                }
            });
        }
    }
    
    // ========================================================================
    // Public API - Seek Operations (Called by UI)
    // ========================================================================
    
    /**
     * Called when user starts dragging the seek bar.
     * This pauses automatic position updates from the player.
     */
    public void onSeekStart() {
        Log.d(TAG, "onSeekStart - user started dragging");
        mIsUserSeeking.set(true);
        mPendingSeek.set(-1);
    }
    
    /**
     * Called when user stops dragging the seek bar.
     * This performs the actual seek and starts the UI feedback window.
     * 
     * @param finalPosition The final position where user released (milliseconds)
     * @param actualSeekCallback Runnable that performs the actual seek on the player
     */
    public void onSeekStop(int finalPosition, @NonNull Runnable actualSeekCallback) {
        Log.d(TAG, "onSeekStop - user stopped at " + finalPosition + "ms");
        seekTo(finalPosition, actualSeekCallback);
    }
    
    /**
     * Performs a seek operation.
     * 
     * <p><b>Flow:</b>
     * <ol>
     *   <li>Clamp position to valid range (0 to duration)</li>
     *   <li>Set user seeking flag (pauses automatic updates)</li>
     *   <li>Store pending seek target</li>
     *   <li>Immediately notify UI of new position (for instant feedback)</li>
     *   <li>Execute actual seek on background thread</li>
     *   <li>When position reaches target, clear user seeking flag</li>
     * </ol>
     * 
     * @param positionMs Target position in milliseconds
     * @param actualSeekCallback Runnable that performs the actual seek on the player
     */
    public void seekTo(int positionMs, @NonNull Runnable actualSeekCallback) {
        long clampedPosition = Math.max(0, Math.min(positionMs, mDuration.get()));
        
        Log.d(TAG, "seekTo: " + positionMs + "ms -> clamped: " + clampedPosition + "ms");
        
        // Mark user as seeking (pauses automatic position updates)
        mIsUserSeeking.set(true);
        
        // Store pending seek - flag will be cleared when position reaches target
        mPendingSeek.set((int) clampedPosition);
        mLastSeekTarget.set((int) clampedPosition);
        mLastSeekTime.set(System.currentTimeMillis());
        
        // Immediately update UI to show seek target
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPositionChanged(clampedPosition, mDuration.get());
                }
            });
        }
        
        // Perform actual seek on background thread (don't block UI)
        new Thread(() -> {
            try {
                actualSeekCallback.run();
                // Note: mIsUserSeeking will be cleared in updatePosition()
                // when the position reaches the seek target
            } catch (Exception e) {
                Log.e(TAG, "Seek failed", e);
                mUiHandler.post(() -> {
                    mPendingSeek.set(-1);
                    mIsUserSeeking.set(false);
                });
            }
        }).start();
    }
    
    // ========================================================================
    // Public API - Song Management (Called by MusicService)
    // ========================================================================
    
    /**
     * Updates the current song information.
     * Called when a new song starts loading or playing.
     * 
     * @param song The new song, or null to clear
     */
    public void updateSong(@Nullable Song song) {
        if (song == null) {
            mCurrentSongPath = null;
            mCurrentSongTitle = "";
            mCurrentArtist = "";
            mCurrentAlbum = "";
            mDuration.set(0);
            mCurrentPosition.set(0);
            return;
        }
        
        mCurrentSongPath = song.getPath();
        mCurrentSongTitle = song.getTitle() != null ? song.getTitle() : "";
        mCurrentArtist = song.getArtist() != null ? song.getArtist() : "";
        mCurrentAlbum = song.getAlbum() != null ? song.getAlbum() : "";
        mDuration.set(song.getDuration());
        mCurrentPosition.set(0);
        mPendingSeek.set(-1);
        mIsUserSeeking.set(false);
        
        // Notify listeners
        notifyMetadataChanged();
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                        mCurrentSongPath, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Updates the play state.
     * Called by MusicService when play/pause occurs.
     * 
     * @param isPlaying True if playing, false if paused
     */
    public void setPlaying(boolean isPlaying) {
        boolean oldState = mIsPlaying.getAndSet(isPlaying);
        if (oldState != isPlaying) {
            notifyPlaybackStateChanged();
            if (mListener != null) {
                mUiHandler.post(() -> {
                    if (mListener != null) {
                        mListener.onPlayStateChanged(isPlaying);
                    }
                });
            }
        }
    }
    
    /**
     * Updates the prepared state.
     * Called when a song is fully loaded and ready to play.
     * 
     * @param isPrepared True if a song is loaded and ready
     */
    public void setPrepared(boolean isPrepared) {
        boolean oldState = mIsPrepared.getAndSet(isPrepared);
        if (oldState != isPrepared) {
            notifyPlaybackStateChanged();
        }
    }
    
    /**
     * Updates the duration (called when song is prepared).
     * 
     * @param durationMs Duration in milliseconds
     */
    public void setDuration(long durationMs) {
        mDuration.set(durationMs);
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPositionChanged(mCurrentPosition.get(), durationMs);
                }
            });
        }
    }
    
    // ========================================================================
    // Public API - Getter Methods (Thread-Safe)
    // ========================================================================
    
    /**
     * Returns the current playback position.
     * If a seek is pending within the UI window, returns the seek target
     * instead of the actual player position (for smooth UI).
     * 
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        int pendingSeek = mPendingSeek.get();
        if (pendingSeek >= 0) {
            long seekTime = mLastSeekTime.get();
            if (System.currentTimeMillis() - seekTime < SEEK_UI_DELAY_MS) {
                return pendingSeek;
            } else {
                mPendingSeek.set(-1);
            }
        }
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song.
     * 
     * @return Duration in milliseconds, or 0 if not loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns true if audio is currently playing.
     * 
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns true if a song is loaded and ready to play.
     * 
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns true if user is currently dragging the seek bar.
     * Used by UI to determine if it should show the seek target.
     * 
     * @return True if user is seeking
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking.get();
    }
    
    /**
     * Returns the current song's file path.
     * 
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentSongPath() {
        return mCurrentSongPath;
    }
    
    /**
     * Returns the current song title.
     * 
     * @return Song title, or empty string if none
     */
    @NonNull
    public String getCurrentSongTitle() {
        return mCurrentSongTitle;
    }
    
    /**
     * Returns the current artist name.
     * 
     * @return Artist name, or empty string if none
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist;
    }
    
    /**
     * Returns the current album name.
     * 
     * @return Album name, or empty string if none
     */
    @NonNull
    public String getCurrentAlbum() {
        return mCurrentAlbum;
    }
    
    /**
     * Resets all state (called when playlist changes or service stops).
     */
    public void reset() {
        mCurrentPosition.set(0);
        mDuration.set(0);
        mPendingSeek.set(-1);
        mLastSeekTarget.set(-1);
        mIsUserSeeking.set(false);
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mCurrentSongPath = null;
        mCurrentSongTitle = "";
        mCurrentArtist = "";
        mCurrentAlbum = "";
        
        notifyPlaybackStateChanged();
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPositionChanged(0, 0);
                    mListener.onPlayStateChanged(false);
                }
            });
        }
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Notifies listener of playback state change (playing/prepared).
     * Used for notification and lock screen updates.
     */
    private void notifyPlaybackStateChanged() {
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onPlaybackStateChanged(mIsPlaying.get(), mIsPrepared.get());
                }
            });
        }
    }
    
    /**
     * Notifies listener of metadata change (title, artist, album, duration).
     * Used for notification updates without full song reload.
     */
    private void notifyMetadataChanged() {
        if (mListener != null) {
            mUiHandler.post(() -> {
                if (mListener != null) {
                    mListener.onMetadataChanged(mCurrentSongTitle, mCurrentArtist,
                        mCurrentAlbum, mDuration.get());
                }
            });
        }
    }
}