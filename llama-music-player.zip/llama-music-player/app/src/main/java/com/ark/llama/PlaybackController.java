package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackController - Single Source of Truth for all playback state.
 * 
 * <p>This class eliminates race conditions by providing a centralized, thread-safe
 * controller for all playback-related state. Every component (MusicService,
 * MusicPlayer, NotificationService, EqualizerActivity) MUST query or modify
 * playback state through this controller.</p>
 * 
 * <h3>Why a Centralized Controller?</h3>
 * <p>Before this controller, state was scattered across multiple components:</p>
 * <ul>
 *   <li>MusicService had mIsPlaying, mCurrentIndex, mCurrentPosition</li>
 *   <li>MusicPlayer had its own copy of position and playing state</li>
 *   <li>NotificationService maintained separate play state</li>
 *   <li>EqualizerActivity queried MusicService directly</li>
 * </ul>
 * <p>This duplication caused race conditions where components disagreed on
 * whether a song was playing, paused, or what position it was at.</p>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All state variables are atomic (lock-free, safe for concurrent reads/writes)</li>
 *   <li>CopyOnWriteArrayList for listener management (thread-safe iteration)</li>
 *   <li>All listener callbacks are posted to Main Thread (UI thread safety)</li>
 *   <li>No external synchronization needed - atomic operations provide visibility</li>
 * </ul>
 * 
 * <h3>Seek Stabilization</h3>
 * <p>When a seek operation is performed, AudioTrack.getPlaybackHeadPosition() may
 * return stale values for up to 300ms. During this stabilization window, the
 * controller reports the seek target position instead of the player's reported
 * position, preventing the seekbar from jumping back to the old position.</p>
 * 
 * <h3>Architecture</h3>
 * <p><b>MusicService WRITES state.</b> <b>MusicPlayer READS state.</b>
 * This class does NOT perform any playback actions. All actions go directly to
 * MusicService, which then updates this controller.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class PlaybackController {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "PlaybackController";
    
    /** 
     * Minimum time between UI position updates (milliseconds).
     * Throttling prevents UI flooding while maintaining smooth animation.
     * 150ms = ~6-7 updates per second, which is plenty smooth for a seek bar.
     */
    private static final int POSITION_UPDATE_INTERVAL_MS = 150;
    
    /** 
     * Duration to wait after a seek before accepting player position updates.
     * AudioTrack may return stale position values immediately after seek.
     * During this window, the seek target position is reported instead.
     */
    private static final int SEEK_STABILIZATION_MS = 300;
    
    // ========================================================================
    // Singleton Pattern (Thread-Safe Double-Checked Locking)
    // ========================================================================
    
    /** Singleton instance (volatile for visibility across threads). */
    private static volatile PlaybackController sInstance;
    
    /** Lock object for singleton initialization. */
    private static final Object sLock = new Object();
    
    /**
     * Returns the singleton instance of PlaybackController.
     * Thread-safe via double-checked locking.
     *
     * @return The singleton instance
     */
    @NonNull
    public static PlaybackController getInstance() {
        if (sInstance == null) {
            synchronized (sLock) {
                if (sInstance == null) {
                    sInstance = new PlaybackController();
                }
            }
        }
        return sInstance;
    }
    
    /**
     * Private constructor for singleton pattern.
     * Prevents instantiation from outside the class.
     */
    private PlaybackController() {
        // Private constructor for singleton
    }
    
    // ========================================================================
    // Atomic State Variables (Thread-Safe, Lock-Free)
    // ========================================================================
    
    /** 
     * Current playback position in milliseconds.
     * Updated by MusicService from LlamaPlayer's playback loop.
     * AtomicLong provides safe reads/writes across threads.
     */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** 
     * Duration of current song in milliseconds.
     * Set when song is prepared (from decoder or MediaPlayer).
     */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** 
     * Flag indicating if audio is currently playing.
     * True = actively playing, False = paused or stopped.
     */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if player is prepared (song loaded, ready to play).
     * True = a song is loaded and can be played immediately.
     */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /**
     * Flag indicating if user is actively dragging the seek bar.
     * When true, automatic position updates from the player are IGNORED.
     * This prevents the seek bar from jumping while the user is dragging.
     */
    private final AtomicBoolean mIsUserSeeking = new AtomicBoolean(false);
    
    /**
     * Timestamp of the last seek operation in milliseconds.
     * Used to determine if we're within the stabilization window.
     */
    private final AtomicLong mLastSeekTime = new AtomicLong(0);
    
    /**
     * Pending seek target position.
     * Reported during stabilization window instead of player-reported position.
     */
    private final AtomicLong mPendingSeekPosition = new AtomicLong(-1);
    
    // ========================================================================
    // Current Song Metadata (Volatile for Visibility)
    // ========================================================================
    
    /** Absolute file path of the currently playing song. */
    private volatile String mCurrentSongPath = null;
    
    /** Title of the currently playing song. */
    private volatile String mCurrentSongTitle = "";
    
    /** Artist of the currently playing song. */
    private volatile String mCurrentArtist = "";
    
    // ========================================================================
    // Listener Management (Thread-Safe)
    // ========================================================================
    
    /**
     * CopyOnWriteArrayList provides thread-safe iteration without locking.
     * Modifications create a new copy, so iterators never see concurrent modification.
     */
    private final CopyOnWriteArrayList<PlaybackControllerListener> mListeners = 
        new CopyOnWriteArrayList<>();
    
    /**
     * Handler for posting callbacks to UI thread.
     * All listener callbacks are posted here for thread safety.
     */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** Last time we sent a position update (for throttling). */
    private long mLastNotifyTime = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     */
    public interface PlaybackControllerListener {
        
        /**
         * Called when playback position changes (throttled to 150ms intervals).
         * Use this to update the seek bar and time display.
         * 
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when play/pause state changes.
         * Use this to update the play button icon.
         * 
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when a new song is loaded (complete metadata).
         * Use this to update the song title, artist, and total time.
         * 
         * @param title Song title
         * @param artist Artist name
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when prepared state changes (song loaded and ready to play).
         * Use this to enable play button and update duration display.
         * 
         * @param isPrepared True if a song is loaded and ready
         */
        void onPreparedStateChanged(boolean isPrepared);
    }
    
    // ========================================================================
    // Public API - Listener Management
    // ========================================================================
    
    /**
     * Registers a listener to receive playback state updates.
     * 
     * <p>The listener will immediately receive the current state for all
     * playback properties upon registration. All callbacks are delivered
     * on the main UI thread.</p>
     *
     * @param listener The listener to register
     */
    public void addListener(@NonNull PlaybackControllerListener listener) {
        if (!mListeners.contains(listener)) {
            mListeners.add(listener);
            
            // Immediately send current state to new listener (on UI thread)
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    // Check if listener was removed before the callback executed
                    if (!mListeners.contains(listener)) {
                        return;
                    }
                    listener.onPositionChanged(mCurrentPosition.get(), mDuration.get());
                    listener.onPlayStateChanged(mIsPlaying.get());
                    listener.onPreparedStateChanged(mIsPrepared.get());
                    if (mCurrentSongPath != null) {
                        listener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                            mCurrentSongPath, mDuration.get());
                    }
                }
            });
        }
    }
    
    /**
     * Unregisters a listener.
     * 
     * @param listener The listener to unregister
     */
    public void removeListener(@NonNull PlaybackControllerListener listener) {
        mListeners.remove(listener);
    }
    
    // ========================================================================
    // Private Notification Methods (All Callbacks on UI Thread)
    // ========================================================================
    
    /**
     * Notifies all listeners of position change.
     * Callback is posted to UI thread with throttling.
     *
     * @param positionMs Current position in milliseconds
     * @param durationMs Total duration in milliseconds
     */
    private void notifyPositionChanged(final long positionMs, final long durationMs) {
        if (mListeners.isEmpty()) return;
        
        mUiHandler.post(new Runnable() {
            @Override
            public void run() {
                for (PlaybackControllerListener listener : mListeners) {
                    try {
                        listener.onPositionChanged(positionMs, durationMs);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying listener of position change", e);
                    }
                }
            }
        });
    }
    
    /**
     * Notifies all listeners of play state change.
     * Callback is posted to UI thread.
     *
     * @param isPlaying True if playing, false if paused
     */
    private void notifyPlayStateChanged(final boolean isPlaying) {
        if (mListeners.isEmpty()) return;
        
        mUiHandler.post(new Runnable() {
            @Override
            public void run() {
                for (PlaybackControllerListener listener : mListeners) {
                    try {
                        listener.onPlayStateChanged(isPlaying);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying listener of play state change", e);
                    }
                }
            }
        });
    }
    
    /**
     * Notifies all listeners of prepared state change.
     * Callback is posted to UI thread.
     *
     * @param isPrepared True if player is prepared
     */
    private void notifyPreparedStateChanged(final boolean isPrepared) {
        if (mListeners.isEmpty()) return;
        
        mUiHandler.post(new Runnable() {
            @Override
            public void run() {
                for (PlaybackControllerListener listener : mListeners) {
                    try {
                        listener.onPreparedStateChanged(isPrepared);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying listener of prepared state change", e);
                    }
                }
            }
        });
    }
    
    /**
     * Notifies all listeners of song change.
     * Callback is posted to UI thread.
     *
     * @param title Song title
     * @param artist Artist name
     * @param path File path
     * @param duration Duration in milliseconds
     */
    private void notifySongChanged(final String title, final String artist, 
                                   final String path, final long duration) {
        if (mListeners.isEmpty()) return;
        
        mUiHandler.post(new Runnable() {
            @Override
            public void run() {
                for (PlaybackControllerListener listener : mListeners) {
                    try {
                        listener.onSongChanged(title, artist, path, duration);
                    } catch (Exception e) {
                        Log.e(TAG, "Error notifying listener of song change", e);
                    }
                }
            }
        });
    }
    
    // ========================================================================
    // WRITE Methods - Called ONLY by MusicService
    // ========================================================================
    
    /**
     * Updates the current playback position.
     * Called by MusicService from LlamaPlayer's playback loop.
     * 
     * <p><b>Important:</b> Updates are IGNORED if:
     * <ul>
     *   <li>User is actively dragging the seek bar (mIsUserSeeking = true)</li>
     *   <li>We're within the seek stabilization window (300ms after a seek)</li>
     *   <li>The new position jumps backward significantly (stale data from AudioTrack)</li>
     * </ul>
     * This prevents UI jitter during user interaction and ensures smooth seek behavior.</p>
     *
     * @param positionMs Current position in milliseconds
     */
    public void updatePosition(long positionMs) {
        // Don't update if user is dragging the seek bar
        if (mIsUserSeeking.get()) {
            Log.v(TAG, "updatePosition: ignoring during user seek");
            return;
        }
        
        // During seek stabilization window, report pending seek target instead
        long lastSeek = mLastSeekTime.get();
        if (lastSeek > 0 && System.currentTimeMillis() - lastSeek < SEEK_STABILIZATION_MS) {
            long pendingSeek = mPendingSeekPosition.get();
            if (pendingSeek >= 0) {
                long currentPos = mCurrentPosition.getAndSet(pendingSeek);
                if (currentPos != pendingSeek) {
                    notifyPositionChanged(pendingSeek, mDuration.get());
                }
                return;
            }
        }
        
        // Clear pending seek after stabilization window expires
        if (lastSeek > 0 && System.currentTimeMillis() - lastSeek >= SEEK_STABILIZATION_MS) {
            mLastSeekTime.set(0);
            mPendingSeekPosition.set(-1);
        }
        
        // Don't accept backward jumps (stale AudioTrack data after seek)
        long currentPos = mCurrentPosition.get();
        if (positionMs < currentPos - 500) {
            Log.v(TAG, "updatePosition: ignoring backward jump from " + currentPos + " to " + positionMs);
            return;
        }
        
        mCurrentPosition.set(positionMs);
        
        // Throttle UI updates to prevent flooding
        long now = System.currentTimeMillis();
        if (now - mLastNotifyTime >= POSITION_UPDATE_INTERVAL_MS) {
            mLastNotifyTime = now;
            notifyPositionChanged(positionMs, mDuration.get());
        }
    }
    
    /**
     * Called by MusicService when a seek operation is performed.
     * 
     * <p>This method updates the position immediately to the seek target and
     * starts the stabilization window. During this window, future position
     * updates from the player will be ignored in favor of the seek target.</p>
     *
     * @param seekPositionMs The target position in milliseconds
     */
    public void onSeekPerformed(long seekPositionMs) {
        Log.d(TAG, "onSeekPerformed: " + seekPositionMs + "ms");
        
        mCurrentPosition.set(seekPositionMs);
        mPendingSeekPosition.set(seekPositionMs);
        mLastSeekTime.set(System.currentTimeMillis());
        
        // Immediately update UI with seek target
        notifyPositionChanged(seekPositionMs, mDuration.get());
    }
    
    /**
     * Updates the play state.
     * Called by MusicService when play/pause occurs.
     *
     * @param isPlaying True if playing, false if paused
     */
    public void setPlaying(boolean isPlaying) {
        boolean oldState = mIsPlaying.getAndSet(isPlaying);
        if (oldState != isPlaying) {
            Log.d(TAG, "setPlaying: " + isPlaying);
            notifyPlayStateChanged(isPlaying);
        }
    }
    
    /**
     * Updates the prepared state.
     * Called when a song is fully loaded and ready to play.
     *
     * @param isPrepared True if a song is loaded and ready
     */
    public void setPrepared(boolean isPrepared) {
        boolean oldState = mIsPrepared.getAndSet(isPrepared);
        if (oldState != isPrepared) {
            Log.d(TAG, "setPrepared: " + isPrepared);
            notifyPreparedStateChanged(isPrepared);
        }
    }
    
    /**
     * Updates the duration (called when song is prepared).
     *
     * @param durationMs Duration in milliseconds
     */
    public void setDuration(long durationMs) {
        long oldDuration = mDuration.getAndSet(durationMs);
        if (oldDuration != durationMs) {
            Log.d(TAG, "setDuration: " + durationMs + "ms");
            notifyPositionChanged(mCurrentPosition.get(), durationMs);
        }
    }
    
    /**
     * Updates the current song information.
     * Called when a new song starts loading or playing.
     *
     * @param song The new song, or null to clear
     */
    public void updateSong(@Nullable Song song) {
        if (song == null) {
            clearSong();
            return;
        }
        
        String newPath = song.getPath();
        String newTitle = song.getTitle() != null ? song.getTitle() : "";
        String newArtist = song.getArtist() != null ? song.getArtist() : "";
        long newDuration = song.getDuration();
        
        // Update all metadata atomically (volatile writes provide visibility)
        mCurrentSongPath = newPath;
        mCurrentSongTitle = newTitle;
        mCurrentArtist = newArtist;
        mDuration.set(newDuration);
        mCurrentPosition.set(0);
        mLastSeekTime.set(0);
        mPendingSeekPosition.set(-1);
        
        Log.d(TAG, "updateSong: " + newTitle + " - " + newArtist);
        notifySongChanged(newTitle, newArtist, newPath, newDuration);
    }
    
    /**
     * Clears all song information (called when playlist is cleared).
     */
    private void clearSong() {
        mCurrentSongPath = null;
        mCurrentSongTitle = "";
        mCurrentArtist = "";
        mDuration.set(0);
        mCurrentPosition.set(0);
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mLastSeekTime.set(0);
        mPendingSeekPosition.set(-1);
        
        notifySongChanged("", "", "", 0);
        notifyPlayStateChanged(false);
        notifyPreparedStateChanged(false);
        notifyPositionChanged(0, 0);
    }
    
    // ========================================================================
    // UI Helper Methods - Called ONLY by MusicPlayer
    // ========================================================================
    
    /**
     * Called when user starts dragging the seek bar.
     * This pauses automatic position updates from the player.
     */
    public void onSeekStart() {
        Log.d(TAG, "onSeekStart - user started dragging");
        mIsUserSeeking.set(true);
    }
    
    /**
     * Called when user stops dragging the seek bar.
     * This resumes automatic position updates from the player.
     *
     * @param targetPositionMs The final position the user seeked to
     */
    public void onSeekStop(long targetPositionMs) {
        Log.d(TAG, "onSeekStop - user stopped dragging at " + targetPositionMs + "ms");
        mIsUserSeeking.set(false);
        mCurrentPosition.set(targetPositionMs);
        notifyPositionChanged(targetPositionMs, mDuration.get());
    }
    
    /**
     * Force resets the user seeking flag (safety timeout).
     * Called when seek operation times out to prevent stuck state.
     * This ensures the UI doesn't get stuck waiting for a seek
     * completion that never arrives.
     */
    public void forceResetSeeking() {
        if (mIsUserSeeking.getAndSet(false)) {
            Log.d(TAG, "forceResetSeeking - safety timeout triggered");
        }
    }
    
    // ========================================================================
    // READ Methods - Called by ANY component
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if not loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns true if audio is currently playing.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns true if a song is loaded and ready to play.
     *
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns true if user is currently dragging the seek bar.
     * Used by UI to determine if it should show the seek target.
     *
     * @return True if user is seeking
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking.get();
    }
    
    /**
     * Returns the current song's file path.
     *
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentSongPath() {
        return mCurrentSongPath;
    }
    
    /**
     * Returns the current song title.
     *
     * @return Song title, or empty string if none
     */
    @NonNull
    public String getCurrentSongTitle() {
        return mCurrentSongTitle;
    }
    
    /**
     * Returns the current artist name.
     *
     * @return Artist name, or empty string if none
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist;
    }
    
    // ========================================================================
    // Reset Method
    // ========================================================================
    
    /**
     * Resets all state (called when playlist changes or service stops).
     * This clears all playback information and notifies listeners.
     */
    public void reset() {
        Log.d(TAG, "reset - clearing all state");
        clearSong();
    }
}