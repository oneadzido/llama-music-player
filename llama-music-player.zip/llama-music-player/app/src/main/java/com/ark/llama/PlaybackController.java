package com.ark.llama;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackController - Central data holder for all playback state.
 * 
 * <p>This class holds playback state data. MusicService WRITES state.
 * MusicPlayer READS state and decides when to update UI.
 * This class does NOT make decisions about throttling or filtering.</p>
 * 
 * <h3>Architecture</h3>
 * <p><b>MusicService WRITES state.</b> <b>MusicPlayer READS state.</b>
 * This class is a passive data holder with callbacks. All UI decisions
 * (throttling, filtering, when to update) are made by MusicPlayer.</p>
 * 
 * <h3>Thread Safety Guarantees</h3>
 * <ul>
 *   <li>All state variables are atomic (lock-free): AtomicLong, AtomicBoolean</li>
 *   <li>Listener callbacks are posted to UI thread via Handler</li>
 *   <li>Read operations are lock-free and thread-safe due to atomic variables</li>
 * </ul>
 * 
 * @see MusicService
 * @see MusicPlayer
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class PlaybackController {
    
    private static final String TAG = "PlaybackController";
    
    // ========================================================================
    // Constants - Stale Data Detection Only
    // ========================================================================
    
    /**
     * Maximum acceptable backward jump in milliseconds.
     * Jumps larger than this are considered stale data and ignored.
     * This is the ONLY filtering done by PlaybackController.
     */
    private static final int MAX_BACKWARD_JUMP_MS = 500;
    
    // ========================================================================
    // Singleton Pattern
    // ========================================================================
    
    /** Singleton instance of PlaybackController. */
    private static PlaybackController sInstance;
    
    /**
     * Returns the singleton instance of PlaybackController.
     * Thread-safe via synchronized on class initialization.
     *
     * @return The singleton PlaybackController instance
     */
    @NonNull
    public static synchronized PlaybackController getInstance() {
        if (sInstance == null) {
            sInstance = new PlaybackController();
        }
        return sInstance;
    }
    
    /**
     * Private constructor for singleton pattern.
     * Prevents instantiation from outside the class.
     */
    private PlaybackController() {
        // Private constructor for singleton
    }
    
    // ========================================================================
    // Atomic State Variables (Thread-Safe, Lock-Free)
    // ========================================================================
    
    /** 
     * Current playback position in milliseconds.
     * Updated by MusicService from LlamaPlayer's playback loop or MediaPlayer polling.
     */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /**
     * Cached position before pause (for restoring on resume).
     * Set by MusicPlayer when pausing, used when resuming.
     */
    private long mPositionBeforePause = -1;
    
    /** 
     * Duration of current song in milliseconds.
     * Set when song is prepared (from decoder or MediaPlayer).
     */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** 
     * Flag indicating if audio is currently playing.
     * True = actively playing, False = paused or stopped.
     */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if player is prepared (song loaded, ready to play).
     * True = a song is loaded and can be played immediately.
     */
    private final AtomicBoolean mIsPrepared = new AtomicBoolean(false);
    
    /**
     * Flag indicating if user is actively dragging the seek bar.
     * Set by MusicPlayer when user starts/stops dragging.
     */
    private final AtomicBoolean mIsUserSeeking = new AtomicBoolean(false);
    
    // ========================================================================
    // Current Song Metadata
    // ========================================================================
    
    /** Absolute file path of the currently playing song. */
    private String mCurrentSongPath = null;
    
    /** Title of the currently playing song. */
    private String mCurrentSongTitle = "";
    
    /** Artist of the currently playing song. */
    private String mCurrentArtist = "";
    
    /** Album of the currently playing song. */
    private String mCurrentAlbum = "";
    
    // ========================================================================
    // UI Thread Components
    // ========================================================================
    
    /** Handler for posting callbacks to UI thread. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    /** 
     * Listener for state change callbacks.
     * MusicPlayer registers to receive updates.
     */
    @Nullable
    private PlaybackControllerListener mListener;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback state changes.
     * All callbacks are delivered on the main UI thread.
     * 
     * <p>MusicPlayer implements this interface to receive state updates.
     * MusicPlayer then decides what to do with them (throttling, filtering, etc.).</p>
     */
    public interface PlaybackControllerListener {
        
        /**
         * Called when playback position changes.
         * MusicPlayer decides whether to update UI based on this.
         * 
         * @param positionMs Current position in milliseconds
         * @param durationMs Total duration of current song in milliseconds
         */
        void onPositionChanged(long positionMs, long durationMs);
        
        /**
         * Called when play/pause state changes.
         * 
         * @param isPlaying True if playing, false if paused
         */
        void onPlayStateChanged(boolean isPlaying);
        
        /**
         * Called when a new song is loaded (complete metadata).
         * 
         * @param title Song title (never null, may be empty)
         * @param artist Artist name (never null, may be empty)
         * @param path File path (for album art loading)
         * @param duration Duration in milliseconds
         */
        void onSongChanged(@NonNull String title, @NonNull String artist, 
                          @NonNull String path, long duration);
        
        /**
         * Called when prepared state changes (song loaded and ready to play).
         * 
         * @param isPrepared True if a song is loaded and ready to play
         */
        void onPreparedStateChanged(boolean isPrepared);
        
        /**
         * Called when a playback operation fails.
         * 
         * @param operation The operation that failed (e.g., "play", "pause", "resume", "seek")
         * @param reason Human-readable reason for failure (can be null)
         */
        void onOperationFailed(@NonNull String operation, @Nullable String reason);
    }
    
    // ========================================================================
    // Public API - Listener Management
    // ========================================================================
    
    /**
     * Sets the listener for state change callbacks.
     * Only one listener can be active at a time (typically MusicPlayer).
     * 
     * <p>Setting a listener immediately sends the current state to the new listener.
     * This ensures the UI is synchronized from the moment of registration.</p>
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackControllerListener listener) {
        mListener = listener;
        if (listener != null) {
            // Immediately send current state to new listener
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(mCurrentPosition.get(), mDuration.get());
                    currentListener.onPlayStateChanged(mIsPlaying.get());
                    currentListener.onPreparedStateChanged(mIsPrepared.get());
                    if (mCurrentSongPath != null) {
                        currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                            mCurrentSongPath, mDuration.get());
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // WRITE Methods - Called by MusicService
    // ========================================================================
    
    /**
     * Updates the current playback position.
     * Called by MusicService from LlamaPlayer's playback loop or MediaPlayer polling.
     * 
     * <p><b>NO THROTTLING - NO DECISION MAKING.</b>
     * This method simply stores the value and notifies the listener.
     * MusicPlayer decides whether to throttle or filter updates.</p>
     * 
     * <p>The only filtering applied is ignoring stale backward jumps
     * (position suddenly dropping by more than 500ms).</p>
     * 
     * @param positionMs Current position in milliseconds
     * @param source Caller identifier for debugging
     */
    public void updatePosition(long positionMs, @NonNull String source) {
        // Don't update if user is dragging the seek bar
        if (mIsUserSeeking.get()) {
            // Still store the position, just don't send to listener
            mCurrentPosition.set(positionMs);
            Log.v(TAG, "updatePosition from " + source + " stored during seek: " + positionMs);
            return;
        }
        
        // Filter out stale backward jumps (AudioTrack reporting old position)
        long currentPos = mCurrentPosition.get();
        if (positionMs < currentPos - MAX_BACKWARD_JUMP_MS && currentPos > 1000) {
            Log.d(TAG, "updatePosition: ignoring stale backward jump from " + currentPos + 
                  " to " + positionMs + " from " + source);
            return;
        }
        
        // Store the value
        mCurrentPosition.set(positionMs);
        
        // Always notify listener - MusicPlayer decides what to do
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(positionMs, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Convenience overload for updatePosition with default source "unspecified".
     * 
     * @param positionMs Current position in milliseconds
     */
    public void updatePosition(long positionMs) {
        updatePosition(positionMs, "unspecified");
    }
    
    /**
     * Updates the play state.
     * Called by MusicService when playback starts or stops.
     * 
     * @param isPlaying True if playing, false if paused
     * @param source Caller identifier for debugging
     */
    public void setPlaying(boolean isPlaying, @NonNull String source) {
        boolean oldState = mIsPlaying.getAndSet(isPlaying);
        if (oldState != isPlaying) {
            Log.d(TAG, "setPlaying: " + isPlaying + " from " + source);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPlayStateChanged(isPlaying);
                    }
                });
            }
        }
    }
    
    /**
     * Convenience overload for setPlaying with default source "unspecified".
     *
     * @param isPlaying True if playing, false if paused
     */
    public void setPlaying(boolean isPlaying) {
        setPlaying(isPlaying, "unspecified");
    }
    
    /**
     * Updates the prepared state.
     * Called when a song is fully loaded and ready to play.
     * 
     * @param isPrepared True if a song is loaded and ready
     * @param source Caller identifier for debugging
     */
    public void setPrepared(boolean isPrepared, @NonNull String source) {
        boolean oldState = mIsPrepared.getAndSet(isPrepared);
        if (oldState != isPrepared) {
            Log.d(TAG, "setPrepared: " + isPrepared + " from " + source);
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onPreparedStateChanged(isPrepared);
                    }
                });
            }
        }
    }
    
    /**
     * Convenience overload for setPrepared with default source "unspecified".
     * 
     * @param isPrepared True if a song is loaded and ready
     */
    public void setPrepared(boolean isPrepared) {
        setPrepared(isPrepared, "unspecified");
    }
    
    /**
     * Updates the duration (called when song is prepared).
     * 
     * @param durationMs Duration in milliseconds
     * @param source Caller identifier for debugging
     */
    public void setDuration(long durationMs, @NonNull String source) {
        long oldDuration = mDuration.getAndSet(durationMs);
        if (oldDuration != durationMs) {
            Log.d(TAG, "setDuration: " + durationMs + "ms from " + source);
            // Don't auto-notify - position update will carry the new duration
        }
    }
    
    /**
     * Convenience overload for setDuration with default source "unspecified".
     * 
     * @param durationMs Duration in milliseconds
     */
    public void setDuration(long durationMs) {
        setDuration(durationMs, "unspecified");
    }
    
    /**
     * Updates the current song information.
     * Called when a new song starts loading or playing.
     * 
     * @param song The new song, or null to clear
     * @param source Caller identifier for debugging
     */
    public void updateSong(@Nullable Song song, @NonNull String source) {
        if (song == null) {
            mCurrentSongPath = null;
            mCurrentSongTitle = "";
            mCurrentArtist = "";
            mCurrentAlbum = "";
            mDuration.set(0);
            mCurrentPosition.set(0);
            mPositionBeforePause = -1;
            Log.d(TAG, "updateSong: cleared from " + source);
            
            if (mListener != null) {
                mUiHandler.post(() -> {
                    PlaybackControllerListener currentListener = mListener;
                    if (currentListener != null) {
                        currentListener.onSongChanged("", "", "", 0);
                    }
                });
            }
            return;
        }
        
        String newPath = song.getPath();
        String newTitle = song.getTitle() != null ? song.getTitle() : "";
        String newArtist = song.getArtist() != null ? song.getArtist() : "";
        String newAlbum = song.getAlbum() != null ? song.getAlbum() : "";
        long newDuration = song.getDuration();
        
        mCurrentSongPath = newPath;
        mCurrentSongTitle = newTitle;
        mCurrentArtist = newArtist;
        mCurrentAlbum = newAlbum;
        mDuration.set(newDuration);
        mCurrentPosition.set(0);
        mPositionBeforePause = -1;
        
        Log.d(TAG, "updateSong: " + newTitle + " - " + newArtist + " from " + source);
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onSongChanged(mCurrentSongTitle, mCurrentArtist, 
                        mCurrentSongPath, mDuration.get());
                }
            });
        }
    }
    
    /**
     * Convenience overload for updateSong with default source "unspecified".
     * 
     * @param song The new song, or null to clear
     */
    public void updateSong(@Nullable Song song) {
        updateSong(song, "unspecified");
    }
    
    /**
     * Notifies listeners that a playback operation failed.
     * Called by MusicService when operations like play, pause, or resume fail.
     * 
     * @param operation The operation that failed (e.g., "play", "pause", "resume", "seek")
     * @param reason Human-readable reason for failure (can be null)
     */
    public void notifyOperationFailed(@NonNull String operation, @Nullable String reason) {
        Log.w(TAG, "Operation failed: " + operation + " - " + reason);
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onOperationFailed(operation, reason);
                }
            });
        }
    }
    
    // ========================================================================
    // UI Helper Methods - Called by MusicPlayer
    // ========================================================================
    
    /**
     * Called when user starts dragging the seek bar.
     * This tells PlaybackController to ignore automatic position updates
     * while the user is dragging.
     */
    public void onSeekStart() {
        Log.d(TAG, "onSeekStart - user started dragging");
        mIsUserSeeking.set(true);
    }
    
    /**
     * Called when user stops dragging the seek bar.
     * This resumes automatic position updates.
     */
    public void onSeekStop() {
        Log.d(TAG, "onSeekStop - user stopped dragging");
        mIsUserSeeking.set(false);
    }
    
    /**
     * Force resets the user seeking flag (safety timeout).
     * Called by MusicPlayer when seek operation times out.
     */
    public void forceResetSeeking() {
        Log.d(TAG, "forceResetSeeking - safety timeout");
        mIsUserSeeking.set(false);
    }
    
    /**
     * Called when the player is about to pause.
     * Do NOT cache position on pause - this causes seek bar to reset.
     * The current position is already stored in mCurrentPosition.
     */
    public void onPause() {
        // Do NOT cache position on pause - this causes seek bar to jump to beginning
        // The current position is already stored in mCurrentPosition
        Log.d(TAG, "onPause called - position preserved: " + getCurrentPosition());
    }
    
    /**
     * Called when the player resumes after being paused.
     * No position restoration needed - mCurrentPosition already has correct value.
     */
    public void onResume() {
        // No position restoration needed - mCurrentPosition already has correct value
        Log.d(TAG, "onResume called - current position: " + getCurrentPosition());
    }
    
    // ========================================================================
    // READ Methods - Called by ANY component (especially MusicPlayer)
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * Thread-safe: uses AtomicLong.get() without locks.
     * 
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     * Thread-safe: uses AtomicLong.get() without locks.
     * 
     * @return Duration in milliseconds, or 0 if not loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns true if audio is currently playing.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get();
    }
    
    /**
     * Returns true if a song is loaded and ready to play.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if prepared
     */
    public boolean isPrepared() {
        return mIsPrepared.get();
    }
    
    /**
     * Returns true if user is currently dragging the seek bar.
     * Thread-safe: uses AtomicBoolean.get() without locks.
     * 
     * @return True if user is seeking
     */
    public boolean isUserSeeking() {
        return mIsUserSeeking.get();
    }
    
    /**
     * Returns the current song's file path.
     * 
     * @return File path, or null if no song loaded
     */
    @Nullable
    public String getCurrentSongPath() {
        return mCurrentSongPath;
    }
    
    /**
     * Returns the current song title.
     * 
     * @return Song title, or empty string if none
     */
    @NonNull
    public String getCurrentSongTitle() {
        return mCurrentSongTitle;
    }
    
    /**
     * Returns the current artist name.
     * 
     * @return Artist name, or empty string if none
     */
    @NonNull
    public String getCurrentArtist() {
        return mCurrentArtist;
    }
    
    /**
     * Returns the current album name.
     * 
     * @return Album name, or empty string if none
     */
    @NonNull
    public String getCurrentAlbum() {
        return mCurrentAlbum;
    }
    
    // ========================================================================
    // Reset Method
    // ========================================================================
    
    /**
     * Resets all state (called when playlist changes or service stops).
     * This clears all playback information and notifies listeners.
     */
    public void reset() {
        Log.d(TAG, "reset - clearing all state");
        
        mCurrentPosition.set(0);
        mDuration.set(0);
        mIsPlaying.set(false);
        mIsPrepared.set(false);
        mIsUserSeeking.set(false);
        mCurrentSongPath = null;
        mCurrentSongTitle = "";
        mCurrentArtist = "";
        mCurrentAlbum = "";
        mPositionBeforePause = -1;
        
        if (mListener != null) {
            mUiHandler.post(() -> {
                PlaybackControllerListener currentListener = mListener;
                if (currentListener != null) {
                    currentListener.onPositionChanged(0, 0);
                    currentListener.onPlayStateChanged(false);
                    currentListener.onPreparedStateChanged(false);
                }
            });
        }
    }
}