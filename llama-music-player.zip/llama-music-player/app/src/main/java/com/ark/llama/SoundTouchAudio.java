package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.AudioFormat;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * Media3 {@link AudioProcessor} that integrates the native SoundTouch library for
 * independent pitch and tempo shifting.
 *
 * <p>This processor is designed to be used with ExoPlayer (Media3) and provides
 * real‑time audio effects without interrupting playback. It supports 16‑bit PCM
 * audio with 1 (mono) or 2 (stereo) channels at any sample rate.</p>
 *
 * <h3>Effect Ranges</h3>
 * <ul>
 *   <li><b>Tempo (speed)</b>: 0.5x … 1.5x – values outside are clamped</li>
 *   <li><b>Pitch (semitone shift)</b>: -6 … +6 semitones – clamped</li>
 * </ul>
 *
 * <h3>Usage with ExoPlayer</h3>
 * <pre>{@code
 * SoundTouchAudio processor = new SoundTouchAudio();
 * ExoPlayer player = new ExoPlayer.Builder(context)
 *         .setAudioProcessors(new AudioProcessor[]{processor})
 *         .build();
 * // Later, during playback:
 * processor.setParameters(1.25f, 2.0f); // 25% faster, +2 semitones
 * }</pre>
 *
 * <h3>Thread Safety</h3>
 * All public methods are safe to call from any thread – the processor is
 * used exclusively on ExoPlayer's internal audio thread.
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 * @see AudioProcessor
 * @see PitchShifter
 */
public final class SoundTouchAudio implements AudioProcessor {

    // ========================================================================
    // Constants
    // ========================================================================
    private static final String TAG = "SoundTouchAudio";
    private static final float MIN_TEMPO = 0.5f;
    private static final float MAX_TEMPO = 1.5f;
    private static final float MIN_PITCH = -6.0f;
    private static final float MAX_PITCH = 6.0f;
    private static final float CLOSE_THRESHOLD = 0.0001f;
    private static final int MAX_FRAMES_PER_BATCH = 4096;
    private static final int DEFAULT_FRAMES_PER_BUFFER = 1024;
    private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocateDirect(0).asReadOnlyBuffer();

    // ========================================================================
    // Native SoundTouch processor
    // ========================================================================
    @Nullable private PitchShifter mPitchShifter;
    private int mSampleRate = 44100;
    private int mChannels = 2;
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;
    private boolean mIsSoundTouchInitialized = false;
    private int mBufferFrames = DEFAULT_FRAMES_PER_BUFFER;

    // ========================================================================
    // Media3 AudioProcessor state
    // ========================================================================
    private int mInputSampleRate;
    private int mInputChannelCount;
    private int mInputEncoding;
    private int mOutputSampleRate;
    private int mOutputChannelCount;
    private int mOutputEncoding;
    private ByteBuffer mBuffer = EMPTY_BUFFER;          // working buffer
    private ShortBuffer mShortBuffer = mBuffer.asShortBuffer();
    private ByteBuffer mOutputBuffer = EMPTY_BUFFER;    // output to ExoPlayer
    private boolean mInputEnded;
    private boolean mPendingReconfigure;

    // ========================================================================
    // Constructor
    // ========================================================================
    public SoundTouchAudio() {
        Log.d(TAG, "SoundTouchAudio processor created");
    }

    // ========================================================================
    // Public effect control API
    // ========================================================================

    /**
     * Adjusts the playback speed without affecting pitch.
     *
     * @param tempo speed multiplier (0.5 … 1.5). Values outside the range are clamped.
     */
    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        if (Math.abs(mCurrentTempo - clamped) > CLOSE_THRESHOLD) {
            mCurrentTempo = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clamped);
            }
        }
    }

    /**
     * Adjusts the pitch (musical key) without affecting speed.
     *
     * @param semitones pitch shift in semitones (-6 … +6). Values outside are clamped.
     */
    public void setPitchSemitones(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        if (Math.abs(mCurrentPitch - clamped) > CLOSE_THRESHOLD) {
            mCurrentPitch = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clamped);
            }
        }
    }

    /**
     * Atomically sets both tempo and pitch. More efficient than calling individual setters.
     *
     * @param tempo         speed multiplier (clamped to 0.5…1.5)
     * @param pitchSemitones pitch shift in semitones (clamped to -6…+6)
     */
    public void setParameters(float tempo, float pitchSemitones) {
        float clampedTempo = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        float clampedPitch = Math.max(MIN_PITCH, Math.min(MAX_PITCH, pitchSemitones));
        boolean tempoChanged = Math.abs(mCurrentTempo - clampedTempo) > CLOSE_THRESHOLD;
        boolean pitchChanged = Math.abs(mCurrentPitch - clampedPitch) > CLOSE_THRESHOLD;
        if (tempoChanged) {
            mCurrentTempo = clampedTempo;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clampedTempo);
            }
        }
        if (pitchChanged) {
            mCurrentPitch = clampedPitch;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clampedPitch);
            }
        }
    }

    /**
     * Returns the current tempo multiplier.
     *
     * @return current tempo (1.0 = normal speed)
     */
    public float getCurrentTempo() {
        return mCurrentTempo;
    }

    /**
     * Returns the current pitch shift in semitones.
     *
     * @return current pitch shift (0 = normal pitch)
     */
    public float getCurrentPitch() {
        return mCurrentPitch;
    }

    /**
     * Checks whether any effect (tempo ≠ 1.0 or pitch ≠ 0) is active.
     * When false, the processor operates in passthrough mode with zero overhead.
     *
     * @return true if an effect is applied
     */
    public boolean isEffectActive() {
        return Math.abs(mCurrentTempo - 1.0f) > CLOSE_THRESHOLD ||
               Math.abs(mCurrentPitch) > CLOSE_THRESHOLD;
    }

    // ========================================================================
    // Internal native SoundTouch management
    // ========================================================================

    private boolean configureSoundTouch(int sampleRate, int channels) {
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "PitchShifter library not available");
            return false;
        }
        if (sampleRate <= 0 || (channels != 1 && channels != 2)) {
            Log.e(TAG, "Invalid sampleRate/channels: " + sampleRate + "/" + channels);
            return false;
        }
        try {
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            mPitchShifter = new PitchShifter(sampleRate, channels);
            mSampleRate = sampleRate;
            mChannels = channels;
            // Target ~20ms of audio per buffer (reduces latency)
            mBufferFrames = (sampleRate * 20 / 1000) * channels;
            mBufferFrames = Math.max(DEFAULT_FRAMES_PER_BUFFER,
                    Math.min(MAX_FRAMES_PER_BATCH, mBufferFrames));
            if (mCurrentPitch != 0f) {
                mPitchShifter.setPitch(mCurrentPitch);
            }
            if (mCurrentTempo != 1.0f) {
                mPitchShifter.setTempo(mCurrentTempo);
            }
            mIsSoundTouchInitialized = true;
            Log.d(TAG, "SoundTouch configured: " + sampleRate + "Hz, " + channels + "ch");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure SoundTouch", e);
            mIsSoundTouchInitialized = false;
            return false;
        }
    }

    @NonNull
    private short[] processSoundTouch(@NonNull short[] input, int frames) {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) return input;
        if (frames <= 0 || input.length < frames * mChannels) return new short[0];
        try {
            mPitchShifter.putFrames(input, frames);
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) return new short[0];
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
            return new short[0];
        } catch (Exception e) {
            Log.e(TAG, "Process error", e);
            return input;
        }
    }

    @Nullable
    private short[] tryReceiveOnce() {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) return null;
        try {
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) return null;
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
        } catch (Exception e) {
            Log.w(TAG, "tryReceiveOnce error", e);
        }
        return null;
    }

    private int numAvailableFrames() {
        return (mIsSoundTouchInitialized && mPitchShifter != null) ? mPitchShifter.numFrames() : 0;
    }

    private void flushSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.flush();
        }
    }

    private void clearSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
        }
    }

    private void releaseSoundTouch() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        mIsSoundTouchInitialized = false;
    }

    // ========================================================================
    // Media3 AudioProcessor implementation
    // ========================================================================

    /**
     * Called by Media3 to configure the processor with the input audio format.
     * This processor only accepts 16‑bit PCM audio.
     *
     * @param inputFormat the format of incoming audio
     * @return the output format (same as input, passthrough)
     * @throws UnhandledAudioFormatException if the format is not 16‑bit PCM
     */
    @NonNull
    @Override
    public AudioFormat onConfigure(@NonNull AudioFormat inputFormat)
            throws UnhandledAudioFormatException {
        if (inputFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw new UnhandledAudioFormatException(inputFormat);
        }
        mInputSampleRate = inputFormat.sampleRate;
        mInputChannelCount = inputFormat.channelCount;
        mInputEncoding = inputFormat.encoding;
        mOutputSampleRate = mInputSampleRate;
        mOutputChannelCount = mInputChannelCount;
        mOutputEncoding = C.ENCODING_PCM_16BIT;
        mPendingReconfigure = true;
        Log.d(TAG, "onConfigure: " + mInputSampleRate + "Hz, " + mInputChannelCount + "ch");
        return new AudioFormat.Builder()
                .setSampleRate(mOutputSampleRate)
                .setChannelCount(mOutputChannelCount)
                .setEncoding(mOutputEncoding)
                .build();
    }

    /**
     * Returns whether the processor should be active. Media3 may bypass it entirely
     * when this returns {@code false}, reducing overhead.
     *
     * @return true if tempo ≠ 1.0 or pitch ≠ 0
     */
    @Override
    public boolean isActive() {
        return isEffectActive();
    }

    /**
     * Queues a buffer of 16‑bit PCM audio for processing.
     * If no effect is active, the buffer is passed through unchanged.
     *
     * @param inputBuffer the input buffer (direct ByteBuffer containing PCM data)
     */
    @Override
    public void queueInput(@NonNull ByteBuffer inputBuffer) {
        if (!inputBuffer.hasRemaining()) return;
        if (mPendingReconfigure) {
            mIsSoundTouchInitialized = configureSoundTouch(mInputSampleRate, mInputChannelCount);
            mPendingReconfigure = false;
        }

        // Passthrough when no effect is active or SoundTouch unavailable
        if (!isActive() || !mIsSoundTouchInitialized || mPitchShifter == null) {
            int bytesToCopy = inputBuffer.remaining();
            if (mOutputBuffer.capacity() < bytesToCopy) {
                mOutputBuffer = ByteBuffer.allocateDirect(bytesToCopy).order(ByteOrder.nativeOrder());
            } else {
                mOutputBuffer.clear();
            }
            mOutputBuffer.put(inputBuffer);
            mOutputBuffer.flip();
            inputBuffer.position(inputBuffer.position() + bytesToCopy);
            return;
        }

        // Active processing via SoundTouch
        ShortBuffer shortBuffer = inputBuffer.asShortBuffer();
        int sampleCount = shortBuffer.remaining();
        short[] pcmData = new short[sampleCount];
        shortBuffer.get(pcmData);
        int frames = sampleCount / mInputChannelCount;
        if (frames > 0) {
            short[] processed = processSoundTouch(pcmData, frames);
            if (processed != null && processed.length > 0) {
                int requiredBytes = processed.length * 2;
                if (mBuffer.capacity() < requiredBytes) {
                    mBuffer = ByteBuffer.allocateDirect(requiredBytes).order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                mShortBuffer.put(processed);
                mBuffer.limit(processed.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
        inputBuffer.position(inputBuffer.position() + inputBuffer.remaining());
    }

    /**
     * Signals that no more input will be queued. Flushes any remaining audio
     * from the SoundTouch pipeline.
     */
    @Override
    public void queueEndOfStream() {
        mInputEnded = true;
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            flushSoundTouch();
            short[] remaining = tryReceiveOnce();
            if (remaining != null && remaining.length > 0) {
                if (mBuffer.capacity() < remaining.length * 2) {
                    mBuffer = ByteBuffer.allocateDirect(remaining.length * 2).order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                mShortBuffer.put(remaining);
                mBuffer.limit(remaining.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
    }

    /**
     * Returns the output buffer containing processed audio.
     *
     * @return a read‑only ByteBuffer with 16‑bit PCM data
     */
    @NonNull
    @Override
    public ByteBuffer getOutput() {
        ByteBuffer result = mOutputBuffer;
        mOutputBuffer = EMPTY_BUFFER;
        return result;
    }

    /**
     * Returns {@code true} when all input has been queued and all output has been consumed.
     *
     * @return true if end of stream is reached
     */
    @Override
    public boolean isEnded() {
        return mInputEnded && (!mIsSoundTouchInitialized || numAvailableFrames() == 0);
    }

    /**
     * Discards any pending data and resets the processor to a fresh state.
     * Effect parameters (tempo, pitch) are preserved.
     */
    @Override
    public void flush() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            flushSoundTouch();
            clearSoundTouch();
        }
        mOutputBuffer = EMPTY_BUFFER;
        mInputEnded = false;
        mPendingReconfigure = true;
    }

    /**
     * Fully resets the processor: releases native resources and resets
     * effect parameters to neutral values (tempo = 1.0, pitch = 0).
     */
    @Override
    public void reset() {
        flush();
        mCurrentTempo = 1.0f;
        mCurrentPitch = 0f;
        releaseSoundTouch();
        mBuffer = EMPTY_BUFFER;
        mShortBuffer = mBuffer.asShortBuffer();
        mOutputBuffer = EMPTY_BUFFER;
        mPendingReconfigure = true;
        Log.d(TAG, "SoundTouchAudio reset");
    }
}