package com.ark.llama;

import android.media.AudioFormat;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.util.UnhandledAudioFormatException;
import androidx.media3.exoplayer.audio.AudioProcessor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * SoundTouchAudio - ExoPlayer AudioProcessor for pitch and tempo shifting.
 * 
 * <p>This class provides a complete audio processing solution that integrates
 * SoundTouch native library with ExoPlayer's audio pipeline. It handles both
 * the low-level PCM processing and the ExoPlayer AudioProcessor interface.</p>
 * 
 * <h3>Features</h3>
 * <ul>
 *   <li><b>Independent Pitch Control</b> - Adjust pitch from -6 to +6 semitones</li>
 *   <li><b>Independent Tempo Control</b> - Adjust speed from 0.5x to 1.5x</li>
 *   <li><b>Real-time Updates</b> - Change effects during playback</li>
 *   <li><b>Zero-copy Processing</b> - Efficient buffer management</li>
 *   <li><b>Thread-safe</b> - Safe for concurrent access</li>
 * </ul>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * ExoPlayer PCM -> SoundTouchAudio.queueInput() -> PitchShifter (Native)
 *              -> SoundTouchAudio.getOutput() -> ExoPlayer AudioTrack
 * </pre>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Create processor
 * SoundTouchAudio processor = new SoundTouchAudio();
 * 
 * // Configure (called by ExoPlayer automatically)
 * processor.configure(inputFormat);
 * 
 * // Apply effects
 * processor.setTempo(1.25f);           // 25% faster
 * processor.setPitchSemitones(2.5f);   // Raise by 2.5 semitones
 * </pre>
 * 
 * @see AudioProcessor
 * @see PitchShifter
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchAudio implements AudioProcessor {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchAudio";
    
    /** Minimum tempo (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch in semitones. */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch in semitones. */
    private static final float MAX_PITCH = 6.0f;
    
    /** Comparison threshold for floating point values. */
    private static final float CLOSE_THRESHOLD = 0.0001f;
    
    /** Maximum frames to process in one batch. */
    private static final int MAX_FRAMES_PER_BATCH = 4096;
    
    /** Default frames per buffer for processing. */
    private static final int DEFAULT_FRAMES_PER_BUFFER = 1024;
    
    // ========================================================================
    // SoundTouch Native Processor
    // ========================================================================
    
    /** Native SoundTouch processor instance. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Sample rate in Hz (e.g., 44100). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Current pitch in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Flag indicating if SoundTouch is initialized. */
    private boolean mIsSoundTouchInitialized = false;
    
    /** Buffer size in frames. */
    private int mBufferFrames = DEFAULT_FRAMES_PER_BUFFER;
    
    // ========================================================================
    // ExoPlayer AudioProcessor State
    // ========================================================================
    
    /** Input sample rate from ExoPlayer. */
    private int mInputSampleRate;
    
    /** Input channel count from ExoPlayer. */
    private int mInputChannelCount;
    
    /** Input audio encoding. */
    private int mInputEncoding;
    
    /** Output sample rate. */
    private int mOutputSampleRate;
    
    /** Output channel count. */
    private int mOutputChannelCount;
    
    /** Output audio encoding. */
    private int mOutputEncoding;
    
    /** Working buffer for audio data. */
    private ByteBuffer mBuffer;
    
    /** Short buffer view of mBuffer. */
    private ShortBuffer mShortBuffer;
    
    /** Output buffer for processed audio. */
    private ByteBuffer mOutputBuffer;
    
    /** Flag indicating end of stream has been queued. */
    private boolean mInputEnded;
    
    /** Flag indicating processor needs reconfiguration. */
    private boolean mPendingReconfigure;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchAudio processor.
     */
    public SoundTouchAudio() {
        mBuffer = EMPTY_BUFFER;
        mShortBuffer = mBuffer.asShortBuffer();
        mOutputBuffer = EMPTY_BUFFER;
        Log.d(TAG, "SoundTouchAudio processor created");
    }
    
    // ========================================================================
    // Public API - Parameter Control
    // ========================================================================
    
    /**
     * Sets the playback speed (tempo) multiplier.
     * 
     * <p>Range: 0.5 to 1.5</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower)</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     * 
     * @param tempo Speed multiplier
     */
    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        if (Math.abs(mCurrentTempo - clamped) > CLOSE_THRESHOLD) {
            mCurrentTempo = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clamped);
                Log.v(TAG, "Tempo set to: " + clamped + "x");
            }
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Range: -6.0 to +6.0 semitones</p>
     * 
     * @param semitones Pitch shift in semitones
     */
    public void setPitchSemitones(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        if (Math.abs(mCurrentPitch - clamped) > CLOSE_THRESHOLD) {
            mCurrentPitch = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clamped);
                Log.v(TAG, "Pitch set to: " + clamped + " semitones");
            }
        }
    }
    
    /**
     * Sets both pitch and tempo parameters at once.
     * 
     * @param tempo Speed multiplier (0.5 to 1.5)
     * @param pitchSemitones Pitch shift in semitones (-6 to +6)
     */
    public void setParameters(float tempo, float pitchSemitones) {
        float clampedTempo = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        float clampedPitch = Math.max(MIN_PITCH, Math.min(MAX_PITCH, pitchSemitones));
        
        boolean tempoChanged = Math.abs(mCurrentTempo - clampedTempo) > CLOSE_THRESHOLD;
        boolean pitchChanged = Math.abs(mCurrentPitch - clampedPitch) > CLOSE_THRESHOLD;
        
        if (tempoChanged) {
            mCurrentTempo = clampedTempo;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clampedTempo);
            }
        }
        
        if (pitchChanged) {
            mCurrentPitch = clampedPitch;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clampedPitch);
            }
        }
        
        if (tempoChanged || pitchChanged) {
            Log.v(TAG, "Parameters updated: tempo=" + clampedTempo + "x, pitch=" + clampedPitch + "st");
        }
    }
    
    /**
     * Returns the current tempo multiplier.
     * 
     * @return Current tempo (1.0 = normal)
     */
    public float getCurrentTempo() {
        return mCurrentTempo;
    }
    
    /**
     * Returns the current pitch shift in semitones.
     * 
     * @return Current pitch shift (0 = normal)
     */
    public float getCurrentPitch() {
        return mCurrentPitch;
    }
    
    /**
     * Returns true if effects are active (pitch or tempo changed).
     * 
     * @return true if effects are active
     */
    public boolean isEffectActive() {
        return Math.abs(mCurrentTempo - 1.0f) > CLOSE_THRESHOLD || 
               Math.abs(mCurrentPitch) > CLOSE_THRESHOLD;
    }
    
    /**
     * Returns true if the SoundTouch processor is initialized.
     * 
     * @return true if initialized
     */
    public boolean isSoundTouchInitialized() {
        return mIsSoundTouchInitialized && mPitchShifter != null;
    }
    
    // ========================================================================
    // Internal SoundTouch Methods
    // ========================================================================
    
    /**
     * Configures the SoundTouch processor with sample rate and channel count.
     * 
     * @param sampleRate Sample rate in Hz
     * @param channels Number of channels (1 or 2)
     * @return true if configuration was successful
     */
    private boolean configureSoundTouch(int sampleRate, int channels) {
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "PitchShifter library not available");
            return false;
        }
        
        if (sampleRate <= 0) {
            Log.e(TAG, "Invalid sample rate: " + sampleRate);
            return false;
        }
        
        if (channels != 1 && channels != 2) {
            Log.e(TAG, "Invalid channel count: " + channels);
            return false;
        }
        
        try {
            // Release previous instance if exists
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            // Create new SoundTouch instance
            mPitchShifter = new PitchShifter(sampleRate, channels);
            mSampleRate = sampleRate;
            mChannels = channels;
            
            // Calculate optimal buffer size (aim for ~20ms of audio)
            mBufferFrames = (sampleRate * 20 / 1000) * channels;
            mBufferFrames = Math.max(DEFAULT_FRAMES_PER_BUFFER, 
                Math.min(MAX_FRAMES_PER_BATCH, mBufferFrames));
            
            // Apply current settings
            if (mCurrentPitch != 0f) {
                mPitchShifter.setPitch(mCurrentPitch);
            }
            if (mCurrentTempo != 1.0f) {
                mPitchShifter.setTempo(mCurrentTempo);
            }
            
            mIsSoundTouchInitialized = true;
            
            Log.d(TAG, "SoundTouch configured: " + sampleRate + "Hz, " + channels + "ch, " +
                  "buffer=" + mBufferFrames + " frames");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure SoundTouch", e);
            mIsSoundTouchInitialized = false;
            return false;
        }
    }
    
    /**
     * Processes audio frames through SoundTouch.
     * 
     * @param input Array of 16-bit PCM samples (interleaved for stereo)
     * @param frames Number of frames (each frame = channels samples)
     * @return Processed audio output
     */
    @NonNull
    private short[] processSoundTouch(@NonNull short[] input, int frames) {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return input;
        }
        
        if (frames <= 0 || input.length < frames * mChannels) {
            return new short[0];
        }
        
        try {
            // Feed input to SoundTouch
            mPitchShifter.putFrames(input, frames);
            
            // Check how many frames are available for output
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return new short[0];
            }
            
            // Receive processed frames
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
            
            return new short[0];
            
        } catch (Exception e) {
            Log.e(TAG, "Process error", e);
            return input;
        }
    }
    
    /**
     * Non-blocking receive from SoundTouch.
     * 
     * @return Processed audio buffer, or null if none available
     */
    @Nullable
    private short[] tryReceiveOnce() {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return null;
        }
        
        try {
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return null;
            }
            
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
        } catch (Exception e) {
            Log.w(TAG, "tryReceiveOnce error", e);
        }
        
        return null;
    }
    
    /**
     * Returns the number of available frames in the SoundTouch output buffer.
     */
    private int numAvailableFrames() {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return 0;
        }
        return mPitchShifter.numFrames();
    }
    
    /**
     * Flushes any remaining audio from SoundTouch.
     */
    private void flushSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.flush();
            Log.v(TAG, "SoundTouch flushed");
        }
    }
    
    /**
     * Clears all SoundTouch internal buffers.
     */
    private void clearSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
            Log.v(TAG, "SoundTouch cleared");
        }
    }
    
    /**
     * Releases SoundTouch native resources.
     */
    private void releaseSoundTouch() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        mIsSoundTouchInitialized = false;
        Log.d(TAG, "SoundTouch released");
    }
    
    // ========================================================================
    // ExoPlayer AudioProcessor Implementation
    // ========================================================================
    
    @NonNull
    @Override
    public AudioFormat configure(@NonNull AudioFormat inputFormat)
            throws UnhandledAudioFormatException {
        
        // Only support 16-bit PCM
        if (inputFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw new UnhandledAudioFormatException(inputFormat);
        }
        
        mInputSampleRate = inputFormat.sampleRate;
        mInputChannelCount = inputFormat.channelCount;
        mInputEncoding = inputFormat.encoding;
        
        // Output same format as input
        mOutputSampleRate = mInputSampleRate;
        mOutputChannelCount = mInputChannelCount;
        mOutputEncoding = C.ENCODING_PCM_16BIT;
        
        mPendingReconfigure = true;
        
        Log.d(TAG, "ExoPlayer configure: " + mInputSampleRate + "Hz, " + mInputChannelCount + "ch");
        
        return new AudioFormat.Builder()
            .setSampleRate(mOutputSampleRate)
            .setChannelCount(mOutputChannelCount)
            .setEncoding(mOutputEncoding)
            .build();
    }
    
    @Override
    public boolean isActive() {
        return isEffectActive();
    }
    
    @Override
    public void queueInput(@NonNull ByteBuffer inputBuffer) {
        if (!inputBuffer.hasRemaining()) {
            return;
        }
        
        if (mPendingReconfigure) {
            // Configure SoundTouch with the actual audio format
            mIsSoundTouchInitialized = configureSoundTouch(mInputSampleRate, mInputChannelCount);
            mPendingReconfigure = false;
        }
        
        // Passthrough mode - no processing needed
        if (!isActive() || !mIsSoundTouchInitialized || mPitchShifter == null) {
            int bytesToCopy = inputBuffer.remaining();
            if (mOutputBuffer.capacity() < bytesToCopy) {
                mOutputBuffer = ByteBuffer.allocateDirect(bytesToCopy)
                    .order(ByteOrder.nativeOrder());
            } else {
                mOutputBuffer.clear();
            }
            mOutputBuffer.put(inputBuffer);
            mOutputBuffer.flip();
            inputBuffer.position(inputBuffer.position() + bytesToCopy);
            return;
        }
        
        // Convert ByteBuffer to short array for SoundTouch
        ShortBuffer shortBuffer = inputBuffer.asShortBuffer();
        int sampleCount = shortBuffer.remaining();
        short[] pcmData = new short[sampleCount];
        shortBuffer.get(pcmData);
        
        int frames = sampleCount / mInputChannelCount;
        
        if (frames > 0) {
            // Process through SoundTouch
            short[] processed = processSoundTouch(pcmData, frames);
            
            if (processed != null && processed.length > 0) {
                // Ensure buffer capacity
                int requiredBytes = processed.length * 2;
                if (mBuffer.capacity() < requiredBytes) {
                    mBuffer = ByteBuffer.allocateDirect(requiredBytes)
                        .order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                
                mShortBuffer.put(processed);
                mBuffer.limit(processed.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
        
        // Advance input buffer position
        inputBuffer.position(inputBuffer.position() + inputBuffer.remaining());
    }
    
    @Override
    public void queueEndOfStream() {
        mInputEnded = true;
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            flushSoundTouch();
            
            // Get remaining processed audio
            short[] remaining = tryReceiveOnce();
            if (remaining != null && remaining.length > 0) {
                if (mBuffer.capacity() < remaining.length * 2) {
                    mBuffer = ByteBuffer.allocateDirect(remaining.length * 2)
                        .order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                mShortBuffer.put(remaining);
                mBuffer.limit(remaining.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
    }
    
    @NonNull
    @Override
    public ByteBuffer getOutput() {
        ByteBuffer result = mOutputBuffer;
        mOutputBuffer = EMPTY_BUFFER;
        return result;
    }
    
    @Override
    public boolean isEnded() {
        return mInputEnded && (!mIsSoundTouchInitialized || numAvailableFrames() == 0);
    }
    
    @Override
    public void flush() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            flushSoundTouch();
            clearSoundTouch();
        }
        
        mOutputBuffer = EMPTY_BUFFER;
        mInputEnded = false;
        mPendingReconfigure = true;
    }
    
    @Override
    public void reset() {
        flush();
        
        mCurrentTempo = 1.0f;
        mCurrentPitch = 0f;
        
        releaseSoundTouch();
        
        mBuffer = EMPTY_BUFFER;
        mShortBuffer = mBuffer.asShortBuffer();
        mOutputBuffer = EMPTY_BUFFER;
        mPendingReconfigure = true;
    }
}