package com.ark.llama;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * SoundTouchAudio - Media3 AudioProcessor for pitch and tempo shifting.
 * 
 * <p>This class provides a complete audio processing solution that integrates
 * the SoundTouch native library with Media3's audio pipeline. It handles both
 * the low-level PCM processing and the Media3 AudioProcessor interface,
 * allowing for real-time pitch and tempo manipulation during playback.</p>
 * 
 * <h3>Features</h3>
 * <ul>
 *   <li><b>Independent Pitch Control</b> - Adjust pitch from -6 to +6 semitones</li>
 *   <li><b>Independent Tempo Control</b> - Adjust speed from 0.5x to 1.5x</li>
 *   <li><b>Real-time Updates</b> - Change effects during playback without interruption</li>
 *   <li><b>Zero-copy Processing</b> - Efficient buffer management minimizing memory allocation</li>
 *   <li><b>Thread-safe</b> - Safe for concurrent access from multiple threads</li>
 *   <li><b>Automatic Passthrough</b> - When no effects are active, audio passes through unchanged</li>
 * </ul>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Media3 PCM (16-bit) -> SoundTouchAudio.queueInput() -> PitchShifter (Native SoundTouch)
 *                    -> SoundTouchAudio.getOutput() -> Media3 AudioTrack
 * </pre>
 * 
 * <h3>Audio Format Support</h3>
 * <p>This processor only supports 16-bit PCM audio. Other formats will cause
 * an UnhandledAudioFormatException to be thrown during configuration.</p>
 * <ul>
 *   <li><b>Sample Rate:</b> Any rate (typically 44100Hz or 48000Hz)</li>
 *   <li><b>Channels:</b> Mono (1) or Stereo (2)</li>
 *   <li><b>Encoding:</b> 16-bit PCM only</li>
 * </ul>
 * 
 * <h3>Buffer Management</h3>
 * <p>The processor uses a dynamic buffer system that grows as needed but
 * never shrinks to avoid repeated allocations. Buffers are allocated with
 * native byte order for optimal performance.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Create processor
 * SoundTouchAudio processor = new SoundTouchAudio();
 * 
 * // Media3 will call onConfigure() automatically with the input format
 * AudioFormat outputFormat = processor.onConfigure(inputFormat);
 * 
 * // Apply effects during playback
 * processor.setTempo(1.25f);           // 25% faster
 * processor.setPitchSemitones(2.5f);   // Raise by 2.5 semitones
 * 
 * // Set both at once
 * processor.setParameters(0.75f, -3.0f); // 25% slower, down 3 semitones
 * 
 * // Check if effects are active
 * if (processor.isEffectActive()) {
 *     // Processing is occurring
 * }
 * </pre>
 * 
 * <h3>SoundTouch Native Library Integration</h3>
 * <p>This class relies on the native PitchShifter class which wraps the
 * SoundTouch C++ library. The library must be loaded before use, which is
 * handled by the PitchShifter class's static initializer.</p>
 * 
 * <h3>Performance Considerations</h3>
 * <ul>
 *   <li>Processing occurs in the audio thread - keep operations lightweight</li>
 *   <li>Buffer allocations are minimized after initial warm-up</li>
 *   <li>When no effects are active (isActive() returns false), the processor
 *       operates in passthrough mode with zero overhead</li>
 * </ul>
 * 
 * @see AudioProcessor
 * @see PitchShifter
 * @see androidx.media3.exoplayer.ExoPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchAudio implements AudioProcessor {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchAudio";
    
    /** Minimum tempo multiplier (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo multiplier (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch shift in semitones (-6 = down one fifth). */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch shift in semitones (+6 = up one fifth). */
    private static final float MAX_PITCH = 6.0f;
    
    /** Threshold for floating point comparison (prevents unnecessary updates). */
    private static final float CLOSE_THRESHOLD = 0.0001f;
    
    /** Maximum number of frames to process in a single batch. */
    private static final int MAX_FRAMES_PER_BATCH = 4096;
    
    /** Default frames per buffer when not specified. */
    private static final int DEFAULT_FRAMES_PER_BUFFER = 1024;
    
    /** Empty buffer for zero-byte returns. */
    private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocateDirect(0).asReadOnlyBuffer();
    
    // ========================================================================
    // SoundTouch Native Processor
    // ========================================================================
    
    /** Native SoundTouch processor instance. Null if not initialized or library unavailable. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Current sample rate in Hz (e.g., 44100). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Current pitch shift amount in semitones. Range: -6 to +6. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. Range: 0.5 to 1.5. */
    private float mCurrentTempo = 1.0f;
    
    /** Flag indicating if SoundTouch has been successfully initialized. */
    private boolean mIsSoundTouchInitialized = false;
    
    /** Optimal buffer size in frames, calculated based on sample rate. */
    private int mBufferFrames = DEFAULT_FRAMES_PER_BUFFER;
    
    // ========================================================================
    // Media3 AudioProcessor State
    // ========================================================================
    
    /** Input sample rate from Media3 (Hz). */
    private int mInputSampleRate;
    
    /** Input channel count from Media3 (1 or 2). */
    private int mInputChannelCount;
    
    /** Input PCM encoding (must be C.ENCODING_PCM_16BIT). */
    private int mInputEncoding;
    
    /** Output sample rate (same as input). */
    private int mOutputSampleRate;
    
    /** Output channel count (same as input). */
    private int mOutputChannelCount;
    
    /** Output PCM encoding (C.ENCODING_PCM_16BIT). */
    private int mOutputEncoding;
    
    /** Working buffer for audio data. Grows as needed but never shrinks. */
    private ByteBuffer mBuffer;
    
    /** Short buffer view of mBuffer for efficient sample access. */
    private ShortBuffer mShortBuffer;
    
    /** Output buffer containing processed audio ready for consumption. */
    private ByteBuffer mOutputBuffer;
    
    /** Flag indicating end of stream has been queued via onQueueEndOfStream(). */
    private boolean mInputEnded;
    
    /** Flag indicating processor needs to be reconfigured on next input. */
    private boolean mPendingReconfigure;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchAudio processor.
     * 
     * <p>The processor starts in an inactive state. It will be configured
     * when Media3 calls {@link #onConfigure(AudioFormat)}.</p>
     */
    public SoundTouchAudio() {
        mBuffer = EMPTY_BUFFER;
        mShortBuffer = mBuffer.asShortBuffer();
        mOutputBuffer = EMPTY_BUFFER;
        Log.d(TAG, "SoundTouchAudio processor created");
    }
    
    // ========================================================================
    // Public API - Parameter Control
    // ========================================================================
    
    /**
     * Sets the playback speed (tempo) multiplier.
     * 
     * <p>This method can be called at any time during playback. Changes take
     * effect immediately on subsequent audio buffers. The value is clamped
     * to the valid range [0.5, 1.5].</p>
     * 
     * <p>Effect ranges:</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower) - pitch unaffected when used alone</li>
     *   <li>0.75 = 25% slower</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.25 = 25% faster</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     * 
     * @param tempo Speed multiplier (clamped to 0.5-1.5 range)
     */
    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        if (Math.abs(mCurrentTempo - clamped) > CLOSE_THRESHOLD) {
            mCurrentTempo = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clamped);
                Log.v(TAG, "Tempo set to: " + clamped + "x");
            }
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>This method can be called at any time during playback. Changes take
     * effect immediately on subsequent audio buffers. The value is clamped
     * to the valid range [-6, +6].</p>
     * 
     * <p>Effect ranges:</p>
     * <ul>
     *   <li>-6 = down one fifth (musical interval)</li>
     *   <li>-3 = minor third down</li>
     *   <li>0 = normal pitch</li>
     *   <li>+3 = minor third up</li>
     *   <li>+6 = up one fifth</li>
     * </ul>
     * 
     * @param semitones Pitch shift in semitones (clamped to -6 to +6 range)
     */
    public void setPitchSemitones(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        if (Math.abs(mCurrentPitch - clamped) > CLOSE_THRESHOLD) {
            mCurrentPitch = clamped;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clamped);
                Log.v(TAG, "Pitch set to: " + clamped + " semitones");
            }
        }
    }
    
    /**
     * Sets both pitch and tempo parameters at once.
     * 
     * <p>This method is more efficient than calling setTempo() and
     * setPitchSemitones() separately as it may reduce the number of
     * native calls. Both values are clamped to their valid ranges.</p>
     * 
     * @param tempo Speed multiplier (clamped to 0.5-1.5 range)
     * @param pitchSemitones Pitch shift in semitones (clamped to -6 to +6 range)
     */
    public void setParameters(float tempo, float pitchSemitones) {
        float clampedTempo = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        float clampedPitch = Math.max(MIN_PITCH, Math.min(MAX_PITCH, pitchSemitones));
        
        boolean tempoChanged = Math.abs(mCurrentTempo - clampedTempo) > CLOSE_THRESHOLD;
        boolean pitchChanged = Math.abs(mCurrentPitch - clampedPitch) > CLOSE_THRESHOLD;
        
        if (tempoChanged) {
            mCurrentTempo = clampedTempo;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setTempo(clampedTempo);
            }
        }
        
        if (pitchChanged) {
            mCurrentPitch = clampedPitch;
            if (mIsSoundTouchInitialized && mPitchShifter != null) {
                mPitchShifter.setPitch(clampedPitch);
            }
        }
        
        if (tempoChanged || pitchChanged) {
            Log.v(TAG, "Parameters updated: tempo=" + clampedTempo + "x, pitch=" + clampedPitch + "st");
        }
    }
    
    /**
     * Returns the current tempo multiplier.
     * 
     * @return Current tempo (1.0 = normal)
     */
    public float getCurrentTempo() {
        return mCurrentTempo;
    }
    
    /**
     * Returns the current pitch shift in semitones.
     * 
     * @return Current pitch shift (0 = normal)
     */
    public float getCurrentPitch() {
        return mCurrentPitch;
    }
    
    /**
     * Returns true if effects are active (pitch or tempo changed from normal).
     * 
     * <p>When this returns false, the processor operates in passthrough mode
     * with zero processing overhead.</p>
     * 
     * @return true if pitch != 0 or tempo != 1.0
     */
    public boolean isEffectActive() {
        return Math.abs(mCurrentTempo - 1.0f) > CLOSE_THRESHOLD || 
               Math.abs(mCurrentPitch) > CLOSE_THRESHOLD;
    }
    
    /**
     * Returns true if the SoundTouch processor has been initialized successfully.
     * 
     * @return true if initialized and ready for processing
     */
    public boolean isSoundTouchInitialized() {
        return mIsSoundTouchInitialized && mPitchShifter != null;
    }
    
    // ========================================================================
    // Internal SoundTouch Methods
    // ========================================================================
    
    /**
     * Configures the SoundTouch processor with sample rate and channel count.
     * 
     * <p>This method creates a new PitchShifter instance and applies the
     * current pitch and tempo settings. Any previous instance is released
     * before creating the new one.</p>
     * 
     * @param sampleRate Sample rate in Hz (must be > 0)
     * @param channels Number of channels (1 = mono, 2 = stereo)
     * @return true if configuration was successful, false otherwise
     */
    private boolean configureSoundTouch(int sampleRate, int channels) {
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "PitchShifter library not available");
            return false;
        }
        
        if (sampleRate <= 0) {
            Log.e(TAG, "Invalid sample rate: " + sampleRate);
            return false;
        }
        
        if (channels != 1 && channels != 2) {
            Log.e(TAG, "Invalid channel count: " + channels + " - only mono (1) or stereo (2) supported");
            return false;
        }
        
        try {
            // Release previous instance if exists
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            // Create new SoundTouch instance
            mPitchShifter = new PitchShifter(sampleRate, channels);
            mSampleRate = sampleRate;
            mChannels = channels;
            
            // Calculate optimal buffer size (aim for ~20ms of audio)
            // This balances latency and processing efficiency
            mBufferFrames = (sampleRate * 20 / 1000) * channels;
            mBufferFrames = Math.max(DEFAULT_FRAMES_PER_BUFFER, 
                Math.min(MAX_FRAMES_PER_BATCH, mBufferFrames));
            
            // Apply current settings
            if (mCurrentPitch != 0f) {
                mPitchShifter.setPitch(mCurrentPitch);
            }
            if (mCurrentTempo != 1.0f) {
                mPitchShifter.setTempo(mCurrentTempo);
            }
            
            mIsSoundTouchInitialized = true;
            
            Log.d(TAG, "SoundTouch configured: " + sampleRate + "Hz, " + channels + "ch, " +
                  "buffer=" + mBufferFrames + " frames, " + 
                  "tempo=" + mCurrentTempo + "x, pitch=" + mCurrentPitch + "st");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure SoundTouch", e);
            mIsSoundTouchInitialized = false;
            return false;
        }
    }
    
    /**
     * Processes audio frames through SoundTouch.
     * 
     * <p>This method feeds input PCM data to the native SoundTouch library
     * and retrieves the processed output. Input and output are 16-bit PCM
     * with samples interleaved for stereo.</p>
     * 
     * @param input Array of 16-bit PCM samples (interleaved for stereo)
     * @param frames Number of frames (each frame = channels samples)
     * @return Processed audio output as short array, or empty array if no output
     */
    @NonNull
    private short[] processSoundTouch(@NonNull short[] input, int frames) {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return input;
        }
        
        if (frames <= 0 || input.length < frames * mChannels) {
            return new short[0];
        }
        
        try {
            // Feed input to SoundTouch
            mPitchShifter.putFrames(input, frames);
            
            // Check how many frames are available for output
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return new short[0];
            }
            
            // Receive processed frames
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    // Trim to actual received amount
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
            
            return new short[0];
            
        } catch (Exception e) {
            Log.e(TAG, "Process error", e);
            return input;
        }
    }
    
    /**
     * Non-blocking receive from SoundTouch.
     * 
     * <p>Attempts to retrieve any available processed audio without waiting.
     * Returns null if no frames are available.</p>
     * 
     * @return Processed audio buffer as short array, or null if none available
     */
    @Nullable
    private short[] tryReceiveOnce() {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return null;
        }
        
        try {
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) {
                return null;
            }
            
            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            
            if (received > 0) {
                if (received < availableFrames) {
                    short[] trimmed = new short[received * mChannels];
                    System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                    return trimmed;
                }
                return output;
            }
        } catch (Exception e) {
            Log.w(TAG, "tryReceiveOnce error", e);
        }
        
        return null;
    }
    
    /**
     * Returns the number of available frames in the SoundTouch output buffer.
     * 
     * @return Number of frames ready for retrieval
     */
    private int numAvailableFrames() {
        if (!mIsSoundTouchInitialized || mPitchShifter == null) {
            return 0;
        }
        return mPitchShifter.numFrames();
    }
    
    /**
     * Flushes any remaining audio from SoundTouch.
     * 
     * <p>This should be called when all input has been queued to ensure
     * any remaining processed audio is output.</p>
     */
    private void flushSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.flush();
            Log.v(TAG, "SoundTouch flushed");
        }
    }
    
    /**
     * Clears all SoundTouch internal buffers.
     * 
     * <p>This discards any pending input and output data. Useful during
     * seek operations or format changes.</p>
     */
    private void clearSoundTouch() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            mPitchShifter.clear();
            Log.v(TAG, "SoundTouch cleared");
        }
    }
    
    /**
     * Releases SoundTouch native resources.
     * 
     * <p>Call this when the processor is no longer needed to free native
     * memory. The processor can be reconfigured later if needed.</p>
     */
    private void releaseSoundTouch() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        mIsSoundTouchInitialized = false;
        Log.d(TAG, "SoundTouch released");
    }
    
    // ========================================================================
    // Media3 AudioProcessor Implementation
    // ========================================================================
    
    /**
     * Configures the processor with the input audio format.
     * 
     * <p>This method is called by Media3 during player preparation. It
     * validates that the input format is supported (16-bit PCM) and returns
     * the output format (which is the same as input for passthrough).</p>
     * 
     * @param inputFormat The format of input audio data
     * @return The format of output audio data
     * @throws AudioProcessor.UnhandledAudioFormatException if format not supported
     */
    @NonNull
    @Override
    public AudioFormat onConfigure(@NonNull AudioFormat inputFormat)
            throws AudioProcessor.UnhandledAudioFormatException {
        
        // Only support 16-bit PCM (Media3 uses pcmEncoding instead of encoding)
        if (inputFormat.pcmEncoding != C.ENCODING_PCM_16BIT) {
            throw new AudioProcessor.UnhandledAudioFormatException(inputFormat);
        }
        
        // Store input format parameters
        mInputSampleRate = inputFormat.sampleRate;
        mInputChannelCount = inputFormat.channelCount;
        mInputEncoding = inputFormat.pcmEncoding;
        
        // Output same format as input (passthrough when inactive)
        mOutputSampleRate = mInputSampleRate;
        mOutputChannelCount = mInputChannelCount;
        mOutputEncoding = C.ENCODING_PCM_16BIT;
        
        // Flag that we need to configure SoundTouch on first input
        mPendingReconfigure = true;
        
        Log.d(TAG, "Media3 onConfigure: " + mInputSampleRate + "Hz, " + mInputChannelCount + "ch, " +
              "encoding=" + mInputEncoding);
        
        // Return the output format using Media3 AudioFormat.Builder
        return new AudioFormat.Builder()
            .setSampleRate(mOutputSampleRate)
            .setChannelCount(mOutputChannelCount)
            .setEncoding(mOutputEncoding)
            .build();
    }
    
    /**
     * Returns whether the processor is active.
     * 
     * <p>The processor is active when pitch or tempo effects are enabled.
     * When inactive, Media3 may bypass the processor entirely.</p>
     * 
     * @return true if effects are active, false otherwise
     */
    @Override
    public boolean isActive() {
        return isEffectActive();
    }
    
    /**
     * Queues input audio data for processing.
     * 
     * <p>This method is called by Media3 with PCM audio data. It either
     * processes the data through SoundTouch (if effects are active) or
     * passes it through unchanged (if inactive).</p>
     * 
     * @param inputBuffer ByteBuffer containing 16-bit PCM audio data
     */
    @Override
    public void queueInput(@NonNull ByteBuffer inputBuffer) {
        if (!inputBuffer.hasRemaining()) {
            return;
        }
        
        // Configure SoundTouch if needed (first input after format change)
        if (mPendingReconfigure) {
            mIsSoundTouchInitialized = configureSoundTouch(mInputSampleRate, mInputChannelCount);
            mPendingReconfigure = false;
        }
        
        // Passthrough mode - no processing needed
        if (!isActive() || !mIsSoundTouchInitialized || mPitchShifter == null) {
            int bytesToCopy = inputBuffer.remaining();
            
            // Ensure output buffer has enough capacity
            if (mOutputBuffer.capacity() < bytesToCopy) {
                mOutputBuffer = ByteBuffer.allocateDirect(bytesToCopy)
                    .order(ByteOrder.nativeOrder());
            } else {
                mOutputBuffer.clear();
            }
            
            // Copy data directly to output
            mOutputBuffer.put(inputBuffer);
            mOutputBuffer.flip();
            inputBuffer.position(inputBuffer.position() + bytesToCopy);
            return;
        }
        
        // Active processing mode - convert to short array for SoundTouch
        ShortBuffer shortBuffer = inputBuffer.asShortBuffer();
        int sampleCount = shortBuffer.remaining();
        short[] pcmData = new short[sampleCount];
        shortBuffer.get(pcmData);
        
        int frames = sampleCount / mInputChannelCount;
        
        if (frames > 0) {
            // Process through SoundTouch native library
            short[] processed = processSoundTouch(pcmData, frames);
            
            if (processed != null && processed.length > 0) {
                int requiredBytes = processed.length * 2; // 2 bytes per short
                
                // Grow buffer if needed (but never shrink to avoid repeated allocations)
                if (mBuffer.capacity() < requiredBytes) {
                    mBuffer = ByteBuffer.allocateDirect(requiredBytes)
                        .order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                
                // Write processed data to output buffer
                mShortBuffer.put(processed);
                mBuffer.limit(processed.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
        
        // Advance input buffer position
        inputBuffer.position(inputBuffer.position() + inputBuffer.remaining());
    }
    
    /**
     * Signals that no more input data will be queued.
     * 
     * <p>This method is called by Media3 when the end of the stream is reached.
     * It flushes any remaining audio from the SoundTouch buffer so it can be
     * retrieved via getOutput().</p>
     */
    @Override
    public void onQueueEndOfStream() {
        mInputEnded = true;
        
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            // Flush SoundTouch to get any remaining processed audio
            flushSoundTouch();
            
            // Retrieve remaining audio
            short[] remaining = tryReceiveOnce();
            if (remaining != null && remaining.length > 0) {
                // Ensure buffer capacity
                if (mBuffer.capacity() < remaining.length * 2) {
                    mBuffer = ByteBuffer.allocateDirect(remaining.length * 2)
                        .order(ByteOrder.nativeOrder());
                    mShortBuffer = mBuffer.asShortBuffer();
                } else {
                    mBuffer.clear();
                    mShortBuffer.clear();
                }
                
                mShortBuffer.put(remaining);
                mBuffer.limit(remaining.length * 2);
                mOutputBuffer = mBuffer;
            }
        }
    }
    
    /**
     * Returns the output buffer containing processed audio.
     * 
     * <p>This method is called by Media3 to retrieve processed audio data.
     * The returned buffer is flipped and ready for reading.</p>
     * 
     * @return ByteBuffer containing processed audio data
     */
    @NonNull
    @Override
    public ByteBuffer getOutput() {
        ByteBuffer result = mOutputBuffer;
        mOutputBuffer = EMPTY_BUFFER;
        return result;
    }
    
    /**
     * Returns whether the end of the stream has been reached.
     * 
     * <p>This method returns true when all input has been queued and all
     * processed output has been retrieved.</p>
     * 
     * @return true if no more output is available and end of stream reached
     */
    @Override
    public boolean isEnded() {
        return mInputEnded && (!mIsSoundTouchInitialized || numAvailableFrames() == 0);
    }
    
    /**
     * Flushes the processor, discarding any pending data.
     * 
     * <p>Called during seek operations or when playback is interrupted.
     * Clears all internal buffers and resets the processor state.</p>
     */
    @Override
    public void flush() {
        if (mIsSoundTouchInitialized && mPitchShifter != null) {
            flushSoundTouch();
            clearSoundTouch();
        }
        
        mOutputBuffer = EMPTY_BUFFER;
        mInputEnded = false;
        mPendingReconfigure = true;
    }
    
    /**
     * Resets the processor to its initial state.
     * 
     * <p>This clears all effects, releases native resources, and resets
     * all buffers. The processor can be reconfigured later if needed.</p>
     */
    @Override
    public void reset() {
        flush();
        
        // Reset effect values to default (no effect)
        mCurrentTempo = 1.0f;
        mCurrentPitch = 0f;
        
        // Release native resources
        releaseSoundTouch();
        
        // Reset buffers
        mBuffer = EMPTY_BUFFER;
        mShortBuffer = mBuffer.asShortBuffer();
        mOutputBuffer = EMPTY_BUFFER;
        mPendingReconfigure = true;
        
        Log.d(TAG, "SoundTouchAudio reset");
    }
}