package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <p>This implementation follows a Professional Audio Engine Architecture
 * specification with strict separation of concerns, explicit state machine,
 * and dedicated background threads for decoding and rendering.</p>
 * 
 * <h3>Architecture (Per Specification)</h3>
 * <pre>
 * MusicPlayer (UI) -> MusicService (Playlist) -> SoundTouchPlayer (Playback)
 *                                                                                          |
 *                                                                                         \/
 * AudioTrack (Output) <- PitchShifter (DSP) <- AudioDecoder (Decode)
 * </pre>
 * 
 * <h3>State Machine (APPENDIX A)</h3>
 * <pre>
 * IDLE -> PREPARING -> READY -> PLAYING • PAUSED -> COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * <h3>Threading Model (APPENDIX B)</h3>
 * <ul>
 *   <li><b>UI Thread</b> - Commands (play/pause/seek/load) and callbacks</li>
 *   <li><b>Playback Thread</b> - Decoding, SoundTouch DSP, AudioTrack writes</li>
 * </ul>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Accurate position tracking using AudioTrack playback head</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Pre-load capability for immediate duration and audio session access</li>
 *   <li>Proper format validation from actual decoder output (not container)</li>
 *   <li>Graceful error handling and resource cleanup</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() {
 *         // Player is ready, duration and audio session available
 *         int duration = (int) player.getDuration();
 *         int sessionId = player.getAudioSessionId();
 *         player.play();
 *     }
 *     public void onCompletion() { /* play next song * / }
 *     public void onError(String error) { /* handle error * / }
 * });
 * 
 * // Load and play
 * if (player.loadSong("/sdcard/Music/song.mp3")) {
 *     player.play();
 * }
 * 
 * // Control playback
 * player.pause();
 * player.resume();
 * player.seekTo(30000);
 * player.setPitch(2.5f);
 * player.setTempo(1.25f);
 * 
 * // Clean up
 * player.release();
 * </pre>
 * 
 * @see AudioDecoder
 * @see PitchShifter
 * @see AudioTrack
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Position update interval in milliseconds for UI callbacks. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Timeout for loadSong() to wait for player to be ready. */
    private static final long LOAD_TIMEOUT_MS = 8000;
    
    /** Sleep time when idle in milliseconds. */
    private static final int IDLE_SLEEP_MS = 10;
    
    /** Sleep time when no data available in milliseconds. */
    private static final int NO_DATA_SLEEP_MS = 5;
    
    /** Maximum attempts to wait for decoder format. */
    private static final int MAX_FORMAT_WAIT_ATTEMPTS = 50;
    
    /** Sleep between format check attempts in milliseconds. */
    private static final int FORMAT_WAIT_SLEEP_MS = 100;
    
    // ========================================================================
    // State Machine
    // ========================================================================
    
    /**
     * Player states as defined in APPENDIX A of the architecture specification.
     * 
     * <p>State transitions:</p>
     * <pre>
     * IDLE -> PREPARING -> READY -> PLAYING • PAUSED -> COMPLETED
     * Any state may transition to ERROR or RELEASED
     * </pre>
     */
    public enum State {
        /** Initial state, no resources allocated. */
        IDLE,
        
        /** Decoder is being created and format is being validated. */
        PREPARING,
        
        /** Player is ready to play (AudioTrack created, format validated). */
        READY,
        
        /** Actively playing audio. */
        PLAYING,
        
        /** Playback paused, position preserved. */
        PAUSED,
        
        /** End of stream reached naturally. */
        COMPLETED,
        
        /** Error occurred, needs recovery or release. */
        ERROR,
        
        /** Resources released, terminal state. */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>Implement this interface to be notified of playback state changes
     * such as play, pause, completion, and errors.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         *
         * @param newState The new state
         * @param oldState The previous state (can be null for initial transition)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * 
         * <p>At this point, the audio session ID is available via {@link #getAudioSessionId()}
         * and the duration is available via {@link #getDuration()}.</p>
         */
        void onPrepared();
        
        /**
         * Called when the current song completes playback naturally.
         * 
         * <p>This occurs when the end of the audio stream is reached.
         * The player will transition to COMPLETED state.</p>
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * <p>This method is called approximately every 100ms to allow UI
         * components (like SeekBar) to update smoothly.</p>
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback.
         * 
         * <p>After this callback, the player enters ERROR state and should
         * be either recovered or released.</p>
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcasts. */
    @NonNull
    private final Context mContext;
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Current player state (atomic for thread-safe reads). */
    private final AtomicReference<State> mState = new AtomicReference<>(State.IDLE);
    
    /** Lock for ready latch synchronization. */
    private final Object mReadyLock = new Object();
    
    /** Latch for loadSong() to wait for player to be ready. */
    @Nullable
    private CountDownLatch mReadyLatch;
    
    /** Audio decoder for extracting and decoding audio. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** Native pitch shifter for tempo and pitch processing. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** AudioTrack for PCM output. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    /** Actual sample rate from decoder output (not container). */
    private int mSampleRate = 44100;
    
    /** Actual channel count from decoder output (not container). */
    private int mChannels = 2;
    
    /** Frame size in bytes (channels * 2 for 16-bit PCM). */
    private int mFrameSize = 4;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Duration of current song in milliseconds. */
    private long mDuration = 0;
    
    /** Path of currently loaded song. */
    @Nullable
    private String mCurrentFilePath = null;
    
    /** Flag indicating format has been validated from decoder output. */
    private boolean mFormatValidated = false;
    
    /** Flag indicating playback is active. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating playback is paused. */
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    
    /** Flag indicating end of stream reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Target seek position (-1 if no seek pending). */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Current playback position in milliseconds. */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Current pitch setting in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Background playback thread. */
    @Nullable
    private Thread mPlaybackThread;
    
    /** Flag indicating the playback thread should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Flag indicating decoder is active. */
    private final AtomicBoolean mDecoderActive = new AtomicBoolean(false);
    
    /** Handler for UI thread callbacks. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>Initializes the player in IDLE state. Resources are allocated lazily
     * when a song is loaded via {@link #loadSong(String)} or {@link #preLoad(String)}.</p>
     *
     * @param context Application context for sending broadcasts and accessing resources
     * @throws IllegalArgumentException if context is null
     */
    public SoundTouchPlayer(@NonNull Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context cannot be null");
        }
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, initial state: IDLE");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * <p>The listener will receive callbacks for state changes, completion,
     * position updates, and errors.</p>
     *
     * @param listener The listener to receive events (can be null to remove)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method initializes the decoder and validates the audio format
     * without creating an AudioTrack. The audio session becomes available
     * after format validation via {@link #getAudioSessionId()}.
     * This allows the UI to display song duration and attach an equalizer
     * before the user presses play.</p>
     * 
     * <p>State transition: IDLE/PREPARING/ERROR -> PREPARING</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @return true if pre-load was initiated successfully, false otherwise
     * @throws IllegalStateException if the player has been released
     */
    public boolean preLoad(@NonNull String filePath) {
        checkNotReleased();
        
        State currentState = mState.get();
        Log.d(TAG, "preLoad: " + filePath + ", currentState=" + currentState);
        
        if (currentState == State.PREPARING) {
            Log.d(TAG, "preLoad: Already preparing, ignoring duplicate request");
            return true;
        }
        
        // Release existing resources if needed
        if (currentState != State.IDLE && currentState != State.ERROR && 
            currentState != State.COMPLETED) {
            releaseInternal();
        }
        
        // Start loading on background thread
        startLoadingThread(filePath);
        
        return true;
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method blocks until the player is ready (READY state) or a timeout occurs.
     * After successful load, the player can be started with {@link #play()}.</p>
     * 
     * <p>State transition: IDLE/PREPARING/ERROR -> PREPARING -> READY</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @return true if loading was successful and player is ready, false otherwise
     * @throws IllegalStateException if the player has been released
     */
    public boolean loadSong(@NonNull String filePath) {
        checkNotReleased();
        
        Log.d(TAG, "loadSong: Loading " + filePath);
        
        synchronized (mReadyLock) {
            mReadyLatch = new CountDownLatch(1);
        }
        
        if (!preLoad(filePath)) {
            Log.e(TAG, "loadSong: preLoad failed");
            return false;
        }
        
        try {
            boolean ready = mReadyLatch.await(LOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (!ready) {
                Log.e(TAG, "loadSong: Timeout waiting for player to be ready");
                transitionToError("Load timeout");
                return false;
            }
        } catch (InterruptedException e) {
            Log.e(TAG, "loadSong: Interrupted while waiting", e);
            Thread.currentThread().interrupt();
            return false;
        }
        
        boolean success = mState.get() == State.READY;
        Log.d(TAG, "loadSong: Complete, success=" + success);
        return success;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in READY state, playback begins from the start.
     * If the player is in PAUSED state, playback resumes from the current position.
     * If the player is in COMPLETED state, playback restarts from the beginning.</p>
     * 
     * <p>State transitions:</p>
     * <ul>
     *   <li>READY -> PLAYING</li>
     *   <li>PAUSED -> PLAYING</li>
     *   <li>COMPLETED -> PLAYING (after seeking to 0)</li>
     * </ul>
     * 
     * @throws IllegalStateException if the player has been released
     */
    public void play() {
        checkNotReleased();
        
        State currentState = mState.get();
        Log.d(TAG, "play() called, currentState=" + currentState + ", formatValidated=" + mFormatValidated);
        
        if (!mFormatValidated) {
            Log.w(TAG, "play() called before format validated - ignoring");
            return;
        }
        
        if (currentState == State.READY) {
            startPlayback();
        } else if (currentState == State.PAUSED) {
            resumePlayback();
        } else if (currentState == State.COMPLETED) {
            seekTo(0);
            startPlayback();
        } else if (currentState == State.IDLE) {
            Log.w(TAG, "play: Called on IDLE, load a song first");
        } else if (currentState == State.ERROR) {
            Log.w(TAG, "play: Cannot play in ERROR state");
            notifyError("Cannot play - player in error state");
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()} or {@link #resume()}.</p>
     * 
     * <p>State transition: PLAYING -> PAUSED</p>
     * 
     * @throws IllegalStateException if the player has been released
     */
    public void pause() {
        checkNotReleased();
        
        if (mState.get() == State.PLAYING) {
            mIsPaused.set(true);
            transitionTo(State.PAUSED);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    Log.d(TAG, "AudioTrack paused");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to pause AudioTrack", e);
                }
            }
        }
    }
    
    /**
     * Resumes playback after pause.
     * 
     * <p>This method is equivalent to calling {@link #play()} when in PAUSED state.</p>
     * 
     * <p>State transition: PAUSED -> PLAYING</p>
     * 
     * @throws IllegalStateException if the player has been released
     */
    public void resume() {
        checkNotReleased();
        
        if (mState.get() == State.PAUSED) {
            mIsPaused.set(false);
            startPlayback();
        }
    }
    
    /**
     * Stops playback and resets the player position to the beginning.
     * 
     * <p>After calling stop, the player remains in READY state and can be
     * restarted by calling {@link #play()}, which will play from the start.</p>
     * 
     * <p>State transition: PLAYING/PAUSED -> READY</p>
     * 
     * @throws IllegalStateException if the player has been released
     */
    public void stop() {
        checkNotReleased();
        
        mIsPlaying.set(false);
        mIsPaused.set(false);
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
            } catch (Exception e) {
                Log.e(TAG, "Failed to stop AudioTrack", e);
            }
        }
        
        if (mDecoder != null) {
            mDecoder.seekTo(0);
        }
        
        mIsEOS.set(false);
        mCurrentPosition.set(0);
        transitionTo(State.READY);
        Log.d(TAG, "Playback stopped, position reset to 0");
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>This method flushes both the decoder and AudioTrack to ensure
     * proper synchronization after the seek operation.</p>
     * 
     * <p>Valid in states: READY, PLAYING, PAUSED, COMPLETED</p>
     *
     * @param positionMs Position in milliseconds to seek to (0 = beginning)
     * @throws IllegalStateException if the player has been released
     */
    public void seekTo(int positionMs) {
        checkNotReleased();
        
        State currentState = mState.get();
        if (currentState == State.READY || currentState == State.PLAYING || 
            currentState == State.PAUSED || currentState == State.COMPLETED) {
            
            // Clamp to valid range
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            
            mSeekTarget.set((int) clampedPosition);
            mCurrentPosition.set(clampedPosition);
            
            if (mDecoder != null) {
                mDecoder.seekTo((int) clampedPosition);
                mIsEOS.set(false);
                Log.d(TAG, "Decoder seeked to " + clampedPosition + "ms");
            }
            
            // Flush AudioTrack to clear old data
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    mAudioTrack.flush();
                    if (currentState == State.PLAYING) {
                        mAudioTrack.play();
                    }
                    Log.d(TAG, "AudioTrack flushed after seek");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to flush AudioTrack after seek", e);
                }
            }
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones, though
     * values outside this range may produce distortion.</p>
     * 
     * <p>The change takes effect on the next audio frame processed.</p>
     *
     * @param semitones The pitch shift amount in semitones (recommended: -6 to +6)
     * @throws IllegalStateException if the player has been released
     */
    public void setPitch(float semitones) {
        checkNotReleased();
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
            Log.d(TAG, "Pitch set to " + semitones + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5, though
     * values outside this range may produce artifacts.</p>
     * 
     * <p>The change takes effect on the next audio frame processed.</p>
     *
     * @param tempo The tempo multiplier (recommended: 0.5 to 1.5)
     * @throws IllegalStateException if the player has been released
     */
    public void setTempo(float tempo) {
        checkNotReleased();
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
            Log.d(TAG, "Tempo set to " + tempo + "x");
        }
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>Uses AudioTrack playback head position for accuracy when available,
     * falling back to the internally tracked position.</p>
     *
     * @return Current position in milliseconds, or 0 if not available
     */
    public long getCurrentPosition() {
        // Use AudioTrack head position for playing/paused states (most accurate)
        if (mAudioTrack != null && mState.get() == State.PLAYING) {
            try {
                // Per Android documentation: value is unsigned 32-bit, handle wraparound
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                
                // Clamp to duration
                long duration = mDuration;
                if (duration > 0 && positionMs > duration) {
                    positionMs = duration;
                }
                
                return positionMs;
            } catch (Exception e) {
                Log.w(TAG, "Failed to get AudioTrack position, using fallback", e);
            }
        }
        
        // Fallback to internally tracked position
        return mCurrentPosition.get();
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get() && mState.get() == State.PLAYING;
    }
    
    /**
     * Checks if a song is loaded and the player is ready for playback.
     *
     * @return true if prepared (READY, PLAYING, or PAUSED state), false otherwise
     */
    public boolean isPrepared() {
        State state = mState.get();
        return state == State.READY || state == State.PLAYING || state == State.PAUSED;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     * 
     * <p>The session ID is valid after the player enters the READY state
     * (i.e., after {@link PlaybackListener#onPrepared()} is called).</p>
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return The current State enum value
     */
    @NonNull
    public State getState() {
        return mState.get();
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     * 
     * <p>State transition: Any state -> RELEASED (terminal)</p>
     */
    public void release() {
        Log.d(TAG, "release() called");
        
        mRunning.set(false);
        mDecoderActive.set(false);
        
        stopPlaybackThread();
        releaseAudioTrack();
        releaseDecoder();
        releasePitchShifter();
        
        transitionTo(State.RELEASED);
        Log.d(TAG, "release() complete");
    }
    
    // ========================================================================
    // Private Methods - Loading and Format Validation
    // ========================================================================
    
    /**
     * Starts the loading thread for a given file path.
     *
     * @param filePath Path to the audio file to load
     */
    private void startLoadingThread(@NonNull String filePath) {
        transitionTo(State.PREPARING);
        mCurrentFilePath = filePath;
        
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            performLoad(filePath);
        }, "SoundTouch-Loader").start();
    }
    
    /**
     * Performs the actual loading of an audio file.
     * 
     * <p>This method runs on a background thread and handles:
     * <ol>
     *   <li>Opening the AudioDecoder</li>
     *   <li>Waiting for the actual decoder output format</li>
     *   <li>Initializing the PitchShifter</li>
     *   <li>Creating the AudioTrack</li>
     *   <li>Broadcasting that the song is prepared</li>
     * </ol>
     * </p>
     *
     * @param filePath Path to the audio file
     */
    private void performLoad(@NonNull String filePath) {
        try {
            // Step 1: Open decoder
            AudioDecoder decoder = new AudioDecoder();
            if (!decoder.open(filePath)) {
                transitionToError("Failed to open audio file: " + filePath);
                return;
            }
            
            mDecoder = decoder;
            mDuration = decoder.getDuration();
            Log.d(TAG, "Decoder opened, container duration: " + mDuration + "ms");
            
            // Step 2: Wait for actual decoder output format (critical fix!)
            if (!waitForActualFormat()) {
                transitionToError("Failed to get audio format from decoder");
                return;
            }
            
            // Step 3: Initialize PitchShifter with actual format
            if (PitchShifter.isLibraryAvailable()) {
                mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                mPitchShifter.setPitch(mCurrentPitch);
                mPitchShifter.setTempo(mCurrentTempo);
                Log.d(TAG, "PitchShifter initialized: " + mSampleRate + "Hz, " + mChannels + "ch");
            } else {
                Log.w(TAG, "PitchShifter library not available, playing without effects");
            }
            
            // Step 4: Create AudioTrack with actual format
            createAudioTrack();
            
            if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                transitionToError("Failed to create AudioTrack");
                return;
            }
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            mFormatValidated = true;
            
            // Step 5: Broadcast that song is prepared (for UI and equalizer)
            broadcastSongPrepared();
            
            // Step 6: Notify listener that player is ready
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onPrepared());
            }
            
            // Step 7: Signal that player is ready (unblock loadSong)
            transitionTo(State.READY);
            synchronized (mReadyLock) {
                if (mReadyLatch != null) {
                    mReadyLatch.countDown();
                    mReadyLatch = null;
                }
            }
            
            Log.d(TAG, "Load complete: " + mSampleRate + "Hz, " + mChannels + 
                  "ch, duration=" + mDuration + "ms, session=" + mAudioSessionId);
            
        } catch (Exception e) {
            Log.e(TAG, "Load failed", e);
            transitionToError(e.getMessage() != null ? e.getMessage() : "Unknown load error");
        }
    }
    
    /**
     * Waits for the actual decoder output format from MediaCodec.
     * 
     * <p>This is a CRITICAL method. According to Android's MediaCodec documentation,
     * the container format (from MediaExtractor) may differ from the decoder's
     * actual output format. This method polls the decoder until it produces
     * its first output buffer with the correct format.</p>
     * 
     * <p>Without this step, AudioTrack may be created with wrong sample rate
     * or channel count, causing crashes or silent playback.</p>
     *
     * @return true if format was successfully obtained, false on timeout or error
     */
    private boolean waitForActualFormat() {
        if (mDecoder == null) {
            return false;
        }
        
        int attempts = 0;
        short[] testBuffer = new short[BUFFER_FRAMES * 2]; // Temporary buffer for reading
        
        while (attempts < MAX_FORMAT_WAIT_ATTEMPTS && mRunning.get()) {
            try {
                // Try to read a small amount of PCM to trigger format detection
                int framesRead = mDecoder.read(testBuffer, BUFFER_FRAMES / 10);
                
                if (framesRead > 0) {
                    // Success! Now get the actual sample rate and channels
                    int newSampleRate = mDecoder.getSampleRate();
                    int newChannels = mDecoder.getChannels();
                    
                    // Validate the values
                    if (newSampleRate > 0 && newSampleRate <= 192000 && 
                        newChannels > 0 && newChannels <= 2) {
                        mSampleRate = newSampleRate;
                        mChannels = newChannels;
                        mFrameSize = mChannels * 2;
                        
                        Log.d(TAG, "Actual decoder format obtained after " + (attempts + 1) + 
                              " attempts: " + mSampleRate + "Hz, " + mChannels + "ch");
                        return true;
                    }
                }
                
                // Wait before next attempt
                Thread.sleep(FORMAT_WAIT_SLEEP_MS);
                attempts++;
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            } catch (Exception e) {
                Log.w(TAG, "Error while waiting for format", e);
                attempts++;
            }
        }
        
        // Fallback to container format if available
        if (mDecoder != null) {
            int fallbackRate = mDecoder.getSampleRate();
            int fallbackChannels = mDecoder.getChannels();
            if (fallbackRate > 0 && fallbackChannels > 0) {
                Log.w(TAG, "Using fallback container format: " + fallbackRate + "Hz, " + 
                      fallbackChannels + "ch");
                mSampleRate = fallbackRate;
                mChannels = fallbackChannels;
                mFrameSize = mChannels * 2;
                return true;
            }
        }
        
        Log.e(TAG, "Failed to obtain audio format after " + MAX_FORMAT_WAIT_ATTEMPTS + " attempts");
        return false;
    }
    
    /**
     * Creates and configures the AudioTrack with the validated format.
     * 
     * <p>This method follows Android best practices for AudioTrack creation:
     * <ul>
     *   <li>Uses AudioAttributes.Builder for usage and content type</li>
     *   <li>Uses AudioFormat.Builder for format specification</li>
     *   <li>Calculates appropriate buffer size based on sample rate</li>
     *   <li>Verifies initialization state after creation</li>
     * </ul>
     * </p>
     */
    private void createAudioTrack() {
        // Release existing AudioTrack if any
        releaseAudioTrack();
        
        // Determine channel configuration
        int channelConfig;
        if (mChannels == 2) {
            channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
        } else if (mChannels == 1) {
            channelConfig = AudioFormat.CHANNEL_OUT_MONO;
        } else {
            Log.e(TAG, "Unsupported channel count: " + mChannels + ", defaulting to stereo");
            channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
            mChannels = 2;
            mFrameSize = 4;
        }
        
        // Calculate minimum buffer size
        int minBufferSize = AudioTrack.getMinBufferSize(
            mSampleRate,
            channelConfig,
            AudioFormat.ENCODING_PCM_16BIT
        );
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize: " + minBufferSize);
            return;
        }
        
        // Target buffer for MIN_BUFFER_MS of audio
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mFrameSize;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        // Build AudioAttributes
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        // Build AudioFormat
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        // Create AudioTrack using Builder pattern
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mAudioTrack = new AudioTrack.Builder()
                    .setAudioAttributes(audioAttributes)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            } else {
                //noinspection deprecation
                mAudioTrack = new AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    mSampleRate,
                    channelConfig,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize,
                    AudioTrack.MODE_STREAM
                );
            }
            
            // Verify initialization
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack not initialized, state=" + mAudioTrack.getState());
                mAudioTrack = null;
            } else {
                Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + 
                      "ch, bufferSize=" + bufferSize + ", minBuffer=" + minBufferSize);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            mAudioTrack = null;
        }
    }
    
    /**
     * Starts the playback thread and begins audio rendering.
     */
    private void startPlayback() {
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            // Thread already running, just update state
            mIsPlaying.set(true);
            mIsPaused.set(false);
            transitionTo(State.PLAYING);
            
            if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                try {
                    mAudioTrack.play();
                } catch (Exception e) {
                    Log.e(TAG, "Failed to start AudioTrack", e);
                }
            }
            return;
        }
        
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mRunning.set(true);
        transitionTo(State.PLAYING);
        
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "Playback thread started");
    }
    
    /**
     * Resumes playback from a paused state.
     */
    private void resumePlayback() {
        mIsPaused.set(false);
        mIsPlaying.set(true);
        transitionTo(State.PLAYING);
        
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "AudioTrack resumed");
            } catch (Exception e) {
                Log.e(TAG, "Failed to resume AudioTrack", e);
            }
        }
    }
    
    /**
     * Main playback loop that runs on a background thread.
     * 
     * <p>This loop continuously:
     * <ol>
     *   <li>Reads PCM data from the decoder</li>
     *   <li>Processes it through SoundTouch (pitch/tempo)</li>
     *   <li>Writes the processed data to AudioTrack</li>
     *   <li>Updates position and notifies listeners</li>
     * </ol>
     * </p>
     */
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mFrameSize];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Playback loop started");
        
        while (mRunning.get() && mState.get() != State.RELEASED) {
            try {
                // Handle pause state
                if (mIsPaused.get() || mState.get() == State.PAUSED) {
                    Thread.sleep(IDLE_SLEEP_MS);
                    continue;
                }
                
                // Check for end of stream
                if (mIsEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                if (mDecoder == null || !mFormatValidated) {
                    Thread.sleep(IDLE_SLEEP_MS);
                    continue;
                }
                
                // Read PCM from decoder
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead <= 0) {
                    if (mDecoder.isEOS()) {
                        mIsEOS.set(true);
                        continue;
                    }
                    Thread.sleep(NO_DATA_SLEEP_MS);
                    continue;
                }
                
                // Process through SoundTouch if available
                short[] samplesToWrite = inputBuffer;
                int samplesCount = framesRead * mChannels;
                
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            samplesCount = received * mChannels;
                        }
                    }
                }
                
                // Write to AudioTrack
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    // Ensure AudioTrack is playing
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        try {
                            mAudioTrack.play();
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to start AudioTrack in playback loop", e);
                        }
                    }
                    
                    // Convert shorts to bytes (little-endian)
                    for (int i = 0; i < samplesCount; i++) {
                        byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                        byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                    }
                    
                    int written = mAudioTrack.write(byteBuffer, 0, samplesCount * 2);
                    if (written < 0) {
                        Log.e(TAG, "AudioTrack.write error: " + written);
                        if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                            Log.w(TAG, "AudioTrack is dead, attempting recreation");
                            recreateAudioTrack();
                        }
                    }
                }
                
                // Update position tracking
                long currentPosition = getCurrentPosition();
                mCurrentPosition.set(currentPosition);
                
                // Notify listeners periodically
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    updatePositionAndNotify(currentPosition);
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "Playback loop interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Playback loop error", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "Playback loop exited");
    }
    
    /**
     * Handles song completion events.
     * 
     * <p>Flushes any remaining data from the pitch shifter pipeline and
     * transitions to COMPLETED state.</p>
     */
    private void handleCompletion() {
        // Flush remaining data from pitch shifter
        if (mPitchShifter != null && mAudioTrack != null) {
            mPitchShifter.flush();
            int available = mPitchShifter.numFrames();
            if (available > 0) {
                short[] outputBuffer = new short[available * mChannels];
                byte[] byteBuffer = new byte[available * mFrameSize];
                int received = mPitchShifter.receiveFrames(outputBuffer, available);
                if (received > 0) {
                    int samplesCount = received * mChannels;
                    for (int i = 0; i < samplesCount; i++) {
                        byteBuffer[i * 2] = (byte) (outputBuffer[i] & 0xFF);
                        byteBuffer[i * 2 + 1] = (byte) ((outputBuffer[i] >> 8) & 0xFF);
                    }
                    try {
                        mAudioTrack.write(byteBuffer, 0, samplesCount * 2);
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to write final samples", e);
                    }
                }
            }
        }
        
        mIsPlaying.set(false);
        mIsEOS.set(true);
        transitionTo(State.COMPLETED);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onCompletion());
        }
        
        Log.d(TAG, "Playback completed");
    }
    
    /**
     * Updates playback position and notifies the listener.
     *
     * @param positionMs Current position in milliseconds
     */
    private void updatePositionAndNotify(long positionMs) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onPositionUpdate(positionMs));
        }
    }
    
    /**
     * Recreates the AudioTrack when it enters a bad state.
     * 
     * <p>This is called when AudioTrack.write returns ERROR_DEAD_OBJECT (-6),
     * indicating the object is no longer valid and needs to be recreated.</p>
     */
    private void recreateAudioTrack() {
        Log.w(TAG, "Recreating AudioTrack due to bad state");
        
        boolean wasPlaying = (mState.get() == State.PLAYING);
        
        releaseAudioTrack();
        createAudioTrack();
        
        if (wasPlaying && mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "Playback restored after AudioTrack recreation");
            } catch (Exception e) {
                Log.e(TAG, "Failed to restore playback after recreation", e);
            }
        }
    }
    
    /**
     * Stops the playback thread and waits for it to terminate.
     */
    private void stopPlaybackThread() {
        mRunning.set(false);
        
        if (mPlaybackThread != null) {
            try {
                mPlaybackThread.interrupt();
                mPlaybackThread.join(1000);
            } catch (InterruptedException e) {
                Log.w(TAG, "Interrupted while waiting for playback thread", e);
                Thread.currentThread().interrupt();
            }
            mPlaybackThread = null;
        }
    }
    
    /**
     * Releases the AudioTrack resources.
     */
    private void releaseAudioTrack() {
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
                Log.d(TAG, "AudioTrack released");
            } catch (Exception e) {
                Log.e(TAG, "Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        mAudioSessionId = 0;
    }
    
    /**
     * Releases the decoder resources.
     */
    private void releaseDecoder() {
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
            Log.d(TAG, "Decoder released");
        }
        mIsEOS.set(false);
        mFormatValidated = false;
    }
    
    /**
     * Releases the PitchShifter resources.
     */
    private void releasePitchShifter() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
            Log.d(TAG, "PitchShifter released");
        }
    }
    
    /**
     * Internal release for preLoad operation.
     */
    private void releaseInternal() {
        mRunning.set(false);
        mDecoderActive.set(false);
        stopPlaybackThread();
        releaseAudioTrack();
        releaseDecoder();
        releasePitchShifter();
    }
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /**
     * Transitions the player to a new state.
     * 
     * <p>This method updates the state atomically and notifies the listener
     * of the state change.</p>
     *
     * @param newState The new state to transition to
     */
    private void transitionTo(State newState) {
        State oldState = mState.getAndSet(newState);
        
        if (oldState == newState) {
            return;
        }
        
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
        
        // Notify listener
        PlaybackListener listener = mListener;
        if (listener != null) {
            final State finalNewState = newState;
            final State finalOldState = oldState;
            mUiHandler.post(() -> listener.onStateChanged(finalNewState, finalOldState));
        }
    }
    
    /**
     * Transitions the player to ERROR state.
     *
     * @param error The error message
     */
    private void transitionToError(String error) {
        State oldState = mState.getAndSet(State.ERROR);
        
        if (oldState == State.ERROR) {
            return;
        }
        
        Log.e(TAG, "Error transition: " + oldState + " -> ERROR: " + error);
        
        // Stop playback
        mRunning.set(false);
        mDecoderActive.set(false);
        
        // Notify listener
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onError(error));
        }
        
        // Signal error to unblock waiting loadSong()
        synchronized (mReadyLock) {
            if (mReadyLatch != null) {
                mReadyLatch.countDown();
                mReadyLatch = null;
            }
        }
    }
    
    /**
     * Notifies the listener of an error (non-fatal).
     *
     * @param error The error message
     */
    private void notifyError(String error) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onError(error));
        }
    }
    
    /**
     * Checks if the player has been released and throws if so.
     *
     * @throws IllegalStateException if the player is in RELEASED state
     */
    private void checkNotReleased() {
        if (mState.get() == State.RELEASED) {
            throw new IllegalStateException("SoundTouchPlayer has been released");
        }
    }
    
    // ========================================================================
    // Broadcast Methods
    // ========================================================================
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "Broadcast SONG_PREPARED: duration=" + mDuration + 
              "ms, session=" + mAudioSessionId);
    }
}