package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class works alongside MediaPlayer as the primary player. It uses
 * AudioDecoder for decoding and PitchShifter for real-time pitch and tempo
 * adjustment. MediaPlayer is used as a fallback when SoundTouchPlayer fails.</p>
 * 
 * <h3>State Machine</h3>
 * <pre>
 * IDLE → PREPARING → READY → PLAYING ⇄ PAUSED → COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    private static final String TAG = "SoundTouchPlayer";
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    private static final String EXTRA_DURATION = "duration";
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    private static final String EXTRA_SONG_PATH = "song_path";
    
    private static final int BUFFER_FRAMES = 4096;
    private static final int MIN_BUFFER_MS = 250;
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    // ========================================================================
    // State Machine (Matches MusicService expectations)
    // ========================================================================
    
    public enum State {
        IDLE,       // Initial state, no resources allocated
        PREPARING,  // Decoder is being created
        READY,      // Player is ready to play (format validated)
        PLAYING,    // Actively playing audio
        PAUSED,     // Playback paused, position preserved
        COMPLETED,  // End of stream reached naturally
        ERROR,      // Error occurred, needs recovery or release
        RELEASED    // Resources released, terminal state
    }
    
    // ========================================================================
    // Playback Listener (Used by MusicService)
    // ========================================================================
    
    public interface PlaybackListener {
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        void onPrepared();
        void onCompletion();
        void onPositionUpdate(long positionMs);
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    @NonNull private final Context mContext;
    @Nullable private PlaybackListener mListener;
    private State mState = State.IDLE;
    private final Object mStateLock = new Object();
    
    // Audio components
    @Nullable private AudioDecoder mDecoder;
    @Nullable private PitchShifter mPitchShifter;
    @Nullable private AudioTrack mAudioTrack;
    
    // Audio format
    private int mSampleRate = 44100;
    private int mChannels = 2;
    private int mAudioSessionId = 0;
    private long mDuration = 0;
    private String mCurrentFilePath = null;
    private boolean mFormatValidated = false;
    
    // Playback state
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    // Pitch and tempo
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;
    
    // Threading
    @Nullable private Thread mPlaybackThread;
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    private final Object mPlaybackLock = new Object();
    
    // UI thread handler
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, state: IDLE");
    }
    
    // ========================================================================
    // Public API Methods (Called by MusicService)
    // ========================================================================
    
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    public boolean preLoad(@NonNull String filePath) {
        return loadSong(filePath);
    }
    
    public boolean loadSong(@NonNull String filePath) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.e(TAG, "loadSong: Player released");
                return false;
            }
            if (mState == State.PREPARING) {
                Log.d(TAG, "loadSong: Already preparing");
                return true;
            }
            mState = State.PREPARING;
        }
        
        mCurrentFilePath = filePath;
        mIsEOS.set(false);
        mSeekTarget.set(-1);
        
        // Start preparation on background thread
        new Thread(() -> {
            try {
                // Open decoder
                AudioDecoder decoder = new AudioDecoder();
                if (!decoder.open(filePath)) {
                    Log.e(TAG, "loadSong: Failed to open decoder");
                    transitionToError("Failed to open audio file");
                    return;
                }
                
                mDecoder = decoder;
                mSampleRate = decoder.getSampleRate();
                mChannels = decoder.getChannels();
                mDuration = decoder.getDuration();
                
                Log.d(TAG, "loadSong: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
                
                // Validate format
                if (mSampleRate <= 0 || mSampleRate > 192000) {
                    transitionToError("Invalid sample rate: " + mSampleRate);
                    return;
                }
                
                if (mChannels < 1 || mChannels > 2) {
                    transitionToError("Invalid channel count: " + mChannels);
                    return;
                }
                
                // Initialize PitchShifter
                if (PitchShifter.isLibraryAvailable()) {
                    mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                    mPitchShifter.setPitch(mCurrentPitch);
                    mPitchShifter.setTempo(mCurrentTempo);
                    Log.d(TAG, "loadSong: PitchShifter initialized");
                }
                
                // Create AudioTrack
                createAudioTrack();
                
                if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    transitionToError("AudioTrack creation failed");
                    return;
                }
                
                mAudioSessionId = mAudioTrack.getAudioSessionId();
                mFormatValidated = true;
                
                // Broadcast prepared event
                broadcastSongPrepared();
                
                // Notify listener
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> {
                        listener.onPrepared();
                        listener.onStateChanged(State.READY, State.PREPARING);
                    });
                }
                
                synchronized (mStateLock) {
                    if (mState != State.RELEASED && mState != State.ERROR) {
                        mState = State.READY;
                        Log.d(TAG, "loadSong: Transitioned to READY");
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "loadSong: Exception", e);
                transitionToError(e.getMessage());
            }
        }, "SoundTouch-Loader").start();
        
        return true;
    }
    
    public void play() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.w(TAG, "play: Player released");
                return;
            }
            
            if (!mFormatValidated) {
                Log.w(TAG, "play: Format not validated yet");
                return;
            }
            
            Log.d(TAG, "play: Called in state " + mState);
            
            if (mState == State.READY) {
                startPlayback();
            } else if (mState == State.PAUSED) {
                resumePlayback();
            } else if (mState == State.COMPLETED) {
                seekTo(0);
                startPlayback();
            } else if (mState == State.IDLE) {
                Log.w(TAG, "play: Called on IDLE, load a song first");
            } else if (mState == State.ERROR) {
                Log.w(TAG, "play: Cannot play in ERROR state");
                if (mListener != null) {
                    mUiHandler.post(() -> mListener.onError("Cannot play - player in error state"));
                }
            }
        }
    }
    
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.PLAYING) {
                mIsPaused.set(true);
                mIsPlaying.set(false);
                mState = State.PAUSED;
                
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.pause();
                        Log.d(TAG, "pause: AudioTrack paused");
                    } catch (Exception e) {
                        Log.e(TAG, "pause: Failed to pause AudioTrack", e);
                    }
                }
                
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.PLAYING));
                }
            }
        }
    }
    
    public void resume() {
        synchronized (mStateLock) {
            if (mState == State.PAUSED) {
                mIsPaused.set(false);
                mIsPlaying.set(true);
                mState = State.PLAYING;
                
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.play();
                        Log.d(TAG, "resume: AudioTrack resumed");
                    } catch (Exception e) {
                        Log.e(TAG, "resume: Failed to resume AudioTrack", e);
                    }
                }
                
                synchronized (mPlaybackLock) {
                    mPlaybackLock.notifyAll();
                }
                
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
                }
            }
        }
    }
    
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    mAudioTrack.flush();
                } catch (Exception e) {
                    Log.e(TAG, "stop: Failed to flush AudioTrack", e);
                }
            }
            
            if (mDecoder != null) {
                mDecoder.seekTo(0);
            }
            
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            
            mIsEOS.set(false);
            mCurrentPosition.set(0);
            mState = State.READY;
            
            Log.d(TAG, "stop: Player reset to READY");
        }
    }
    
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) {
                return;
            }
            
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mSeekTarget.set((int) clampedPosition);
            mCurrentPosition.set(clampedPosition);
            
            Log.d(TAG, "seekTo: Pending seek to " + clampedPosition + "ms");
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
        }
    }
    
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
            Log.d(TAG, "setPitch: " + semitones + " semitones");
        }
    }
    
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
            Log.d(TAG, "setTempo: " + tempo + "x");
        }
    }
    
    public long getDuration() {
        return mDuration;
    }
    
    public long getCurrentPosition() {
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    return positionMs;
                }
            } catch (Exception e) {
                // Fall through to cached position
            }
        }
        return mCurrentPosition.get();
    }
    
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get() && mState == State.PLAYING;
    }
    
    public boolean isPrepared() {
        return mState == State.READY || mState == State.PLAYING || mState == State.PAUSED;
    }
    
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    @NonNull
    public State getState() {
        return mState;
    }
    
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release: Releasing resources");
            
            mRunning.set(false);
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.interrupt();
                    mPlaybackThread.join(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.stop();
                    mAudioTrack.release();
                } catch (Exception e) {
                    Log.e(TAG, "release: Error releasing AudioTrack", e);
                }
                mAudioTrack = null;
            }
            
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            if (mDecoder != null) {
                mDecoder.release();
                mDecoder = null;
            }
            
            mState = State.RELEASED;
            Log.d(TAG, "release: Complete");
        }
    }
    
    // ========================================================================
    // Private Methods - AudioTrack Creation
    // ========================================================================
    
    private void createAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "createAudioTrack: Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        int minBufferSize = AudioTrack.getMinBufferSize(
            mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createAudioTrack: Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        Log.d(TAG, "createAudioTrack: " + mSampleRate + "Hz, " + mChannels + "ch");
    }
    
    // ========================================================================
    // Private Methods - Playback Management
    // ========================================================================
    
    private void startPlayback() {
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            mState = State.PLAYING;
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                } catch (Exception e) {
                    Log.e(TAG, "startPlayback: Failed to start AudioTrack", e);
                }
            }
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            return;
        }
        
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        mState = State.PLAYING;
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
            } catch (Exception e) {
                Log.e(TAG, "startPlayback: Failed to start AudioTrack", e);
            }
        }
        
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "startPlayback: Playback thread started");
    }
    
    private void resumePlayback() {
        if (mState != State.PAUSED) {
            return;
        }
        
        mIsPaused.set(false);
        mIsPlaying.set(true);
        mState = State.PLAYING;
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "resumePlayback: AudioTrack resumed");
            } catch (Exception e) {
                Log.e(TAG, "resumePlayback: Failed to resume", e);
            }
        }
        
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
        }
    }
    
    // ========================================================================
    // Private Methods - Main Playback Loop
    // ========================================================================
    
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        long decoderWaitStart = 0;
        
        Log.d(TAG, "playbackLoop: Started");
        
        while (mRunning.get() && mState != State.RELEASED) {
            try {
                // Check for pause
                if (mIsPaused.get() || mState != State.PLAYING) {
                    synchronized (mPlaybackLock) {
                        if (mIsPaused.get() || mState != State.PLAYING) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                
                // Handle pending seek
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0) {
                    performSeek(seekTarget);
                    decoderWaitStart = 0;
                }
                
                // Check for end of stream
                if (mIsEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                if (mDecoder == null || !mFormatValidated) {
                    Thread.sleep(10);
                    continue;
                }
                
                // Read PCM from decoder
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead < 0) {
                    Log.e(TAG, "playbackLoop: Decoder read error");
                    transitionToError("Decoder read error");
                    break;
                }
                
                if (framesRead == 0) {
                    decoderWaitStart += 10;
                    if (decoderWaitStart > 5000) {
                        Log.e(TAG, "playbackLoop: Decoder timeout");
                        transitionToError("Decoder timeout");
                        break;
                    }
                    Thread.sleep(10);
                    continue;
                }
                
                decoderWaitStart = 0;
                
                // Process through PitchShifter
                short[] samplesToWrite = inputBuffer;
                int sampleCount = framesRead * mChannels;
                
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                
                // Write to AudioTrack
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && mState == State.PLAYING) {
                        try {
                            mAudioTrack.play();
                        } catch (Exception e) {
                            Log.e(TAG, "playbackLoop: Failed to start AudioTrack", e);
                        }
                    }
                    
                    for (int i = 0; i < sampleCount; i++) {
                        byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                        byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                    }
                    
                    mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                }
                
                updateCurrentPosition();
                
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "playbackLoop: Interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "playbackLoop: Exception", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "playbackLoop: Exited");
    }
    
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs + "ms");
        
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mIsEOS.set(false);
        }
        
        if (mPitchShifter != null) {
            mPitchShifter.clear();
        }
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                if (mState == State.PLAYING) {
                    mAudioTrack.play();
                }
            } catch (Exception e) {
                Log.e(TAG, "performSeek: Error flushing AudioTrack", e);
            }
        }
        
        mCurrentPosition.set(positionMs);
    }
    
    private void updateCurrentPosition() {
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    mCurrentPosition.set(positionMs);
                }
            } catch (Exception e) {
                // Use cached position
            }
        }
    }
    
    private void handleCompletion() {
        Log.d(TAG, "handleCompletion: Song finished");
        
        mIsPlaying.set(false);
        mIsEOS.set(true);
        mState = State.COMPLETED;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onCompletion();
                listener.onStateChanged(State.COMPLETED, State.PLAYING);
            });
        }
        
        mRunning.set(false);
    }
    
    // ========================================================================
    // Private Methods - State Management
    // ========================================================================
    
    private void transitionToError(String error) {
        synchronized (mStateLock) {
            if (mState == State.ERROR || mState == State.RELEASED) {
                return;
            }
            
            Log.e(TAG, "transitionToError: " + error);
            mState = State.ERROR;
        }
        
        mRunning.set(false);
        mIsPlaying.set(false);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, null);
            });
        }
    }
    
    // ========================================================================
    // Private Methods - Broadcast
    // ========================================================================
    
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongPrepared: duration=" + mDuration + "ms, session=" + mAudioSessionId);
    }
}