package com.ark.llama;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This player completely replaces Android's MediaPlayer for audio playback when
 * pitch and tempo effects are needed. It uses the SoundTouch native library for
 * high-quality, independent pitch shifting and tempo adjustment.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>Independent Pitch Control</b> - Adjust pitch from -6 to +6 semitones
 *       without affecting playback speed</li>
 *   <li><b>Independent Tempo Control</b> - Adjust speed from 0.5x to 1.5x
 *       without affecting pitch</li>
 *   <li><b>Gapless Playback</b> - Smooth transitions between songs</li>
 *   <li><b>Seek Support</b> - Jump to any position in the song</li>
 *   <li><b>Real-time Updates</b> - Change pitch/tempo during playback</li>
 *   <li><b>Automatic Error Recovery</b> - Handles decoder errors gracefully</li>
 *   <li><b>Equalizer Integration</b> - Provides audio session ID for system equalizer</li>
 *   <li><b>Sample Rate Fallback</b> - Automatically uses supported sample rate if
 *       the file's native rate is not supported by the device</li>
 *   <li><b>Crash Resilience</b> - Comprehensive error handling with fallback to MediaPlayer</li>
 *   <li><b>Non-Blocking Operations</b> - No Thread.sleep() calls; uses state flags and handlers</li>
 * </ul>
 * 
 * <h3>Architecture</h3>
 * <p>The player follows this processing pipeline:</p>
 * <pre>
 * Audio File -> MediaExtractor -> MediaCodec (Decode to PCM) -> SoundTouch (Process) -> AudioTrack (Play)
 * </pre>
 * 
 * <h3>Supported Formats</h3>
 * <p>Any format supported by Android's MediaCodec, including:</p>
 * <ul>
 *   <li>MP3 (audio/mpeg)</li>
 *   <li>AAC (audio/mp4a-latm)</li>
 *   <li>FLAC (audio/flac)</li>
 *   <li>OGG (audio/ogg)</li>
 *   <li>M4A (audio/mp4)</li>
 *   <li>WAV (audio/x-wav)</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is designed for single-threaded use from the calling thread.
 * All public methods are safe to call from the UI thread; heavy operations
 * are offloaded to a background thread automatically. Seek operations use
 * non-blocking flags instead of Thread.sleep().</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer();
 * player.setListener(new SoundTouchPlayer.PlaybackListener() {
 *     public void onPrepared() { /* ready to play * / }
 *     public void onPlaybackStarted() { /* playing * / }
 *     public void onCompletion() { /* song finished * / }
 *     public void onError(String error) { /* handle error * / }
 * });
 * 
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * player.play();
 * player.release();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Buffer size in milliseconds for audio processing (100ms). */
    private static final int BUFFER_SIZE_MS = 100;
    
    /** Decoder timeout in microseconds (10ms). */
    private static final long DECODER_TIMEOUT_US = 10000;
    
    /** AudioTrack buffer multiplier for smooth playback. */
    private static final int AUDIO_TRACK_BUFFER_MULTIPLIER = 4;
    
    /** Maximum recovery attempts before giving up. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Maximum extractor retries for corrupt files. */
    private static final int MAX_EXTRACTOR_RETRIES = 2;
    
    /** Maximum empty buffers before decoder stall detection. */
    private static final int MAX_EMPTY_BUFFERS = 50;
    
    /** Progress update interval in milliseconds. */
    private static final int PROGRESS_UPDATE_INTERVAL_MS = 500;
    
    /** Minimum tempo (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch in semitones. */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch in semitones. */
    private static final float MAX_PITCH = 6.0f;
    
    /** Common sample rates to try as fallbacks (in order of preference). */
    private static final int[] FALLBACK_SAMPLE_RATES = {48000, 44100, 32000, 24000, 16000, 12000, 8000};
    
    /** Delay for retry operations in milliseconds (non-blocking via Handler). */
    private static final int RETRY_DELAY_MS = 100;
    
    /** Short delay for playback loop polling (non-blocking via postDelayed). */
    private static final int SHORT_POLL_DELAY_MS = 10;
    
    /** Medium delay for playback loop when waiting (non-blocking via postDelayed). */
    private static final int MEDIUM_POLL_DELAY_MS = 50;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    // Core components
    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private AudioProcessor mAudioProcessor;
    
    // Threading
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;
    private Handler mMainHandler;
    private Runnable mProgressUpdater;
    
    // State flags (Atomic for thread safety)
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mIsSeeking = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicBoolean mIsReleased = new AtomicBoolean(false);
    private final AtomicBoolean mIsEndOfStream = new AtomicBoolean(false);
    private int mRecoveryAttempts = 0;
    
    // Non-blocking seek state
    private final AtomicBoolean mSeekRequested = new AtomicBoolean(false);
    private long mPendingSeekPosition = -1;
    private final Object mSeekLock = new Object();
    
    // Retry state
    private String mRetryFilePath;
    private int mRetryCount;
    
    // Audio parameters
    private int mSampleRate = 44100;
    private int mOriginalSampleRate = 44100;
    private int mChannels = 2;
    private long mDuration = 0;
    private long mCurrentPosition = 0;
    
    // Track info
    private int mAudioTrackIndex = -1;
    private MediaFormat mAudioFormat;
    
    // Playback parameters
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;
    
    // Callback listener
    @Nullable
    private PlaybackListener mListener;
    
    // Decoder stall detection
    private int mConsecutiveEmptyBuffers = 0;
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback events.
     * 
     * <p>Implement this interface to receive callbacks about playback state
     * changes, errors, and position updates.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when playback starts (after play() is called and audio begins).
         */
        void onPlaybackStarted();
        
        /**
         * Called when playback is paused.
         */
        void onPlaybackPaused();
        
        /**
         * Called when playback resumes after being paused.
         */
        void onPlaybackResumed();
        
        /**
         * Called when the current song finishes playing.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * @param position Current position in milliseconds
         */
        void onPositionUpdate(long position);
        
        /**
         * Called when an error occurs during playback.
         * 
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the player is ready for playback (after loadSong succeeds).
         */
        void onPrepared();
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer.
     * 
     * <p>Creates the audio processor and sets up the progress update handler.
     * The player is not ready for playback until loadSong() is called.</p>
     */
    public SoundTouchPlayer() {
        mMainHandler = new Handler(Looper.getMainLooper());
        mAudioProcessor = new AudioProcessor();
        
        // Setup periodic progress updater
        mProgressUpdater = new Runnable() {
            @Override
            public void run() {
                if (mIsPlaying.get() && !mIsPaused.get() && !mIsSeeking.get() && mListener != null) {
                    updateCurrentPosition();
                    mListener.onPositionUpdate(mCurrentPosition);
                }
                if (mIsPlaying.get() && !mIsReleased.get()) {
                    mMainHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS);
                }
            }
        };
        
        Log.d(TAG, "SoundTouchPlayer created");
    }
    
    // ========================================================================
    // Sample Rate Helper Methods
    // ========================================================================
    
    /**
     * Checks if a sample rate is supported by AudioTrack on this device.
     * 
     * @param sampleRate The sample rate to check in Hz
     * @return true if supported, false otherwise
     */
    private boolean isSampleRateSupported(int sampleRate) {
        try {
            int bufferSize = AudioTrack.getMinBufferSize(sampleRate, 
                AudioFormat.CHANNEL_OUT_STEREO, 
                AudioFormat.ENCODING_PCM_16BIT);
            return bufferSize > 0;
        } catch (Exception e) {
            Log.w(TAG, "Sample rate " + sampleRate + " check failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Gets the best supported sample rate closest to the original.
     * If the original is supported, it returns the original.
     * Otherwise, it tries common fallback rates in order of preference.
     * 
     * @param originalRate The original sample rate from the audio file
     * @return A supported sample rate (always returns a valid rate)
     */
    private int getBestSupportedSampleRate(int originalRate) {
        if (isSampleRateSupported(originalRate)) {
            return originalRate;
        }
        
        Log.w(TAG, "Sample rate " + originalRate + " is NOT supported by this device");
        
        for (int rate : FALLBACK_SAMPLE_RATES) {
            if (isSampleRateSupported(rate)) {
                Log.w(TAG, "Falling back to supported sample rate: " + rate + " Hz (was " + originalRate + " Hz)");
                return rate;
            }
        }
        
        Log.w(TAG, "No common sample rate supported! Using 44100 Hz as last resort");
        return 44100;
    }
    
    /**
     * Checks if the decoder supports output at a different sample rate.
     * 
     * @param format The media format to check
     * @param targetRate The desired sample rate
     * @return true if the decoder can output at the target rate
     */
    private boolean canDecoderResample(@NonNull MediaFormat format, int targetRate) {
        String mime = format.getString(MediaFormat.KEY_MIME);
        if (mime == null) return false;
        return mime.startsWith("audio/");
    }
    
    // ========================================================================
    // AudioTrack Health Methods
    // ========================================================================
    
    /**
     * Checks if the AudioTrack is healthy and responsive.
     * Used to detect Audio HAL crashes.
     * 
     * @return true if AudioTrack is healthy, false otherwise
     */
    private boolean isAudioTrackHealthy() {
        if (mAudioTrack == null) return false;
        try {
            int state = mAudioTrack.getState();
            if (state != AudioTrack.STATE_INITIALIZED) {
                Log.w(TAG, "AudioTrack unhealthy: state=" + state);
                return false;
            }
            int testWrite = mAudioTrack.write(new short[0], 0, 0);
            return testWrite >= 0;
        } catch (Exception e) {
            Log.w(TAG, "AudioTrack health check failed", e);
            return false;
        }
    }
    
    /**
     * Handles AudioTrack write errors with appropriate recovery.
     * 
     * @param errorCode The error code from AudioTrack.write()
     */
    private void handleAudioTrackError(int errorCode) {
        Log.e(TAG, "AudioTrack write error: " + errorCode);
        if (errorCode == AudioTrack.ERROR_DEAD_OBJECT || 
            errorCode == AudioTrack.ERROR_INVALID_OPERATION) {
            Log.w(TAG, "AudioTrack dead or invalid, forcing full recovery");
            mAudioTrack = null;
            attemptRecovery();
        }
    }
    
    // ========================================================================
    // Public API
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Retry runnable for data source setup (non-blocking).
     */
    private final Runnable mRetryDataSourceRunnable = new Runnable() {
        @Override
        public void run() {
            if (!mIsReleased.get()) {
                attemptSetDataSource(mRetryFilePath, mRetryCount);
            }
        }
    };
    
    /**
     * Attempts to set the data source with retry support.
     * 
     * @param filePath The file path to load
     * @param retryCount Current retry attempt number
     */
    private void attemptSetDataSource(@NonNull String filePath, int retryCount) {
        if (mIsReleased.get()) return;
        
        try {
            mExtractor.setDataSource(filePath);
            continueLoadAfterDataSource(filePath);
        } catch (IOException e) {
            Log.w(TAG, "Failed to set data source, retry " + retryCount, e);
            if (retryCount >= MAX_EXTRACTOR_RETRIES) {
                notifyError("Cannot read audio file: " + e.getMessage());
                mIsPreparing.set(false);
            } else {
                mRetryFilePath = filePath;
                mRetryCount = retryCount + 1;
                mMainHandler.postDelayed(mRetryDataSourceRunnable, RETRY_DELAY_MS);
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "Failed to set data source, retry " + retryCount, e);
            if (retryCount >= MAX_EXTRACTOR_RETRIES) {
                notifyError("Cannot read audio file: " + e.getMessage());
                mIsPreparing.set(false);
            } else {
                mRetryFilePath = filePath;
                mRetryCount = retryCount + 1;
                mMainHandler.postDelayed(mRetryDataSourceRunnable, RETRY_DELAY_MS);
            }
        }
    }
    
    /**
     * Continues the loading process after data source is successfully set.
     * 
     * @param filePath The file path being loaded
     */
    private void continueLoadAfterDataSource(@NonNull String filePath) {
        try {
            // Find the audio track safely
            mAudioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                try {
                    MediaFormat format = mExtractor.getTrackFormat(i);
                    String mime = format.getString(MediaFormat.KEY_MIME);
                    if (mime != null && mime.startsWith("audio/")) {
                        mAudioTrackIndex = i;
                        mAudioFormat = format;
                        break;
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Failed to read track " + i, e);
                }
            }
            
            if (mAudioTrackIndex == -1 || mAudioFormat == null) {
                Log.e(TAG, "No audio track found in file");
                notifyError("No audio track found");
                mIsPreparing.set(false);
                return;
            }
            
            mExtractor.selectTrack(mAudioTrackIndex);
            
            try {
                mOriginalSampleRate = mAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                mSampleRate = mOriginalSampleRate;
                mChannels = mAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                mDuration = mAudioFormat.getLong(MediaFormat.KEY_DURATION);
            } catch (Exception e) {
                Log.e(TAG, "Failed to read audio format parameters", e);
                notifyError("Invalid audio format");
                mIsPreparing.set(false);
                return;
            }
            
            Log.d(TAG, "Audio format: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
            
            int bestRate = getBestSupportedSampleRate(mSampleRate);
            boolean needsResampling = (bestRate != mSampleRate);
            
            if (needsResampling) {
                if (canDecoderResample(mAudioFormat, bestRate)) {
                    MediaFormat decoderFormat = mAudioFormat;
                    decoderFormat.setInteger(MediaFormat.KEY_SAMPLE_RATE, bestRate);
                    mSampleRate = bestRate;
                    Log.d(TAG, "Decoder will resample from " + mOriginalSampleRate + " to " + mSampleRate + " Hz");
                } else {
                    mSampleRate = bestRate;
                    Log.w(TAG, "AudioTrack will resample from " + mOriginalSampleRate + " to " + mSampleRate + " Hz");
                }
            }
            
            if (!mAudioProcessor.configure(mSampleRate, mChannels)) {
                Log.e(TAG, "Failed to configure AudioProcessor");
                notifyError("Failed to configure audio processor");
                mIsPreparing.set(false);
                return;
            }
            
            mAudioProcessor.setPitchSemitones(mCurrentPitch);
            mAudioProcessor.setTempo(mCurrentTempo);
            
            String mime = mAudioFormat.getString(MediaFormat.KEY_MIME);
            if (mime == null) {
                Log.e(TAG, "No MIME type found in audio format");
                notifyError("Unknown audio format");
                mIsPreparing.set(false);
                return;
            }
            
            try {
                mDecoder = MediaCodec.createDecoderByType(mime);
                mDecoder.configure(mAudioFormat, null, null, 0);
                mDecoder.start();
            } catch (Exception e) {
                Log.e(TAG, "Failed to create or configure decoder", e);
                notifyError("Decoder initialization failed: " + e.getMessage());
                mIsPreparing.set(false);
                return;
            }
            
            if (!createAudioTrack()) {
                mIsPreparing.set(false);
                return;
            }
            
            if (mPlaybackThread == null || !mPlaybackThread.isAlive()) {
                mPlaybackThread = new HandlerThread("SoundTouchPlayer");
                mPlaybackThread.start();
                mPlaybackHandler = new Handler(mPlaybackThread.getLooper());
            }
            
            mIsPreparing.set(false);
            mIsEndOfStream.set(false);
            mCurrentPosition = 0;
            mRecoveryAttempts = 0;
            mConsecutiveEmptyBuffers = 0;
            mSeekRequested.set(false);
            mPendingSeekPosition = -1;
            
            Log.d(TAG, "Song loaded successfully: " + filePath);
            if (needsResampling) {
                Log.d(TAG, "  Resampled from " + mOriginalSampleRate + " to " + mSampleRate + " Hz");
            }
            
            if (mListener != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mListener != null) {
                            mListener.onPrepared();
                        }
                    }
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error during load continuation", e);
            notifyError("Error loading: " + e.getMessage());
            mIsPreparing.set(false);
        }
    }
    
    /**
     * Loads a song from file path.
     * 
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false if an error occurred
     */
    public boolean loadSong(@NonNull String filePath) {
        if (mIsReleased.get()) {
            Log.e(TAG, "Player is released, cannot load song");
            notifyError("Player is released");
            return false;
        }
        
        if (!PitchShifter.isLibraryAvailable()) {
            Log.e(TAG, "SoundTouch library not available");
            notifyError("SoundTouch library not available");
            return false;
        }
        
        mIsPreparing.set(true);
        
        try {
            releaseDecoder();
            releaseAudioTrack();
            
            mConsecutiveEmptyBuffers = 0;
            mSeekRequested.set(false);
            mPendingSeekPosition = -1;
            
            mExtractor = new MediaExtractor();
            attemptSetDataSource(filePath, 0);
            
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error loading song", e);
            notifyError("Unexpected error: " + e.getMessage());
            mIsPreparing.set(false);
            return false;
        }
    }
    
    /**
     * Starts or resumes playback.
     */
    public void play() {
        if (mIsReleased.get()) {
            Log.e(TAG, "Cannot play: player is released");
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Still preparing, will play when ready");
            return;
        }
        
        if (mAudioTrack == null) {
            Log.e(TAG, "Cannot play: AudioTrack not initialized");
            notifyError("AudioTrack not initialized");
            return;
        }
        
        if (mIsEndOfStream.get()) {
            Log.d(TAG, "Reached end of stream, restarting from beginning");
            seekTo(0);
        }
        
        mIsPlaying.set(true);
        mIsPaused.set(false);
        
        if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }
        
        if (mPlaybackHandler != null && !mIsSeeking.get()) {
            mPlaybackHandler.post(mPlaybackRunnable);
        }
        
        mMainHandler.removeCallbacks(mProgressUpdater);
        mMainHandler.post(mProgressUpdater);
        
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackStarted();
                    }
                }
            });
        }
        
        Log.d(TAG, "Playback started");
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        if (!mIsPlaying.get() || mIsPaused.get()) return;
        
        mIsPaused.set(true);
        
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.pause();
        }
        
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackPaused();
                    }
                }
            });
        }
        
        Log.d(TAG, "Playback paused");
    }
    
    /**
     * Resumes playback after being paused.
     */
    public void resume() {
        if (!mIsPlaying.get() || !mIsPaused.get()) return;
        
        mIsPaused.set(false);
        
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }
        
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackResumed();
                    }
                }
            });
        }
        
        Log.d(TAG, "Playback resumed");
    }
    
    /**
     * Stops playback and resets position to beginning.
     */
    public void stop() {
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mIsSeeking.set(false);
        mSeekRequested.set(false);
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
            } catch (Exception ignored) {}
        }
        
        if (mAudioProcessor != null) {
            mAudioProcessor.flush();
            mAudioProcessor.clear();
        }
        
        mCurrentPosition = 0;
        mIsEndOfStream.set(false);
        seekDecoderTo(0);
        
        Log.d(TAG, "Playback stopped");
    }
    
    /**
     * Performs the actual seek operation (non-blocking).
     * 
     * @param targetPosition Position to seek to in milliseconds
     */
    private void performSeek(long targetPosition) {
        synchronized (mSeekLock) {
            long clampedPosition = targetPosition;
            if (clampedPosition < 0) clampedPosition = 0;
            if (clampedPosition > mDuration) clampedPosition = mDuration;
            
            final long finalPosition = clampedPosition;
            boolean wasPlaying = mIsPlaying.get() && !mIsPaused.get();
            
            if (wasPlaying) {
                mIsPlaying.set(false);
            }
            
            mCurrentPosition = finalPosition;
            
            if (mAudioProcessor != null) {
                mAudioProcessor.flush();
                mAudioProcessor.clear();
            }
            
            mConsecutiveEmptyBuffers = 0;
            seekDecoderTo(finalPosition);
            mIsEndOfStream.set(false);
            
            if (wasPlaying) {
                mIsPlaying.set(true);
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.play();
                }
            }
            
            if (mListener != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mListener != null) {
                            mListener.onPositionUpdate(finalPosition);
                        }
                    }
                });
            }
        }
        
        Log.d(TAG, "Seeked to: " + targetPosition + "ms");
    }
    
    /**
     * Seeks to a specific position in the song (non-blocking).
     * 
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(final long positionMs) {
        synchronized (mSeekLock) {
            mPendingSeekPosition = positionMs;
            mSeekRequested.set(true);
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * @param semitones Pitch shift amount (positive = higher pitch, negative = lower)
     */
    public void setPitch(float semitones) {
        float clamped = semitones;
        if (clamped < MIN_PITCH) clamped = MIN_PITCH;
        if (clamped > MAX_PITCH) clamped = MAX_PITCH;
        mCurrentPitch = clamped;
        
        if (mAudioProcessor != null && mAudioProcessor.isInitialized()) {
            mAudioProcessor.setPitchSemitones(clamped);
            Log.d(TAG, "Pitch set to: " + clamped + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * @param tempo Tempo multiplier (0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        float clamped = tempo;
        if (clamped < MIN_TEMPO) clamped = MIN_TEMPO;
        if (clamped > MAX_TEMPO) clamped = MAX_TEMPO;
        mCurrentTempo = clamped;
        
        if (mAudioProcessor != null && mAudioProcessor.isInitialized()) {
            mAudioProcessor.setTempo(clamped);
            Log.d(TAG, "Tempo set to: " + clamped + "x");
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * @return Current position, or 0 if not playing
     */
    public long getCurrentPosition() {
        return mCurrentPosition;
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     * 
     * @return Song duration, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns true if playback is currently active (playing and not paused).
     * 
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get();
    }
    
    /**
     * Returns true if the player is prepared and ready for playback.
     * 
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return !mIsPreparing.get() && mAudioTrack != null && mDecoder != null;
    }
    
    /**
     * Returns the audio session ID for use with Android's equalizer.
     * 
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioTrack != null ? mAudioTrack.getAudioSessionId() : 0;
    }
    
    /**
     * Releases all resources used by the player.
     */
    public void release() {
        if (mIsReleased.get()) return;
        
        Log.d(TAG, "Releasing SoundTouchPlayer");
        
        mIsReleased.set(true);
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mIsSeeking.set(false);
        mSeekRequested.set(false);
        
        mMainHandler.removeCallbacks(mProgressUpdater);
        
        if (mPlaybackHandler != null) {
            mPlaybackHandler.removeCallbacks(mPlaybackRunnable);
        }
        
        if (mPlaybackThread != null) {
            mPlaybackThread.quitSafely();
            try {
                mPlaybackThread.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mPlaybackThread = null;
            mPlaybackHandler = null;
        }
        
        releaseDecoder();
        releaseAudioTrack();
        
        if (mAudioProcessor != null) {
            mAudioProcessor.release();
            mAudioProcessor = null;
        }
        
        Log.d(TAG, "SoundTouchPlayer released");
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack for PCM output.
     * 
     * @return true if AudioTrack was created successfully, false otherwise
     */
    private boolean createAudioTrack() {
        try {
            int channelConfig = (mChannels == 1) ? 
                AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            
            int bufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, 
                AudioFormat.ENCODING_PCM_16BIT);
            
            if (bufferSize <= 0) {
                Log.e(TAG, "Invalid buffer size: " + bufferSize + " for sample rate " + mSampleRate);
                if (mSampleRate != 44100) {
                    Log.w(TAG, "Trying fallback sample rate 44100 Hz");
                    mSampleRate = 44100;
                    bufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, 
                        AudioFormat.ENCODING_PCM_16BIT);
                    if (bufferSize <= 0) {
                        Log.e(TAG, "Still invalid buffer size: " + bufferSize);
                        notifyError("AudioTrack buffer size invalid");
                        return false;
                    }
                } else {
                    notifyError("AudioTrack buffer size invalid");
                    return false;
                }
            }
            
            bufferSize = bufferSize * AUDIO_TRACK_BUFFER_MULTIPLIER;
            
            int minBufferSizeMs = mSampleRate * mChannels * 2 * BUFFER_SIZE_MS / 1000;
            if (bufferSize < minBufferSizeMs) {
                bufferSize = minBufferSizeMs;
            }
            
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            
            AudioFormat format = new AudioFormat.Builder()
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build();
            
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed");
                notifyError("AudioTrack initialization failed");
                return false;
            }
            
            Log.d(TAG, "AudioTrack created: sampleRate=" + mSampleRate + 
                  "Hz, bufferSize=" + bufferSize + " bytes");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            notifyError("Failed to create AudioTrack: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Seeks the decoder to a specific position.
     * 
     * @param positionMs Target position in milliseconds
     */
    private void seekDecoderTo(long positionMs) {
        if (mExtractor == null) return;
        
        try {
            mExtractor.seekTo(positionMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            
            if (mDecoder != null) {
                try {
                    mDecoder.flush();
                } catch (Exception e) {
                    Log.w(TAG, "Failed to flush decoder during seek", e);
                }
            }
            
            Log.d(TAG, "Decoder seeked to: " + positionMs + "ms");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to seek decoder", e);
        }
    }
    
    /**
     * Updates the current position based on AudioTrack playback head.
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && !mIsSeeking.get() && !mSeekRequested.get()) {
            try {
                long framesPlayed = mAudioTrack.getPlaybackHeadPosition();
                if (framesPlayed > 0) {
                    long positionMs = framesPlayed * 1000L / mSampleRate;
                    if (positionMs > mCurrentPosition && positionMs < mDuration) {
                        mCurrentPosition = positionMs;
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to update current position", e);
            }
        }
    }
    
    /**
     * Releases the decoder and extractor resources.
     */
    private void releaseDecoder() {
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing decoder", e);
            }
            mDecoder = null;
        }
        
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing extractor", e);
            }
            mExtractor = null;
        }
        
        mAudioTrackIndex = -1;
        mAudioFormat = null;
    }
    
    /**
     * Releases the AudioTrack resources.
     */
    private void releaseAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
    }
    
    /**
     * Attempts to recover from a playback error.
     * 
     * @return true if recovery was successful, false if max attempts reached
     */
    private boolean attemptRecovery() {
        mRecoveryAttempts++;
        
        if (mRecoveryAttempts > MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached");
            notifyError("Playback failed after " + MAX_RECOVERY_ATTEMPTS + " attempts");
            return false;
        }
        
        Log.w(TAG, "Attempting recovery (" + mRecoveryAttempts + "/" + MAX_RECOVERY_ATTEMPTS + ")");
        
        final long position = mCurrentPosition;
        boolean wasPlaying = mIsPlaying.get();
        mIsPlaying.set(false);
        
        releaseAudioTrack();
        if (!createAudioTrack()) {
            return false;
        }
        
        mConsecutiveEmptyBuffers = 0;
        seekTo(position);
        
        if (wasPlaying && position < mDuration - 1000) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                mAudioTrack.play();
            }
        }
        
        return true;
    }
    
    /**
     * Notifies the listener of an error on the main thread.
     * 
     * @param error Error message
     */
    private void notifyError(@NonNull final String error) {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onError(error);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Playback Runnable
    // ========================================================================
    
    /**
     * Main playback loop that runs on a background thread.
     * No Thread.sleep() calls - uses Handler.postDelayed for non-blocking operation.
     */
    private final Runnable mPlaybackRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsReleased.get()) return;
            
            if (mSeekRequested.getAndSet(false)) {
                long targetPosition;
                synchronized (mSeekLock) {
                    targetPosition = mPendingSeekPosition;
                    mPendingSeekPosition = -1;
                }
                if (targetPosition >= 0) {
                    performSeek(targetPosition);
                }
                if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.postDelayed(this, SHORT_POLL_DELAY_MS);
                }
                return;
            }
            
            if (mIsPaused.get()) {
                if (mIsPlaying.get() && !mIsReleased.get() && mPlaybackHandler != null) {
                    mPlaybackHandler.postDelayed(this, MEDIUM_POLL_DELAY_MS);
                }
                return;
            }
            
            try {
                if (!isAudioTrackHealthy()) {
                    Log.w(TAG, "AudioTrack unhealthy, attempting recovery");
                    if (!attemptRecovery()) {
                        if (mPlaybackHandler != null && !mIsReleased.get()) {
                            mPlaybackHandler.postDelayed(this, MEDIUM_POLL_DELAY_MS);
                        }
                        return;
                    }
                    if (mPlaybackHandler != null && !mIsReleased.get()) {
                        mPlaybackHandler.post(this);
                    }
                    return;
                }
                
                if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    if (!attemptRecovery()) {
                        if (mPlaybackHandler != null && !mIsReleased.get()) {
                            mPlaybackHandler.postDelayed(this, MEDIUM_POLL_DELAY_MS);
                        }
                        return;
                    }
                }
                
                try {
                    int availableBuffer = mAudioTrack.getBufferSizeInFrames() - mAudioTrack.getPlaybackHeadPosition();
                    if (availableBuffer < mSampleRate / 10) {
                        if (mPlaybackHandler != null && !mIsReleased.get()) {
                            mPlaybackHandler.postDelayed(this, SHORT_POLL_DELAY_MS);
                        }
                        return;
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Failed to check buffer availability", e);
                    if (mPlaybackHandler != null && !mIsReleased.get()) {
                        mPlaybackHandler.postDelayed(this, SHORT_POLL_DELAY_MS);
                    }
                    return;
                }
                
                boolean reachedEOS = processDecoderOutput();
                
                if (reachedEOS) {
                    processRemainingAudio();
                    
                    mIsPlaying.set(false);
                    mIsEndOfStream.set(true);
                    
                    if (mListener != null) {
                        mMainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (mListener != null) {
                                    mListener.onCompletion();
                                }
                            }
                        });
                    }
                    return;
                }
                
                if (mIsPlaying.get() && !mIsPaused.get() && !mIsReleased.get() && mPlaybackHandler != null) {
                    mPlaybackHandler.post(this);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Playback error", e);
                if (!attemptRecovery()) {
                    notifyError("Playback error: " + e.getMessage());
                } else if (mIsPlaying.get() && !mIsReleased.get() && mPlaybackHandler != null) {
                    mPlaybackHandler.post(this);
                }
            }
        }
        
        /**
         * Processes decoder output and feeds to SoundTouch processor.
         * 
         * @return true if end of stream reached, false otherwise
         */
        private boolean processDecoderOutput() {
            if (mDecoder == null) return true;
            
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean eos = false;
            
            while (true) {
                int outputIndex;
                try {
                    outputIndex = mDecoder.dequeueOutputBuffer(info, DECODER_TIMEOUT_US);
                } catch (Exception e) {
                    Log.e(TAG, "Decoder dequeueOutputBuffer failed", e);
                    return false;
                }
                
                if (outputIndex >= 0) {
                    mConsecutiveEmptyBuffers = 0;
                    
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        eos = true;
                    }
                    
                    if (info.size > 0) {
                        ByteBuffer outputBuffer;
                        try {
                            outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to get output buffer", e);
                            mDecoder.releaseOutputBuffer(outputIndex, false);
                            continue;
                        }
                        
                        if (outputBuffer != null) {
                            processAudioBuffer(outputBuffer, info);
                        }
                    }
                    
                    try {
                        mDecoder.releaseOutputBuffer(outputIndex, false);
                    } catch (Exception e) {
                        Log.w(TAG, "Failed to release output buffer", e);
                    }
                    
                } else if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    mConsecutiveEmptyBuffers++;
                    if (mConsecutiveEmptyBuffers > MAX_EMPTY_BUFFERS) {
                        Log.e(TAG, "Decoder stalled: " + mConsecutiveEmptyBuffers + " empty buffers");
                        notifyError("Decoder stalled");
                        return true;
                    }
                    break;
                    
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat newFormat = mDecoder.getOutputFormat();
                    Log.d(TAG, "Output format changed: " + newFormat);
                    continue;
                    
                } else {
                    Log.w(TAG, "Unknown decoder output status: " + outputIndex);
                    break;
                }
            }
            
            return eos;
        }
        
        /**
         * Processes an audio buffer through SoundTouch and writes to AudioTrack.
         * 
         * @param buffer The decoded PCM buffer
         * @param info Buffer metadata (size, flags)
         */
        private void processAudioBuffer(ByteBuffer buffer, MediaCodec.BufferInfo info) {
            if (mAudioProcessor == null || mAudioTrack == null) return;
            
            if (info.size <= 0) {
                Log.w(TAG, "Invalid buffer size: " + info.size);
                return;
            }
            
            if (info.size % 2 != 0) {
                Log.w(TAG, "Buffer size not even, skipping: " + info.size);
                return;
            }
            
            try {
                buffer.order(ByteOrder.LITTLE_ENDIAN);
                
                if (buffer.remaining() < info.size) {
                    Log.w(TAG, "Buffer underflow, skipping: remaining=" + buffer.remaining() + 
                          ", needed=" + info.size);
                    return;
                }
                
                int sampleCount = info.size / 2;
                short[] pcmData = new short[sampleCount];
                
                for (int i = 0; i < sampleCount && buffer.hasRemaining(); i++) {
                    pcmData[i] = buffer.getShort();
                }
                
                int frames = pcmData.length / mChannels;
                if (frames <= 0) return;
                
                short[] processed = mAudioProcessor.process(pcmData, frames);
                
                if (processed != null && processed.length > 0) {
                    int written = mAudioTrack.write(processed, 0, processed.length);
                    if (written < 0) {
                        handleAudioTrackError(written);
                    }
                }
                
            } catch (BufferUnderflowException e) {
                Log.w(TAG, "Buffer underflow during conversion", e);
            } catch (Exception e) {
                Log.e(TAG, "Error processing audio buffer", e);
            }
        }
        
        /**
         * Flushes any remaining audio from the SoundTouch processor.
         * Called at the end of the song to ensure all processed audio
         * is played before stopping. No Thread.sleep() is used.
         */
        private void processRemainingAudio() {
            if (mAudioProcessor == null || mAudioTrack == null) return;
            
            try {
                mAudioProcessor.flush();
                
                short[] remaining;
                int emptyCount = 0;
                int maxEmptyAttempts = 10;
                
                while (emptyCount < maxEmptyAttempts) {
                    remaining = tryReceiveOnce();
                    if (remaining != null && remaining.length > 0) {
                        int written = mAudioTrack.write(remaining, 0, remaining.length);
                        if (written < 0) {
                            handleAudioTrackError(written);
                            break;
                        }
                        emptyCount = 0;
                    } else {
                        emptyCount++;
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Error during remaining audio flush", e);
            }
        }
        
        /**
         * Tries to receive output from SoundTouch once (non-blocking).
         * 
         * @return Processed audio buffer, or null if none available
         */
        @Nullable
        private short[] tryReceiveOnce() {
            if (mAudioProcessor == null) return null;
            
            try {
                int availableFrames = mAudioProcessor.numAvailableFrames();
                if (availableFrames == 0) {
                    return null;
                }
                
                short[] output = new short[availableFrames * mChannels];
                int received = mAudioProcessor.receive(output);
                
                if (received > 0) {
                    if (received < availableFrames) {
                        short[] trimmed = new short[received * mChannels];
                        System.arraycopy(output, 0, trimmed, 0, trimmed.length);
                        return trimmed;
                    }
                    return output;
                }
                
            } catch (Exception e) {
                Log.w(TAG, "Error receiving from SoundTouch", e);
            }
            
            return null;
        }
    };
}