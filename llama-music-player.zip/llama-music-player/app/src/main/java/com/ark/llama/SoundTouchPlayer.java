package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides real-time pitch and tempo shifting using the SoundTouch native library.
 * It is the primary player for Llama Music Player, with MediaPlayer as a fallback only when
 * SoundTouch fails at runtime.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <pre>
 * Audio File -> AudioDecoder -> PitchShifter (optional) -> AudioTrack -> Speakers
 * </pre>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control (-6 to +6 semitones)</li>
 *   <li>Independent tempo control (0.5x to 1.5x speed)</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Proper AudioTrack priming to prevent buffer underruns</li>
 *   <li>Seamless seek and state management</li>
 *   <li>Broadcasts audio session ID for equalizer attachment</li>
 * </ul>
 * 
 * <h3>State Machine</h3>
 * <pre>
 * IDLE -> PREPARING -> READY -> PLAYING ⇄ PAUSED -> COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * <h3>Playback Listener</h3>
 * <p>Clients can register a {@link PlaybackListener} to receive state change,
 * position update, and error notifications.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() { ... });
 * 
 * // Pre-load song (duration and audio session become available)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Start playback
 * player.play();
 * 
 * // Adjust pitch and tempo
 * player.setPitch(2.0f);   // raise by 2 semitones
 * player.setTempo(1.25f);  // speed up by 25%
 * 
 * // Seek to 30 seconds
 * player.seekTo(30000);
 * 
 * // Clean up
 * player.release();
 * </pre>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #release()} when the player is no longer needed to
 * free native resources and prevent memory leaks.</p>
 * 
 * @see AudioDecoder
 * @see PitchShifter
 * @see AudioTrack
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action when a song is prepared (duration and session ID available). */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Number of stereo frames per internal buffer (increased to 8192 for smoother flow). */
    private static final int BUFFER_FRAMES = 8192;
    
    /** Minimum buffer duration in milliseconds for AudioTrack. */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Interval for position update callbacks to UI (milliseconds). */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Number of chunks to write to AudioTrack before calling play() (priming). */
    private static final int PRIME_CHUNK_COUNT = 4;
    
    // ========================================================================
    // State Enumeration
    // ========================================================================
    
    /**
     * Represents the current state of the player.
     */
    public enum State {
        /** Initial state, no song loaded. */
        IDLE,
        /** Loading song asynchronously. */
        PREPARING,
        /** Song loaded and ready to play. */
        READY,
        /** Actively playing audio. */
        PLAYING,
        /** Playback paused. */
        PAUSED,
        /** Song finished normally. */
        COMPLETED,
        /** An error occurred. */
        ERROR,
        /** Player resources released. */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback events.
     * <p>All callbacks are delivered on the main UI thread.</p>
     */
    public interface PlaybackListener {
        /**
         * Called when the player state changes.
         * @param newState The new state
         * @param oldState The previous state (may be null)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /** Called when the song is prepared and ready for playback. */
        void onPrepared();
        
        /** Called when the song completes normally. */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs.
         * @param error Description of the error
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    @NonNull private final Context mContext;
    @Nullable private PlaybackListener mListener;
    private State mState = State.IDLE;
    private final Object mStateLock = new Object();
    
    @Nullable private AudioDecoder mDecoder;
    @Nullable private PitchShifter mPitchShifter;
    @Nullable private AudioTrack mAudioTrack;
    
    private int mSampleRate = 44100;
    private int mChannels = 2;
    private int mAudioSessionId = 0;
    private long mDuration = 0;
    private String mCurrentFilePath = null;
    private boolean mFormatValidated = false;
    
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;
    
    @Nullable private Thread mPlaybackThread;
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    private final Object mPlaybackLock = new Object();
    private final Object mDecoderLock = new Object();
    
    // Priming state (reset on seek)
    private final AtomicBoolean mPrimed = new AtomicBoolean(false);
    private volatile int mPrimeCount = 0;
    
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer.
     * 
     * <p>The player is initially in {@link State#IDLE}. Call {@link #loadSong(String)}
     * or {@link #preLoad(String)} to prepare a song.</p>
     *
     * @param context Application context (used for broadcasts and audio session)
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback listener.
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method is equivalent to {@link #loadSong(String)} and provides
     * early access to song duration and audio session ID for equalizer attachment.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully, false if player is released
     */
    public boolean preLoad(@NonNull String filePath) {
        return loadSong(filePath);
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method is asynchronous. When loading completes successfully,
     * {@link PlaybackListener#onPrepared()} is called and the state becomes
     * {@link State#READY}.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully, false if player is released
     */
    public boolean loadSong(@NonNull String filePath) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) return false;
            if (mState == State.PREPARING) return true;
            mState = State.PREPARING;
        }
        mCurrentFilePath = filePath;
        mIsEOS.set(false);
        mSeekTarget.set(-1);
        
        new Thread(() -> {
            try {
                AudioDecoder decoder = new AudioDecoder();
                if (!decoder.open(filePath)) {
                    transitionToError("Failed to open audio file");
                    return;
                }
                mDecoder = decoder;
                mSampleRate = decoder.getSampleRate();
                mChannels = decoder.getChannels();
                mDuration = decoder.getDuration();
                Log.d(TAG, "loadSong: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
                if (mSampleRate <= 0 || mSampleRate > 192000 || mChannels < 1 || mChannels > 2) {
                    transitionToError("Invalid audio format");
                    return;
                }
                if (PitchShifter.isLibraryAvailable()) {
                    mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                    mPitchShifter.setPitch(mCurrentPitch);
                    mPitchShifter.setTempo(mCurrentTempo);
                }
                createAudioTrack();
                if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    transitionToError("AudioTrack creation failed");
                    return;
                }
                mAudioSessionId = mAudioTrack.getAudioSessionId();
                mFormatValidated = true;
                broadcastSongPrepared();
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> {
                        listener.onPrepared();
                        listener.onStateChanged(State.READY, State.PREPARING);
                    });
                }
                synchronized (mStateLock) {
                    if (mState != State.RELEASED && mState != State.ERROR) {
                        mState = State.READY;
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "loadSong exception", e);
                transitionToError(e.getMessage());
            }
        }, "SoundTouch-Loader").start();
        return true;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in {@link State#READY}, playback starts from the beginning.
     * If in {@link State#PAUSED}, playback resumes from the current position.
     * If in {@link State#COMPLETED}, playback restarts from the beginning.</p>
     */
    public void play() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) return;
            if (mState == State.READY) {
                startPlayback();
            } else if (mState == State.PAUSED) {
                resumePlayback();
            } else if (mState == State.COMPLETED) {
                seekTo(0);
                startPlayback();
            }
        }
    }
    
    /**
     * Pauses playback if currently playing.
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.PLAYING) {
                mIsPaused.set(true);
                mIsPlaying.set(false);
                mState = State.PAUSED;
                if (mAudioTrack != null) {
                    try { mAudioTrack.pause(); } catch (Exception e) { Log.e(TAG, "pause error", e); }
                }
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.PLAYING));
                }
            }
        }
    }
    
    /**
     * Resumes playback from a paused state.
     */
    public void resume() {
        synchronized (mStateLock) {
            if (mState == State.PAUSED) {
                mIsPaused.set(false);
                mIsPlaying.set(true);
                mState = State.PLAYING;
                if (mAudioTrack != null) {
                    try { mAudioTrack.play(); } catch (Exception e) { Log.e(TAG, "resume error", e); }
                }
                synchronized (mPlaybackLock) {
                    mPlaybackLock.notifyAll();
                }
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player to READY state.
     * The current song remains loaded but position resets to beginning.
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) return;
            mIsPlaying.set(false);
            mIsPaused.set(false);
            if (mAudioTrack != null) {
                try { mAudioTrack.pause(); mAudioTrack.flush(); } catch (Exception e) { Log.e(TAG, "stop error", e); }
            }
            if (mDecoder != null) mDecoder.seekTo(0);
            if (mPitchShifter != null) mPitchShifter.clear();
            mIsEOS.set(false);
            mCurrentPosition.set(0);
            mState = State.READY;
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>If the player is in a play state, playback will continue from the new position.
     * The seek operation resets the AudioTrack priming state to ensure smooth playback.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) return;
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mSeekTarget.set((int) clampedPosition);
            mCurrentPosition.set(clampedPosition);
            // Reset priming state for the seek
            mPrimed.set(false);
            mPrimeCount = 0;
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * Recommended range: -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) mPitchShifter.setPitch(semitones);
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down, greater than 1.0 speed up.
     * Recommended range: 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) mPitchShifter.setTempo(tempo);
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song loaded
     */
    public long getDuration() { return mDuration; }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) return positionMs;
            } catch (Exception ignored) {}
        }
        return mCurrentPosition.get();
    }
    
    /**
     * Checks if the player is currently playing audio.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() { return mIsPlaying.get() && !mIsPaused.get() && mState == State.PLAYING; }
    
    /**
     * Checks if a song is loaded and the player is ready (or playing/paused).
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() { return mState == State.READY || mState == State.PLAYING || mState == State.PAUSED; }
    
    /**
     * Returns the audio session ID for the current AudioTrack.
     * <p>This ID is used by {@link EqualizerManager} to attach an equalizer.</p>
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() { return mAudioSessionId; }
    
    /**
     * Returns the current player state.
     *
     * @return Current {@link State}
     */
    @NonNull public State getState() { return mState; }
    
    /**
     * Releases all resources held by the player.
     * <p>After calling this, the player cannot be used again.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) return;
            mRunning.set(false);
            synchronized (mPlaybackLock) { mPlaybackLock.notifyAll(); }
            if (mPlaybackThread != null) {
                try { mPlaybackThread.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                mPlaybackThread = null;
            }
            if (mAudioTrack != null) {
                try { mAudioTrack.stop(); mAudioTrack.release(); } catch (Exception e) { Log.e(TAG, "release error", e); }
                mAudioTrack = null;
            }
            if (mPitchShifter != null) { mPitchShifter.close(); mPitchShifter = null; }
            if (mDecoder != null) { mDecoder.release(); mDecoder = null; }
            mState = State.RELEASED;
        }
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack instance.
     * Uses the current sample rate and channel count.
     */
    private void createAudioTrack() {
        if (mAudioTrack != null) {
            try { mAudioTrack.release(); } catch (Exception e) { Log.e(TAG, "release old track error", e); }
            mAudioTrack = null;
        }
        int channelConfig = (mChannels == 2) ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize=" + minBufferSize);
            return;
        }
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + "ch, buffer=" + bufferSize);
    }
    
    /**
     * Starts the playback thread and resets priming state.
     */
    private void startPlayback() {
        mPrimed.set(false);
        mPrimeCount = 0;
        
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            mState = State.PLAYING;
            if (mAudioTrack != null) {
                try { mAudioTrack.play(); } catch (Exception e) { Log.e(TAG, "startPlayback play error", e); }
            }
            synchronized (mPlaybackLock) { mPlaybackLock.notifyAll(); }
            return;
        }
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        mState = State.PLAYING;
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        Log.d(TAG, "Playback thread started");
    }
    
    /**
     * Resumes playback from paused state.
     */
    private void resumePlayback() {
        if (mState != State.PAUSED) return;
        mIsPaused.set(false);
        mIsPlaying.set(true);
        mState = State.PLAYING;
        if (mAudioTrack != null) {
            try { mAudioTrack.play(); } catch (Exception e) { Log.e(TAG, "resume error", e); }
        }
        synchronized (mPlaybackLock) { mPlaybackLock.notifyAll(); }
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
        }
    }
    
    /**
     * Main playback loop.
     * <p>Continuously reads PCM data from the decoder, optionally processes through
     * PitchShifter, and writes to AudioTrack. Implements proper priming: the first
     * PRIME_CHUNK_COUNT chunks are written before calling play() to prevent underrun.</p>
     */
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Playback loop started");
        
        while (mRunning.get() && mState != State.RELEASED) {
            try {
                if (mIsPaused.get() || mState != State.PLAYING) {
                    synchronized (mPlaybackLock) {
                        if (mIsPaused.get() || mState != State.PLAYING) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0) performSeek(seekTarget);
                if (mIsEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                if (mDecoder == null || !mFormatValidated) {
                    synchronized (mDecoderLock) {
                        if (mDecoder == null || !mFormatValidated) {
                            mDecoderLock.wait(100);
                            continue;
                        }
                    }
                    continue;
                }
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                if (framesRead < 0) {
                    transitionToError("Decoder read error");
                    break;
                }
                if (framesRead == 0) continue;
                
                short[] samplesToWrite = inputBuffer;
                int sampleCount = framesRead * mChannels;
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                for (int i = 0; i < sampleCount; i++) {
                    byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                    byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                }
                int written = mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                if (written < 0) {
                    Log.e(TAG, "AudioTrack.write error: " + written);
                    transitionToError("AudioTrack write error");
                    break;
                }
                // Prime the track: after writing PRIME_CHUNK_COUNT chunks, start playback
                if (!mPrimed.get()) {
                    mPrimeCount++;
                    if (mPrimeCount >= PRIME_CHUNK_COUNT && mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        try {
                            mAudioTrack.play();
                            mPrimed.set(true);
                            Log.d(TAG, "AudioTrack primed and playing");
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to start AudioTrack after priming", e);
                        }
                    }
                } else if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && mState == State.PLAYING) {
                    try { mAudioTrack.play(); } catch (Exception e) { Log.e(TAG, "Re-start AudioTrack failed", e); }
                }
                updateCurrentPosition();
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
            } catch (InterruptedException e) {
                Log.d(TAG, "Playback loop interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Playback loop exception", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        Log.d(TAG, "Playback loop exited");
    }
    
    /**
     * Performs a seek operation by flushing decoder and AudioTrack.
     * Resets priming state for the seek.
     *
     * @param positionMs Target position in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs);
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mIsEOS.set(false);
        }
        if (mPitchShifter != null) mPitchShifter.clear();
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                mPrimed.set(false);
                mPrimeCount = 0;
            } catch (Exception e) { Log.e(TAG, "seek flush error", e); }
        }
        mCurrentPosition.set(positionMs);
    }
    
    /**
     * Updates the cached current position from AudioTrack's playback head.
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) mCurrentPosition.set(positionMs);
            } catch (Exception ignored) {}
        }
    }
    
    /**
     * Handles normal song completion.
     */
    private void handleCompletion() {
        Log.d(TAG, "Song completed");
        mIsPlaying.set(false);
        mIsEOS.set(true);
        mState = State.COMPLETED;
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onCompletion();
                listener.onStateChanged(State.COMPLETED, State.PLAYING);
            });
        }
        mRunning.set(false);
    }
    
    /**
     * Transitions the player to ERROR state and notifies listener.
     *
     * @param error Description of the error
     */
    private void transitionToError(String error) {
        synchronized (mStateLock) {
            if (mState == State.ERROR || mState == State.RELEASED) return;
            Log.e(TAG, "Error: " + error);
            mState = State.ERROR;
        }
        mRunning.set(false);
        mIsPlaying.set(false);
        synchronized (mPlaybackLock) { mPlaybackLock.notifyAll(); }
        synchronized (mDecoderLock) { mDecoderLock.notifyAll(); }
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, null);
            });
        }
    }
    
    /**
     * Broadcasts an intent with song duration and audio session ID.
     * Used by EqualizerManager and UI to get metadata before playback starts.
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "Broadcast prepared: dur=" + mDuration + ", session=" + mAudioSessionId);
    }
}