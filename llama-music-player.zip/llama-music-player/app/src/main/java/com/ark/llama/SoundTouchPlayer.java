package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Pre-load capability for immediate duration and audio session access</li>
 * </ul>
 * 
 * <h3>Architecture</h3>
 * <pre>
 * Audio File -> AudioDecoder -> PitchShifter (SoundTouch) -> AudioTrack -> Speakers
 * </pre>
 * 
 * <h3>Pre-load Feature</h3>
 * <p>The {@link #preLoad(String)} method allows the player to initialize the decoder
 * and create an AudioTrack instance without starting playback. This provides:</p>
 * <ul>
 *   <li>Immediate access to song duration for UI display</li>
 *   <li>Early creation of audio session for equalizer attachment</li>
 *   <li>Faster response when user presses play</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() { ... }
 *     public void onCompletion() { ... }
 * });
 * 
 * // Pre-load for duration and session (optional)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Or load and play immediately
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.play();
 * 
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * 
 * player.release();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Default sample rate (44.1 kHz). */
    private static final int DEFAULT_SAMPLE_RATE = 44100;
    
    /** Default number of channels (stereo). */
    private static final int DEFAULT_CHANNELS = 2;
    
    /** Buffer size multiplier for AudioTrack (200ms buffer). */
    private static final int BUFFER_SIZE_MULTIPLIER = 2;
    
    /** Minimum buffer size in milliseconds. */
    private static final int MIN_BUFFER_MS = 100;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcast sending. */
    @NonNull
    private final Context mContext;
    
    /** Native pitch shifter instance (SoundTouch wrapper). */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Audio decoder for reading various audio formats. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** AudioTrack for PCM output to speakers/headphones. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Lock object for thread-safe operations. */
    @NonNull
    private final Object mLock = new Object();
    
    /** Flag indicating if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Flag indicating if the player is paused. */
    private volatile boolean mIsPaused = false;
    
    /** Flag indicating if a song is loaded and ready. */
    private volatile boolean mIsPrepared = false;
    
    /** Flag indicating if the player is in pre-load state (loaded but not playing). */
    private volatile boolean mIsPreloadedOnly = false;
    
    /** Flag indicating if the playback thread should stop. */
    private volatile boolean mShouldStop = false;
    
    /** Current sample rate in Hz. */
    private int mSampleRate = DEFAULT_SAMPLE_RATE;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = DEFAULT_CHANNELS;
    
    /** Number of samples per frame (equals channel count). */
    private int mFrameSize = DEFAULT_CHANNELS;
    
    /** Duration of the current song in milliseconds. */
    private long mDuration = 0;
    
    /** File path of the currently loaded song. */
    @Nullable
    private String mCurrentFilePath = null;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Target seek position in milliseconds (set during seek operation). */
    private volatile int mSeekTarget = -1;
    
    /** Playback thread for continuous audio processing. */
    @Nullable
    private Thread mPlaybackThread;
    
    // ========================================================================
    // Inner Interfaces and Classes
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>Implement this interface to be notified of playback state changes
     * such as start, pause, completion, and errors.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when playback starts (after play() is called and audio begins).
         */
        void onPlaybackStarted();
        
        /**
         * Called when playback is paused.
         */
        void onPlaybackPaused();
        
        /**
         * Called when playback resumes after being paused.
         */
        void onPlaybackResumed();
        
        /**
         * Called when the current song completes playback.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         *
         * @param position Current position in milliseconds
         */
        void onPositionUpdate(long position);
        
        /**
         * Called when an error occurs during playback.
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * The audio session is now available and duration is known.
         */
        void onPrepared();
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>Initializes the native pitch shifter with default parameters.
     * The actual sample rate and channel count will be set when a song is loaded.</p>
     *
     * @param context Application context for sending broadcasts
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        
        if (PitchShifter.isLibraryAvailable()) {
            mPitchShifter = new PitchShifter(DEFAULT_SAMPLE_RATE, DEFAULT_CHANNELS);
            Log.d(TAG, "SoundTouchPlayer initialized successfully");
        } else {
            Log.e(TAG, "PitchShifter library not available!");
        }
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     *
     * @param listener The listener to receive events (can be null)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        synchronized (mLock) {
            mListener = listener;
        }
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method initializes the decoder and creates an AudioTrack instance,
     * which provides immediate access to:
     * <ul>
     *   <li>Song duration (for UI display)</li>
     *   <li>Audio session ID (for equalizer attachment)</li>
     * </ul>
     * </p>
     * 
     * <p>The player enters a "pre-loaded" state where play() can be called
     * immediately without additional loading time.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was successful, false otherwise
     */
    public boolean preLoad(@NonNull String filePath) {
        synchronized (mLock) {
            // Validate file exists
            File file = new File(filePath);
            if (!file.exists() || !file.canRead()) {
                Log.e(TAG, "preLoad: File not accessible: " + filePath);
                notifyError("File not accessible: " + filePath);
                return false;
            }
            
            try {
                // Release existing decoder if any
                if (mDecoder != null) {
                    mDecoder.release();
                    mDecoder = null;
                }
                
                // Create and open decoder
                mDecoder = new AudioDecoder();
                if (!mDecoder.open(filePath)) {
                    Log.e(TAG, "preLoad: Failed to open decoder for: " + filePath);
                    notifyError("Failed to open audio file");
                    return false;
                }
                
                // Extract audio metadata
                mDuration = mDecoder.getDuration();
                mSampleRate = mDecoder.getSampleRate();
                mChannels = mDecoder.getChannels();
                mFrameSize = mChannels;
                mCurrentFilePath = filePath;
                
                Log.d(TAG, "preLoad: File info - duration=" + mDuration + "ms, " +
                      "sampleRate=" + mSampleRate + "Hz, channels=" + mChannels);
                
                // Update pitch shifter with correct parameters
                if (mPitchShifter != null) {
                    mPitchShifter.close();
                }
                mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                
                // Create AudioTrack to get audio session (without playing)
                initAudioTrackForPreload();
                
                mIsPrepared = true;
                mIsPreloadedOnly = true;
                mIsPlaying = false;
                mIsPaused = false;
                
                Log.d(TAG, "preLoad: Success - session=" + mAudioSessionId);
                
                // Notify listeners that player is prepared
                notifyPrepared();
                
                // Broadcast that song is ready for UI
                broadcastSongPrepared();
                
                return true;
                
            } catch (Exception e) {
                Log.e(TAG, "preLoad: Exception", e);
                notifyError("Pre-load failed: " + e.getMessage());
                return false;
            }
        }
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method internally calls {@link #preLoad(String)} to initialize
     * the decoder and create the audio session. The player will be ready
     * to play immediately after this method returns true.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false otherwise
     */
    public boolean loadSong(@NonNull String filePath) {
        if (!preLoad(filePath)) {
            return false;
        }
        
        synchronized (mLock) {
            mIsPreloadedOnly = false;
        }
        
        return true;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in pre-loaded state (song loaded but not playing),
     * this method starts the playback thread. If already playing, this method
     * does nothing. If paused, it resumes playback.</p>
     */
    public void play() {
        synchronized (mLock) {
            if (!mIsPrepared) {
                Log.w(TAG, "play: Player not prepared, call loadSong() first");
                return;
            }
            
            // If already playing, do nothing
            if (mIsPlaying && !mIsPaused) {
                Log.d(TAG, "play: Already playing");
                return;
            }
            
            // If paused, just resume
            if (mIsPaused) {
                resumePlayback();
                return;
            }
            
            // Start new playback
            startPlayback();
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()} or {@link #resume()}.</p>
     */
    public void pause() {
        synchronized (mLock) {
            if (!mIsPlaying || mIsPaused) {
                return;
            }
            
            pausePlayback();
        }
    }
    
    /**
     * Resumes playback after pause.
     */
    public void resume() {
        synchronized (mLock) {
            if (!mIsPrepared || !mIsPaused) {
                return;
            }
            
            resumePlayback();
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>After calling stop, the player remains prepared and can be restarted
     * by calling {@link #play()} which will restart from the beginning.</p>
     */
    public void stop() {
        synchronized (mLock) {
            if (!mIsPrepared) {
                return;
            }
            
            stopPlayback();
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation happens asynchronously and takes effect
     * immediately. The player will continue playing from the new position.</p>
     *
     * @param positionMs Position in milliseconds to seek to
     */
    public void seekTo(int positionMs) {
        synchronized (mLock) {
            if (!mIsPrepared || mDecoder == null) {
                Log.w(TAG, "seekTo: Player not prepared");
                return;
            }
            
            // Clamp position to valid range
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mSeekTarget = (int) clampedPosition;
            
            // Seek in decoder (will be processed in playback thread)
            mDecoder.seekTo((int) clampedPosition);
            
            // Clear pitch shifter buffers for clean transition
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            
            Log.d(TAG, "seekTo: " + clampedPosition + "ms");
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        synchronized (mLock) {
            if (mPitchShifter != null) {
                mPitchShifter.setPitch(semitones);
                Log.d(TAG, "setPitch: " + semitones + " semitones");
            }
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier (e.g., 1.25 for 125% speed)
     */
    public void setTempo(float tempo) {
        synchronized (mLock) {
            if (mPitchShifter != null) {
                mPitchShifter.setTempo(tempo);
                Log.d(TAG, "setTempo: " + tempo + "x");
            }
        }
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position in milliseconds, or 0 if not playing
     */
    public long getCurrentPosition() {
        synchronized (mLock) {
            if (mDecoder == null) {
                return 0;
            }
            return mDecoder.getCurrentPosition();
        }
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying && !mIsPaused;
    }
    
    /**
     * Checks if a song is loaded and the player is ready.
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mIsPrepared;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     */
    public void release() {
        synchronized (mLock) {
            Log.d(TAG, "release: Releasing resources");
            
            // Stop playback thread
            mShouldStop = true;
            mIsPlaying = false;
            mIsPrepared = false;
            mIsPreloadedOnly = false;
            
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.interrupt();
                    mPlaybackThread.join(1000);
                } catch (InterruptedException e) {
                    Log.w(TAG, "release: Interrupted while waiting for thread", e);
                }
                mPlaybackThread = null;
            }
            
            // Release AudioTrack
            if (mAudioTrack != null) {
                try {
                    if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                        mAudioTrack.stop();
                    }
                    mAudioTrack.release();
                } catch (Exception e) {
                    Log.e(TAG, "release: Error releasing AudioTrack", e);
                }
                mAudioTrack = null;
            }
            
            // Release decoder
            if (mDecoder != null) {
                mDecoder.release();
                mDecoder = null;
            }
            
            // Release pitch shifter
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            mAudioSessionId = 0;
            mCurrentFilePath = null;
            mDuration = 0;
            mSeekTarget = -1;
            
            Log.d(TAG, "release: Resources released");
        }
    }
    
    // ========================================================================
    // Private Playback Control Methods
    // ========================================================================
    
    /**
     * Initializes AudioTrack for pre-load state (creates session without playing).
     * 
     * <p>This method creates an AudioTrack instance and obtains its audio session ID,
     * but does not call play() on it. This allows the equalizer to attach before
     * playback begins.</p>
     */
    private void initAudioTrackForPreload() {
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        // Calculate appropriate buffer size
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        // Use a reasonable buffer size (200ms of audio)
        int targetBufferSize = mSampleRate * mFrameSize * 2 * 200 / 1000;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        bufferSize = Math.max(bufferSize, mSampleRate * mFrameSize * MIN_BUFFER_MS / 1000);
        
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            .setAudioFormat(new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .build())
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        mAudioSessionId = mAudioTrack.getAudioSessionId();
        Log.d(TAG, "initAudioTrackForPreload: Session=" + mAudioSessionId + 
              ", bufferSize=" + bufferSize);
    }
    
    /**
     * Initializes AudioTrack for active playback.
     */
    private void initAudioTrackForPlayback() {
        // Reuse existing AudioTrack if already initialized
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            return;
        }
        
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        int targetBufferSize = mSampleRate * mFrameSize * 2 * 200 / 1000;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            .setAudioFormat(new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .build())
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        mAudioSessionId = mAudioTrack.getAudioSessionId();
    }
    
    /**
     * Starts new playback from the beginning.
     */
    private void startPlayback() {
        Log.d(TAG, "startPlayback: Beginning playback");
        
        // Initialize AudioTrack for playback if needed
        initAudioTrackForPlayback();
        
        // Start the playback thread
        mShouldStop = false;
        mPlaybackThread = new Thread(new Runnable() {
            @Override
            public void run() {
                processAudioData();
            }
        });
        mPlaybackThread.start();
        
        // Start AudioTrack
        if (mAudioTrack != null) {
            mAudioTrack.play();
        }
        
        mIsPlaying = true;
        mIsPaused = false;
        
        // Notify listener
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPlaybackStarted();
            } catch (Exception e) {
                Log.e(TAG, "startPlayback: Listener error", e);
            }
        }
    }
    
    /**
     * Pauses playback (keeps thread alive).
     */
    private void pausePlayback() {
        Log.d(TAG, "pausePlayback: Pausing");
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
            } catch (Exception e) {
                Log.e(TAG, "pausePlayback: Error pausing", e);
            }
        }
        
        mIsPaused = true;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPlaybackPaused();
            } catch (Exception e) {
                Log.e(TAG, "pausePlayback: Listener error", e);
            }
        }
    }
    
    /**
     * Resumes playback after pause.
     */
    private void resumePlayback() {
        Log.d(TAG, "resumePlayback: Resuming");
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
            } catch (Exception e) {
                Log.e(TAG, "resumePlayback: Error resuming", e);
            }
        }
        
        mIsPaused = false;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPlaybackResumed();
            } catch (Exception e) {
                Log.e(TAG, "resumePlayback: Listener error", e);
            }
        }
    }
    
    /**
     * Stops playback completely.
     */
    private void stopPlayback() {
        Log.d(TAG, "stopPlayback: Stopping");
        
        mShouldStop = true;
        mIsPlaying = false;
        mIsPaused = false;
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
            } catch (Exception e) {
                Log.e(TAG, "stopPlayback: Error stopping", e);
            }
        }
        
        // Seek back to beginning
        if (mDecoder != null) {
            mDecoder.seekTo(0);
        }
    }
    
    // ========================================================================
    // Audio Processing Thread
    // ========================================================================
    
    /**
     * Main audio processing loop.
     * 
     * <p>This method runs in a background thread and continuously:
     * <ol>
     *   <li>Reads PCM data from the decoder</li>
     *   <li>Processes it through the pitch shifter</li>
     *   <li>Writes the processed data to AudioTrack</li>
     *   <li>Handles seek requests and completion detection</li>
     * </ol>
     * </p>
     */
    private void processAudioData() {
        Log.d(TAG, "processAudioData: Thread started");
        
        final int samplesPerFrame = mFrameSize;
        final int bufferFrames = 4096; // Process in chunks
        final short[] inputBuffer = new short[bufferFrames * samplesPerFrame];
        final short[] outputBuffer = new short[bufferFrames * samplesPerFrame];
        
        boolean reachedEnd = false;
        
        while (!mShouldStop && !reachedEnd) {
            try {
                // Check for seek requests
                if (mSeekTarget >= 0 && mDecoder != null) {
                    mDecoder.seekTo(mSeekTarget);
                    if (mPitchShifter != null) {
                        mPitchShifter.clear();
                    }
                    mSeekTarget = -1;
                }
                
                // Read PCM data from decoder
                int framesRead = mDecoder.read(inputBuffer, bufferFrames);
                
                if (framesRead <= 0) {
                    // End of file reached
                    reachedEnd = true;
                    break;
                }
                
                // Process through pitch shifter
                if (mPitchShifter != null) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, bufferFrames);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        
                        if (received > 0 && mAudioTrack != null) {
                            int samplesToWrite = received * samplesPerFrame;
                            mAudioTrack.write(outputBuffer, 0, samplesToWrite);
                        }
                    }
                } else {
                    // No pitch shifting - direct write
                    if (mAudioTrack != null) {
                        int samplesToWrite = framesRead * samplesPerFrame;
                        mAudioTrack.write(inputBuffer, 0, samplesToWrite);
                    }
                }
                
                // Small delay to prevent CPU spinning
                Thread.sleep(10);
                
            } catch (InterruptedException e) {
                Log.d(TAG, "processAudioData: Interrupted");
                break;
            } catch (Exception e) {
                Log.e(TAG, "processAudioData: Error", e);
                notifyError("Playback error: " + e.getMessage());
                break;
            }
        }
        
        // Flush remaining data
        flushRemainingData();
        
        // Handle completion
        if (reachedEnd && !mShouldStop) {
            handleCompletion();
        }
        
        Log.d(TAG, "processAudioData: Thread finished");
    }
    
    /**
     * Flushes any remaining data in the pitch shifter pipeline.
     */
    private void flushRemainingData() {
        if (mPitchShifter != null && mAudioTrack != null) {
            mPitchShifter.flush();
            
            int available = mPitchShifter.numFrames();
            if (available > 0) {
                final int bufferFrames = 4096;
                final short[] outputBuffer = new short[bufferFrames * mFrameSize];
                int toRead = Math.min(available, bufferFrames);
                int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                
                if (received > 0) {
                    int samplesToWrite = received * mFrameSize;
                    mAudioTrack.write(outputBuffer, 0, samplesToWrite);
                }
            }
        }
    }
    
    /**
     * Handles song completion.
     */
    private void handleCompletion() {
        Log.d(TAG, "handleCompletion: Song finished");
        
        mIsPlaying = false;
        mIsPaused = false;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onCompletion();
            } catch (Exception e) {
                Log.e(TAG, "handleCompletion: Listener error", e);
            }
        }
    }
    
    // ========================================================================
    // Broadcast and Notification Methods
    // ========================================================================
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongPrepared: duration=" + mDuration + 
              ", session=" + mAudioSessionId);
    }
    
    /**
     * Notifies the listener that the player is prepared.
     */
    private void notifyPrepared() {
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPrepared();
            } catch (Exception e) {
                Log.e(TAG, "notifyPrepared: Listener error", e);
            }
        }
    }
    
    /**
     * Notifies the listener of an error.
     *
     * @param error Human-readable error message
     */
    private void notifyError(@NonNull String error) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onError(error);
            } catch (Exception e) {
                Log.e(TAG, "notifyError: Listener error", e);
            }
        }
    }
}