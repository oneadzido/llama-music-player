package com.ark.llama;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer – High‑quality audio player using MediaCodec + SoundTouch.
 * 
 * <p>This player provides independent pitch and tempo control using the SoundTouch
 * native library. It decodes audio via MediaCodec, processes PCM through PitchShifter,
 * and outputs to AudioTrack. All operations are performed on a background thread
 * to avoid blocking the UI.</p>
 * 
 * <h3>Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Seek to any position in the audio file</li>
 *   <li>Automatic sample rate fallback for AudioTrack compatibility</li>
 *   <li>Recovery from decoder/AudioTrack errors</li>
 *   <li>Non‑blocking operations using Handler and postDelayed</li>
 *   <li>Audio session ID for system equalizer integration</li>
 * </ul>
 * 
 * <h3>Supported Formats</h3>
 * <p>Any format supported by Android's MediaExtractor, including MP3, AAC, FLAC,
 * OGG, M4A, and WAV.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All public methods are safe to call from any thread. The player uses atomic
 * flags and a dedicated HandlerThread for decoding.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer();
 * player.setListener(new SoundTouchPlayer.PlaybackListener() {
 *     public void onPlaybackStarted() { }
 *     public void onPlaybackPaused() { }
 *     public void onPlaybackResumed() { }
 *     public void onCompletion() { }
 *     public void onPositionUpdate(long position) { }
 *     public void onError(String error) { }
 *     public void onPrepared() { }
 * });
 * 
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.play();
 * player.setPitch(2.5f);
 * player.setTempo(1.25f);
 * player.seekTo(30000);
 * player.pause();
 * player.resume();
 * player.release();
 * </pre>
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";

    /** Decoder timeout in microseconds (10 ms). */
    private static final long DECODER_TIMEOUT_US = 10000;

    /** Multiplier for AudioTrack buffer size. */
    private static final int AUDIO_TRACK_BUFFER_MULTIPLIER = 2;

    /** Target buffer size in milliseconds for smooth playback. */
    private static final int BUFFER_SIZE_MS = 100;

    /** Maximum number of recovery attempts before giving up. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    /** Maximum empty decoder output buffers before stall detection. */
    private static final int MAX_EMPTY_BUFFERS = 50;

    /** Progress update interval in milliseconds. */
    private static final int PROGRESS_UPDATE_INTERVAL_MS = 500;

    /** Minimum tempo (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;

    /** Maximum tempo (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;

    /** Minimum pitch in semitones. */
    private static final float MIN_PITCH = -6.0f;

    /** Maximum pitch in semitones. */
    private static final float MAX_PITCH = 6.0f;

    /** Fallback sample rates in Hz (in order of preference). */
    private static final int[] FALLBACK_SAMPLE_RATES = {48000, 44100, 32000, 24000, 16000};

    // ========================================================================
    // Member Variables
    // ========================================================================

    // Core components
    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private PitchShifter mPitchShifter;

    // Threading
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // State flags (Atomic for thread safety)
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicBoolean mIsReleased = new AtomicBoolean(false);
    private final AtomicBoolean mIsEndOfStream = new AtomicBoolean(false);
    private final AtomicBoolean mSeekRequested = new AtomicBoolean(false);
    private int mRecoveryAttempts = 0;
    private int mConsecutiveEmptyBuffers = 0;

    // Seek state
    private long mPendingSeekPosition = -1;
    private final Object mSeekLock = new Object();

    // Audio parameters
    private int mSampleRate = 44100;
    private int mChannels = 2;
    private long mDuration = 0;
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    private final AtomicLong mLastReportedPosition = new AtomicLong(0);

    // Track info
    private int mAudioTrackIndex = -1;
    private MediaFormat mAudioFormat;

    // Playback parameters
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;

    // Callback listener
    @Nullable
    private PlaybackListener mListener;

    // ========================================================================
    // Progress Updater Runnable
    // ========================================================================

    /** Periodic progress updater that runs on the main thread. */
    private final Runnable mProgressUpdater = new Runnable() {
        @Override
        public void run() {
            if (mIsPlaying.get() && !mIsPaused.get() && mListener != null) {
                updateCurrentPosition();
                long position = mCurrentPosition.get();
                if (position != mLastReportedPosition.get()) {
                    mLastReportedPosition.set(position);
                    mListener.onPositionUpdate(position);
                }
            }
            if (!mIsReleased.get()) {
                mMainHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS);
            }
        }
    };

    // ========================================================================
    // Listener Interface
    // ========================================================================

    /**
     * Listener interface for playback events.
     * 
     * <p>Implement this interface to receive callbacks about playback state
     * changes, errors, and position updates.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when playback starts (after play() is called and audio begins).
         */
        void onPlaybackStarted();
        
        /**
         * Called when playback is paused.
         */
        void onPlaybackPaused();
        
        /**
         * Called when playback resumes after being paused.
         */
        void onPlaybackResumed();
        
        /**
         * Called when the current song finishes playing.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         *
         * @param position Current position in milliseconds
         */
        void onPositionUpdate(long position);
        
        /**
         * Called when an error occurs during playback.
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the player is ready for playback (after loadSong succeeds).
         */
        void onPrepared();
    }

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new SoundTouchPlayer.
     * 
     * <p>The player is not ready for playback until loadSong() is called
     * and the onPrepared() callback is received.</p>
     */
    public SoundTouchPlayer() {
        Log.d(TAG, "SoundTouchPlayer created");
    }

    // ========================================================================
    // Public API Methods
    // ========================================================================

    /**
     * Sets the playback event listener.
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }

    /**
     * Loads a song from file path.
     * 
     * <p>This method extracts audio track information, configures the decoder,
     * creates the AudioTrack, and prepares the PitchShifter. The player is ready
     * for playback when onPrepared() is called.</p>
     * 
     * <p><b>Supported formats:</b> MP3, AAC, FLAC, OGG, M4A, WAV (any format
     * supported by MediaCodec)</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully (onPrepared will be called),
     *         false if an error occurred (onError will be called)
     */
    public boolean loadSong(@NonNull String filePath) {
        if (mIsReleased.get()) {
            notifyError("Player is released");
            return false;
        }
        if (!PitchShifter.isLibraryAvailable()) {
            notifyError("PitchShifter library not available");
            return false;
        }

        mIsPreparing.set(true);

        // Release previous resources
        releaseDecoder();
        releaseAudioTrack();
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }

        mConsecutiveEmptyBuffers = 0;
        mSeekRequested.set(false);
        mPendingSeekPosition = -1;
        mIsEndOfStream.set(false);
        mCurrentPosition.set(0);
        mLastReportedPosition.set(0);
        mRecoveryAttempts = 0;

        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);

            // Find audio track
            mAudioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mAudioTrackIndex = i;
                    mAudioFormat = format;
                    break;
                }
            }
            if (mAudioTrackIndex == -1 || mAudioFormat == null) {
                notifyError("No audio track found");
                mIsPreparing.set(false);
                return false;
            }

            // Extract audio parameters
            mSampleRate = mAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mChannels = mAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDuration = mAudioFormat.getLong(MediaFormat.KEY_DURATION);
            Log.d(TAG, "Audio format: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");

            // Create PitchShifter
            mPitchShifter = new PitchShifter(mSampleRate, mChannels);
            mPitchShifter.setPitch(mCurrentPitch);
            mPitchShifter.setTempo(mCurrentTempo);

            // Create decoder
            String mime = mAudioFormat.getString(MediaFormat.KEY_MIME);
            mDecoder = MediaCodec.createDecoderByType(mime);
            mDecoder.configure(mAudioFormat, null, null, 0);
            mDecoder.start();

            // Select track in extractor
            mExtractor.selectTrack(mAudioTrackIndex);

            // Create AudioTrack
            if (!createAudioTrack()) {
                notifyError("Failed to create AudioTrack");
                mIsPreparing.set(false);
                return false;
            }

            // Start background thread
            if (mPlaybackThread == null || !mPlaybackThread.isAlive()) {
                mPlaybackThread = new HandlerThread("SoundTouchPlayer");
                mPlaybackThread.start();
                mPlaybackHandler = new Handler(mPlaybackThread.getLooper());
            }

            mIsPreparing.set(false);
            notifyPrepared();

            // Start progress updates
            mMainHandler.removeCallbacks(mProgressUpdater);
            mMainHandler.post(mProgressUpdater);

            Log.d(TAG, "Song loaded successfully");
            return true;

        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            notifyError("Cannot read audio file: " + e.getMessage());
            mIsPreparing.set(false);
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error during load", e);
            notifyError("Load error: " + e.getMessage());
            mIsPreparing.set(false);
            return false;
        }
    }

    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is at the end of the song, it will restart from the beginning.
     * This method is non-blocking - playback happens on a background thread.</p>
     */
    public void play() {
        if (mIsReleased.get()) {
            Log.e(TAG, "Cannot play: player released");
            return;
        }
        if (mIsPreparing.get()) {
            Log.d(TAG, "Still preparing, will play when ready");
            return;
        }
        if (mAudioTrack == null || mDecoder == null) {
            notifyError("Player not initialized");
            return;
        }

        // If at end, restart from beginning
        if (mIsEndOfStream.get()) {
            seekTo(0);
            mIsEndOfStream.set(false);
        }

        mIsPlaying.set(true);
        mIsPaused.set(false);

        if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }

        // Start decoding loop
        if (mPlaybackHandler != null && !mPlaybackHandler.hasCallbacks(mPlaybackRunnable)) {
            mPlaybackHandler.post(mPlaybackRunnable);
        }

        notifyPlaybackStarted();
        Log.d(TAG, "Playback started");
    }

    /**
     * Pauses playback.
     * 
     * <p>The current position is preserved and can be resumed with play() or resume().
     * The decoder continues to process audio but the AudioTrack is paused.</p>
     */
    public void pause() {
        if (!mIsPlaying.get() || mIsPaused.get()) return;

        mIsPaused.set(true);
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.pause();
        }
        notifyPlaybackPaused();
        Log.d(TAG, "Playback paused");
    }

    /**
     * Resumes playback after being paused.
     * 
     * <p>This is equivalent to calling play() when paused.</p>
     */
    public void resume() {
        if (!mIsPlaying.get() || !mIsPaused.get()) return;

        mIsPaused.set(false);
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }
        notifyPlaybackResumed();
        Log.d(TAG, "Playback resumed");
    }

    /**
     * Stops playback and resets position to beginning.
     * 
     * <p>Unlike pause(), stop() resets the playback position to 0.
     * Call play() to start from the beginning.</p>
     */
    public void stop() {
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mSeekRequested.set(false);

        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
            } catch (Exception ignored) {}
        }

        if (mPitchShifter != null) {
            mPitchShifter.clear();
        }

        mCurrentPosition.set(0);
        mLastReportedPosition.set(0);
        mIsEndOfStream.set(false);
        seekDecoderTo(0);

        Log.d(TAG, "Playback stopped");
    }

    /**
     * Seeks to a specific position in the song (non‑blocking).
     * 
     * <p>This method requests a seek but does not block. The actual seek
     * is performed in the playback loop on the next iteration.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(long positionMs) {
        // Clamp to valid range
        long clampedPosition = positionMs;
        if (clampedPosition < 0) clampedPosition = 0;
        if (clampedPosition > mDuration) clampedPosition = mDuration;

        synchronized (mSeekLock) {
            mPendingSeekPosition = clampedPosition;
            mSeekRequested.set(true);
        }
        Log.d(TAG, "Seek requested to: " + clampedPosition + "ms");
    }

    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Range: -6.0 to +6.0 semitones</p>
     *
     * @param semitones Pitch shift amount (positive = higher pitch, negative = lower)
     */
    public void setPitch(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        mCurrentPitch = clamped;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(clamped);
            Log.d(TAG, "Pitch set to: " + clamped);
        }
    }

    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Range: 0.5 to 1.5</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower)</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     *
     * @param tempo Tempo multiplier
     */
    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        mCurrentTempo = clamped;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(clamped);
            Log.d(TAG, "Tempo set to: " + clamped);
        }
    }

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position, or 0 if not playing
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }

    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return Song duration, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }

    /**
     * Returns true if playback is currently active (playing and not paused).
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get();
    }

    /**
     * Returns true if the player is prepared and ready for playback.
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return !mIsPreparing.get() && mAudioTrack != null && mDecoder != null;
    }

    /**
     * Returns the audio session ID for use with Android's equalizer.
     * 
     * <p>This ID can be passed to EqualizerManager to attach the system
     * equalizer to this player's audio session.</p>
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioTrack != null ? mAudioTrack.getAudioSessionId() : 0;
    }

    /**
     * Releases all resources used by the player.
     * 
     * <p>After calling this method, the player cannot be used again.
     * This should be called when the player is no longer needed.</p>
     */
    public void release() {
        if (mIsReleased.get()) return;
        Log.d(TAG, "Releasing SoundTouchPlayer");

        mIsReleased.set(true);
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mSeekRequested.set(false);

        mMainHandler.removeCallbacks(mProgressUpdater);

        if (mPlaybackHandler != null) {
            mPlaybackHandler.removeCallbacks(mPlaybackRunnable);
            mPlaybackHandler = null;
        }
        if (mPlaybackThread != null) {
            mPlaybackThread.quitSafely();
            try {
                mPlaybackThread.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mPlaybackThread = null;
        }

        releaseDecoder();
        releaseAudioTrack();
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }

        Log.d(TAG, "SoundTouchPlayer released");
    }

    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Creates and configures the AudioTrack for PCM output.
     * 
     * <p>The AudioTrack is configured with the same sample rate and channel
     * count as the decoded audio. The buffer size is calculated to ensure
     * smooth playback without underruns.</p>
     *
     * @return true if AudioTrack was created successfully, false otherwise
     */
    private boolean createAudioTrack() {
        try {
            int channelConfig = (mChannels == 1) ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
            if (minBufferSize <= 0) {
                for (int rate : FALLBACK_SAMPLE_RATES) {
                    minBufferSize = AudioTrack.getMinBufferSize(rate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
                    if (minBufferSize > 0) {
                        Log.w(TAG, "Sample rate fallback: " + mSampleRate + " -> " + rate + " Hz");
                        mSampleRate = rate;
                        break;
                    }
                }
                if (minBufferSize <= 0) {
                    Log.e(TAG, "No viable sample rate found");
                    return false;
                }
            }

            int bufferSize = minBufferSize * AUDIO_TRACK_BUFFER_MULTIPLIER;
            int frameSizeMs = mSampleRate * mChannels * 2 * BUFFER_SIZE_MS / 1000;
            if (bufferSize < frameSizeMs) {
                bufferSize = frameSizeMs;
            }

            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setSampleRate(mSampleRate)
                    .setChannelMask(channelConfig)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build();
            mAudioTrack = new AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed");
                return false;
            }
            Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, bufferSize=" + bufferSize);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            return false;
        }
    }

    /**
     * Releases the decoder and extractor resources.
     */
    private void releaseDecoder() {
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception ignored) {}
            mDecoder = null;
        }
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception ignored) {}
            mExtractor = null;
        }
        mAudioTrackIndex = -1;
        mAudioFormat = null;
    }

    /**
     * Releases the AudioTrack resources.
     */
    private void releaseAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception ignored) {}
            mAudioTrack = null;
        }
    }

    /**
     * Seeks the decoder to a specific position.
     * 
     * <p>This method seeks to the nearest keyframe before the target position
     * and flushes the decoder to clear any pending data.</p>
     *
     * @param positionMs Target position in milliseconds
     */
    private void seekDecoderTo(long positionMs) {
        if (mExtractor == null) return;
        try {
            // Seek to keyframe before target position (in microseconds)
            mExtractor.seekTo(positionMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            if (mDecoder != null) {
                mDecoder.flush();
            }
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            Log.d(TAG, "Decoder seeked to " + positionMs + "ms");
        } catch (Exception e) {
            Log.e(TAG, "Seek failed", e);
        }
    }

    /**
     * Updates the current position based on AudioTrack playback head.
     * 
     * <p>This method reads the number of frames played from AudioTrack and
     * converts to milliseconds.</p>
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && !mSeekRequested.get() && !mIsPaused.get()) {
            try {
                long framesPlayed = mAudioTrack.getPlaybackHeadPosition();
                if (framesPlayed > 0) {
                    long positionMs = (framesPlayed * 1000L) / mSampleRate;
                    if (positionMs < mDuration) {
                        mCurrentPosition.set(positionMs);
                    } else if (positionMs >= mDuration && !mIsEndOfStream.get()) {
                        // Near end of stream, let completion handler take over
                        if (positionMs - mDuration < 500) {
                            mCurrentPosition.set(mDuration);
                        }
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to update position", e);
            }
        }
    }

    /**
     * Attempts to recover from a playback error.
     * 
     * <p>This method recreates the AudioTrack and seeks back to the last
     * known position.</p>
     *
     * @return true if recovery was successful, false if max attempts reached
     */
    private boolean attemptRecovery() {
        mRecoveryAttempts++;
        if (mRecoveryAttempts > MAX_RECOVERY_ATTEMPTS) {
            notifyError("Playback failed after " + MAX_RECOVERY_ATTEMPTS + " attempts");
            return false;
        }
        Log.w(TAG, "Attempting recovery (" + mRecoveryAttempts + "/" + MAX_RECOVERY_ATTEMPTS + ")");
        boolean wasPlaying = mIsPlaying.get() && !mIsPaused.get();
        long position = mCurrentPosition.get();

        mIsPlaying.set(false);
        releaseAudioTrack();
        if (!createAudioTrack()) {
            return false;
        }
        seekDecoderTo(position);
        if (wasPlaying) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            if (mAudioTrack != null) {
                mAudioTrack.play();
            }
        }
        return true;
    }

    /**
     * Notifies the listener of an error on the main thread.
     *
     * @param error Error message
     */
    private void notifyError(@NonNull final String error) {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onError(error);
                }
            });
        }
    }

    /**
     * Notifies the listener that the player is prepared on the main thread.
     */
    private void notifyPrepared() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPrepared();
                }
            });
        }
    }

    /**
     * Notifies the listener that playback started on the main thread.
     */
    private void notifyPlaybackStarted() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackStarted();
                }
            });
        }
    }

    /**
     * Notifies the listener that playback paused on the main thread.
     */
    private void notifyPlaybackPaused() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackPaused();
                }
            });
        }
    }

    /**
     * Notifies the listener that playback resumed on the main thread.
     */
    private void notifyPlaybackResumed() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackResumed();
                }
            });
        }
    }

    /**
     * Notifies the listener that the song completed on the main thread.
     */
    private void notifyCompletion() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onCompletion();
                }
            });
        }
    }

    // ========================================================================
    // Playback Runnable (Background Loop)
    // ========================================================================

    /**
     * Main playback loop that runs on a background thread.
     * 
     * <p>This runnable continuously:
     * <ol>
     *   <li>Checks for pending seek requests (non-blocking)</li>
     *   <li>Feeds encoded data to the decoder</li>
     *   <li>Processes decoder output through PitchShifter</li>
     *   <li>Writes processed audio to AudioTrack</li>
     * </ol>
     * </p>
     */
    private final Runnable mPlaybackRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsReleased.get()) return;

            // Handle pending seek
            if (mSeekRequested.getAndSet(false)) {
                long target;
                synchronized (mSeekLock) {
                    target = mPendingSeekPosition;
                    mPendingSeekPosition = -1;
                }
                if (target >= 0) {
                    seekDecoderTo(target);
                    mCurrentPosition.set(target);
                    mLastReportedPosition.set(target);
                    if (mListener != null) {
                        mListener.onPositionUpdate(target);
                    }
                    mIsEndOfStream.set(false);
                }
                if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.post(this);
                }
                return;
            }

            // If paused, just delay and continue
            if (mIsPaused.get()) {
                if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.postDelayed(this, 50);
                }
                return;
            }

            try {
                // 1. Feed input to decoder
                feedDecoderInput();

                // 2. Process decoder output
                boolean eosReached = processDecoderOutput();

                if (eosReached) {
                    flushRemainingAudio();
                    mIsPlaying.set(false);
                    mIsEndOfStream.set(true);
                    notifyCompletion();
                    return;
                }

                // Continue loop
                if (mIsPlaying.get() && !mIsPaused.get() && !mIsReleased.get() && mPlaybackHandler != null) {
                    mPlaybackHandler.post(this);
                }
            } catch (Exception e) {
                Log.e(TAG, "Playback loop error", e);
                if (!attemptRecovery()) {
                    notifyError("Playback error: " + e.getMessage());
                } else if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.post(this);
                }
            }
        }

        /**
         * Feeds one input buffer to the decoder from the extractor.
         */
        private void feedDecoderInput() {
            if (mDecoder == null || mExtractor == null) return;

            int inputIndex = mDecoder.dequeueInputBuffer(DECODER_TIMEOUT_US);
            if (inputIndex < 0) return;

            ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
            if (inputBuffer == null) return;

            int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
            if (sampleSize < 0) {
                // End of stream
                mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            } else {
                long presentationTimeUs = mExtractor.getSampleTime();
                mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                mExtractor.advance();
            }
        }

        /**
         * Processes one decoder output buffer, feeds PCM to PitchShifter,
         * and writes processed audio to AudioTrack.
         *
         * @return true if end of stream was reached, false otherwise
         */
        private boolean processDecoderOutput() {
            if (mDecoder == null) return true;

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int outputIndex = mDecoder.dequeueOutputBuffer(info, DECODER_TIMEOUT_US);

            if (outputIndex >= 0) {
                mConsecutiveEmptyBuffers = 0;
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;

                if (info.size > 0) {
                    ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                    if (outputBuffer != null) {
                        outputBuffer.order(ByteOrder.LITTLE_ENDIAN);
                        int sampleCount = info.size / 2;
                        short[] pcm = new short[sampleCount];
                        for (int i = 0; i < sampleCount; i++) {
                            pcm[i] = outputBuffer.getShort();
                        }
                        int frames = pcm.length / mChannels;
                        mPitchShifter.putFrames(pcm, frames);
                        writeProcessedAudio();
                    }
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
                return eos;
            } else if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                mConsecutiveEmptyBuffers++;
                if (mConsecutiveEmptyBuffers > MAX_EMPTY_BUFFERS) {
                    Log.e(TAG, "Decoder stalled");
                    notifyError("Decoder stalled");
                    return true;
                }
                writeProcessedAudio();
                return false;
            } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                Log.d(TAG, "Output format changed: " + mDecoder.getOutputFormat());
                return false;
            }
            writeProcessedAudio();
            return false;
        }

        /**
         * Retrieves processed frames from PitchShifter and writes to AudioTrack.
         */
        private void writeProcessedAudio() {
            if (mAudioTrack == null || mPitchShifter == null) return;
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) return;

            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            if (received > 0) {
                int samples = received * mChannels;
                int written = mAudioTrack.write(output, 0, samples);
                if (written < 0) {
                    Log.e(TAG, "AudioTrack write error: " + written);
                    if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                        attemptRecovery();
                    }
                }
            }
        }

        /**
         * Flushes remaining audio from PitchShifter after end of stream.
         */
        private void flushRemainingAudio() {
            if (mPitchShifter == null) return;
            mPitchShifter.flush();
            int empty = 0;
            while (empty < 20) {
                int frames = mPitchShifter.numFrames();
                if (frames == 0) break;
                short[] out = new short[frames * mChannels];
                int received = mPitchShifter.receiveFrames(out, frames);
                if (received > 0 && mAudioTrack != null) {
                    mAudioTrack.write(out, 0, received * mChannels);
                } else {
                    empty++;
                }
            }
        }
    };
}