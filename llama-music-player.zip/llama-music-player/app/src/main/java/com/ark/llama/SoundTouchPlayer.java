package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import net.surina.soundtouch.SoundTouch;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides real-time pitch and tempo shifting using the SoundTouch native library.
 * It is the primary player for Llama Music Player, with MediaPlayer as a fallback only when
 * SoundTouch fails at runtime.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <pre>
 * Audio File -> AudioDecoder -> SoundTouch -> AudioTrack -> Speakers
 * </pre>
 * 
 * <p>The audio processing pipeline works as follows:</p>
 * <ol>
 *   <li><b>AudioDecoder</b> - Decodes compressed audio (MP3, AAC, FLAC, OGG) to 16-bit PCM</li>
 *   <li><b>SoundTouch</b> - Applies pitch and tempo changes in real-time using WSOLA algorithm</li>
 *   <li><b>AudioTrack</b> - Plays the processed PCM audio to the device speakers or headphones</li>
 * </ol>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control (-6 to +6 semitones)</li>
 *   <li>Independent tempo control (0.5x to 1.5x speed)</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Proper AudioTrack priming to prevent buffer underruns</li>
 *   <li>Seamless seek and state management</li>
 *   <li>Broadcasts audio session ID for equalizer attachment</li>
 *   <li>Comprehensive playback state machine with error recovery</li>
 * </ul>
 * 
 * <h3>State Machine</h3>
 * <pre>
 * IDLE -> PREPARING -> READY -> PLAYING ⇄ PAUSED -> COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * <p>State transition descriptions:</p>
 * <ul>
 *   <li><b>IDLE</b> - Initial state, no song loaded. Player created but not configured.</li>
 *   <li><b>PREPARING</b> - Loading song asynchronously. Decoder initialization in progress.</li>
 *   <li><b>READY</b> - Song loaded and ready to play. Waiting for play() command.</li>
 *   <li><b>PLAYING</b> - Actively playing audio through AudioTrack.</li>
 *   <li><b>PAUSED</b> - Playback paused at current position. Can resume.</li>
 *   <li><b>COMPLETED</b> - Song finished normally. Can restart from beginning.</li>
 *   <li><b>ERROR</b> - An error occurred. Player cannot continue.</li>
 *   <li><b>RELEASED</b> - Player resources released. Cannot be used again.</li>
 * </ul>
 * 
 * <h3>AudioTrack Priming</h3>
 * <p>To prevent audio buffer underruns (which cause pops or silence), the player implements
 * a priming strategy: the first {@value #PRIME_CHUNK_COUNT} chunks of audio are written
 * to the AudioTrack without calling play(). After the buffer is sufficiently filled,
 * {@link AudioTrack#play()} is called. This ensures a smooth audio start.</p>
 * 
 * <h3>Playback Listener</h3>
 * <p>Clients can register a {@link PlaybackListener} to receive state change,
 * position update, and error notifications. All callbacks are delivered on the
 * main UI thread for safe UI updates.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is thread-safe for most operations. Internal state is protected
 * by synchronization locks. The playback thread runs independently and communicates
 * via atomic variables and wait/notify mechanisms.</p>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #release()} when the player is no longer needed to
 * free native resources and prevent memory leaks. The player implements
 * {@link AutoCloseable}-like behavior but does not implement the interface
 * to maintain compatibility with older Android versions.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Create player instance
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * 
 * // Set up listener for events
 * player.setListener(new PlaybackListener() {
 *     {@literal @}Override
 *     public void onStateChanged(State newState, State oldState) {
 *         // Update UI based on state
 *     }
 *     
 *     {@literal @}Override
 *     public void onPrepared() {
 *         // Song is ready, enable play button
 *     }
 *     
 *     {@literal @}Override
 *     public void onCompletion() {
 *         // Song finished, play next song
 *     }
 *     
 *     {@literal @}Override
 *     public void onPositionUpdate(long positionMs) {
 *         // Update seekbar position
 *     }
 *     
 *     {@literal @}Override
 *     public void onError(String error) {
 *         // Handle error, possibly fall back to MediaPlayer
 *     }
 * });
 * 
 * // Pre-load song (duration and audio session become available)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Start playback
 * player.play();
 * 
 * // Adjust pitch and tempo during playback
 * player.setPitch(2.0f);   // raise by 2 semitones
 * player.setTempo(1.25f);  // speed up by 25%
 * 
 * // Seek to 30 seconds
 * player.seekTo(30000);
 * 
 * // Pause and resume
 * player.pause();
 * player.resume();
 * 
 * // Clean up
 * player.release();
 * </pre>
 * 
 * <h3>Integration with MusicService</h3>
 * <p>This player is designed to be used by {@link MusicService} as the primary
 * playback engine. The service handles:</p>
 * <ul>
 *   <li>Playlist management and navigation</li>
 *   <li>Repeat and shuffle modes</li>
 *   <li>Audio focus management</li>
 *   <li>Media session integration for lock screen controls</li>
 *   <li>Fallback to MediaPlayer if SoundTouch fails</li>
 * </ul>
 * 
 * @see AudioDecoder
 * @see SoundTouch
 * @see AudioTrack
 * @see MusicService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";
    
    /**
     * Broadcast action when a song is prepared.
     * <p>This intent is sent when the decoder and AudioTrack are initialized.
     * It contains the song duration and audio session ID for equalizer attachment.</p>
     */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID (used by EqualizerManager). */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /**
     * Number of stereo frames per internal buffer.
     * <p>Increased to 8192 for smoother audio flow and reduced CPU usage.
     * Each frame contains samples for all channels (2 for stereo).</p>
     */
    private static final int BUFFER_FRAMES = 8192;
    
    /**
     * Minimum buffer duration in milliseconds for AudioTrack.
     * <p>The AudioTrack buffer is sized to hold at least this many milliseconds
     * of audio to prevent underruns during brief system load spikes.</p>
     */
    private static final int MIN_BUFFER_MS = 250;
    
    /**
     * Interval for position update callbacks to UI in milliseconds.
     * <p>Updates are throttled to this frequency to reduce UI thread load.</p>
     */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /**
     * Number of chunks to write to AudioTrack before calling play().
     * <p>This priming strategy prevents audio buffer underruns at startup.
     * After writing this many chunks, the AudioTrack is started.</p>
     */
    private static final int PRIME_CHUNK_COUNT = 4;
    
    // ========================================================================
    // State Enumeration
    // ========================================================================
    
    /**
     * Represents the current state of the player.
     * <p>State transitions are synchronized and atomic. Certain operations
     * are only allowed in specific states.</p>
     */
    public enum State {
        /**
         * Initial state, no song loaded.
         * <p>Player has been created but not configured. Call {@link #loadSong(String)}
         * to transition to PREPARING.</p>
         */
        IDLE,
        
        /**
         * Loading song asynchronously.
         * <p>Decoder initialization, format detection, and AudioTrack creation
         * are in progress. Playback controls are disabled until READY.</p>
         */
        PREPARING,
        
        /**
         * Song loaded and ready to play.
         * <p>All resources are initialized. Call {@link #play()} to start playback.</p>
         */
        READY,
        
        /**
         * Actively playing audio.
         * <p>Audio is being processed through SoundTouch and played via AudioTrack.
         * Call {@link #pause()} to pause or {@link #stop()} to stop.</p>
         */
        PLAYING,
        
        /**
         * Playback paused.
         * <p>Playback position is preserved. Call {@link #resume()} to continue
         * from the paused position.</p>
         */
        PAUSED,
        
        /**
         * Song finished normally.
         * <p>The end of the audio file was reached. Call {@link #play()} to
         * restart from the beginning.</p>
         */
        COMPLETED,
        
        /**
         * An error occurred.
         * <p>The player cannot continue. The UI should fall back to MediaPlayer
         * or show an error message.</p>
         */
        ERROR,
        
        /**
         * Player resources released.
         * <p>All native and Java resources have been freed. The player cannot
         * be used again.</p>
         */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback events.
     * 
     * <p>All callbacks are delivered on the main UI thread to allow safe UI updates.
     * Implementations should be lightweight and return quickly.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         * <p>Use this callback to update UI elements based on the new state,
         * such as enabling/disabling buttons or showing/hiding progress indicators.</p>
         *
         * @param newState The new state after the transition
         * @param oldState The previous state before the transition (may be null on first call)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the song is prepared and ready for playback.
         * <p>This indicates that the decoder and AudioTrack are initialized.
         * At this point, {@link #getDuration()} returns the correct duration,
         * and {@link #getAudioSessionId()} returns a valid session ID for equalizer attachment.</p>
         * 
         * <p>This is the signal to enable the play button and update the UI
         * with the song duration.</p>
         */
        void onPrepared();
        
        /**
         * Called when the song completes normally.
         * <p>This indicates that the end of the audio file was reached.
         * The UI should update to show completion and may advance to the next song
         * if repeat mode is enabled.</p>
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * <p>Updates are throttled to {@value #POSITION_UPDATE_INTERVAL_MS} milliseconds.
         * Use this callback to update a seekbar or time display.</p>
         * 
         * <p>Note: This callback is not called when the user is actively seeking
         * to avoid UI jitter.</p>
         *
         * @param positionMs Current position in milliseconds from start of song
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback or preparation.
         * <p>The player enters {@link State#ERROR} after this callback.
         * The calling code should handle the error appropriately, typically
         * by falling back to MediaPlayer.</p>
         *
         * @param error Human-readable description of the error for logging/debugging
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcasts and resource access. */
    @NonNull private final Context mContext;
    
    /** Listener for playback events, or null if not set. */
    @Nullable private PlaybackListener mListener;
    
    /** Current player state, protected by mStateLock. */
    private State mState = State.IDLE;
    
    /** Lock object for thread-safe state transitions. */
    private final Object mStateLock = new Object();
    
    /** Audio decoder for reading and decoding compressed audio files. */
    @Nullable private AudioDecoder mDecoder;
    
    /** Official SoundTouch processor for pitch and tempo changes. */
    @Nullable private SoundTouch mSoundTouch;
    
    /** AudioTrack for PCM audio output to speakers/headphones. */
    @Nullable private AudioTrack mAudioTrack;
    
    /** Sample rate of the current audio in Hz (e.g., 44100). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 for mono, 2 for stereo). */
    private int mChannels = 2;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Total duration of the current song in milliseconds. */
    private long mDuration = 0;
    
    /** File path of the currently loaded song. */
    private String mCurrentFilePath = null;
    
    /** Flag indicating if audio format has been validated. */
    private boolean mFormatValidated = false;
    
    /** Atomic flag indicating if audio is currently playing. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Atomic flag indicating if playback is paused. */
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    
    /** Atomic flag indicating if end-of-stream has been reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Current playback position in milliseconds (cached for non-playing states). */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Pending seek target position in milliseconds, or -1 if none. */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Current pitch shift amount in semitones (range: -6 to +6). */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier (range: 0.5 to 1.5). */
    private float mCurrentTempo = 1.0f;
    
    /** Background thread for audio playback loop. */
    @Nullable private Thread mPlaybackThread;
    
    /** Flag indicating if playback loop should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Lock for synchronizing playback thread wait/notify. */
    private final Object mPlaybackLock = new Object();
    
    /** Lock for synchronizing decoder access. */
    private final Object mDecoderLock = new Object();
    
    /** Flag indicating if AudioTrack has been primed (buffered enough data). */
    private final AtomicBoolean mPrimed = new AtomicBoolean(false);
    
    /** Counter for number of chunks written during priming phase. */
    private volatile int mPrimeCount = 0;
    
    /** Handler for delivering callbacks on the main UI thread. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer.
     * 
     * <p>The player is initially in {@link State#IDLE}. Call {@link #loadSong(String)}
     * or {@link #preLoad(String)} to prepare a song for playback.</p>
     * 
     * <p>The application context is stored for sending broadcasts when the song
     * is prepared, which allows the UI to receive duration and audio session ID
     * before playback begins.</p>
     *
     * @param context Application context (used for broadcasts and audio session)
     * @throws NullPointerException if context is null
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback listener.
     * 
     * <p>The listener receives state change, position update, and error callbacks.
     * All callbacks are delivered on the main UI thread.</p>
     * 
     * <p>Only one listener can be set at a time. Set to null to remove.</p>
     *
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method is equivalent to {@link #loadSong(String)} and provides
     * early access to song duration and audio session ID. Use this when you
     * want to prepare a song but not start playing immediately, such as when
     * setting up a playlist or displaying song metadata.</p>
     * 
     * <p>Benefits of pre-loading:</p>
     * <ul>
     *   <li>Song duration becomes available immediately for UI display</li>
     *   <li>Audio session is created, allowing equalizer attachment before play</li>
     *   <li>Decoder is initialized, reducing latency when play is pressed</li>
     * </ul>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully, false if player is released or already loading
     */
    public boolean preLoad(@NonNull String filePath) {
        return loadSong(filePath);
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method is asynchronous. It starts a background thread that:
     * <ol>
     *   <li>Opens and configures the audio decoder</li>
     *   <li>Extracts audio format (sample rate, channels, duration)</li>
     *   <li>Initializes the SoundTouch processor</li>
     *   <li>Creates and configures the AudioTrack</li>
     * </ol>
     * </p>
     * 
     * <p>When loading completes successfully, the state becomes {@link State#READY}
     * and {@link PlaybackListener#onPrepared()} is called on the UI thread.</p>
     * 
     * <p>If loading fails, the state becomes {@link State#ERROR} and
     * {@link PlaybackListener#onError(String)} is called.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading started successfully, false if player is released or already loading
     */
    public boolean loadSong(@NonNull String filePath) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.w(TAG, "loadSong called on released player");
                return false;
            }
            if (mState == State.PREPARING) {
                Log.d(TAG, "Already preparing, ignoring loadSong");
                return true;
            }
            mState = State.PREPARING;
        }
        
        mCurrentFilePath = filePath;
        mIsEOS.set(false);
        mSeekTarget.set(-1);
        
        new Thread(() -> {
            try {
                // Step 1: Initialize decoder
                AudioDecoder decoder = new AudioDecoder();
                if (!decoder.open(filePath)) {
                    transitionToError("Failed to open audio file");
                    return;
                }
                mDecoder = decoder;
                mSampleRate = decoder.getSampleRate();
                mChannels = decoder.getChannels();
                mDuration = decoder.getDuration();
                
                Log.d(TAG, "loadSong: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
                
                // Validate audio format
                if (mSampleRate <= 0 || mSampleRate > 192000 || mChannels < 1 || mChannels > 2) {
                    transitionToError("Invalid audio format: " + mSampleRate + "Hz, " + mChannels + "ch");
                    return;
                }
                
                // Step 2: Initialize official SoundTouch
                try {
                    mSoundTouch = new SoundTouch();
                    mSoundTouch.setPitchSemiTones(mCurrentPitch);
                    mSoundTouch.setTempo(mCurrentTempo);
                    Log.d(TAG, "SoundTouch initialized successfully");
                } catch (UnsatisfiedLinkError e) {
                    Log.e(TAG, "SoundTouch native library not available", e);
                    transitionToError("SoundTouch library not available: " + e.getMessage());
                    return;
                }
                
                // Step 3: Create AudioTrack
                createAudioTrack();
                if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    transitionToError("AudioTrack creation failed");
                    return;
                }
                
                // Step 4: Get audio session ID for equalizer
                mAudioSessionId = mAudioTrack.getAudioSessionId();
                mFormatValidated = true;
                
                // Step 5: Broadcast that song is prepared (for UI duration and equalizer)
                broadcastSongPrepared();
                
                // Step 6: Notify listener
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> {
                        listener.onPrepared();
                        listener.onStateChanged(State.READY, State.PREPARING);
                    });
                }
                
                synchronized (mStateLock) {
                    if (mState != State.RELEASED && mState != State.ERROR) {
                        mState = State.READY;
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "loadSong exception", e);
                transitionToError(e.getMessage());
            }
        }, "SoundTouch-Loader").start();
        
        return true;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>Behavior depends on current state:</p>
     * <ul>
     *   <li>{@link State#READY} - Playback starts from the beginning</li>
     *   <li>{@link State#PAUSED} - Playback resumes from the current position</li>
     *   <li>{@link State#COMPLETED} - Playback restarts from the beginning</li>
     * </ul>
     * 
     * <p>If called in any other state, the call is ignored.</p>
     * 
     * <p>When playback starts, the AudioTrack is primed with audio data before
     * calling play() to prevent buffer underruns.</p>
     */
    public void play() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) {
                Log.w(TAG, "play called in invalid state: " + mState);
                return;
            }
            
            if (mState == State.READY) {
                startPlayback();
            } else if (mState == State.PAUSED) {
                resumePlayback();
            } else if (mState == State.COMPLETED) {
                seekTo(0);
                startPlayback();
            } else {
                Log.d(TAG, "play called in state " + mState + " - ignoring");
            }
        }
    }
    
    /**
     * Pauses playback if currently playing.
     * 
     * <p>Playback position is preserved and can be resumed with {@link #resume()}.
     * The AudioTrack is paused but not flushed, so the buffer retains audio data.</p>
     * 
     * <p>If called in any state other than {@link State#PLAYING}, the call is ignored.</p>
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState != State.PLAYING) {
                return;
            }
            
            mIsPaused.set(true);
            mIsPlaying.set(false);
            mState = State.PAUSED;
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    Log.d(TAG, "AudioTrack paused");
                } catch (Exception e) {
                    Log.e(TAG, "pause error", e);
                }
            }
            
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.PLAYING));
            }
        }
    }
    
    /**
     * Resumes playback from a paused state.
     * 
     * <p>If the player is paused, playback continues from the current position.
     * The AudioTrack is restarted and the playback thread is notified.</p>
     * 
     * <p>If called in any state other than {@link State#PAUSED}, the call is ignored.</p>
     */
    public void resume() {
        synchronized (mStateLock) {
            if (mState != State.PAUSED) {
                Log.d(TAG, "resume called but state is " + mState);
                return;
            }
            
            mIsPaused.set(false);
            mIsPlaying.set(true);
            mState = State.PLAYING;
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "AudioTrack resumed");
                } catch (Exception e) {
                    Log.e(TAG, "resume error", e);
                }
            }
            
            // Notify playback thread to continue processing
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
            }
        }
    }
    
    /**
     * Stops playback and resets the player to READY state.
     * 
     * <p>The current song remains loaded but the playback position resets to the
     * beginning. Use this when you want to stop playback but keep the song loaded
     * for future playback.</p>
     * 
     * <p>This method does not release resources; call {@link #release()} to
     * completely free the player.</p>
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    mAudioTrack.flush();
                    Log.d(TAG, "AudioTrack stopped and flushed");
                } catch (Exception e) {
                    Log.e(TAG, "stop error", e);
                }
            }
            
            if (mDecoder != null) {
                mDecoder.seekTo(0);
            }
            
            if (mSoundTouch != null) {
                mSoundTouch.clear();
            }
            
            mIsEOS.set(false);
            mCurrentPosition.set(0);
            mState = State.READY;
            
            Log.d(TAG, "Playback stopped, reset to READY");
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>If the player is in a play state (PLAYING or PAUSED), playback will
     * continue from the new position. The seek operation resets the AudioTrack
     * priming state to ensure smooth playback after the seek.</p>
     * 
     * <p>The seek is performed asynchronously. The playback thread detects the
     * seek target and performs the operation on the next iteration.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) {
                Log.w(TAG, "seekTo called in invalid state: " + mState);
                return;
            }
            
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mSeekTarget.set((int) clampedPosition);
            mCurrentPosition.set(clampedPosition);
            
            // Reset priming state for the seek
            mPrimed.set(false);
            mPrimeCount = 0;
            
            // Wake up playback thread to process seek
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            Log.d(TAG, "Seek requested to " + clampedPosition + "ms");
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch (higher key), negative values lower it
     * (lower key). The effective range is approximately -6 to +6 semitones,
     * though values outside this range may produce audible artifacts.</p>
     * 
     * <p>The change takes effect immediately on subsequent audio frames.
     * There is no audible transition or gap when changing pitch during playback.</p>
     *
     * @param semitones The pitch shift amount in semitones (recommended: -6 to +6)
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mSoundTouch != null) {
            mSoundTouch.setPitchSemiTones(semitones);
            Log.d(TAG, "Pitch set to " + semitones + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5,
     * though values outside this range may produce artifacts.</p>
     * 
     * <p>The change takes effect immediately on subsequent audio frames.
     * There is no audible transition or gap when changing tempo during playback.</p>
     *
     * @param tempo The tempo multiplier (recommended: 0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mSoundTouch != null) {
            mSoundTouch.setTempo(tempo);
            Log.d(TAG, "Tempo set to " + tempo + "x");
        }
    }
    
    /**
     * Returns the total duration of the current song.
     *
     * @return Duration in milliseconds, or 0 if no song loaded or not yet prepared
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the current playback position.
     * 
     * <p>When actively playing, this returns the actual position from AudioTrack's
     * playback head. When paused or stopped, it returns the cached position.</p>
     *
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        // When playing, get actual position from AudioTrack
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    return positionMs;
                }
            } catch (Exception ignored) {
                // Fall through to cached position
            }
        }
        return mCurrentPosition.get();
    }
    
    /**
     * Checks if the player is currently playing audio.
     *
     * @return true if playing, false if paused, stopped, or in any other state
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get() && mState == State.PLAYING;
    }
    
    /**
     * Checks if a song is loaded and the player is ready for playback.
     * 
     * <p>Returns true when the player is in READY, PLAYING, or PAUSED state.
     * These states indicate that a song is loaded and can be played or resumed.</p>
     *
     * @return true if prepared and ready, false otherwise
     */
    public boolean isPrepared() {
        return mState == State.READY || mState == State.PLAYING || mState == State.PAUSED;
    }
    
    /**
     * Returns the audio session ID for the current AudioTrack.
     * 
     * <p>This ID is used by {@link EqualizerManager} to attach an equalizer
     * to the audio session. The session ID is available as soon as the
     * AudioTrack is created, which happens during {@link #loadSong(String)}.</p>
     *
     * @return Audio session ID, or 0 if not available (no AudioTrack created)
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     * 
     * <p>Use this to check the player's state before performing operations
     * that may only be valid in certain states.</p>
     *
     * @return Current {@link State}
     */
    @NonNull
    public State getState() {
        return mState;
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>After calling this method, the player cannot be used again.
     * Any pending operations are cancelled, and native resources are freed.</p>
     * 
     * <p>It is safe to call this method multiple times; subsequent calls
     * have no effect.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "Releasing SoundTouchPlayer resources");
            
            // Stop playback thread
            mRunning.set(false);
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            
            // Wait for playback thread to finish
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.join(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    Log.w(TAG, "Interrupted while waiting for playback thread");
                }
                mPlaybackThread = null;
            }
            
            // Release AudioTrack
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.stop();
                    mAudioTrack.release();
                    Log.d(TAG, "AudioTrack released");
                } catch (Exception e) {
                    Log.e(TAG, "AudioTrack release error", e);
                }
                mAudioTrack = null;
            }
            
            // Close SoundTouch (frees native resources)
            if (mSoundTouch != null) {
                mSoundTouch.close();
                mSoundTouch = null;
                Log.d(TAG, "SoundTouch closed");
            }
            
            // Release decoder
            if (mDecoder != null) {
                mDecoder.release();
                mDecoder = null;
            }
            
            mState = State.RELEASED;
            Log.d(TAG, "SoundTouchPlayer released");
        }
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack instance.
     * 
     * <p>This method calculates the appropriate buffer size based on the
     * sample rate and channel count. The buffer is sized to hold at least
     * {@value #MIN_BUFFER_MS} milliseconds of audio to prevent underruns.</p>
     * 
     * <p>If a previous AudioTrack exists, it is released first.</p>
     */
    private void createAudioTrack() {
        // Release existing AudioTrack if any
        if (mAudioTrack != null) {
            try {
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "release old track error", e);
            }
            mAudioTrack = null;
        }
        
        // Determine channel configuration
        int channelConfig = (mChannels == 2) ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        // Get minimum buffer size from system
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        // Calculate target buffer size for 250ms of audio
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        // Build audio attributes
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        // Build audio format
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        // Create AudioTrack
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + "ch, buffer=" + bufferSize + " bytes");
    }
    
    /**
     * Starts the playback thread and resets priming state.
     * 
     * <p>If the playback thread is already alive, it is resumed rather than
     * recreated. This handles the case where playback was paused and now resumed.</p>
     */
    private void startPlayback() {
        mPrimed.set(false);
        mPrimeCount = 0;
        
        // Check if thread is already running (resume case)
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            mState = State.PLAYING;
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "AudioTrack started (existing thread)");
                } catch (Exception e) {
                    Log.e(TAG, "startPlayback play error", e);
                }
            }
            
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            return;
        }
        
        // Start new playback thread
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        mState = State.PLAYING;
        
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "Playback thread started");
    }
    
    /**
     * Resumes playback from paused state.
     * 
     * <p>This is called when the player is in PAUSED state and play() is called.
     * It restarts the AudioTrack and notifies the playback thread.</p>
     */
    private void resumePlayback() {
        if (mState != State.PAUSED) {
            return;
        }
        
        mIsPaused.set(false);
        mIsPlaying.set(true);
        mState = State.PLAYING;
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "AudioTrack resumed");
            } catch (Exception e) {
                Log.e(TAG, "resume error", e);
            }
        }
        
        // Wake up playback thread
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
        }
    }
    
    /**
     * Main playback loop running on a background thread.
     * 
     * <p>This method continuously:
     * <ol>
     *   <li>Reads PCM frames from the AudioDecoder</li>
     *   <li>Processes frames through SoundTouch for pitch/tempo changes</li>
     *   <li>Writes processed PCM to AudioTrack</li>
     *   <li>Priming: writes PRIME_CHUNK_COUNT chunks before calling play()</li>
     *   <li>Handles seek requests and end-of-stream</li>
     * </ol>
     * </p>
     * 
     * <p>The loop runs with {@link Process#THREAD_PRIORITY_URGENT_AUDIO}
     * priority to minimize audio latency.</p>
     */
    private void playbackLoop() {
        // Set high priority for audio playback
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        // Buffers for audio processing
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Playback loop started");
        
        while (mRunning.get() && mState != State.RELEASED) {
            try {
                // Wait if paused
                if (mIsPaused.get() || mState != State.PLAYING) {
                    synchronized (mPlaybackLock) {
                        if (mIsPaused.get() || mState != State.PLAYING) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                
                // Handle seek request
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0) {
                    performSeek(seekTarget);
                }
                
                // Check for end of stream
                if (mIsEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                // Wait for decoder if not ready
                if (mDecoder == null || !mFormatValidated) {
                    synchronized (mDecoderLock) {
                        if (mDecoder == null || !mFormatValidated) {
                            mDecoderLock.wait(100);
                            continue;
                        }
                    }
                    continue;
                }
                
                // Read PCM frames from decoder
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                if (framesRead < 0) {
                    transitionToError("Decoder read error");
                    break;
                }
                if (framesRead == 0) {
                    continue; // No data yet, try again
                }
                
                // Process through SoundTouch
                short[] samplesToWrite = inputBuffer;
                int sampleCount = framesRead * mChannels;
                
                if (mSoundTouch != null) {
                    mSoundTouch.putSamples(inputBuffer, framesRead);
                    int available = mSoundTouch.numSamples();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mSoundTouch.receiveSamples(outputBuffer, toRead);
                        if (received > 0) {
                            samplesToWrite = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                
                // Convert shorts to bytes for AudioTrack
                for (int i = 0; i < sampleCount; i++) {
                    byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                    byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                }
                
                // Write to AudioTrack
                int written = mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                if (written < 0) {
                    Log.e(TAG, "AudioTrack.write error: " + written);
                    transitionToError("AudioTrack write error: " + written);
                    break;
                }
                
                // Priming: wait until buffer is filled before starting playback
                if (!mPrimed.get()) {
                    mPrimeCount++;
                    if (mPrimeCount >= PRIME_CHUNK_COUNT && mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        try {
                            mAudioTrack.play();
                            mPrimed.set(true);
                            Log.d(TAG, "AudioTrack primed and playing");
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to start AudioTrack after priming", e);
                        }
                    }
                } else if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && mState == State.PLAYING) {
                    // Ensure AudioTrack is playing
                    try {
                        mAudioTrack.play();
                    } catch (Exception e) {
                        Log.e(TAG, "Re-start AudioTrack failed", e);
                    }
                }
                
                // Update cached position
                updateCurrentPosition();
                
                // Send position updates to listener at throttled rate
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "Playback loop interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Playback loop exception", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "Playback loop exited");
    }
    
    /**
     * Performs a seek operation by flushing decoder and AudioTrack.
     * 
     * <p>This method is called from the playback loop when a seek target is set.
     * It seeks the decoder, clears the SoundTouch buffer, and flushes the
     * AudioTrack to remove any stale audio data.</p>
     * 
     * <p>The priming state is also reset to ensure smooth playback after the seek.</p>
     *
     * @param positionMs Target position in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs + "ms");
        
        // Seek the decoder to the new position
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mIsEOS.set(false);
        }
        
        // Clear SoundTouch buffers
        if (mSoundTouch != null) {
            mSoundTouch.clear();
        }
        
        // Flush AudioTrack to remove stale data
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                mPrimed.set(false);
                mPrimeCount = 0;
                Log.d(TAG, "AudioTrack flushed for seek");
            } catch (Exception e) {
                Log.e(TAG, "seek flush error", e);
            }
        }
        
        // Update cached position
        mCurrentPosition.set(positionMs);
    }
    
    /**
     * Updates the cached current position from AudioTrack's playback head.
     * 
     * <p>This method is called on each iteration of the playback loop to keep
     * the cached position approximately in sync with actual playback.</p>
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    mCurrentPosition.set(positionMs);
                }
            } catch (Exception ignored) {
                // Use cached position
            }
        }
    }
    
    /**
     * Handles normal song completion.
     * 
     * <p>When the end of the audio file is reached, this method updates state
     * to COMPLETED and notifies the listener. The playback loop then exits.</p>
     */
    private void handleCompletion() {
        Log.d(TAG, "Song completed");
        mIsPlaying.set(false);
        mIsEOS.set(true);
        mState = State.COMPLETED;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onCompletion();
                listener.onStateChanged(State.COMPLETED, State.PLAYING);
            });
        }
        
        mRunning.set(false);
    }
    
    /**
     * Transitions the player to ERROR state and notifies listener.
     * 
     * <p>This method is called when an unrecoverable error occurs. The player
     * stops all processing and enters the ERROR state. The caller should
     * handle the error appropriately, typically by falling back to MediaPlayer.</p>
     *
     * @param error Description of the error for logging and debugging
     */
    private void transitionToError(String error) {
        synchronized (mStateLock) {
            if (mState == State.ERROR || mState == State.RELEASED) {
                return;
            }
            Log.e(TAG, "Error: " + error);
            mState = State.ERROR;
        }
        
        // Stop all processing
        mRunning.set(false);
        mIsPlaying.set(false);
        
        // Wake up any waiting threads
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        synchronized (mDecoderLock) {
            mDecoderLock.notifyAll();
        }
        
        // Notify listener
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> {
                listener.onError(error);
                listener.onStateChanged(State.ERROR, null);
            });
        }
    }
    
    /**
     * Broadcasts an intent with song duration and audio session ID.
     * 
     * <p>This broadcast is received by {@link MusicPlayer} to update the UI
     * with song duration and to attach the equalizer to the audio session
     * before playback begins.</p>
     * 
     * <p>This solves two critical issues:</p>
     * <ol>
     *   <li>Timer showing 00:00 after folder import (duration is now known)</li>
     *   <li>Equalizer being disabled until play is pressed (session now exists)</li>
     * </ol>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "Broadcast prepared: duration=" + mDuration + "ms, session=" + mAudioSessionId);
    }
}