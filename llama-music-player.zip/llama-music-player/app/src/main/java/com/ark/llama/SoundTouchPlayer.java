package com.ark.llama;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer – High‑quality audio player using MediaCodec + SoundTouch.
 * <p>
 * This player provides independent pitch/tempo control, seeking, and robust error recovery.
 * All public methods are thread‑safe.
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {

    private static final String TAG = "SoundTouchPlayer";

    // Timeout for dequeue operations (microseconds)
    private static final long DECODER_TIMEOUT_US = 10000;
    // Multiplier for AudioTrack buffer size
    private static final int AUDIO_TRACK_BUFFER_MULTIPLIER = 2;
    // Target buffer size in milliseconds for AudioTrack
    private static final int BUFFER_SIZE_MS = 100;
    // Maximum recovery attempts
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    // Maximum consecutive empty output buffers before stall detection
    private static final int MAX_EMPTY_BUFFERS = 50;
    // Progress update interval (ms)
    private static final int PROGRESS_UPDATE_INTERVAL_MS = 500;
    // Pitch and tempo limits
    private static final float MIN_TEMPO = 0.5f;
    private static final float MAX_TEMPO = 1.5f;
    private static final float MIN_PITCH = -6.0f;
    private static final float MAX_PITCH = 6.0f;
    // Fallback sample rates (Hz)
    private static final int[] FALLBACK_SAMPLE_RATES = {48000, 44100, 32000, 24000, 16000};

    // Core components
    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private PitchShifter mPitchShifter;

    // Threading
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // State flags
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    private final AtomicBoolean mIsReleased = new AtomicBoolean(false);
    private final AtomicBoolean mIsEndOfStream = new AtomicBoolean(false);
    private final AtomicBoolean mSeekRequested = new AtomicBoolean(false);
    private int mRecoveryAttempts = 0;
    private int mConsecutiveEmptyBuffers = 0;

    // Seek state
    private long mPendingSeekPosition = -1;
    private final Object mSeekLock = new Object();

    // Audio parameters
    private int mSampleRate = 44100;
    private int mChannels = 2;
    private long mDuration = 0;
    private final AtomicLong mCurrentPosition = new AtomicLong(0);

    // Track info
    private int mAudioTrackIndex = -1;
    private MediaFormat mAudioFormat;

    // Playback parameters
    private float mCurrentPitch = 0f;
    private float mCurrentTempo = 1.0f;

    // Callback
    @Nullable
    private PlaybackListener mListener;

    // Progress updater
    private final Runnable mProgressUpdater = new Runnable() {
        @Override
        public void run() {
            if (mIsPlaying.get() && !mIsPaused.get() && mListener != null) {
                updateCurrentPosition();
                mListener.onPositionUpdate(mCurrentPosition.get());
            }
            if (!mIsReleased.get()) {
                mMainHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS);
            }
        }
    };

    public interface PlaybackListener {
        void onPlaybackStarted();
        void onPlaybackPaused();
        void onPlaybackResumed();
        void onCompletion();
        void onPositionUpdate(long position);
        void onError(@NonNull String error);
        void onPrepared();
    }

    public SoundTouchPlayer() {
        Log.d(TAG, "SoundTouchPlayer created");
    }

    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }

    /**
     * Loads a song from file path.
     * @return true if loading started successfully
     */
    public boolean loadSong(@NonNull String filePath) {
        if (mIsReleased.get()) {
            notifyError("Player is released");
            return false;
        }
        if (!PitchShifter.isLibraryAvailable()) {
            notifyError("PitchShifter library not available");
            return false;
        }

        mIsPreparing.set(true);

        // Release previous resources
        releaseDecoder();
        releaseAudioTrack();
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }

        mConsecutiveEmptyBuffers = 0;
        mSeekRequested.set(false);
        mPendingSeekPosition = -1;
        mIsEndOfStream.set(false);
        mCurrentPosition.set(0);
        mRecoveryAttempts = 0;

        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);

            // Find audio track
            mAudioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mAudioTrackIndex = i;
                    mAudioFormat = format;
                    break;
                }
            }
            if (mAudioTrackIndex == -1 || mAudioFormat == null) {
                notifyError("No audio track found");
                mIsPreparing.set(false);
                return false;
            }

            // Extract audio parameters
            mSampleRate = mAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mChannels = mAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDuration = mAudioFormat.getLong(MediaFormat.KEY_DURATION);
            Log.d(TAG, "Audio format: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");

            // Create PitchShifter
            mPitchShifter = new PitchShifter(mSampleRate, mChannels);
            mPitchShifter.setPitch(mCurrentPitch);
            mPitchShifter.setTempo(mCurrentTempo);

            // Create decoder
            String mime = mAudioFormat.getString(MediaFormat.KEY_MIME);
            mDecoder = MediaCodec.createDecoderByType(mime);
            mDecoder.configure(mAudioFormat, null, null, 0);
            mDecoder.start();

            // Select track in extractor
            mExtractor.selectTrack(mAudioTrackIndex);

            // Create AudioTrack
            if (!createAudioTrack()) {
                notifyError("Failed to create AudioTrack");
                mIsPreparing.set(false);
                return false;
            }

            // Start background thread
            if (mPlaybackThread == null || !mPlaybackThread.isAlive()) {
                mPlaybackThread = new HandlerThread("SoundTouchPlayer");
                mPlaybackThread.start();
                mPlaybackHandler = new Handler(mPlaybackThread.getLooper());
            }

            mIsPreparing.set(false);
            notifyPrepared();

            // Start progress updates
            mMainHandler.removeCallbacks(mProgressUpdater);
            mMainHandler.post(mProgressUpdater);

            Log.d(TAG, "Song loaded successfully");
            return true;

        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            notifyError("Cannot read audio file: " + e.getMessage());
            mIsPreparing.set(false);
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error during load", e);
            notifyError("Load error: " + e.getMessage());
            mIsPreparing.set(false);
            return false;
        }
    }

    public void play() {
        if (mIsReleased.get()) {
            Log.e(TAG, "Cannot play: player released");
            return;
        }
        if (mIsPreparing.get()) {
            Log.d(TAG, "Still preparing, will play when ready");
            return;
        }
        if (mAudioTrack == null || mDecoder == null) {
            notifyError("Player not initialized");
            return;
        }

        if (mIsEndOfStream.get()) {
            seekTo(0);
        }

        mIsPlaying.set(true);
        mIsPaused.set(false);

        if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }

        if (mPlaybackHandler != null && !mPlaybackHandler.hasCallbacks(mPlaybackRunnable)) {
            mPlaybackHandler.post(mPlaybackRunnable);
        }

        notifyPlaybackStarted();
        Log.d(TAG, "Playback started");
    }

    public void pause() {
        if (!mIsPlaying.get() || mIsPaused.get()) return;
        mIsPaused.set(true);
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.pause();
        }
        notifyPlaybackPaused();
        Log.d(TAG, "Playback paused");
    }

    public void resume() {
        if (!mIsPlaying.get() || !mIsPaused.get()) return;
        mIsPaused.set(false);
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mAudioTrack.play();
        }
        notifyPlaybackResumed();
        Log.d(TAG, "Playback resumed");
    }

    public void stop() {
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mSeekRequested.set(false);
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
            } catch (Exception ignored) {}
        }
        if (mPitchShifter != null) {
            mPitchShifter.clear();
        }
        mCurrentPosition.set(0);
        mIsEndOfStream.set(false);
        seekDecoderTo(0);
        Log.d(TAG, "Playback stopped");
    }

    public void seekTo(long positionMs) {
        synchronized (mSeekLock) {
            mPendingSeekPosition = positionMs;
            mSeekRequested.set(true);
        }
    }

    public void setPitch(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        mCurrentPitch = clamped;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(clamped);
        }
    }

    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        mCurrentTempo = clamped;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(clamped);
        }
    }

    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }

    public long getDuration() {
        return mDuration;
    }

    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get();
    }

    public boolean isPrepared() {
        return !mIsPreparing.get() && mAudioTrack != null && mDecoder != null;
    }

    public int getAudioSessionId() {
        return mAudioTrack != null ? mAudioTrack.getAudioSessionId() : 0;
    }

    public void release() {
        if (mIsReleased.get()) return;
        Log.d(TAG, "Releasing SoundTouchPlayer");
        mIsReleased.set(true);
        mIsPlaying.set(false);
        mIsPaused.set(false);
        mSeekRequested.set(false);

        mMainHandler.removeCallbacks(mProgressUpdater);
        if (mPlaybackHandler != null) {
            mPlaybackHandler.removeCallbacks(mPlaybackRunnable);
            mPlaybackHandler = null;
        }
        if (mPlaybackThread != null) {
            mPlaybackThread.quitSafely();
            try {
                mPlaybackThread.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mPlaybackThread = null;
        }

        releaseDecoder();
        releaseAudioTrack();
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        Log.d(TAG, "SoundTouchPlayer released");
    }

    // ========================================================================
    // Private Helpers
    // ========================================================================

    private boolean createAudioTrack() {
        try {
            int channelConfig = (mChannels == 1) ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
            if (minBufferSize <= 0) {
                for (int rate : FALLBACK_SAMPLE_RATES) {
                    minBufferSize = AudioTrack.getMinBufferSize(rate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
                    if (minBufferSize > 0) {
                        Log.w(TAG, "Sample rate fallback: " + mSampleRate + " -> " + rate + " Hz");
                        mSampleRate = rate;
                        break;
                    }
                }
                if (minBufferSize <= 0) {
                    Log.e(TAG, "No viable sample rate found");
                    return false;
                }
            }

            int bufferSize = minBufferSize * AUDIO_TRACK_BUFFER_MULTIPLIER;
            int frameSizeMs = mSampleRate * mChannels * 2 * BUFFER_SIZE_MS / 1000;
            if (bufferSize < frameSizeMs) {
                bufferSize = frameSizeMs;
            }

            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setSampleRate(mSampleRate)
                    .setChannelMask(channelConfig)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build();
            mAudioTrack = new AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed");
                return false;
            }
            Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, bufferSize=" + bufferSize);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            return false;
        }
    }

    private void releaseDecoder() {
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception ignored) {}
            mDecoder = null;
        }
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception ignored) {}
            mExtractor = null;
        }
        mAudioTrackIndex = -1;
        mAudioFormat = null;
    }

    private void releaseAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception ignored) {}
            mAudioTrack = null;
        }
    }

    private void seekDecoderTo(long positionMs) {
        if (mExtractor == null) return;
        try {
            mExtractor.seekTo(positionMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            if (mDecoder != null) {
                mDecoder.flush();
            }
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            Log.d(TAG, "Decoder seeked to " + positionMs + "ms");
        } catch (Exception e) {
            Log.e(TAG, "Seek failed", e);
        }
    }

    private void updateCurrentPosition() {
        if (mAudioTrack != null && !mSeekRequested.get()) {
            try {
                long framesPlayed = mAudioTrack.getPlaybackHeadPosition();
                long positionMs = framesPlayed * 1000L / mSampleRate;
                if (positionMs > mCurrentPosition.get() && positionMs < mDuration) {
                    mCurrentPosition.set(positionMs);
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to update position", e);
            }
        }
    }

    private boolean attemptRecovery() {
        mRecoveryAttempts++;
        if (mRecoveryAttempts > MAX_RECOVERY_ATTEMPTS) {
            notifyError("Playback failed after " + MAX_RECOVERY_ATTEMPTS + " attempts");
            return false;
        }
        Log.w(TAG, "Attempting recovery (" + mRecoveryAttempts + "/" + MAX_RECOVERY_ATTEMPTS + ")");
        boolean wasPlaying = mIsPlaying.get();
        long position = mCurrentPosition.get();
        mIsPlaying.set(false);
        releaseAudioTrack();
        if (!createAudioTrack()) {
            return false;
        }
        seekDecoderTo(position);
        if (wasPlaying) {
            mIsPlaying.set(true);
            mIsPaused.set(false);
            if (mAudioTrack != null) {
                mAudioTrack.play();
            }
        }
        return true;
    }

    private void notifyError(@NonNull final String error) {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onError(error);
                }
            });
        }
    }

    private void notifyPrepared() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPrepared();
                }
            });
        }
    }

    private void notifyPlaybackStarted() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackStarted();
                }
            });
        }
    }

    private void notifyPlaybackPaused() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackPaused();
                }
            });
        }
    }

    private void notifyPlaybackResumed() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onPlaybackResumed();
                }
            });
        }
    }

    private void notifyCompletion() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) mListener.onCompletion();
                }
            });
        }
    }

    // ========================================================================
    // Playback Loop (Input + Output)
    // ========================================================================

    private final Runnable mPlaybackRunnable = new Runnable() {
        @Override
        public void run() {
            if (mIsReleased.get()) return;

            // Handle pending seek
            if (mSeekRequested.getAndSet(false)) {
                long target;
                synchronized (mSeekLock) {
                    target = mPendingSeekPosition;
                    mPendingSeekPosition = -1;
                }
                if (target >= 0) {
                    seekDecoderTo(target);
                    mCurrentPosition.set(target);
                    if (mListener != null) {
                        mListener.onPositionUpdate(target);
                    }
                    mIsEndOfStream.set(false);
                }
                if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.post(this);
                }
                return;
            }

            if (mIsPaused.get()) {
                if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.postDelayed(this, 50);
                }
                return;
            }

            try {
                // 1. Feed input to decoder
                boolean inputEos = feedDecoderInput();

                // 2. Process decoder output
                boolean outputEos = processDecoderOutput();

                if (outputEos || inputEos) {
                    // End of stream reached
                    flushRemainingAudio();
                    mIsPlaying.set(false);
                    mIsEndOfStream.set(true);
                    notifyCompletion();
                    return;
                }

                if (mIsPlaying.get() && !mIsPaused.get() && !mIsReleased.get() && mPlaybackHandler != null) {
                    mPlaybackHandler.post(this);
                }
            } catch (Exception e) {
                Log.e(TAG, "Playback loop error", e);
                if (!attemptRecovery()) {
                    notifyError("Playback error: " + e.getMessage());
                } else if (mPlaybackHandler != null && !mIsReleased.get()) {
                    mPlaybackHandler.post(this);
                }
            }
        }

        /**
         * Feeds one input buffer to the decoder from the extractor.
         * @return true if end of stream has been queued, false otherwise
         */
        private boolean feedDecoderInput() {
            if (mDecoder == null || mExtractor == null) return false;

            int inputIndex = mDecoder.dequeueInputBuffer(DECODER_TIMEOUT_US);
            if (inputIndex < 0) {
                return false;
            }

            ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
            if (inputBuffer == null) {
                return false;
            }

            int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
            if (sampleSize < 0) {
                // End of stream
                mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                return true;
            } else {
                long presentationTimeUs = mExtractor.getSampleTime();
                mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                mExtractor.advance();
                return false;
            }
        }

        /**
         * Processes one decoder output buffer, feeds PCM to PitchShifter,
         * and writes processed audio to AudioTrack.
         * @return true if end of stream was reached, false otherwise
         */
        private boolean processDecoderOutput() {
            if (mDecoder == null) return true;

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int outputIndex = mDecoder.dequeueOutputBuffer(info, DECODER_TIMEOUT_US);

            if (outputIndex >= 0) {
                mConsecutiveEmptyBuffers = 0;
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;

                if (info.size > 0) {
                    ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                    if (outputBuffer != null) {
                        outputBuffer.order(ByteOrder.LITTLE_ENDIAN);
                        int sampleCount = info.size / 2;
                        short[] pcm = new short[sampleCount];
                        for (int i = 0; i < sampleCount; i++) {
                            pcm[i] = outputBuffer.getShort();
                        }
                        int frames = pcm.length / mChannels;
                        mPitchShifter.putFrames(pcm, frames);
                        writeProcessedAudio();
                    }
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
                return eos;
            } else if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                mConsecutiveEmptyBuffers++;
                if (mConsecutiveEmptyBuffers > MAX_EMPTY_BUFFERS) {
                    Log.e(TAG, "Decoder stalled");
                    notifyError("Decoder stalled");
                    return true;
                }
                // Still try to write any pending PitchShifter output
                writeProcessedAudio();
                return false;
            } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                Log.d(TAG, "Output format changed: " + mDecoder.getOutputFormat());
                return false;
            }
            writeProcessedAudio();
            return false;
        }

        private void writeProcessedAudio() {
            if (mAudioTrack == null || mPitchShifter == null) return;
            int availableFrames = mPitchShifter.numFrames();
            if (availableFrames == 0) return;

            short[] output = new short[availableFrames * mChannels];
            int received = mPitchShifter.receiveFrames(output, availableFrames);
            if (received > 0) {
                int samples = received * mChannels;
                int written = mAudioTrack.write(output, 0, samples);
                if (written < 0) {
                    Log.e(TAG, "AudioTrack write error: " + written);
                    if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                        attemptRecovery();
                    }
                }
            }
        }

        private void flushRemainingAudio() {
            if (mPitchShifter == null) return;
            mPitchShifter.flush();
            int empty = 0;
            while (empty < 20) {
                int frames = mPitchShifter.numFrames();
                if (frames == 0) break;
                short[] out = new short[frames * mChannels];
                int received = mPitchShifter.receiveFrames(out, frames);
                if (received > 0 && mAudioTrack != null) {
                    mAudioTrack.write(out, 0, received * mChannels);
                } else {
                    empty++;
                }
            }
        }
    };
}