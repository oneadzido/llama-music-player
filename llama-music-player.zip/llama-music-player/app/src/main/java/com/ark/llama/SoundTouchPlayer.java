package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.FileDescriptor;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - Audio player with independent pitch and tempo control.
 * 
 * <p>This class is designed to mirror Android's MediaPlayer behavior exactly,
 * providing the same state machine, method signatures, listener patterns, and
 * error handling. It uses the native PitchShifter library for independent
 * pitch and tempo control, which is not possible with standard MediaPlayer.</p>
 * 
 * <p>This player works alongside MediaPlayer as the primary player in MusicService,
 * with MediaPlayer serving as a fallback when SoundTouchPlayer encounters errors
 * (e.g., native library missing, decoding failure, or audio format issues).</p>
 * 
 * <h3>Supported Audio Formats</h3>
 * <p>The player supports all formats supported by Android's MediaCodec and
 * MediaExtractor APIs, including:</p>
 * <ul>
 *   <li>MP3 (.mp3)</li>
 *   <li>FLAC (.flac)</li>
 *   <li>OGG (.ogg)</li>
 *   <li>M4A (.m4a)</li>
 *   <li>AAC (.aac)</li>
 *   <li>WAV (.wav)</li>
 * </ul>
 * 
 * <h3>State Machine (Matches MediaPlayer Exactly)</h3>
 * <pre>
 *                    ┌─────────────────────────────────────────────────────────┐
 *                    │                                                         │
 *                    │                                                         │
 *              reset()│                                                         │
 *                    │                                                         │
 *      Idle ─────────┴────────────────────────────────────────────────────────┘
 *        │
 *        │ setDataSource()
 *        ↓
 *   Initialized
 *        │
 *        │ prepare() or prepareAsync()
 *        ↓
 *    Preparing ──┬──(prepare() completes)──→ Prepared
 *                │                            │
 *                └──(prepareAsync() completes)┘
 *                                              │
 *                                              │ start()
 *                                              ↓
 *                                          Started ──┬──pause()──→ Paused
 *                                              │      │              │
 *                                              │      └──start()─────┘
 *                                              │      │
 *                                              │      │ stop()
 *                                              │      ↓
 *                                              │   Stopped
 *                                              │      │
 *                                              │      │ reset()
 *                                              │      ↓
 *                                              │    Idle
 *                                              │
 *                                              │ (playback completes)
 *                                              ↓
 *                                   PlaybackCompleted
 *                                              │
 *                                              │ seekTo() or stop()
 *                                              ↓
 *                                    (returns to appropriate state)
 *
 * Any state can transition to Error (except Released)
 * </pre>
 * 
 * <h3>State Constants (Matches MediaPlayer)</h3>
 * <ul>
 *   <li>{@code MEDIA_PLAYER_STATE_IDLE = 1}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_INITIALIZED = 2}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_PREPARING = 3}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_PREPARED = 4}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_STARTED = 5}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_PAUSED = 6}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_STOPPED = 7}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED = 8}</li>
 *   <li>{@code MEDIA_PLAYER_STATE_ERROR = 9}</li>
 * </ul>
 * 
 * <h3>Error Codes (Matches MediaPlayer)</h3>
 * <ul>
 *   <li>{@code MEDIA_ERROR_UNKNOWN = 1}</li>
 *   <li>{@code MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK = 2}</li>
 *   <li>{@code MEDIA_ERROR_IO = 3}</li>
 *   <li>{@code MEDIA_ERROR_MALFORMED = 4}</li>
 *   <li>{@code MEDIA_ERROR_UNSUPPORTED = 5}</li>
 *   <li>{@code MEDIA_ERROR_TIMED_OUT = 6}</li>
 * </ul>
 * 
 * <h3>Usage Example (Same as MediaPlayer)</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * 
 * player.setOnPreparedListener(mp -> {
 *     int duration = mp.getDuration();
 *     int sessionId = mp.getAudioSessionId();
 *     mp.start();
 * });
 * 
 * player.setOnCompletionListener(mp -> {
 *     // Play next song
 * });
 * 
 * player.setOnErrorListener((mp, what, extra) -> {
 *     // Fallback to MediaPlayer
 *     return true;
 * });
 * 
 * player.setDataSource("/sdcard/Music/song.mp3");
 * player.prepareAsync();
 * 
 * // SoundTouch-specific features (extends MediaPlayer)
 * player.setPitch(2.5f);      // Raise pitch by 2.5 semitones
 * player.setPlaybackParams(1.25f);  // Speed up by 25%
 * 
 * player.pause();
 * player.seekTo(30000);
 * player.release();
 * </pre>
 * 
 * <h3>Integration with MusicService</h3>
 * <p>The MusicService uses this class as the primary player with automatic
 * fallback to MediaPlayer:</p>
 * <pre>
 * if (soundTouchPlayer.loadSong(song.getPath())) {
 *     soundTouchPlayer.play();  // Success - using SoundTouch
 * } else {
 *     fallbackToMediaPlayer();   // Failure - switch to MediaPlayer
 * }
 * </pre>
 * 
 * @see MediaPlayer
 * @see PitchShifter
 * @see AudioDecoder
 * @see AudioTrack
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.2
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Position update interval in milliseconds for UI callbacks. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    // ========================================================================
    // MediaPlayer Error Codes
    // ========================================================================
    
    /** Unspecified media player error. */
    public static final int MEDIA_ERROR_UNKNOWN = 1;
    
    /** Media is not valid for progressive playback (e.g., needs index file). */
    public static final int MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK = 2;
    
    /** Input/Output error during playback. */
    public static final int MEDIA_ERROR_IO = 3;
    
    /** Malformed media stream. */
    public static final int MEDIA_ERROR_MALFORMED = 4;
    
    /** Unsupported media format. */
    public static final int MEDIA_ERROR_UNSUPPORTED = 5;
    
    /** Operation timed out. */
    public static final int MEDIA_ERROR_TIMED_OUT = 6;
    
    // ========================================================================
    // MediaPlayer Info/Warning Codes
    // ========================================================================
    
    /** Unspecified media player info. */
    public static final int MEDIA_INFO_UNKNOWN = 1;
    
    /** Video track is lagging. */
    public static final int MEDIA_INFO_VIDEO_TRACK_LAGGING = 700;
    
    /** Media buffering has started. */
    public static final int MEDIA_INFO_BUFFERING_START = 701;
    
    /** Media buffering has ended. */
    public static final int MEDIA_INFO_BUFFERING_END = 702;
    
    // ========================================================================
    // MediaPlayer State Constants
    // ========================================================================
    
    /** Player is in idle state (initial state after creation or reset). */
    private static final int MEDIA_PLAYER_STATE_IDLE = 1;
    
    /** Data source has been set, player is ready for preparation. */
    private static final int MEDIA_PLAYER_STATE_INITIALIZED = 2;
    
    /** Player is preparing asynchronously. */
    private static final int MEDIA_PLAYER_STATE_PREPARING = 3;
    
    /** Player is prepared and ready for playback. */
    private static final int MEDIA_PLAYER_STATE_PREPARED = 4;
    
    /** Player is actively playing audio. */
    private static final int MEDIA_PLAYER_STATE_STARTED = 5;
    
    /** Player is paused, position preserved. */
    private static final int MEDIA_PLAYER_STATE_PAUSED = 6;
    
    /** Player has been stopped, position reset. */
    private static final int MEDIA_PLAYER_STATE_STOPPED = 7;
    
    /** Playback has completed naturally. */
    private static final int MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED = 8;
    
    /** Player is in error state. */
    private static final int MEDIA_PLAYER_STATE_ERROR = 9;
    
    // ========================================================================
    // MediaPlayer-Compatible Listener Interfaces
    // ========================================================================
    
    /**
     * Interface definition for a callback to be invoked when the media source is ready for playback.
     * 
     * <p>This callback is triggered after a successful prepare() or prepareAsync() call.
     * At this point, the duration and audio session ID are available.</p>
     */
    public interface OnPreparedListener {
        /**
         * Called when the media source is ready for playback.
         *
         * @param mp The SoundTouchPlayer instance that is ready
         */
        void onPrepared(@NonNull SoundTouchPlayer mp);
    }
    
    /**
     * Interface definition for a callback to be invoked when playback of a media source has completed.
     * 
     * <p>This callback is triggered when the end of the audio stream is reached
     * and playback stops naturally.</p>
     */
    public interface OnCompletionListener {
        /**
         * Called when the end of the media source is reached during playback.
         *
         * @param mp The SoundTouchPlayer instance that completed playback
         */
        void onCompletion(@NonNull SoundTouchPlayer mp);
    }
    
    /**
     * Interface definition for a callback to be invoked when an error occurs during playback.
     * 
     * <p>Returning true indicates that the error was handled and no further action is needed.
     * Returning false causes the player to enter the error state.</p>
     */
    public interface OnErrorListener {
        /**
         * Called when an error occurs during playback or preparation.
         *
         * @param mp The SoundTouchPlayer instance that encountered the error
         * @param what The type of error (MEDIA_ERROR_* constant)
         * @param extra An extra error code specific to the error type
         * @return True if the error was handled, false to enter error state
         */
        boolean onError(@NonNull SoundTouchPlayer mp, int what, int extra);
    }
    
    /**
     * Interface definition for a callback to be invoked when a seek operation completes.
     */
    public interface OnSeekCompleteListener {
        /**
         * Called when a seek operation completes.
         *
         * @param mp The SoundTouchPlayer instance that performed the seek
         */
        void onSeekComplete(@NonNull SoundTouchPlayer mp);
    }
    
    /**
     * Interface definition for a callback to be invoked when informational events occur.
     */
    public interface OnInfoListener {
        /**
         * Called when an informational event occurs during playback.
         *
         * @param mp The SoundTouchPlayer instance
         * @param what The type of info event (MEDIA_INFO_* constant)
         * @param extra An extra info code
         * @return True if the info was handled
         */
        boolean onInfo(@NonNull SoundTouchPlayer mp, int what, int extra);
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcasts and resource access. */
    @NonNull private final Context mContext;
    
    // MediaPlayer-compatible listeners
    @Nullable private OnPreparedListener mOnPreparedListener;
    @Nullable private OnCompletionListener mOnCompletionListener;
    @Nullable private OnErrorListener mOnErrorListener;
    @Nullable private OnSeekCompleteListener mOnSeekCompleteListener;
    @Nullable private OnInfoListener mOnInfoListener;
    
    /** Current player state (matches MediaPlayer state machine). */
    private int mState = MEDIA_PLAYER_STATE_IDLE;
    
    /** Lock for thread-safe state changes. */
    private final Object mStateLock = new Object();
    
    /** Pending seek position (-1 if no seek pending). */
    private int mCurrentSeekPosition = -1;
    
    // Audio components
    /** Audio decoder for extracting and decoding audio. */
    @Nullable private AudioDecoder mDecoder;
    
    /** Native pitch shifter for tempo and pitch processing. */
    @Nullable private PitchShifter mPitchShifter;
    
    /** AudioTrack for PCM output. */
    @Nullable private AudioTrack mAudioTrack;
    
    // Audio format
    /** Actual sample rate from decoder output (not container). */
    private int mSampleRate = 44100;
    
    /** Actual channel count from decoder output (not container). */
    private int mChannels = 2;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Duration of current song in milliseconds. */
    private int mDuration = 0;
    
    /** Path of currently loaded song. */
    @Nullable private String mDataSource = null;
    
    /** Flag indicating player is prepared and ready. */
    private boolean mIsPrepared = false;
    
    // Playback state
    /** Flag indicating playback is active. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Current playback position in milliseconds. */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Flag indicating end of stream reached. */
    private boolean mIsEOS = false;
    
    // Pitch and tempo (SoundTouch-specific extensions)
    /** Current pitch shift in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    // Threading
    /** Background playback thread. */
    @Nullable private Thread mPlaybackThread;
    
    /** Flag indicating the playback thread should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Lock for thread synchronization (wait/notify). */
    private final Object mPlaybackLock = new Object();
    
    /** Handler for UI thread callbacks. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>The player starts in the IDLE state and must be initialized with
     * {@link #setDataSource(String)} followed by {@link #prepare()} or
     * {@link #prepareAsync()} before playback can begin.</p>
     *
     * @param context Application context for sending broadcasts and accessing resources
     * @throws IllegalArgumentException if context is null
     */
    public SoundTouchPlayer(@NonNull Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context cannot be null");
        }
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, state=IDLE");
    }
    
    // ========================================================================
    // MediaPlayer-Compatible Data Source Methods
    // ========================================================================
    
    /**
     * Sets the data source (file path) for the media file.
     * 
     * <p>This method must be called before {@link #prepare()} or {@link #prepareAsync()}.
     * The player must be in the IDLE state when calling this method.</p>
     *
     * @param path The path of the media file to play
     * @throws IOException if the file cannot be accessed
     * @throws IllegalStateException if the player is not in IDLE state
     */
    public void setDataSource(@NonNull String path) throws IOException, IllegalStateException {
        synchronized (mStateLock) {
            if (mState != MEDIA_PLAYER_STATE_IDLE) {
                throw new IllegalStateException("setDataSource called in state " + mState);
            }
            mDataSource = path;
            mState = MEDIA_PLAYER_STATE_INITIALIZED;
            Log.d(TAG, "setDataSource: " + path);
        }
    }
    
    /**
     * Sets the data source (Uri) for the media file.
     * 
     * <p>This method resolves the URI to a file path. For content URIs, it attempts
     * to extract the data column. If resolution fails, an IOException is thrown.</p>
     *
     * @param context The application context
     * @param uri The URI of the media file
     * @throws IOException if the URI cannot be resolved
     * @throws IllegalStateException if the player is not in IDLE state
     */
    public void setDataSource(@NonNull Context context, @NonNull Uri uri) throws IOException, IllegalStateException {
        String path = getFilePathFromUri(context, uri);
        if (path == null) {
            throw new IOException("Cannot resolve URI: " + uri);
        }
        setDataSource(path);
    }
    
    /**
     * Sets the data source (FileDescriptor) for the media file.
     * 
     * <p>This method is not supported by SoundTouchPlayer. Use
     * {@link #setDataSource(String)} or {@link #setDataSource(Context, Uri)} instead.</p>
     *
     * @param fd The FileDescriptor of the media file
     * @throws UnsupportedOperationException always thrown
     * @throws IOException never thrown
     * @throws IllegalStateException never thrown
     */
    public void setDataSource(@NonNull FileDescriptor fd) throws IOException, IllegalStateException {
        throw new UnsupportedOperationException("FileDescriptor not supported. Use file path or URI.");
    }
    
    // ========================================================================
    // MediaPlayer-Compatible Preparation Methods
    // ========================================================================
    
    /**
     * Prepares the player synchronously (blocks until ready).
     * 
     * <p>This method parses the media file and creates the audio pipeline.
     * It blocks the calling thread until preparation is complete. After successful
     * preparation, the player enters the PREPARED state and the {@link OnPreparedListener}
     * callback is invoked.</p>
     * 
     * <p>To prepare asynchronously without blocking, use {@link #prepareAsync()}.</p>
     *
     * @throws IOException if the media file cannot be read or decoded
     * @throws IllegalStateException if the player is not in INITIALIZED state
     */
    public void prepare() throws IOException, IllegalStateException {
        synchronized (mStateLock) {
            if (mState != MEDIA_PLAYER_STATE_INITIALIZED) {
                throw new IllegalStateException("prepare called in state " + mState);
            }
            mState = MEDIA_PLAYER_STATE_PREPARING;
        }
        
        try {
            performPrepare();
            
            synchronized (mStateLock) {
                mState = MEDIA_PLAYER_STATE_PREPARED;
                mIsPrepared = true;
            }
            
            Log.d(TAG, "prepare: Complete, duration=" + mDuration);
            
        } catch (Exception e) {
            synchronized (mStateLock) {
                mState = MEDIA_PLAYER_STATE_ERROR;
            }
            throw new IOException(e.getMessage());
        }
    }
    
    /**
     * Prepares the player asynchronously (non-blocking).
     * 
     * <p>This method starts preparation on a background thread and returns immediately.
     * When preparation completes, the {@link OnPreparedListener} callback is invoked.
     * The player enters the PREPARED state and is ready for playback.</p>
     * 
     * <p>To prepare synchronously, use {@link #prepare()}.</p>
     */
    public void prepareAsync() {
        synchronized (mStateLock) {
            if (mState != MEDIA_PLAYER_STATE_INITIALIZED) {
                notifyError(MEDIA_ERROR_UNKNOWN, 0);
                return;
            }
            mState = MEDIA_PLAYER_STATE_PREPARING;
        }
        
        new Thread(() -> {
            try {
                performPrepare();
                
                synchronized (mStateLock) {
                    mState = MEDIA_PLAYER_STATE_PREPARED;
                    mIsPrepared = true;
                }
                
                mMainHandler.post(() -> {
                    if (mOnPreparedListener != null && mState != MEDIA_PLAYER_STATE_ERROR) {
                        mOnPreparedListener.onPrepared(SoundTouchPlayer.this);
                    }
                });
                
            } catch (Exception e) {
                Log.e(TAG, "prepareAsync failed", e);
                synchronized (mStateLock) {
                    mState = MEDIA_PLAYER_STATE_ERROR;
                }
                notifyError(MEDIA_ERROR_UNKNOWN, 0);
            }
        }, "SoundTouch-Prepare").start();
    }
    
    /**
     * Internal preparation logic.
     * Opens decoder, initializes PitchShifter, and creates AudioTrack.
     *
     * @throws IOException if preparation fails
     */
    private void performPrepare() throws IOException {
        if (mDataSource == null) {
            throw new IOException("Data source not set");
        }
        
        // Open decoder
        mDecoder = new AudioDecoder();
        if (!mDecoder.open(mDataSource)) {
            throw new IOException("Failed to open decoder");
        }
        
        // Get audio format
        mSampleRate = mDecoder.getSampleRate();
        mChannels = mDecoder.getChannels();
        mDuration = mDecoder.getDuration();
        
        if (mSampleRate <= 0 || mChannels <= 0 || mChannels > 2) {
            throw new IOException("Invalid audio format: " + mSampleRate + "Hz, " + mChannels + "ch");
        }
        
        // Initialize PitchShifter
        if (PitchShifter.isLibraryAvailable()) {
            mPitchShifter = new PitchShifter(mSampleRate, mChannels);
            mPitchShifter.setPitch(mCurrentPitch);
            mPitchShifter.setTempo(mCurrentTempo);
        }
        
        // Create AudioTrack
        createAudioTrack();
        
        if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
            throw new IOException("AudioTrack creation failed");
        }
        
        mAudioSessionId = mAudioTrack.getAudioSessionId();
        
        // Broadcast for equalizer
        broadcastSongPrepared();
        
        Log.d(TAG, "performPrepare: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration);
    }
    
    // ========================================================================
    // MediaPlayer-Compatible Playback Control Methods
    // ========================================================================
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in PREPARED state, playback starts from the beginning.
     * If the player is in PAUSED state, playback resumes from the current position.
     * If the player is in PLAYBACK_COMPLETED state, playback restarts from the beginning.</p>
     *
     * @throws IllegalStateException if the player is not in PREPARED, PAUSED, or PLAYBACK_COMPLETED state
     */
    public void start() throws IllegalStateException {
        synchronized (mStateLock) {
            if (mState == MEDIA_PLAYER_STATE_PREPARED) {
                mState = MEDIA_PLAYER_STATE_STARTED;
                startPlayback();
            } else if (mState == MEDIA_PLAYER_STATE_PAUSED) {
                mState = MEDIA_PLAYER_STATE_STARTED;
                resumePlayback();
            } else if (mState == MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED) {
                seekTo(0);
                mState = MEDIA_PLAYER_STATE_STARTED;
                startPlayback();
            } else {
                throw new IllegalStateException("start called in state " + getStateName(mState));
            }
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #start()}.</p>
     *
     * @throws IllegalStateException if the player is not in STARTED state
     */
    public void pause() throws IllegalStateException {
        synchronized (mStateLock) {
            if (mState == MEDIA_PLAYER_STATE_STARTED) {
                mState = MEDIA_PLAYER_STATE_PAUSED;
                mIsPlaying.set(false);
                
                if (mAudioTrack != null) {
                    mAudioTrack.pause();
                }
                
                Log.d(TAG, "pause: Playback paused");
            } else {
                throw new IllegalStateException("pause called in state " + getStateName(mState));
            }
        }
    }
    
    /**
     * Stops playback and resets the player position to the beginning.
     * 
     * <p>After calling stop, the player enters the STOPPED state and must be
     * prepared again before playback can resume.</p>
     *
     * @throws IllegalStateException if the player is not in STARTED, PAUSED, or PLAYBACK_COMPLETED state
     */
    public void stop() throws IllegalStateException {
        synchronized (mStateLock) {
            if (mState == MEDIA_PLAYER_STATE_STARTED || mState == MEDIA_PLAYER_STATE_PAUSED || 
                mState == MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED) {
                
                stopPlaybackThread();
                
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.pause();
                        mAudioTrack.flush();
                    } catch (Exception e) {
                        Log.e(TAG, "stop: Error flushing AudioTrack", e);
                    }
                }
                
                if (mDecoder != null) {
                    mDecoder.seekTo(0);
                }
                
                if (mPitchShifter != null) {
                    mPitchShifter.clear();
                }
                
                mIsPlaying.set(false);
                mIsEOS = false;
                mCurrentPosition.set(0);
                mState = MEDIA_PLAYER_STATE_STOPPED;
                
                Log.d(TAG, "stop: Playback stopped");
            } else {
                throw new IllegalStateException("stop called in state " + getStateName(mState));
            }
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation may snap to the nearest key frame. Upon completion,
     * the {@link OnSeekCompleteListener} callback is invoked.</p>
     *
     * @param positionMs Position in milliseconds to seek to (0 = beginning)
     * @throws IllegalStateException if the player is not in PREPARED, STARTED, PAUSED, or PLAYBACK_COMPLETED state
     */
    public void seekTo(int positionMs) throws IllegalStateException {
        synchronized (mStateLock) {
            if (mState == MEDIA_PLAYER_STATE_PREPARED || mState == MEDIA_PLAYER_STATE_STARTED || 
                mState == MEDIA_PLAYER_STATE_PAUSED || mState == MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED) {
                
                mCurrentSeekPosition = Math.max(0, Math.min(positionMs, mDuration));
                mCurrentPosition.set(mCurrentSeekPosition);
                mIsEOS = false;
                
                // Wake up playback thread
                synchronized (mPlaybackLock) {
                    mPlaybackLock.notifyAll();
                }
                
                Log.d(TAG, "seekTo: " + positionMs + "ms");
            } else {
                throw new IllegalStateException("seekTo called in state " + getStateName(mState));
            }
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>Uses AudioTrack's playback head position for accuracy during active playback.</p>
     *
     * @return Current position in milliseconds, or 0 if not available
     */
    public int getCurrentPosition() {
        if (mAudioTrack != null && mState == MEDIA_PLAYER_STATE_STARTED) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                return (int) ((frames * 1000) / mSampleRate);
            } catch (Exception e) {
                // Fallback to cached position
            }
        }
        return (int) mCurrentPosition.get();
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public int getDuration() {
        return mDuration;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mState == MEDIA_PLAYER_STATE_STARTED && mIsPlaying.get();
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     * 
     * <p>The session ID is valid after the player enters the PREPARED state.</p>
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    // ========================================================================
    // SoundTouch-Specific Methods (Extends MediaPlayer Capabilities)
    // ========================================================================
    
    /**
     * Sets the playback speed (tempo) independently of pitch.
     * 
     * <p>This extends MediaPlayer's capabilities by allowing tempo changes
     * without affecting pitch. Values less than 1.0 slow down the audio,
     * values greater than 1.0 speed it up.</p>
     *
     * @param tempo The tempo multiplier (recommended: 0.5 to 1.5)
     */
    public void setPlaybackParams(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
            Log.d(TAG, "setPlaybackParams: tempo=" + tempo);
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>This extends MediaPlayer's capabilities by allowing pitch changes
     * without affecting tempo. Positive values raise the pitch, negative values
     * lower it.</p>
     *
     * @param semitones The pitch shift amount in semitones (recommended: -6 to +6)
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
            Log.d(TAG, "setPitch: " + semitones + " semitones");
        }
    }
    
    // ========================================================================
    // MediaPlayer-Compatible Listener Methods
    // ========================================================================
    
    /**
     * Registers a callback to be invoked when the media source is ready for playback.
     *
     * @param listener The callback to be invoked, or null to remove the listener
     */
    public void setOnPreparedListener(@Nullable OnPreparedListener listener) {
        mOnPreparedListener = listener;
    }
    
    /**
     * Registers a callback to be invoked when playback of a media source has completed.
     *
     * @param listener The callback to be invoked, or null to remove the listener
     */
    public void setOnCompletionListener(@Nullable OnCompletionListener listener) {
        mOnCompletionListener = listener;
    }
    
    /**
     * Registers a callback to be invoked when an error occurs during playback.
     *
     * @param listener The callback to be invoked, or null to remove the listener
     */
    public void setOnErrorListener(@Nullable OnErrorListener listener) {
        mOnErrorListener = listener;
    }
    
    /**
     * Registers a callback to be invoked when a seek operation completes.
     *
     * @param listener The callback to be invoked, or null to remove the listener
     */
    public void setOnSeekCompleteListener(@Nullable OnSeekCompleteListener listener) {
        mOnSeekCompleteListener = listener;
    }
    
    /**
     * Registers a callback to be invoked when informational events occur.
     *
     * @param listener The callback to be invoked, or null to remove the listener
     */
    public void setOnInfoListener(@Nullable OnInfoListener listener) {
        mOnInfoListener = listener;
    }
    
    // ========================================================================
    // MediaPlayer-Compatible Reset and Release Methods
    // ========================================================================
    
    /**
     * Resets the player to the IDLE state.
     * 
     * <p>This method releases all resources and returns the player to its
     * initial state. A new data source must be set before playback can resume.</p>
     */
    public void reset() {
        Log.d(TAG, "reset");
        
        stopPlaybackThread();
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "reset: Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
        }
        
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        
        mIsPlaying.set(false);
        mIsEOS = false;
        mCurrentPosition.set(0);
        mCurrentSeekPosition = -1;
        mDataSource = null;
        mDuration = 0;
        mIsPrepared = false;
        
        synchronized (mStateLock) {
            mState = MEDIA_PLAYER_STATE_IDLE;
        }
        
        Log.d(TAG, "reset: Player reset to IDLE");
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed to prevent
     * memory leaks. After release, the player cannot be used again.</p>
     */
    public void release() {
        Log.d(TAG, "release");
        
        stopPlaybackThread();
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "release: Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
        }
        
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        
        synchronized (mStateLock) {
            mState = MEDIA_PLAYER_STATE_ERROR;
        }
        
        Log.d(TAG, "release: Player released");
    }
    
    // ========================================================================
    // Package-Private Methods for MusicService Integration
    // ========================================================================
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method is called by MusicService to obtain the song duration and
     * audio session ID before the user presses play. It returns true if successful,
     * false otherwise (triggering fallback to MediaPlayer).</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was successful, false otherwise
     */
    boolean preLoad(@NonNull String filePath) {
        try {
            setDataSource(filePath);
            prepare();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "preLoad failed", e);
            return false;
        }
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method is called by MusicService when playing a song. It returns
     * true if successful, false otherwise (triggering fallback to MediaPlayer).</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false otherwise
     */
    boolean loadSong(@NonNull String filePath) {
        try {
            if (mState != MEDIA_PLAYER_STATE_IDLE && mState != MEDIA_PLAYER_STATE_INITIALIZED) {
                reset();
            }
            setDataSource(filePath);
            prepare();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "loadSong failed", e);
            return false;
        }
    }
    
    /**
     * Checks if the player has been prepared and is ready for playback.
     *
     * @return true if prepared, false otherwise
     */
    boolean isPrepared() {
        return mIsPrepared && mState == MEDIA_PLAYER_STATE_PREPARED;
    }
    
    // ========================================================================
    // Private Methods - Playback Thread Management
    // ========================================================================
    
    /**
     * Starts the playback thread.
     */
    private void startPlayback() {
        if (mPlaybackThread != null && mPlaybackThread.isAlive()) {
            mIsPlaying.set(true);
            if (mAudioTrack != null) {
                mAudioTrack.play();
            }
            synchronized (mPlaybackLock) {
                mPlaybackLock.notifyAll();
            }
            return;
        }
        
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsEOS = false;
        
        if (mAudioTrack != null) {
            mAudioTrack.play();
        }
        
        mPlaybackThread = new Thread(this::playbackLoop, "SoundTouch-Playback");
        mPlaybackThread.start();
        
        Log.d(TAG, "startPlayback: Thread started");
    }
    
    /**
     * Resumes playback from a paused state.
     */
    private void resumePlayback() {
        mIsPlaying.set(true);
        if (mAudioTrack != null) {
            mAudioTrack.play();
        }
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        Log.d(TAG, "resumePlayback: Resumed");
    }
    
    /**
     * Stops the playback thread.
     */
    private void stopPlaybackThread() {
        mRunning.set(false);
        synchronized (mPlaybackLock) {
            mPlaybackLock.notifyAll();
        }
        if (mPlaybackThread != null) {
            try {
                mPlaybackThread.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mPlaybackThread = null;
        }
    }
    
    // ========================================================================
    // Private Methods - Main Playback Loop
    // ========================================================================
    
    /**
     * Main playback loop that runs on a background thread.
     * 
     * <p>This loop reads PCM data from the decoder, processes it through the
     * PitchShifter, and writes the processed audio to AudioTrack.</p>
     */
    private void playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] outputBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mChannels * 2];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "playbackLoop: Started");
        
        while (mRunning.get() && mState != MEDIA_PLAYER_STATE_ERROR) {
            try {
                // Wait if paused
                if (!mIsPlaying.get()) {
                    synchronized (mPlaybackLock) {
                        if (!mIsPlaying.get()) {
                            mPlaybackLock.wait();
                            continue;
                        }
                    }
                }
                
                // Handle pending seek
                if (mCurrentSeekPosition >= 0) {
                    performSeek(mCurrentSeekPosition);
                    mCurrentSeekPosition = -1;
                    
                    mMainHandler.post(() -> {
                        if (mOnSeekCompleteListener != null && mState != MEDIA_PLAYER_STATE_ERROR) {
                            mOnSeekCompleteListener.onSeekComplete(SoundTouchPlayer.this);
                        }
                    });
                }
                
                // Check for end of stream
                if (mIsEOS || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                if (mDecoder == null) {
                    Thread.sleep(10);
                    continue;
                }
                
                // Read PCM
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead < 0) {
                    Log.e(TAG, "playbackLoop: Decoder error");
                    notifyError(MEDIA_ERROR_IO, 0);
                    break;
                }
                
                if (framesRead == 0) {
                    Thread.sleep(5);
                    continue;
                }
                
                // Process through PitchShifter
                short[] samples = inputBuffer;
                int sampleCount = framesRead * mChannels;
                
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        if (received > 0) {
                            samples = outputBuffer;
                            sampleCount = received * mChannels;
                        }
                    }
                }
                
                // Write to AudioTrack
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && mIsPlaying.get()) {
                        mAudioTrack.play();
                    }
                    
                    // Convert shorts to bytes (little-endian)
                    for (int i = 0; i < sampleCount; i++) {
                        byteBuffer[i * 2] = (byte) (samples[i] & 0xFF);
                        byteBuffer[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
                    }
                    
                    mAudioTrack.write(byteBuffer, 0, sampleCount * 2);
                }
                
                // Update position
                updateCurrentPosition();
                
                // Notify position updates
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "playbackLoop: Interrupted");
                break;
            } catch (Exception e) {
                Log.e(TAG, "playbackLoop: Error", e);
                notifyError(MEDIA_ERROR_UNKNOWN, 0);
                break;
            }
        }
        
        Log.d(TAG, "playbackLoop: Exited");
    }
    
    /**
     * Performs a seek operation.
     *
     * @param positionMs Position to seek to in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: " + positionMs + "ms");
        
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mIsEOS = false;
        }
        
        if (mPitchShifter != null) {
            mPitchShifter.clear();
        }
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                if (mIsPlaying.get()) {
                    mAudioTrack.play();
                }
            } catch (Exception e) {
                Log.e(TAG, "performSeek: Error flushing", e);
            }
        }
        
        mCurrentPosition.set(positionMs);
    }
    
    /**
     * Updates the current playback position using AudioTrack head position.
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && mIsPlaying.get()) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long position = (frames * 1000) / mSampleRate;
                if (position < mDuration) {
                    mCurrentPosition.set(position);
                }
            } catch (Exception e) {
                // Use cached position
            }
        }
    }
    
    /**
     * Handles song completion.
     */
    private void handleCompletion() {
        Log.d(TAG, "handleCompletion: Playback completed");
        
        mIsPlaying.set(false);
        mIsEOS = true;
        
        synchronized (mStateLock) {
            if (mState == MEDIA_PLAYER_STATE_STARTED) {
                mState = MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED;
            }
        }
        
        mMainHandler.post(() -> {
            if (mOnCompletionListener != null && mState != MEDIA_PLAYER_STATE_ERROR) {
                mOnCompletionListener.onCompletion(SoundTouchPlayer.this);
            }
        });
    }
    
    // ========================================================================
    // Private Methods - AudioTrack Creation
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack with the validated format.
     */
    private void createAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "createAudioTrack: Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, 
            AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createAudioTrack: Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mChannels * 2;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat format = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        mAudioTrack = new AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build();
        
        Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, " + mChannels + "ch");
    }
    
    // ========================================================================
    // Private Methods - Error Handling
    // ========================================================================
    
    /**
     * Notifies the error listener of an error.
     *
     * @param what The error code
     * @param extra Extra error information
     */
    private void notifyError(int what, int extra) {
        mMainHandler.post(() -> {
            if (mOnErrorListener != null && mState != MEDIA_PLAYER_STATE_ERROR) {
                mOnErrorListener.onError(SoundTouchPlayer.this, what, extra);
            }
        });
    }
    
    /**
     * Returns a human-readable state name for logging.
     *
     * @param state The state constant
     * @return Human-readable state name
     */
    private String getStateName(int state) {
        switch (state) {
            case MEDIA_PLAYER_STATE_IDLE: return "IDLE";
            case MEDIA_PLAYER_STATE_INITIALIZED: return "INITIALIZED";
            case MEDIA_PLAYER_STATE_PREPARING: return "PREPARING";
            case MEDIA_PLAYER_STATE_PREPARED: return "PREPARED";
            case MEDIA_PLAYER_STATE_STARTED: return "STARTED";
            case MEDIA_PLAYER_STATE_PAUSED: return "PAUSED";
            case MEDIA_PLAYER_STATE_STOPPED: return "STOPPED";
            case MEDIA_PLAYER_STATE_PLAYBACK_COMPLETED: return "PLAYBACK_COMPLETED";
            case MEDIA_PLAYER_STATE_ERROR: return "ERROR";
            default: return "UNKNOWN(" + state + ")";
        }
    }
    
    // ========================================================================
    // Private Methods - Broadcast
    // ========================================================================
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mDataSource);
        mContext.sendBroadcast(intent);
        Log.d(TAG, "broadcastSongPrepared: duration=" + mDuration + ", session=" + mAudioSessionId);
    }
    
    // ========================================================================
    // Private Methods - URI Helper
    // ========================================================================
    
    /**
     * Converts a content URI to a file system path.
     *
     * @param context Application context
     * @param uri The URI to convert
     * @return File system path, or null if resolution fails
     */
    @Nullable
    private String getFilePathFromUri(@NonNull Context context, @NonNull Uri uri) {
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        
        try {
            String[] projection = {android.provider.MediaStore.MediaColumns.DATA};
            try (android.database.Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.MediaColumns.DATA);
                    return cursor.getString(columnIndex);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to resolve URI", e);
        }
        return null;
    }
}