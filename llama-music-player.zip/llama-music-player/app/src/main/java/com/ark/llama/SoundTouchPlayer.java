package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <p>This implementation follows a Professional Audio Engine Architecture
 * specification with strict separation of concerns, explicit state machine,
 * and dedicated threads for decoding and rendering.</p>
 * 
 * <h3>Architecture (Per Specification)</h3>
 * <pre>
 * MusicPlayer (UI) -> MusicService (Playlist) -> SoundTouchPlayer (Playback)
 *                                                                                          |
 *                                                                                         \/
 * AudioTrack (Output) <- PitchShifter (DSP) <- AudioDecoder (Decode)
 * </pre>
 * 
 * <h3>State Machine (APPENDIX A)</h3>
 * <pre>
 * IDLE -> PREPARING -> PREPARED -> READY -> PLAYING • PAUSED -> COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * <h3>Thread Ownership (APPENDIX B)</h3>
 * <ul>
 *   <li><b>UI Thread</b> - Commands (play/pause/seek/load) and callbacks</li>
 *   <li><b>Decoder Thread</b> - MediaExtractor/MediaCodec, PCM extraction</li>
 *   <li><b>Renderer Thread</b> - SoundTouch DSP, AudioTrack writes</li>
 *   <li><b>Watchdog Thread</b> - Health monitoring, stall detection</li>
 * </ul>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Accurate position tracking using AudioTrack playback head</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Pre-load capability for immediate duration and audio session access</li>
 *   <li>Watchdog thread for stall detection and recovery</li>
 *   <li>Explicit state machine for predictable behavior</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() { ... }
 *     public void onCompletion() { ... }
 * });
 * 
 * // Pre-load for duration and session (optional)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Or load and play immediately
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.play();
 * 
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * 
 * player.release();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Default sample rate (44.1 kHz) - will be overridden by actual decoder output. */
    private static final int DEFAULT_SAMPLE_RATE = 44100;
    
    /** Default number of channels (stereo) - will be overridden by actual decoder output. */
    private static final int DEFAULT_CHANNELS = 2;
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Position update interval in milliseconds for UI callbacks. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Maximum stall time in milliseconds before watchdog intervenes. */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    /** Watchdog check interval in milliseconds. */
    private static final int WATCHDOG_INTERVAL_MS = 500;
    
    /** Number of consecutive stalls before recovery is attempted. */
    private static final int MAX_STALL_COUNT = 3;
    
    /** Sleep time when idle in milliseconds (background thread only). */
    private static final int IDLE_SLEEP_MS = 10;
    
    /** Sleep time when no data available in milliseconds (background thread only). */
    private static final int NO_DATA_SLEEP_MS = 5;
    
    /** Delay for retrying AudioTrack play when not ready. */
    private static final int AUDIOTRACK_RETRY_DELAY_MS = 50;
    
    /** Timeout for loadSong() to wait for player to be ready. */
    private static final long LOAD_TIMEOUT_MS = 8000;
    
    /** Success code for AudioTrack operations. */
    private static final int AUDIOTRACK_SUCCESS = 0;
    
    /** Error code indicating AudioTrack is dead and needs recreation. */
    private static final int AUDIOTRACK_ERROR_DEAD_OBJECT = -6;
    
    // ========================================================================
    // State Machine (APPENDIX A)
    // ========================================================================
    
    /**
     * Player states as defined in APPENDIX A of the architecture specification.
     * 
     * <p>State transitions:</p>
     * <pre>
     * IDLE -> PREPARING -> PREPARED -> READY -> PLAYING • PAUSED -> COMPLETED
     * Any state may transition to ERROR or RELEASED
     * </pre>
     */
    public enum State {
        /** Initial state, no resources allocated. */
        IDLE,
        
        /** Decoder is being created. */
        PREPARING,
        
        /** Decoder open, waiting for format validation. */
        PREPARED,
        
        /** AudioTrack created, format validated, ready to play. */
        READY,
        
        /** Actively playing audio. */
        PLAYING,
        
        /** Playback paused, position preserved. */
        PAUSED,
        
        /** End of stream reached naturally. */
        COMPLETED,
        
        /** Error occurred, needs recovery or release. */
        ERROR,
        
        /** Resources released, terminal state. */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>Implement this interface to be notified of playback state changes
     * such as start, pause, completion, and errors.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         *
         * @param newState The new state
         * @param oldState The previous state
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * The audio session is now available and duration is known.
         */
        void onPrepared();
        
        /**
         * Called when the current song completes playback.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback.
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Command Queue (Thread-Safe Communication)
    // ========================================================================
    
    /**
     * Commands that can be sent from UI thread to decoder/renderer threads.
     * Uses Command pattern for thread-safe communication between layers.
     */
    private enum Command {
        /** No operation. */
        NONE,
        
        /** Load a song file. */
        LOAD,
        
        /** Start playback. */
        PLAY,
        
        /** Pause playback. */
        PAUSE,
        
        /** Resume playback from paused state. */
        RESUME,
        
        /** Stop playback and reset position. */
        STOP,
        
        /** Seek to a specific position. */
        SEEK,
        
        /** Set pitch shift amount. */
        SET_PITCH,
        
        /** Set tempo multiplier. */
        SET_TEMPO,
        
        /** Release all resources. */
        RELEASE
    }
    
    /**
     * Command with optional parameters.
     * Immutable for thread safety.
     */
    private static class CommandMessage {
        final Command command;
        final String stringParam;
        final int intParam;
        final float floatParam;
        
        CommandMessage(Command command) {
            this(command, null, 0, 0f);
        }
        
        CommandMessage(Command command, String stringParam) {
            this(command, stringParam, 0, 0f);
        }
        
        CommandMessage(Command command, int intParam) {
            this(command, null, intParam, 0f);
        }
        
        CommandMessage(Command command, float floatParam) {
            this(command, null, 0, floatParam);
        }
        
        private CommandMessage(Command command, String stringParam, int intParam, float floatParam) {
            this.command = command;
            this.stringParam = stringParam;
            this.intParam = intParam;
            this.floatParam = floatParam;
        }
        
        /**
         * Creates a LOAD command with a file path.
         *
         * @param path The file path to load
         * @return The command message
         */
        static CommandMessage load(String path) {
            return new CommandMessage(Command.LOAD, path);
        }
        
        /**
         * Creates a SEEK command with a position.
         *
         * @param positionMs The position in milliseconds
         * @return The command message
         */
        static CommandMessage seek(int positionMs) {
            return new CommandMessage(Command.SEEK, positionMs);
        }
        
        /**
         * Creates a SET_PITCH command.
         *
         * @param semitones The pitch shift in semitones
         * @return The command message
         */
        static CommandMessage setPitch(float semitones) {
            return new CommandMessage(Command.SET_PITCH, semitones);
        }
        
        /**
         * Creates a SET_TEMPO command.
         *
         * @param tempo The tempo multiplier
         * @return The command message
         */
        static CommandMessage setTempo(float tempo) {
            return new CommandMessage(Command.SET_TEMPO, tempo);
        }
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcasts. */
    @NonNull
    private final Context mContext;
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Current player state (atomic for thread-safe reads). */
    private final AtomicReference<State> mState = new AtomicReference<>(State.IDLE);
    
    /** Command queue for decoder thread (thread-safe). */
    private final ConcurrentLinkedQueue<CommandMessage> mCommandQueue = new ConcurrentLinkedQueue<>();
    
    /** Latch for loadSong() to wait for player to be ready. */
    @Nullable
    private CountDownLatch mReadyLatch;
    
    /** Lock for thread coordination. */
    private final Object mStateLock = new Object();
    
    /** Lock for renderer waiting. */
    private final Object mRendererLock = new Object();
    
    /** Flag indicating release is complete. */
    private boolean mReleaseComplete = true;
    
    /** Playback start system time for position tracking. */
    private long mPlaybackStartSystemTime = 0;
    
    /** Seek adjustment for position tracking. */
    private long mSeekAdjustmentMs = 0;
    
    // ========================================================================
    // Audio Components
    // ========================================================================
    
    /** Audio decoder (MediaExtractor/MediaCodec). Owned by decoder thread. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** Native pitch shifter (SoundTouch JNI). Owned by renderer thread. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** AudioTrack for PCM output. Owned by renderer thread. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    // ========================================================================
    // Threads (APPENDIX B)
    // ========================================================================
    
    /** Decoder thread for extraction and decode. */
    @Nullable
    private HandlerThread mDecoderThread;
    
    /** Handler for decoder thread commands. */
    @Nullable
    private Handler mDecoderHandler;
    
    /** Renderer thread for DSP and AudioTrack writes. */
    @Nullable
    private HandlerThread mRendererThread;
    
    /** Handler for renderer thread commands. */
    @Nullable
    private Handler mRendererHandler;
    
    /** Watchdog thread for health monitoring. */
    @Nullable
    private HandlerThread mWatchdogThread;
    
    /** Handler for watchdog thread. */
    @Nullable
    private Handler mWatchdogHandler;
    
    /** Runnable for continuous rendering loop. */
    @Nullable
    private Runnable mRenderRunnable;
    
    /** Runnable for watchdog monitoring. */
    @Nullable
    private Runnable mWatchdogRunnable;
    
    /** Handler for UI thread callbacks. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Decoder State (Owned by decoder thread, read by renderer)
    // ========================================================================
    
    /** Current file path. */
    private final AtomicReference<String> mCurrentFilePath = new AtomicReference<>();
    
    /** Song duration in milliseconds. */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** Current sample rate from decoder. */
    private int mSampleRate = DEFAULT_SAMPLE_RATE;
    
    /** Number of channels from decoder. */
    private int mChannels = DEFAULT_CHANNELS;
    
    /** Frame size (samples per frame = channels). */
    private int mFrameSize = DEFAULT_CHANNELS;
    
    /** Flag indicating decoder has reached EOS. */
    private final AtomicBoolean mDecoderEOS = new AtomicBoolean(false);
    
    /** Flag indicating decoder is active (not stopped). */
    private final AtomicBoolean mDecoderActive = new AtomicBoolean(false);
    
    // ========================================================================
    // Rendering State (Owned by renderer thread)
    // ========================================================================
    
    /** Current pitch setting. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo setting. */
    private float mCurrentTempo = 1.0f;
    
    /** AudioTrack buffer size in bytes. */
    private int mAudioTrackBufferSize = 0;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Flag indicating format has been validated (AudioTrack created with correct format). */
    private boolean mFormatValidated = false;
    
    /** Seek target position in milliseconds (-1 = no seek). */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Flag indicating AudioTrack play was requested but pending format change. */
    private boolean mPlayPending = false;
    
    /** Flag indicating if AudioTrack is currently in a bad state needing recreation. */
    private boolean mAudioTrackNeedsRecreation = false;
    
    // ========================================================================
    // Watchdog State
    // ========================================================================
    
    /** Last reported playback position from renderer. */
    private final AtomicLong mLastReportedPosition = new AtomicLong(0);
    
    /** Last timestamp when position changed. */
    private final AtomicLong mLastPositionChangeTime = new AtomicLong(System.currentTimeMillis());
    
    /** Number of consecutive stalls detected. */
    private final AtomicInteger mStallCount = new AtomicInteger(0);
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>Initializes the player in IDLE state. Resources are allocated lazily
     * when a song is loaded.</p>
     *
     * @param context Application context for sending broadcasts
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, initial state: IDLE");
    }
    
    // ========================================================================
    // Public API Methods (UI Thread)
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     *
     * @param listener The listener to receive events (can be null)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Creates AudioTrack immediately (synchronously) to get audio session ID.
     * This ensures equalizer can attach before playback starts.
     * The AudioTrack will be recreated later with correct format if needed.
     * 
     * <p>Per Android AudioTrack documentation:
     * <ul>
     *   <li>Use Builder pattern for creation</li>
     *   <li>Call getAudioSessionId() AFTER creation</li>
     *   <li>Verify STATE_INITIALIZED after creation</li>
     * </ul>
     * </p>
     */
    private void createImmediateAudioTrack() {
        if (mAudioTrack != null) {
            Log.d(TAG, "AudioTrack already exists, session=" + mAudioSessionId);
            return;
        }
        
        // Use default values initially - will be reconfigured when format is known
        int channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
        int sampleRate = DEFAULT_SAMPLE_RATE;
        
        // Calculate minimum buffer size per documentation
        int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createImmediateAudioTrack: Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        // Target buffer for 250ms of audio per specification
        int frameSize = DEFAULT_CHANNELS * 2; // 2 bytes per sample for 16-bit PCM
        int targetBufferFrames = sampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * frameSize;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        // Build AudioAttributes as per documentation
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        // Build AudioFormat as per documentation
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        try {
            // Create AudioTrack using Builder pattern (recommended by documentation)
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            // Verify initialization state per documentation
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack not initialized, state=" + mAudioTrack.getState());
                mAudioTrack = null;
                return;
            }
            
            // Get audio session ID AFTER creation (per documentation)
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            Log.d(TAG, "Immediate AudioTrack created - session=" + mAudioSessionId + 
                  ", bufferSize=" + bufferSize + ", minBuffer=" + minBufferSize);
            
            // Broadcast session immediately for equalizer
            broadcastSongPrepared();
            
        } catch (Exception e) {
            Log.e(TAG, "createImmediateAudioTrack failed", e);
            mAudioTrack = null;
        }
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method initializes the decoder and CREATES the AudioTrack immediately
     * to ensure the audio session ID is available for equalizer attachment.</p>
     * 
     * <p>State transition: IDLE/PREPARED/COMPLETED/ERROR -> PREPARING</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was initiated successfully, false otherwise
     */
    public boolean preLoad(@NonNull String filePath) {
        checkNotReleased();
        
        State currentState = mState.get();
        Log.d(TAG, "preLoad: " + filePath + ", currentState=" + currentState);
        
        // If already preparing, queue the command and return
        if (currentState == State.PREPARING) {
            Log.d(TAG, "preLoad: Already preparing, queuing command");
            mCommandQueue.offer(CommandMessage.load(filePath));
            return true;
        }
        
        // Release existing resources if needed
        if (currentState != State.IDLE && currentState != State.ERROR) {
            Log.d(TAG, "preLoad: Releasing existing resources");
            releaseInternal();
        }
        
        // Queue load command
        mCommandQueue.offer(CommandMessage.load(filePath));
        startDecoderThread();
        
        // CRITICAL: Create AudioTrack immediately so session ID is available
        // This ensures equalizer can attach before playback starts
        createImmediateAudioTrack();
        
        // Notify listener that we're preparing
        transitionTo(State.PREPARING);
        
        return true;
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method internally calls {@link #preLoad(String)} to initialize
     * the decoder. The player will be ready to play immediately after this
     * method returns true.</p>
     * 
     * <p>State transition: IDLE/PREPARED/COMPLETED/ERROR -> PREPARING -> READY</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false otherwise
     */
    public boolean loadSong(@NonNull String filePath) {
        checkNotReleased();
        
        Log.d(TAG, "loadSong: Loading " + filePath);
        
        // Create a new latch for this load operation
        mReadyLatch = new CountDownLatch(1);
        
        // Start preload
        if (!preLoad(filePath)) {
            Log.e(TAG, "loadSong: preLoad failed");
            return false;
        }
        
        // Wait for player to be READY
        try {
            boolean ready = mReadyLatch.await(LOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (!ready) {
                Log.e(TAG, "loadSong: Timeout waiting for player to be ready");
                transitionToError("Load timeout");
                return false;
            }
        } catch (InterruptedException e) {
            Log.e(TAG, "loadSong: Interrupted while waiting", e);
            Thread.currentThread().interrupt();
            return false;
        }
        
        boolean success = mState.get() == State.READY;
        Log.d(TAG, "loadSong: Complete, success=" + success + ", state=" + mState.get());
        return success;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>State transitions:</p>
     * <ul>
     *   <li>READY -> PLAYING</li>
     *   <li>PAUSED -> PLAYING</li>
     *   <li>COMPLETED -> seeks to 0 then PLAYING</li>
     * </ul>
     */
    public void play() {
        checkNotReleased();
        
        State currentState = mState.get();
        Log.d(TAG, "play() called, currentState=" + currentState + ", formatValidated=" + mFormatValidated);
        
        if (currentState == State.READY || currentState == State.PREPARED) {
            // Reset timing for accurate seekbar
            mPlaybackStartSystemTime = System.currentTimeMillis();
            mSeekAdjustmentMs = 0;
            
            // If format not validated yet, mark play as pending
            if (!mFormatValidated) {
                Log.d(TAG, "play() called before format validated - marking pending");
                mPlayPending = true;
                return;
            }
            
            sendCommand(Command.PLAY);
        } else if (currentState == State.PAUSED) {
            // Resume from pause - keep current position
            sendCommand(Command.RESUME);
        } else if (currentState == State.COMPLETED) {
            // Seek to start then play
            if (mDecoder != null) {
                mDecoder.seekTo(0);
                mDecoderEOS.set(false);
            }
            mSeekAdjustmentMs = 0;
            if (!mFormatValidated) {
                mPlayPending = true;
                return;
            }
            sendCommand(Command.PLAY);
        } else if (currentState == State.IDLE) {
            Log.w(TAG, "play: Called on IDLE, ignoring - load a song first");
        } else if (currentState == State.ERROR) {
            Log.w(TAG, "play: Cannot play in ERROR state");
            notifyError("Cannot play - player in error state");
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>State transition: PLAYING -> PAUSED</p>
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()} or {@link #resume()}.</p>
     */
    public void pause() {
        checkNotReleased();
        
        if (mState.get() == State.PLAYING) {
            sendCommand(Command.PAUSE);
        }
    }
    
    /**
     * Resumes playback after pause.
     * 
     * <p>State transition: PAUSED -> PLAYING</p>
     */
    public void resume() {
        checkNotReleased();
        
        if (mState.get() == State.PAUSED) {
            sendCommand(Command.RESUME);
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>After calling stop, the player remains prepared and can be restarted
     * by calling {@link #play()} which will restart from the beginning.</p>
     * 
     * <p>State transition: PLAYING/PAUSED -> PREPARED</p>
     */
    public void stop() {
        checkNotReleased();
        sendCommand(Command.STOP);
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation flushes both the decoder and AudioTrack, which is
     * critical for proper operation. According to Android CTS requirements,
     * failing to flush AudioTrack on seek causes presentation timestamp
     * mismatches in the audio HAL, resulting in no sound after seek.</p>
     * 
     * <p>Valid in states: PREPARED, READY, PLAYING, PAUSED, COMPLETED</p>
     *
     * @param positionMs Position in milliseconds to seek to
     */
    public void seekTo(int positionMs) {
        checkNotReleased();
        
        State currentState = mState.get();
        if (currentState == State.PREPARED || currentState == State.READY ||
            currentState == State.PLAYING || currentState == State.PAUSED || 
            currentState == State.COMPLETED) {
            mSeekTarget.set(positionMs);
            sendCommand(Command.SEEK, positionMs);
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        checkNotReleased();
        mCurrentPitch = semitones;
        sendCommand(Command.SET_PITCH, semitones);
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier (e.g., 1.25 for 125% speed)
     */
    public void setTempo(float tempo) {
        checkNotReleased();
        mCurrentTempo = tempo;
        sendCommand(Command.SET_TEMPO, tempo);
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>Uses AudioTrack playback head position for accuracy when available,
     * as specified in the architecture documentation. This provides smooth,
     * accurate seekbar updates that don't rush to the end.</p>
     * 
     * <p>Per Android documentation: The playback head position value should
     * be reinterpreted as unsigned 32-bits, wrapping every ~27 hours.</p>
     *
     * @return Current position in milliseconds, or 0 if not playing
     */
    public long getCurrentPosition() {
        State state = mState.get();
        
        // Use AudioTrack head position for playing/paused states (most accurate)
        if ((state == State.PLAYING || state == State.PAUSED) && mAudioTrack != null) {
            try {
                // Per documentation: value is unsigned 32-bit, handle wraparound
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long headPositionMs = (frames * 1000) / mSampleRate;
                
                // Add seek adjustment if we've seeked
                if (mSeekAdjustmentMs > 0) {
                    headPositionMs += mSeekAdjustmentMs;
                }
                
                // Clamp to duration
                long duration = mDuration.get();
                if (duration > 0 && headPositionMs > duration) {
                    headPositionMs = duration;
                }
                
                return headPositionMs;
            } catch (Exception e) {
                Log.w(TAG, "Failed to get AudioTrack head position", e);
            }
        }
        
        // Fallback to decoder position
        AudioDecoder decoder = mDecoder;
        if (decoder != null) {
            return decoder.getCurrentPosition();
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        State state = mState.get();
        if (state != State.PLAYING) {
            return false;
        }
        
        // Double-check with AudioTrack
        if (mAudioTrack != null) {
            try {
                return mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING;
            } catch (Exception e) {
                return true;
            }
        }
        return true;
    }
    
    /**
     * Checks if a song is loaded and the player is ready.
     *
     * @return true if prepared (READY, PLAYING, or PAUSED state), false otherwise
     */
    public boolean isPrepared() {
        State state = mState.get();
        return state == State.READY || state == State.PLAYING || state == State.PAUSED;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return The current State
     */
    @NonNull
    public State getState() {
        return mState.get();
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     * 
     * <p>State transition: Any state -> RELEASED (terminal)</p>
     */
    public void release() {
        Log.d(TAG, "release() called");
        
        mReleaseComplete = false;
        sendCommand(Command.RELEASE);
        
        synchronized (mStateLock) {
            while (!mReleaseComplete) {
                try {
                    mStateLock.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        
        stopThreads();
        
        mState.set(State.RELEASED);
        Log.d(TAG, "release() complete, state: RELEASED");
    }
    
    /**
     * Wakes up the renderer thread if it's waiting.
     */
    private void wakeupRenderer() {
        synchronized (mRendererLock) {
            mRendererLock.notifyAll();
        }
    }
    
    // ========================================================================
    // Thread Management
    // ========================================================================
    
    /**
     * Starts the decoder thread if not already running.
     */
    private void startDecoderThread() {
        if (mDecoderThread != null && mDecoderThread.isAlive()) {
            return;
        }
        
        mDecoderThread = new HandlerThread("AudioDecoder");
        mDecoderThread.start();
        mDecoderHandler = new Handler(mDecoderThread.getLooper());
        mDecoderHandler.post(mDecoderRunnable);
        
        Log.d(TAG, "Decoder thread started");
    }
    
    /**
     * Starts the renderer thread if not already running.
     */
    private void startRendererThread() {
        if (mRendererThread != null && mRendererThread.isAlive()) {
            return;
        }
        
        mRendererThread = new HandlerThread("AudioRenderer", Process.THREAD_PRIORITY_URGENT_AUDIO);
        mRendererThread.start();
        mRendererHandler = new Handler(mRendererThread.getLooper());
        
        mRenderRunnable = new Runnable() {
            @Override
            public void run() {
                processRendering();
            }
        };
        mRendererHandler.post(mRenderRunnable);
        
        Log.d(TAG, "Renderer thread started");
    }
    
    /**
     * Starts the watchdog thread for health monitoring.
     */
    private void startWatchdogThread() {
        if (mWatchdogThread != null && mWatchdogThread.isAlive()) {
            return;
        }
        
        mWatchdogThread = new HandlerThread("AudioWatchdog", Process.THREAD_PRIORITY_BACKGROUND);
        mWatchdogThread.start();
        mWatchdogHandler = new Handler(mWatchdogThread.getLooper());
        
        mWatchdogRunnable = new Runnable() {
            @Override
            public void run() {
                while (mWatchdogThread != null && mWatchdogThread.isAlive() && 
                       mState.get() != State.RELEASED && mState.get() != State.ERROR && 
                       mState.get() != State.IDLE) {
                    try {
                        Thread.sleep(WATCHDOG_INTERVAL_MS);
                        checkPlaybackHealth();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                Log.d(TAG, "Watchdog thread exiting - state: " + mState.get());
            }
        };
        mWatchdogHandler.post(mWatchdogRunnable);
        
        Log.d(TAG, "Watchdog thread started");
    }
    
    /**
     * Stops all background threads.
     */
    private void stopThreads() {
        // Wake up any waiting threads
        wakeupRenderer();
        synchronized (mStateLock) {
            mStateLock.notifyAll();
        }
        
        // Stop watchdog
        if (mWatchdogThread != null) {
            mWatchdogThread.quitSafely();
            try { mWatchdogThread.join(500); } catch (InterruptedException ignored) {}
            mWatchdogThread = null;
            mWatchdogHandler = null;
        }
        
        // Stop renderer
        if (mRendererThread != null) {
            mRendererThread.quitSafely();
            try { mRendererThread.join(500); } catch (InterruptedException ignored) {}
            mRendererThread = null;
            mRendererHandler = null;
            mRenderRunnable = null;
        }
        
        // Stop decoder
        if (mDecoderThread != null) {
            mDecoderThread.quitSafely();
            try { mDecoderThread.join(500); } catch (InterruptedException ignored) {}
            mDecoderThread = null;
            mDecoderHandler = null;
        }
    }
    
    /**
     * Sends a command to the decoder thread.
     *
     * @param command The command to send
     */
    private void sendCommand(Command command) {
        mCommandQueue.offer(new CommandMessage(command));
    }
    
    /**
     * Sends a command with an integer parameter.
     *
     * @param command The command to send
     * @param param The integer parameter
     */
    private void sendCommand(Command command, int param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    /**
     * Sends a command with a float parameter.
     *
     * @param command The command to send
     * @param param The float parameter
     */
    private void sendCommand(Command command, float param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    /**
     * Sends a command with a string parameter.
     *
     * @param command The command to send
     * @param param The string parameter
     */
    private void sendCommand(Command command, String param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    // ========================================================================
    // Decoder Thread Runnable (APPENDIX B)
    // ========================================================================
    
    /**
     * Main decoder thread loop.
     * 
     * <p>This method runs in a background thread and processes commands
     * from the command queue. It handles all MediaExtractor and MediaCodec
     * operations.</p>
     */
    private final Runnable mDecoderRunnable = new Runnable() {
        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            mDecoderActive.set(true);
            
            while (mDecoderActive.get() && mState.get() != State.RELEASED) {
                try {
                    CommandMessage cmd = mCommandQueue.poll();
                    if (cmd != null) {
                        processCommand(cmd);
                    }
                    
                    // Small sleep to prevent CPU spinning
                    Thread.sleep(IDLE_SLEEP_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Decoder thread error", e);
                    transitionToError(e.getMessage());
                }
            }
            
            Log.d(TAG, "Decoder thread exiting");
        }
    };
    
    /**
     * Processes a single command from the queue.
     *
     * @param cmd The command to process
     */
    private void processCommand(CommandMessage cmd) {
        switch (cmd.command) {
            case LOAD:
                processLoad(cmd.stringParam);
                break;
            case PLAY:
                processPlay();
                break;
            case PAUSE:
                processPause();
                break;
            case RESUME:
                processResume();
                break;
            case STOP:
                processStop();
                break;
            case SEEK:
                processSeek(cmd.intParam);
                break;
            case SET_PITCH:
                processSetPitch(cmd.floatParam);
                break;
            case SET_TEMPO:
                processSetTempo(cmd.floatParam);
                break;
            case RELEASE:
                processRelease();
                break;
            default:
                break;
        }
    }
    
    // ========================================================================
    // Command Processing (Decoder Thread)
    // ========================================================================
    
    /**
     * Processes a LOAD command.
     *
     * @param filePath The file path to load
     */
    private void processLoad(@NonNull String filePath) {
        transitionTo(State.PREPARING);
        
        try {
            // Release existing resources
            releaseDecoder();
            
            // Create and open decoder
            mDecoder = new AudioDecoder();
            if (!mDecoder.open(filePath)) {
                transitionToError("Failed to open audio file");
                return;
            }
            
            // Extract metadata
            mDuration.set(mDecoder.getDuration());
            mCurrentFilePath.set(filePath);
            mDecoderEOS.set(false);
            mSeekTarget.set(-1);
            
            Log.d(TAG, "Load complete: duration=" + mDuration.get() + "ms, " +
                  "sampleRate=" + mDecoder.getSampleRate() + ", channels=" + mDecoder.getChannels());
            
            // Start renderer thread (creates AudioTrack when format is known)
            startRendererThread();
            startWatchdogThread();
            
        } catch (Exception e) {
            Log.e(TAG, "Load failed", e);
            transitionToError(e.getMessage());
        }
    }
    
    /**
     * Processes a PLAY command.
     */
    private void processPlay() {
        State currentState = mState.get();
        Log.d(TAG, "processPlay: currentState=" + currentState + ", mFormatValidated=" + mFormatValidated);
        
        if (currentState == State.READY || currentState == State.PREPARED || currentState == State.COMPLETED) {
            // Ensure decoder is positioned at start if completed
            if (currentState == State.COMPLETED && mDecoder != null) {
                mDecoder.seekTo(0);
                mDecoderEOS.set(false);
            }
            
            // Make sure AudioTrack exists and is ready
            if (mAudioTrack == null) {
                Log.w(TAG, "processPlay: AudioTrack is null, creating now");
                createAudioTrack();
            }
            
            if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "processPlay: AudioTrack.play() called, playState=" + mAudioTrack.getPlayState());
                } catch (IllegalStateException e) {
                    Log.e(TAG, "processPlay: Failed to start AudioTrack", e);
                }
            }
            
            transitionTo(State.PLAYING);
            
            // Wake up renderer thread
            wakeupRenderer();
        } else if (currentState == State.PAUSED) {
            processResume();
        }
    }
    
    /**
     * Processes a PAUSE command.
     */
    private void processPause() {
        transitionTo(State.PAUSED);
    }
    
    /**
     * Processes a RESUME command.
     */
    private void processResume() {
        if (mState.get() == State.PAUSED) {
            if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "processResume: AudioTrack.play() called");
                } catch (IllegalStateException e) {
                    Log.e(TAG, "processResume: Failed to resume AudioTrack", e);
                }
            }
            transitionTo(State.PLAYING);
            
            // Wake up renderer thread
            wakeupRenderer();
        }
    }
    
    /**
     * Processes a STOP command.
     */
    private void processStop() {
        if (mDecoder != null) {
            mDecoder.seekTo(0);
            mDecoderEOS.set(false);
        }
        mPlaybackStartSystemTime = 0;
        mSeekAdjustmentMs = 0;
        transitionTo(State.PREPARED);
    }
    
    /**
     * Processes a SEEK command.
     *
     * @param positionMs The position to seek to in milliseconds
     */
    private void processSeek(int positionMs) {
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mDecoderEOS.set(false);
            mSeekTarget.set(positionMs);
            
            if (mState.get() == State.PLAYING) {
                mSeekAdjustmentMs = positionMs;
            }
            
            // Notify renderer to flush
            if (mRendererHandler != null) {
                mRendererHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        flushAudioTrack();
                    }
                });
            }
        }
    }
    
    /**
     * Processes a SET_PITCH command.
     *
     * @param semitones The pitch shift in semitones
     */
    private void processSetPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
        }
    }
    
    /**
     * Processes a SET_TEMPO command.
     *
     * @param tempo The tempo multiplier
     */
    private void processSetTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
        }
    }
    
    /**
     * Processes a RELEASE command.
     */
    private void processRelease() {
        mDecoderActive.set(false);
        
        stopThreads();
        releaseRenderer();
        releaseDecoder();
        
        transitionTo(State.RELEASED);
        
        // Signal that release is complete
        mReleaseComplete = true;
        synchronized (mStateLock) {
            mStateLock.notifyAll();
        }
    }
    
    /**
     * Releases decoder resources.
     */
    private void releaseDecoder() {
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
        }
        mDecoderEOS.set(false);
        mPlaybackStartSystemTime = 0;
        mSeekAdjustmentMs = 0;
    }
    
    /**
     * Releases renderer resources.
     */
    private void releaseRenderer() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        mAudioSessionId = 0;
        mFormatValidated = false;
        mPlayPending = false;
        mAudioTrackNeedsRecreation = false;
        
        // Wake up any waiting renderer
        wakeupRenderer();
    }
    
    /**
     * Internal release for preLoad operation.
     */
    private void releaseInternal() {
        mDecoderActive.set(false);
        stopThreads();
        releaseRenderer();
        releaseDecoder();
    }
    
    // ========================================================================
    // Renderer Thread (APPENDIX B)
    // ========================================================================
    
    /**
     * Main renderer thread loop.
     * 
     * <p>This method runs in a background thread with high audio priority.
     * It reads PCM data from the decoder, processes it through SoundTouch,
     * and writes it to AudioTrack.</p>
     */
    private void processRendering() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mFrameSize];
        short[] outputBuffer = new short[BUFFER_FRAMES * mFrameSize];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Renderer thread started");
        
        while (mState.get() != State.RELEASED && mDecoderActive.get()) {
            try {
                State currentState = mState.get();
                
                // Handle seek marker
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0 && mDecoder != null) {
                    if (mPitchShifter != null) {
                        mPitchShifter.clear();
                    }
                }
                
                // Only process when playing
                if (currentState != State.PLAYING) {
                    synchronized (mRendererLock) {
                        if (mState.get() != State.PLAYING && mState.get() != State.RELEASED) {
                            mRendererLock.wait();
                        }
                    }
                    continue;
                }
                
                // Check if decoder is at EOS
                if (mDecoderEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                if (mDecoder == null) {
                    Thread.sleep(IDLE_SLEEP_MS);
                    continue;
                }
                
                // Read PCM from decoder (blocking call)
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead <= 0) {
                    if (mDecoder.isEOS()) {
                        mDecoderEOS.set(true);
                        continue;
                    }
                    Thread.sleep(NO_DATA_SLEEP_MS);
                    continue;
                }
                
                // Validate format on first read
                if (!mFormatValidated) {
                    Log.d(TAG, "Renderer: First PCM frame received, validating format");
                    validateFormatAndRecreateAudioTrack();
                    if (!mFormatValidated) {
                        continue;
                    }
                    Log.d(TAG, "Renderer: Format validated, player is READY");
                }
                
                // Process through pitch shifter
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        
                        if (received > 0 && mAudioTrack != null && 
                            mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                            int samplesToWrite = received * mFrameSize;
                            int written = mAudioTrack.write(outputBuffer, 0, samplesToWrite, 
                                AudioTrack.WRITE_BLOCKING);
                            
                            if (written < 0) {
                                handleAudioTrackError(written);
                            } else if (written < samplesToWrite && mState.get() == State.PLAYING) {
                                Log.w(TAG, "Partial write: " + written + "/" + samplesToWrite);
                            }
                        }
                    }
                } else if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    // Bypass pitch shifter if not available
                    int samplesToWrite = framesRead * mFrameSize;
                    int written = mAudioTrack.write(inputBuffer, 0, samplesToWrite, 
                        AudioTrack.WRITE_BLOCKING);
                    
                    if (written < 0) {
                        handleAudioTrackError(written);
                    }
                }
                
                // Update UI position using AudioTrack head position
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    updatePositionAndNotify(getCurrentPosition());
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Log.d(TAG, "Renderer thread interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Renderer error", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "Renderer thread exiting");
    }
    
    /**
     * Validates decoder output format and recreates AudioTrack with correct parameters.
     * 
     * <p>According to Android's MediaCodec documentation, the actual decoder
     * output format may differ from the container's MediaFormat. This method
     * recreates the AudioTrack with the correct parameters when the first frame
     * is decoded.</p>
     */
    private void validateFormatAndRecreateAudioTrack() {
        if (mDecoder == null) return;
        
        int newSampleRate = mDecoder.getSampleRate();
        int newChannels = mDecoder.getChannels();
        
        boolean formatChanged = (newSampleRate != mSampleRate || newChannels != mChannels);
        
        mSampleRate = newSampleRate;
        mChannels = newChannels;
        mFrameSize = mChannels;
        
        // Recreate pitch shifter with correct format
        if (PitchShifter.isLibraryAvailable()) {
            if (mPitchShifter != null) {
                mPitchShifter.close();
            }
            mPitchShifter = new PitchShifter(mSampleRate, mChannels);
            mPitchShifter.setPitch(mCurrentPitch);
            mPitchShifter.setTempo(mCurrentTempo);
            Log.d(TAG, "PitchShifter recreated with sampleRate=" + mSampleRate + ", channels=" + mChannels);
        }
        
        // Track if we need to restore playback
        boolean wasPlaying = (mState.get() == State.PLAYING);
        
        // If format changed, recreate AudioTrack with correct parameters
        if (formatChanged && mAudioTrack != null) {
            Log.d(TAG, "Format changed - recreating AudioTrack: " + 
                  "was " + mSampleRate + "/" + mChannels + 
                  ", now " + newSampleRate + "/" + newChannels +
                  ", wasPlaying=" + wasPlaying);
            
            // Release old AudioTrack
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        // Create or recreate AudioTrack
        if (mAudioTrack == null) {
            createAudioTrack();
        }
        
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            mFormatValidated = true;
            
            // Optimize buffer size for low latency
            optimizeAudioTrackBuffer();
            
            // CRITICAL: Restore playback if we were playing before format change
            if (wasPlaying && mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "Restarted AudioTrack playback after format change");
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Failed to restart AudioTrack after format change", e);
                    // Schedule retry
                    mUiHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mAudioTrack != null && mState.get() == State.PLAYING) {
                                try {
                                    mAudioTrack.play();
                                    Log.d(TAG, "Retry: AudioTrack.play() after format change");
                                } catch (IllegalStateException ex) {
                                    Log.e(TAG, "Retry failed", ex);
                                    mPlayPending = true;
                                }
                            }
                        }
                    }, AUDIOTRACK_RETRY_DELAY_MS);
                }
            } else if (mPlayPending) {
                mPlayPending = false;
                sendCommand(Command.PLAY);
            }
            
            // Broadcast song prepared again with correct session (if changed)
            broadcastSongPrepared();
            
            // Notify listener that player is ready
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onPrepared();
                    }
                });
            }
            
            // Transition to READY state and signal loadSong()
            State currentState = mState.get();
            if (currentState != State.ERROR && currentState != State.RELEASED && 
                currentState != State.PLAYING) {
                transitionTo(State.READY);
                Log.d(TAG, "validateFormatAndRecreateAudioTrack: Transitioned to READY state");
            }
            
            if (mReadyLatch != null) {
                mReadyLatch.countDown();
                mReadyLatch = null;
                Log.d(TAG, "validateFormatAndRecreateAudioTrack: Signaled loadSong() that player is READY");
            }
        } else {
            Log.e(TAG, "validateFormatAndRecreateAudioTrack: Failed to create AudioTrack!");
        }
    }
    
    /**
     * Creates AudioTrack following Android best practices per documentation.
     * 
     * <p>Key requirements from AudioTrack documentation:
     * <ul>
     *   <li>Use AudioAttributes.Builder for usage and content type</li>
     *   <li>Use AudioFormat.Builder for format specification</li>
     *   <li>Use getMinBufferSize() for initial estimate</li>
     *   <li>Use setBufferSizeInFrames() to optimize latency</li>
     *   <li>Call getAudioSessionId() AFTER creation, not before</li>
     * </ul>
     * </p>
     */
    private void createAudioTrack() {
        // Release existing AudioTrack if any
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        // Determine channel configuration per documentation
        int channelConfig;
        if (mChannels == 2) {
            channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
        } else if (mChannels == 1) {
            channelConfig = AudioFormat.CHANNEL_OUT_MONO;
        } else {
            Log.e(TAG, "Unsupported channel count: " + mChannels);
            return;
        }
        
        // Step 1: Calculate minimum buffer size as per documentation
        int minBufferSize = AudioTrack.getMinBufferSize(
            mSampleRate,
            channelConfig,
            AudioFormat.ENCODING_PCM_16BIT
        );
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize: " + minBufferSize);
            transitionToError("AudioTrack buffer size invalid");
            return;
        }
        
        // Step 2: Calculate target buffer size (minimum 250ms as per spec)
        int frameSize = mChannels * 2; // 2 bytes per sample for 16-bit PCM
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * frameSize;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        // Step 3: Build AudioAttributes as per documentation
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        // Step 4: Build AudioFormat as per documentation
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        // Step 5: Create AudioTrack using Builder pattern (recommended)
        try {
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            // Step 6: Verify initialization state per documentation
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack not initialized, state=" + mAudioTrack.getState());
                mAudioTrack = null;
                transitionToError("AudioTrack initialization failed");
                return;
            }
            
            // Step 7: Get audio session ID AFTER creation (per documentation)
            int newSessionId = mAudioTrack.getAudioSessionId();
            if (newSessionId != mAudioSessionId) {
                mAudioSessionId = newSessionId;
                Log.d(TAG, "AudioTrack created with session=" + mAudioSessionId);
                // Broadcast new session for equalizer
                broadcastSongPrepared();
            }
            
            // Step 8: Record buffer info for debugging
            int bufferCapacityFrames = mAudioTrack.getBufferCapacityInFrames();
            mAudioTrackBufferSize = bufferCapacityFrames * frameSize;
            Log.d(TAG, "AudioTrack created: bufferSize=" + bufferSize + 
                  ", capacity=" + bufferCapacityFrames + " frames, minBuffer=" + minBufferSize);
            
            // Step 9: If we were playing, restore playback state
            if (mPlayPending && mState.get() == State.PLAYING) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "Restored playback after AudioTrack creation");
                    mPlayPending = false;
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Failed to restore playback", e);
                }
            }
            
        } catch (IllegalStateException | IllegalArgumentException e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            transitionToError("AudioTrack creation failed: " + e.getMessage());
        }
    }
    
    /**
     * Optimizes AudioTrack buffer size for low latency.
     * 
     * <p>Per Android documentation: The buffer size can be optimized
     * by lowering it after each write() call until the audio glitches,
     * which is detected by calling getUnderrunCount(). Then increase
     * until no glitches. This technique provides a compromise between
     * latency and glitch rate.</p>
     */
    private void optimizeAudioTrackBuffer() {
        if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
            return;
        }
        
        // Only optimize on API 23+ which supports setBufferSizeInFrames
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                int currentBufferFrames = mAudioTrack.getBufferSizeInFrames();
                int capacityFrames = mAudioTrack.getBufferCapacityInFrames();
                
                // Start with 75% of capacity for better latency
                int optimalFrames = Math.max(
                    (int)(capacityFrames * 0.75),
                    mSampleRate * MIN_BUFFER_MS / 1000 / 2 // Half of min buffer for low latency
                );
                optimalFrames = Math.min(optimalFrames, capacityFrames);
                
                int result = mAudioTrack.setBufferSizeInFrames(optimalFrames);
                if (result >= 0) {
                    Log.d(TAG, "Buffer size optimized: " + optimalFrames + " frames (was " + 
                          currentBufferFrames + ")");
                } else {
                    Log.w(TAG, "Buffer optimization returned: " + result);
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to optimize buffer size", e);
            }
        }
    }
    
    /**
     * Properly flushes AudioTrack as per Android documentation.
     * 
     * <p>Per documentation: flush() discards data but doesn't guarantee
     * buffer space availability. Must be called while stopped or paused.</p>
     */
    private void flushAudioTrack() {
        if (mAudioTrack == null) {
            return;
        }
        
        try {
            // Save playback state
            boolean wasPlaying = (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING);
            
            // Must pause before flush per documentation
            if (wasPlaying) {
                mAudioTrack.pause();
            }
            
            // Flush the audio data (discards pending data)
            mAudioTrack.flush();
            Log.d(TAG, "AudioTrack flushed successfully");
            
            // Reset position tracking
            if (wasPlaying && mState.get() == State.PLAYING) {
                mAudioTrack.play();
                Log.d(TAG, "AudioTrack playback resumed after flush");
            }
            
        } catch (IllegalStateException e) {
            Log.e(TAG, "Failed to flush AudioTrack - may need recreation", e);
            // Schedule recreation
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    recreateAudioTrack();
                }
            });
        }
    }
    
    /**
     * Recreates AudioTrack when it enters a bad state.
     * 
     * <p>Per documentation: ERROR_DEAD_OBJECT (-6) indicates the object
     * is no longer valid and needs to be recreated.</p>
     */
    private void recreateAudioTrack() {
        Log.w(TAG, "Recreating AudioTrack due to bad state");
        
        boolean wasPlaying = (mState.get() == State.PLAYING);
        boolean wasPending = mPlayPending;
        
        // Release old AudioTrack
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing AudioTrack for recreation", e);
            }
            mAudioTrack = null;
        }
        
        // Create new AudioTrack
        createAudioTrack();
        
        // Restore playback state if needed
        if (wasPlaying && mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "Playback restored after AudioTrack recreation");
            } catch (IllegalStateException e) {
                Log.e(TAG, "Failed to restore playback after recreation", e);
                mPlayPending = true;
            }
        } else if (wasPending) {
            mPlayPending = true;
        }
    }
    
    /**
     * Handles AudioTrack.write errors per documentation.
     * 
     * <p>Per documentation: ERROR_DEAD_OBJECT (-6) indicates the object
     * is no longer valid and needs to be recreated.</p>
     *
     * @param errorCode The error code from AudioTrack.write
     */
    private void handleAudioTrackError(int errorCode) {
        Log.e(TAG, "AudioTrack.write error: " + errorCode);
        
        switch (errorCode) {
            case AudioTrack.ERROR_DEAD_OBJECT:
                // Object is no longer valid - must recreate per documentation
                Log.w(TAG, "AudioTrack is dead, recreating");
                recreateAudioTrack();
                break;
                
            case AudioTrack.ERROR_BAD_VALUE:
                Log.e(TAG, "Bad value passed to AudioTrack.write");
                // This shouldn't happen - check buffer sizes
                break;
                
            case AudioTrack.ERROR_INVALID_OPERATION:
                Log.e(TAG, "Invalid operation - AudioTrack may not be initialized");
                recreateAudioTrack();
                break;
                
            default:
                Log.e(TAG, "Unknown AudioTrack error: " + errorCode);
                break;
        }
        
        // Notify listener of error for potential recovery
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onError("AudioTrack error: " + errorCode);
                }
            });
        }
    }
    
    /**
     * Updates playback position using AudioTrack.getPlaybackHeadPosition().
     * 
     * <p>Per documentation: The value should be reinterpreted as unsigned 32-bits.
     * This method handles the wrapping properly.</p>
     */
    private void updatePositionAndNotify(long positionMs) {
        // Get accurate position from AudioTrack when possible
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED && 
            mState.get() == State.PLAYING) {
            try {
                // Per documentation: value wraps every ~27 hours at 44.1kHz
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long trackPositionMs = (frames * 1000) / mSampleRate;
                
                // Add seek adjustment if we've seeked
                if (mSeekAdjustmentMs > 0) {
                    trackPositionMs += mSeekAdjustmentMs;
                }
                
                // Clamp to duration
                long duration = mDuration.get();
                if (duration > 0 && trackPositionMs > duration) {
                    trackPositionMs = duration;
                }
                
                positionMs = trackPositionMs;
            } catch (Exception e) {
                Log.w(TAG, "Failed to get AudioTrack position, using fallback", e);
            }
        }
        
        mLastReportedPosition.set(positionMs);
        mLastPositionChangeTime.set(System.currentTimeMillis());
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onPositionUpdate(positionMs);
                }
            });
        }
    }
    
    /**
     * Handles song completion.
     * 
     * <p>Flushes any remaining data from the pitch shifter pipeline and
     * transitions to COMPLETED state.</p>
     */
    private void handleCompletion() {
        // Flush remaining data from pitch shifter
        if (mPitchShifter != null && mAudioTrack != null) {
            mPitchShifter.flush();
            int available = mPitchShifter.numFrames();
            if (available > 0) {
                short[] outputBuffer = new short[available * mFrameSize];
                int received = mPitchShifter.receiveFrames(outputBuffer, available);
                if (received > 0 && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.write(outputBuffer, 0, received * mFrameSize, AudioTrack.WRITE_BLOCKING);
                }
            }
        }
        
        transitionTo(State.COMPLETED);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onCompletion();
                }
            });
        }
        
        Log.d(TAG, "Playback completed");
    }
    
    // ========================================================================
    // Watchdog (APPENDIX B)
    // ========================================================================
    
    /**
     * Checks playback health and attempts recovery if stalled.
     * 
     * <p>The watchdog monitors the playback position. If it doesn't advance
     * for MAX_STALL_TIME_MS, a stall is counted. After MAX_STALL_COUNT stalls,
     * recovery is attempted.</p>
     */
    private void checkPlaybackHealth() {
        State state = mState.get();
        if (state != State.PLAYING) {
            mStallCount.set(0);
            return;
        }
        
        long currentPosition = getCurrentPosition();
        long lastPosition = mLastReportedPosition.get();
        long now = System.currentTimeMillis();
        long timeSinceLastChange = now - mLastPositionChangeTime.get();
        
        if (currentPosition == lastPosition && timeSinceLastChange > MAX_STALL_TIME_MS) {
            int stallCount = mStallCount.incrementAndGet();
            Log.w(TAG, "Playback stall detected! Count=" + stallCount + 
                  ", position stuck at " + currentPosition + "ms");
            
            if (stallCount >= MAX_STALL_COUNT) {
                Log.w(TAG, "Multiple stalls detected, attempting recovery");
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onError("Playback stalled - recovering");
                        }
                    });
                }
                attemptRecovery();
                mStallCount.set(0);
            }
        } else if (currentPosition != lastPosition) {
            mLastReportedPosition.set(currentPosition);
            mLastPositionChangeTime.set(now);
            mStallCount.set(0);
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     */
    private void attemptRecovery() {
        if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            try {
                mAudioTrack.pause();
                // Use wait with timeout instead of Thread.sleep
                synchronized (mRendererLock) {
                    mRendererLock.wait(50);
                }
                mAudioTrack.flush();
                mAudioTrack.play();
                Log.d(TAG, "Recovery: AudioTrack flushed and restarted");
            } catch (Exception e) {
                Log.e(TAG, "Recovery failed", e);
                recreateAudioTrack();
            }
        } else {
            recreateAudioTrack();
        }
    }
    
    // ========================================================================
    // State Management (APPENDIX A)
    // ========================================================================
    
    /**
     * Transitions the player to a new state.
     * 
     * <p>This method updates the state atomically and notifies the listener
     * of the state change. It also handles AudioTrack state changes on the
     * renderer thread.</p>
     *
     * @param newState The new state to transition to
     */
    private void transitionTo(State newState) {
        State oldState = mState.getAndSet(newState);
        
        if (oldState == newState) {
            return;
        }
        
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
        
        // Wake up renderer if entering playing state
        if (newState == State.PLAYING) {
            wakeupRenderer();
        }
        
        // Handle AudioTrack state changes on renderer thread
        if (mRendererHandler != null) {
            mRendererHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleAudioTrackForState(newState);
                }
            });
        } else {
            // If renderer thread not ready, handle on current thread
            handleAudioTrackForState(newState);
        }
        
        // Notify listener AFTER AudioTrack state change
        PlaybackListener listener = mListener;
        if (listener != null) {
            final State finalNewState = newState;
            final State finalOldState = oldState;
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onStateChanged(finalNewState, finalOldState);
                }
            });
        }
    }
    
    /**
     * Transitions the player to ERROR state.
     *
     * @param error The error message
     */
    private void transitionToError(String error) {
        State oldState = mState.getAndSet(State.ERROR);
        
        if (oldState == State.ERROR) {
            return;
        }
        
        Log.e(TAG, "Error transition: " + oldState + " -> ERROR: " + error);
        
        // Stop all background threads immediately to prevent hanging
        stopThreads();
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onError(error);
                }
            });
        }
        
        // Signal error to unblock waiting loadSong()
        if (mReadyLatch != null) {
            mReadyLatch.countDown();
            mReadyLatch = null;
        }
    }
    
    /**
     * Handles AudioTrack state changes based on player state.
     *
     * @param state The new player state
     */
    private void handleAudioTrackForState(State state) {
        if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
            Log.w(TAG, "handleAudioTrackForState: AudioTrack not ready, state=" + state);
            // If AudioTrack isn't ready but we need to play, schedule a retry
            if (state == State.PLAYING && mFormatValidated) {
                Log.d(TAG, "AudioTrack not ready for PLAYING, scheduling retry");
                mUiHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mState.get() == State.PLAYING && mAudioTrack != null &&
                            mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                            try {
                                mAudioTrack.play();
                                Log.d(TAG, "Retry: AudioTrack.play() called");
                            } catch (IllegalStateException e) {
                                Log.e(TAG, "Retry failed", e);
                            }
                        }
                    }
                }, AUDIOTRACK_RETRY_DELAY_MS);
            }
            return;
        }
        
        try {
            switch (state) {
                case PLAYING:
                    Log.d(TAG, "handleAudioTrackForState: Starting playback");
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.play();
                        Log.d(TAG, "AudioTrack.play() called, playState=" + mAudioTrack.getPlayState());
                    } else {
                        Log.d(TAG, "AudioTrack already playing");
                    }
                    break;
                    
                case PAUSED:
                    if (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.pause();
                        Log.d(TAG, "AudioTrack.pause() called");
                    }
                    break;
                    
                case PREPARED:
                case COMPLETED:
                    if (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.pause();
                    }
                    mAudioTrack.flush();
                    break;
                    
                default:
                    break;
            }
        } catch (IllegalStateException e) {
            Log.e(TAG, "Error handling AudioTrack for state " + state, e);
        }
    }
    
    /**
     * Notifies the listener of an error.
     *
     * @param error The error message
     */
    private void notifyError(String error) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onError(error);
                }
            });
        }
    }
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration.get());
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath.get());
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "Broadcast SONG_PREPARED: duration=" + mDuration.get() + 
              ", session=" + mAudioSessionId);
    }
    
    /**
     * Checks if the player has been released and throws if so.
     *
     * @throws IllegalStateException if the player is in RELEASED state
     */
    private void checkNotReleased() {
        if (mState.get() == State.RELEASED) {
            throw new IllegalStateException("SoundTouchPlayer has been released");
        }
    }
}