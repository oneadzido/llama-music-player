package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Pre-load capability for immediate duration and audio session access</li>
 * </ul>
 * 
 * <h3>Architecture</h3>
 * <pre>
 * Audio File -> AudioDecoder -> PitchShifter (SoundTouch) -> AudioTrack -> Speakers
 * </pre>
 * 
 * <h3>Pre-load Feature</h3>
 * <p>The {@link #preLoad(String)} method allows the player to initialize the decoder
 * and create an AudioTrack instance without starting playback. This provides:</p>
 * <ul>
 *   <li>Immediate access to song duration for UI display</li>
 *   <li>Early creation of audio session for equalizer attachment</li>
 *   <li>Faster response when user presses play</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() { ... }
 *     public void onCompletion() { ... }
 * });
 * 
 * // Pre-load for duration and session (optional)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Or load and play immediately
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.play();
 * 
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * 
 * player.release();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Default sample rate (44.1 kHz) - will be overridden by actual decoder output. */
    private static final int DEFAULT_SAMPLE_RATE = 44100;
    
    /** Default number of channels (stereo) - will be overridden by actual decoder output. */
    private static final int DEFAULT_CHANNELS = 2;
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 200;
    
    /** Position update interval in milliseconds. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcast sending. */
    @NonNull
    private final Context mContext;
    
    /** Native pitch shifter instance (SoundTouch wrapper). */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** Audio decoder for reading various audio formats. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** AudioTrack for PCM output to speakers/headphones. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Lock object for thread-safe operations. */
    @NonNull
    private final Object mLock = new Object();
    
    /** Lock object for pause/wait coordination. */
    @NonNull
    private final Object mPauseLock = new Object();
    
    /** Flag indicating if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Flag indicating if the player is paused. */
    private volatile boolean mIsPaused = false;
    
    /** Flag indicating if a song is loaded and ready. */
    private volatile boolean mIsPrepared = false;
    
    /** Flag indicating if the player is in pre-load state (loaded but not playing). */
    private volatile boolean mIsPreloadedOnly = false;
    
    /** Flag indicating if the playback thread should stop. */
    private volatile boolean mShouldStop = false;
    
    /** Flag indicating if decoder output format has been validated. */
    private volatile boolean mFormatValidated = false;
    
    /** Current sample rate in Hz (actual from decoder). */
    private int mSampleRate = DEFAULT_SAMPLE_RATE;
    
    /** Number of audio channels (actual from decoder). */
    private int mChannels = DEFAULT_CHANNELS;
    
    /** Number of samples per frame (equals channel count). */
    private int mFrameSize = DEFAULT_CHANNELS;
    
    /** Duration of the current song in milliseconds. */
    private long mDuration = 0;
    
    /** File path of the currently loaded song. */
    @Nullable
    private String mCurrentFilePath = null;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Target seek position in milliseconds (set during seek operation). */
    private volatile int mSeekTarget = -1;
    
    /** Current pitch setting in semitones (stored for reapplication on format change). */
    private float mCurrentPitch = 0f;
    
    /** Current tempo setting (stored for reapplication on format change). */
    private float mCurrentTempo = 1.0f;
    
    /** Playback thread for continuous audio processing. */
    @Nullable
    private Thread mPlaybackThread;
    
    // ========================================================================
    // Inner Interfaces and Classes
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>Implement this interface to be notified of playback state changes
     * such as start, pause, completion, and errors.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when playback starts (after play() is called and audio begins).
         */
        void onPlaybackStarted();
        
        /**
         * Called when playback is paused.
         */
        void onPlaybackPaused();
        
        /**
         * Called when playback resumes after being paused.
         */
        void onPlaybackResumed();
        
        /**
         * Called when the current song completes playback.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         *
         * @param position Current position in milliseconds
         */
        void onPositionUpdate(long position);
        
        /**
         * Called when an error occurs during playback.
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * The audio session is now available and duration is known.
         */
        void onPrepared();
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>Initializes the native pitch shifter with default parameters.
     * The actual sample rate and channel count will be set when a song is loaded
     * and the decoder output format is known.</p>
     *
     * @param context Application context for sending broadcasts
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        
        if (PitchShifter.isLibraryAvailable()) {
            mPitchShifter = new PitchShifter(DEFAULT_SAMPLE_RATE, DEFAULT_CHANNELS);
            Log.d(TAG, "SoundTouchPlayer initialized successfully");
        } else {
            Log.e(TAG, "PitchShifter library not available!");
        }
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     *
     * @param listener The listener to receive events (can be null)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        synchronized (mLock) {
            mListener = listener;
        }
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method initializes the decoder but does NOT create AudioTrack.
     * AudioTrack creation is deferred until the actual decoder output format
     * is known, which prevents format mismatches that cause silent playback.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was successful, false otherwise
     */
    public boolean preLoad(@NonNull String filePath) {
        synchronized (mLock) {
            // Validate file exists
            File file = new File(filePath);
            if (!file.exists() || !file.canRead()) {
                Log.e(TAG, "preLoad: File not accessible: " + filePath);
                notifyError("File not accessible: " + filePath);
                return false;
            }
            
            try {
                // Release existing decoder if any
                if (mDecoder != null) {
                    mDecoder.release();
                    mDecoder = null;
                }
                
                // Create and open decoder
                mDecoder = new AudioDecoder();
                if (!mDecoder.open(filePath)) {
                    Log.e(TAG, "preLoad: Failed to open decoder for: " + filePath);
                    notifyError("Failed to open audio file");
                    return false;
                }
                
                // Extract audio metadata (container values - may be overridden later)
                mDuration = mDecoder.getDuration();
                mSampleRate = mDecoder.getSampleRate();
                mChannels = mDecoder.getChannels();
                mFrameSize = mChannels;
                mCurrentFilePath = filePath;
                mFormatValidated = false;
                
                Log.d(TAG, "preLoad: File info (container) - duration=" + mDuration + "ms, " +
                      "sampleRate=" + mSampleRate + "Hz, channels=" + mChannels);
                
                // Update pitch shifter with initial values (will be recreated if format changes)
                if (PitchShifter.isLibraryAvailable()) {
                    if (mPitchShifter != null) {
                        mPitchShifter.close();
                    }
                    mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                    mPitchShifter.setPitch(mCurrentPitch);
                    mPitchShifter.setTempo(mCurrentTempo);
                }
                
                // IMPORTANT: Do NOT create AudioTrack here!
                // AudioTrack must be created with the ACTUAL decoder output format,
                // which may differ from the container format. Creation is deferred
                // until the first frame is decoded in processAudioData().
                
                mIsPrepared = true;
                mIsPreloadedOnly = true;
                mIsPlaying = false;
                mIsPaused = false;
                
                Log.d(TAG, "preLoad: Success (AudioTrack deferred until format known)");
                
                // Notify listeners that player is prepared
                notifyPrepared();
                
                // Broadcast that song is ready for UI
                broadcastSongPrepared();
                
                return true;
                
            } catch (Exception e) {
                Log.e(TAG, "preLoad: Exception", e);
                notifyError("Pre-load failed: " + e.getMessage());
                return false;
            }
        }
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method internally calls {@link #preLoad(String)} to initialize
     * the decoder. The player will be ready to play immediately after this
     * method returns true.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false otherwise
     */
    public boolean loadSong(@NonNull String filePath) {
        if (!preLoad(filePath)) {
            return false;
        }
        
        synchronized (mLock) {
            mIsPreloadedOnly = false;
        }
        
        return true;
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in pre-loaded state (song loaded but not playing),
     * this method starts the playback thread. If already playing, this method
     * does nothing. If paused, it resumes playback.</p>
     */
    public void play() {
        synchronized (mLock) {
            if (!mIsPrepared) {
                Log.w(TAG, "play: Player not prepared, call loadSong() first");
                return;
            }
            
            // If already playing, do nothing
            if (mIsPlaying && !mIsPaused) {
                Log.d(TAG, "play: Already playing");
                return;
            }
            
            // If paused, just resume
            if (mIsPaused) {
                resume();
                return;
            }
            
            // Start new playback
            startPlayback();
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>This method signals the playback thread to pause and waits
     * for it to acknowledge the pause state.</p>
     * 
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()} or {@link #resume()}.</p>
     */
    public void pause() {
        synchronized (mLock) {
            if (!mIsPlaying || mIsPaused) {
                return;
            }
            
            Log.d(TAG, "pause: Pausing playback");
            mIsPaused = true;
            
            // Pause AudioTrack immediately
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                } catch (Exception e) {
                    Log.e(TAG, "pause: Error pausing AudioTrack", e);
                }
            }
            
            // Notify listener
            PlaybackListener listener = mListener;
            if (listener != null) {
                try {
                    listener.onPlaybackPaused();
                } catch (Exception e) {
                    Log.e(TAG, "pause: Listener error", e);
                }
            }
        }
    }
    
    /**
     * Resumes playback after pause.
     * 
     * <p>This method notifies the waiting playback thread to continue.</p>
     */
    public void resume() {
        synchronized (mLock) {
            if (!mIsPrepared || !mIsPaused) {
                return;
            }
            
            Log.d(TAG, "resume: Resuming playback");
            mIsPaused = false;
            
            // Resume AudioTrack
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                } catch (Exception e) {
                    Log.e(TAG, "resume: Error resuming AudioTrack", e);
                }
            }
            
            // Notify waiting thread
            synchronized (mPauseLock) {
                mPauseLock.notifyAll();
            }
            
            // Notify listener
            PlaybackListener listener = mListener;
            if (listener != null) {
                try {
                    listener.onPlaybackResumed();
                } catch (Exception e) {
                    Log.e(TAG, "resume: Listener error", e);
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>After calling stop, the player remains prepared and can be restarted
     * by calling {@link #play()} which will restart from the beginning.</p>
     */
    public void stop() {
        synchronized (mLock) {
            if (!mIsPrepared) {
                return;
            }
            
            stopPlayback();
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation flushes both the decoder and AudioTrack, which is
     * critical for proper operation. According to Android CTS requirements,
     * failing to flush AudioTrack on seek causes presentation timestamp
     * mismatches in the audio HAL, resulting in no sound after seek.</p>
     *
     * @param positionMs Position in milliseconds to seek to
     */
    public void seekTo(int positionMs) {
        synchronized (mLock) {
            if (!mIsPrepared || mDecoder == null) {
                Log.w(TAG, "seekTo: Player not prepared");
                return;
            }
            
            // Clamp position to valid range
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mSeekTarget = (int) clampedPosition;
            
            // Seek in decoder (will be processed in playback thread)
            mDecoder.seekTo((int) clampedPosition);
            
            // CRITICAL: Flush AudioTrack as required by Android CTS
            // Without this, the audio HAL's presentation timestamp tracking
            // becomes desynchronized, causing the "plays briefly then stops" issue
            flushAudioTrack();
            
            // Clear pitch shifter buffers for clean transition
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            
            Log.d(TAG, "seekTo: " + clampedPosition + "ms");
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        synchronized (mLock) {
            mCurrentPitch = semitones;
            if (mPitchShifter != null) {
                mPitchShifter.setPitch(semitones);
                Log.d(TAG, "setPitch: " + semitones + " semitones");
            }
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier (e.g., 1.25 for 125% speed)
     */
    public void setTempo(float tempo) {
        synchronized (mLock) {
            mCurrentTempo = tempo;
            if (mPitchShifter != null) {
                mPitchShifter.setTempo(tempo);
                Log.d(TAG, "setTempo: " + tempo + "x");
            }
        }
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position in milliseconds, or 0 if not playing
     */
    public long getCurrentPosition() {
        synchronized (mLock) {
            if (mDecoder == null) {
                return 0;
            }
            return mDecoder.getCurrentPosition();
        }
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying && !mIsPaused;
    }
    
    /**
     * Checks if a song is loaded and the player is ready.
     *
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        return mIsPrepared;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     */
    public void release() {
        synchronized (mLock) {
            Log.d(TAG, "release: Releasing resources");
            
            // Stop playback thread
            mShouldStop = true;
            mIsPlaying = false;
            mIsPrepared = false;
            mIsPreloadedOnly = false;
            
            // Wake up paused thread
            synchronized (mPauseLock) {
                mPauseLock.notifyAll();
            }
            
            if (mPlaybackThread != null) {
                try {
                    mPlaybackThread.interrupt();
                    mPlaybackThread.join(1000);
                } catch (InterruptedException e) {
                    Log.w(TAG, "release: Interrupted while waiting for thread", e);
                    Thread.currentThread().interrupt();
                }
                mPlaybackThread = null;
            }
            
            // Release AudioTrack
            if (mAudioTrack != null) {
                try {
                    if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                        mAudioTrack.stop();
                    }
                    mAudioTrack.release();
                } catch (Exception e) {
                    Log.e(TAG, "release: Error releasing AudioTrack", e);
                }
                mAudioTrack = null;
            }
            
            // Release decoder
            if (mDecoder != null) {
                mDecoder.release();
                mDecoder = null;
            }
            
            // Release pitch shifter
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            mAudioSessionId = 0;
            mCurrentFilePath = null;
            mDuration = 0;
            mSeekTarget = -1;
            mFormatValidated = false;
            
            Log.d(TAG, "release: Resources released");
        }
    }
    
    // ========================================================================
    // Private Playback Control Methods
    // ========================================================================
    
    /**
     * Creates AudioTrack according to Android best practices.
     * 
     * <p>Key points from Android documentation:
     * <ul>
     *   <li>Use AudioAttributes.Builder for usage and content type</li>
     *   <li>Use AudioFormat.Builder for format specification</li>
     *   <li>Buffer size should be at least getMinBufferSize()</li>
     *   <li>Use MODE_STREAM for continuous data flow</li>
     *   <li>Call getAudioSessionId() AFTER creation</li>
     * </ul>
     * </p>
     */
    private void createAudioTrack() {
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createAudioTrack: Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        // According to Android docs, buffer should be at least minBufferSize
        // but larger buffers prevent underruns
        int targetBufferSize = mSampleRate * mFrameSize * 2 * MIN_BUFFER_MS / 1000;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        try {
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            
            Log.d(TAG, "createAudioTrack: session=" + mAudioSessionId + 
                  ", bufferSize=" + bufferSize + ", minBuffer=" + minBufferSize +
                  ", sampleRate=" + mSampleRate + ", channels=" + mChannels);
            
            // Verify AudioTrack state according to Android docs
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "createAudioTrack: AudioTrack not properly initialized, state=" + mAudioTrack.getState());
                mAudioTrack = null;
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            Log.e(TAG, "createAudioTrack: Failed to create AudioTrack", e);
            mAudioTrack = null;
        }
    }
    
    /**
     * Flushes the AudioTrack to clear any pending audio data.
     * 
     * <p>This is CRITICAL after seek operations. According to Android CTS
     * documentation: "Flush the audio track when seeking... As part of a seek
     * operation, the APK player will not just flush the codecs, but also flush
     * the audio track. This is critical for resetting the presentation timestamp
     * tracking in the audio HAL for tunnel mode."</p>
     * 
     * <p>Without this, after a seek you may experience the "plays briefly then
     * stops" symptom due to timestamp desynchronization.</p>
     */
    private void flushAudioTrack() {
        if (mAudioTrack != null) {
            try {
                // Pause first to ensure we can flush cleanly
                mAudioTrack.pause();
                // Flush removes all pending data from the playback buffer
                mAudioTrack.flush();
                Log.d(TAG, "flushAudioTrack: AudioTrack flushed successfully");
            } catch (IllegalStateException e) {
                Log.e(TAG, "flushAudioTrack: Illegal state", e);
            }
        }
    }
    
    /**
     * Recreates AudioTrack when format changes.
     * 
     * <p>According to Android documentation, AudioTrack cannot be reconfigured
     * once created. The correct approach is to release the old instance and
     * create a new one with the updated parameters.</p>
     */
    private void recreateAudioTrack() {
        Log.d(TAG, "recreateAudioTrack: " + mSampleRate + "Hz, " + mChannels + "ch");
        
        boolean wasPlaying = mIsPlaying && !mIsPaused;
        
        if (mAudioTrack != null) {
            try {
                if (wasPlaying) {
                    mAudioTrack.pause();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "recreateAudioTrack: Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        createAudioTrack();
        
        if (wasPlaying && mAudioTrack != null) {
            mAudioTrack.play();
        }
    }
    
    /**
     * Starts new playback from the beginning.
     */
    private void startPlayback() {
        Log.d(TAG, "startPlayback: Beginning playback");
        
        // AudioTrack will be created when the decoder output format is known
        // Do NOT create it here - wait for format validation in processAudioData()
        
        // Start the playback thread
        mShouldStop = false;
        mPlaybackThread = new Thread(new Runnable() {
            @Override
            public void run() {
                // Set high priority for audio thread (critical for smooth playback)
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                processAudioData();
            }
        });
        mPlaybackThread.start();
        
        mIsPlaying = true;
        mIsPaused = false;
        
        // Notify listener
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPlaybackStarted();
            } catch (Exception e) {
                Log.e(TAG, "startPlayback: Listener error", e);
            }
        }
    }
    
    /**
     * Stops playback completely.
     */
    private void stopPlayback() {
        Log.d(TAG, "stopPlayback: Stopping");
        
        mShouldStop = true;
        mIsPlaying = false;
        mIsPaused = false;
        
        // Wake up paused thread
        synchronized (mPauseLock) {
            mPauseLock.notifyAll();
        }
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
            } catch (Exception e) {
                Log.e(TAG, "stopPlayback: Error stopping", e);
            }
        }
        
        // Seek back to beginning
        if (mDecoder != null) {
            mDecoder.seekTo(0);
        }
    }
    
    // ========================================================================
    // Audio Processing Thread
    // ========================================================================
    
    /**
     * Main audio processing loop.
     * 
     * <p>This method runs in a background thread and uses blocking I/O:
     * <ul>
     *   <li>{@link AudioDecoder#read(short[], int)} blocks until PCM data is available or EOS</li>
     *   <li>{@link AudioTrack#write(short[], int, int)} blocks until buffer space is available</li>
     *   <li>Pause uses wait/notify instead of spinning</li>
     * </ul>
     * </p>
     * 
     * <p><b>Critical:</b> According to Android's MediaCodec documentation,
     * the actual decoder output format (sample rate and channel count) may differ
     * from the container's MediaFormat. This method detects those changes and
     * creates the AudioTrack with the correct parameters ONLY when the first
     * frame is decoded.</p>
     */
    private void processAudioData() {
        Log.d(TAG, "processAudioData: Thread started");
        
        int samplesPerFrame = mFrameSize;
        short[] inputBuffer = new short[BUFFER_FRAMES * samplesPerFrame];
        short[] outputBuffer = new short[BUFFER_FRAMES * samplesPerFrame];
        
        boolean reachedEnd = false;
        long lastPositionUpdate = 0;
        boolean audioTrackCreated = false;
        
        while (!mShouldStop && !reachedEnd) {
            // Handle pause - block until resumed (no spinning)
            if (mIsPaused) {
                synchronized (mPauseLock) {
                    try {
                        mPauseLock.wait();
                    } catch (InterruptedException e) {
                        Log.d(TAG, "processAudioData: Interrupted while paused");
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                continue;
            }
            
            // Handle seek requests
            if (mSeekTarget >= 0 && mDecoder != null) {
                mDecoder.seekTo(mSeekTarget);
                if (mPitchShifter != null) {
                    mPitchShifter.clear();
                }
                // Note: AudioTrack flush is already done in seekTo() method
                mSeekTarget = -1;
            }
            
            try {
                // This call blocks until PCM data is available or EOS
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead <= 0) {
                    if (mDecoder.isEOS()) {
                        reachedEnd = true;
                        Log.d(TAG, "processAudioData: End of stream reached");
                        break;
                    }
                    // No data yet but not EOS - continue loop, decoder.read will block again
                    continue;
                }
                
                // CRITICAL: Validate decoder output format
                // According to Android docs, the actual format may differ from container
                int decoderSampleRate = mDecoder.getSampleRate();
                int decoderChannels = mDecoder.getChannels();
                
                if (!mFormatValidated || decoderSampleRate != mSampleRate || decoderChannels != mChannels) {
                    Log.w(TAG, "processAudioData: Decoder format change detected - " +
                          "was " + mSampleRate + "/" + mChannels + 
                          ", now " + decoderSampleRate + "/" + decoderChannels);
                    
                    mSampleRate = decoderSampleRate;
                    mChannels = decoderChannels;
                    mFrameSize = mChannels;
                    samplesPerFrame = mChannels;
                    
                    // Recreate pitch shifter with correct format
                    if (PitchShifter.isLibraryAvailable()) {
                        if (mPitchShifter != null) {
                            mPitchShifter.close();
                        }
                        mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                        mPitchShifter.setPitch(mCurrentPitch);
                        mPitchShifter.setTempo(mCurrentTempo);
                        Log.d(TAG, "processAudioData: PitchShifter recreated");
                    }
                    
                    // IMPORTANT: Create AudioTrack with the CORRECT format
                    // This must happen AFTER we know the actual decoder output format
                    if (mAudioTrack != null) {
                        try {
                            mAudioTrack.release();
                        } catch (Exception e) {
                            Log.e(TAG, "processAudioData: Error releasing old AudioTrack", e);
                        }
                        mAudioTrack = null;
                    }
                    
                    createAudioTrack();
                    audioTrackCreated = true;
                    
                    if (mAudioTrack != null && !mIsPaused) {
                        mAudioTrack.play();
                        Log.d(TAG, "processAudioData: AudioTrack created and started");
                    } else if (mAudioTrack == null) {
                        Log.e(TAG, "processAudioData: Failed to create AudioTrack!");
                        notifyError("Failed to create AudioTrack");
                        break;
                    }
                    
                    // Resize buffers for new channel count
                    inputBuffer = new short[BUFFER_FRAMES * samplesPerFrame];
                    outputBuffer = new short[BUFFER_FRAMES * samplesPerFrame];
                    
                    mFormatValidated = true;
                    
                    // Continue to next iteration with new buffers
                    continue;
                }
                
                // If AudioTrack somehow doesn't exist yet (shouldn't happen), create it
                if (mAudioTrack == null && mFormatValidated) {
                    createAudioTrack();
                    if (mAudioTrack != null && !mIsPaused) {
                        mAudioTrack.play();
                    }
                }
                
                // Process through pitch shifter
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        
                        if (received > 0 && mAudioTrack != null) {
                            int samplesToWrite = received * samplesPerFrame;
                            // This call blocks until buffer space is available
                            int written = mAudioTrack.write(outputBuffer, 0, samplesToWrite);
                            
                            // Handle write errors
                            if (written < 0) {
                                Log.e(TAG, "AudioTrack.write error: " + written);
                                // Error codes: -1 = unknown, -2 = invalid op, -3 = bad value,
                                // -4 = dead object, -5 = would block, -6 = bad state
                                if (written == -6) {
                                    // AudioTrack in bad state - need to recreate
                                    Log.w(TAG, "AudioTrack in bad state, recreating");
                                    recreateAudioTrack();
                                    if (mAudioTrack != null && !mIsPaused) {
                                        mAudioTrack.play();
                                    }
                                }
                            } else if (written != samplesToWrite) {
                                Log.w(TAG, "AudioTrack.write partial: " + written + "/" + samplesToWrite);
                            }
                        }
                    }
                } else if (mAudioTrack != null) {
                    // Bypass pitch shifter if not available
                    int samplesToWrite = framesRead * samplesPerFrame;
                    int written = mAudioTrack.write(inputBuffer, 0, samplesToWrite);
                    if (written < 0) {
                        Log.e(TAG, "AudioTrack.write error (bypass): " + written);
                        if (written == -6) {
                            recreateAudioTrack();
                            if (mAudioTrack != null && !mIsPaused) {
                                mAudioTrack.play();
                            }
                        }
                    }
                }
                
                // Update position periodically for UI
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    PlaybackListener listener = mListener;
                    if (listener != null && mDecoder != null) {
                        long position = mDecoder.getCurrentPosition();
                        listener.onPositionUpdate(position);
                    }
                    lastPositionUpdate = now;
                }
                
            } catch (Exception e) {
                Log.e(TAG, "processAudioData: Error", e);
                notifyError("Playback error: " + e.getMessage());
                break;
            }
        }
        
        // Flush remaining data in pitch shifter
        flushRemainingData();
        
        // Handle completion
        if (reachedEnd && !mShouldStop) {
            handleCompletion();
        }
        
        Log.d(TAG, "processAudioData: Thread finished");
    }
    
    /**
     * Flushes any remaining data in the pitch shifter pipeline.
     * 
     * <p>This ensures all audio data is written to AudioTrack before
     * the playback thread exits.</p>
     */
    private void flushRemainingData() {
        if (mPitchShifter != null && mAudioTrack != null && !mIsPaused) {
            mPitchShifter.flush();
            
            int available = mPitchShifter.numFrames();
            if (available > 0) {
                short[] outputBuffer = new short[available * mFrameSize];
                int received = mPitchShifter.receiveFrames(outputBuffer, available);
                
                if (received > 0 && mAudioTrack != null) {
                    int samplesToWrite = received * mFrameSize;
                    int written = mAudioTrack.write(outputBuffer, 0, samplesToWrite);
                    Log.d(TAG, "flushRemainingData: Wrote " + written + " / " + samplesToWrite + " samples");
                }
            }
        }
    }
    
    /**
     * Handles song completion.
     * 
     * <p>Notifies the listener and ensures AudioTrack is properly stopped.</p>
     */
    private void handleCompletion() {
        Log.d(TAG, "handleCompletion: Song finished");
        
        mIsPlaying = false;
        mIsPaused = false;
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onCompletion();
            } catch (Exception e) {
                Log.e(TAG, "handleCompletion: Listener error", e);
            }
        }
    }
    
    // ========================================================================
    // Broadcast and Notification Methods
    // ========================================================================
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongPrepared: duration=" + mDuration + 
              ", session=" + mAudioSessionId);
    }
    
    /**
     * Notifies the listener that the player is prepared.
     */
    private void notifyPrepared() {
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onPrepared();
            } catch (Exception e) {
                Log.e(TAG, "notifyPrepared: Listener error", e);
            }
        }
    }
    
    /**
     * Notifies the listener of an error.
     *
     * @param error Human-readable error message
     */
    private void notifyError(@NonNull String error) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            try {
                listener.onError(error);
            } catch (Exception e) {
                Log.e(TAG, "notifyError: Listener error", e);
            }
        }
    }
}