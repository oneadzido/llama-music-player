package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <p>This implementation follows the Expanded Professional Audio Engine Architecture
 * specification with strict separation of concerns, explicit state machine, and
 * dedicated threads for decoding and rendering.</p>
 * 
 * <h3>Architecture (Per Specification)</h3>
 * <pre>
 * MusicPlayer (UI) -> MusicService (Playlist) -> SoundTouchPlayer (Playback)
 *                                                                                          |
 *                                                                                         \/
 * AudioTrack (Output) <- PitchShifter (DSP) <- AudioDecoder (Decode)
 * </pre>
 * 
 * <h3>State Machine (APPENDIX A)</h3>
 * <pre>
 * IDLE -> PREPARING -> PREPARED -> PLAYING ↔ PAUSED -> COMPLETED
 * Any state may transition to ERROR or RELEASED
 * </pre>
 * 
 * <h3>Thread Ownership (APPENDIX B)</h3>
 * <ul>
 *   <li><b>UI Thread</b> - Commands (play/pause/seek/load) and callbacks</li>
 *   <li><b>Decoder Thread</b> - MediaExtractor/MediaCodec, PCM extraction</li>
 *   <li><b>Renderer Thread</b> - SoundTouch DSP, AudioTrack writes</li>
 *   <li><b>Watchdog Thread</b> - Health monitoring, stall detection</li>
 * </ul>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Pre-load capability with immediate AudioTrack creation for equalizer attachment</li>
 *   <li>Watchdog thread for stall detection and recovery</li>
 *   <li>Explicit state machine for predictable behavior</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() { ... }
 *     public void onCompletion() { ... }
 * });
 * 
 * // Pre-load for duration and session (optional)
 * player.preLoad("/sdcard/Music/song.mp3");
 * 
 * // Or load and play immediately
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.play();
 * 
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * 
 * player.release();
 * </pre>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Default sample rate (44.1 kHz) - will be overridden by actual decoder output. */
    private static final int DEFAULT_SAMPLE_RATE = 44100;
    
    /** Default number of channels (stereo) - will be overridden by actual decoder output. */
    private static final int DEFAULT_CHANNELS = 2;
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Position update interval in milliseconds for UI callbacks. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Maximum stall time in milliseconds before watchdog intervenes. */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    /** Watchdog check interval in milliseconds. */
    private static final int WATCHDOG_INTERVAL_MS = 500;
    
    /** Number of consecutive stalls before recovery is attempted. */
    private static final int MAX_STALL_COUNT = 3;
    
    /** Sleep time when idle in milliseconds. */
    private static final int IDLE_SLEEP_MS = 10;
    
    /** Sleep time when no data available in milliseconds. */
    private static final int NO_DATA_SLEEP_MS = 5;
    
    /** Delay for retrying AudioTrack play when not ready. */
    private static final int AUDIOTRACK_RETRY_DELAY_MS = 50;
    
    // ========================================================================
    // State Machine (APPENDIX A)
    // ========================================================================
    
    /**
     * Player states as defined in APPENDIX A of the architecture specification.
     * 
     * <p>State transitions:</p>
     * <pre>
     * IDLE -> PREPARING -> PREPARED -> PLAYING ↔ PAUSED -> COMPLETED
     * Any state may transition to ERROR or RELEASED
     * </pre>
     */
    public enum State {
        /** Initial state, no resources allocated. */
        IDLE,
        
        /** Decoder and AudioTrack are being created. */
        PREPARING,
        
        /** Ready to play, AudioTrack created, session available. */
        PREPARED,
        
        /** Actively playing audio. */
        PLAYING,
        
        /** Playback paused, position preserved. */
        PAUSED,
        
        /** End of stream reached naturally. */
        COMPLETED,
        
        /** Error occurred, needs recovery or release. */
        ERROR,
        
        /** Resources released, terminal state. */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>Implement this interface to be notified of playback state changes
     * such as start, pause, completion, and errors.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         *
         * @param newState The new state
         * @param oldState The previous state
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * The audio session is now available and duration is known.
         */
        void onPrepared();
        
        /**
         * Called when the current song completes playback.
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback.
         *
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Command Queue (Thread-Safe Communication)
    // ========================================================================
    
    /**
     * Commands that can be sent from UI thread to decoder/renderer threads.
     * Uses Command pattern for thread-safe communication between layers.
     */
    private enum Command {
        /** No operation. */
        NONE,
        
        /** Load a song file. */
        LOAD,
        
        /** Start playback. */
        PLAY,
        
        /** Pause playback. */
        PAUSE,
        
        /** Resume playback from paused state. */
        RESUME,
        
        /** Stop playback and reset position. */
        STOP,
        
        /** Seek to a specific position. */
        SEEK,
        
        /** Set pitch shift amount. */
        SET_PITCH,
        
        /** Set tempo multiplier. */
        SET_TEMPO,
        
        /** Release all resources. */
        RELEASE
    }
    
    /**
     * Command with optional parameters.
     * Immutable for thread safety.
     */
    private static class CommandMessage {
        final Command command;
        final String stringParam;
        final int intParam;
        final float floatParam;
        
        CommandMessage(Command command) {
            this(command, null, 0, 0f);
        }
        
        CommandMessage(Command command, String stringParam) {
            this(command, stringParam, 0, 0f);
        }
        
        CommandMessage(Command command, int intParam) {
            this(command, null, intParam, 0f);
        }
        
        CommandMessage(Command command, float floatParam) {
            this(command, null, 0, floatParam);
        }
        
        private CommandMessage(Command command, String stringParam, int intParam, float floatParam) {
            this.command = command;
            this.stringParam = stringParam;
            this.intParam = intParam;
            this.floatParam = floatParam;
        }
        
        /**
         * Creates a LOAD command with a file path.
         *
         * @param path The file path to load
         * @return The command message
         */
        static CommandMessage load(String path) {
            return new CommandMessage(Command.LOAD, path);
        }
        
        /**
         * Creates a SEEK command with a position.
         *
         * @param positionMs The position in milliseconds
         * @return The command message
         */
        static CommandMessage seek(int positionMs) {
            return new CommandMessage(Command.SEEK, positionMs);
        }
        
        /**
         * Creates a SET_PITCH command.
         *
         * @param semitones The pitch shift in semitones
         * @return The command message
         */
        static CommandMessage setPitch(float semitones) {
            return new CommandMessage(Command.SET_PITCH, semitones);
        }
        
        /**
         * Creates a SET_TEMPO command.
         *
         * @param tempo The tempo multiplier
         * @return The command message
         */
        static CommandMessage setTempo(float tempo) {
            return new CommandMessage(Command.SET_TEMPO, tempo);
        }
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for broadcasts. */
    @NonNull
    private final Context mContext;
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Current player state (atomic for thread-safe reads). */
    private final AtomicReference<State> mState = new AtomicReference<>(State.IDLE);
    
    /** Command queue for decoder thread (thread-safe). */
    private final ConcurrentLinkedQueue<CommandMessage> mCommandQueue = new ConcurrentLinkedQueue<>();
    
    // ========================================================================
    // Audio Components
    // ========================================================================
    
    /** Audio decoder (MediaExtractor/MediaCodec). Owned by decoder thread. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** Native pitch shifter (SoundTouch JNI). Owned by renderer thread. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** AudioTrack for PCM output. Owned by renderer thread. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    // ========================================================================
    // Threads (APPENDIX B)
    // ========================================================================
    
    /** Decoder thread for extraction and decode. */
    @Nullable
    private HandlerThread mDecoderThread;
    
    /** Handler for decoder thread commands. */
    @Nullable
    private Handler mDecoderHandler;
    
    /** Renderer thread for DSP and AudioTrack writes. */
    @Nullable
    private HandlerThread mRendererThread;
    
    /** Handler for renderer thread commands. */
    @Nullable
    private Handler mRendererHandler;
    
    /** Watchdog thread for health monitoring. */
    @Nullable
    private HandlerThread mWatchdogThread;
    
    /** Handler for watchdog thread. */
    @Nullable
    private Handler mWatchdogHandler;
    
    /** Runnable for continuous rendering loop. */
    @Nullable
    private Runnable mRenderRunnable;
    
    /** Runnable for watchdog monitoring. */
    @Nullable
    private Runnable mWatchdogRunnable;
    
    /** Handler for UI thread callbacks. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Decoder State (Owned by decoder thread, read by renderer)
    // ========================================================================
    
    /** Current file path. */
    private final AtomicReference<String> mCurrentFilePath = new AtomicReference<>();
    
    /** Song duration in milliseconds. */
    private final AtomicLong mDuration = new AtomicLong(0);
    
    /** Current sample rate from decoder. */
    private int mSampleRate = DEFAULT_SAMPLE_RATE;
    
    /** Number of channels from decoder. */
    private int mChannels = DEFAULT_CHANNELS;
    
    /** Frame size (samples per frame = channels). */
    private int mFrameSize = DEFAULT_CHANNELS;
    
    /** Flag indicating decoder has reached EOS. */
    private final AtomicBoolean mDecoderEOS = new AtomicBoolean(false);
    
    /** Flag indicating decoder is active (not stopped). */
    private final AtomicBoolean mDecoderActive = new AtomicBoolean(false);
    
    // ========================================================================
    // Rendering State (Owned by renderer thread)
    // ========================================================================
    
    /** Current pitch setting. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo setting. */
    private float mCurrentTempo = 1.0f;
    
    /** AudioTrack buffer size in bytes. */
    private int mAudioTrackBufferSize = 0;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Flag indicating format has been validated (AudioTrack created with correct format). */
    private boolean mFormatValidated = false;
    
    /** Seek target position in milliseconds (-1 = no seek). */
    private final AtomicInteger mSeekTarget = new AtomicInteger(-1);
    
    /** Flag indicating AudioTrack play was requested but pending format change. */
    private boolean mPlayPending = false;
    
    // ========================================================================
    // Watchdog State
    // ========================================================================
    
    /** Last reported playback position from renderer. */
    private final AtomicLong mLastReportedPosition = new AtomicLong(0);
    
    /** Last timestamp when position changed. */
    private final AtomicLong mLastPositionChangeTime = new AtomicLong(System.currentTimeMillis());
    
    /** Number of consecutive stalls detected. */
    private final AtomicInteger mStallCount = new AtomicInteger(0);
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>Initializes the player in IDLE state. Resources are allocated lazily
     * when a song is loaded.</p>
     *
     * @param context Application context for sending broadcasts
     */
    public SoundTouchPlayer(@NonNull Context context) {
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, initial state: IDLE");
    }
    
    // ========================================================================
    // Public API Methods (UI Thread)
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     *
     * @param listener The listener to receive events (can be null)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Creates AudioTrack immediately (synchronously) to get audio session ID.
     * This ensures equalizer can attach before playback starts.
     * The AudioTrack will be recreated later with correct format if needed.
     */
    private void createAudioTrackImmediately() {
        if (mAudioTrack != null) {
            return; // Already created
        }
        
        // Use default values initially - will be reconfigured when format is known
        int channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
        int sampleRate = 44100;
        
        int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createAudioTrackImmediately: Invalid minBufferSize");
            return;
        }
        
        int targetBufferSize = sampleRate * 2 * 2 * MIN_BUFFER_MS / 1000;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        try {
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            Log.d(TAG, "AudioTrack created immediately - session=" + mAudioSessionId);
            
            // Broadcast session immediately
            broadcastSongPrepared();
            
            // Notify listener that player is prepared (session available)
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onPrepared();
                    }
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "createAudioTrackImmediately failed", e);
        }
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This method initializes the decoder and CREATES the AudioTrack immediately
     * to ensure the audio session ID is available for equalizer attachment.</p>
     * 
     * <p>State transition: IDLE/PREPARED/COMPLETED/ERROR -> PREPARING</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was initiated successfully, false otherwise
     */
    public boolean preLoad(@NonNull String filePath) {
        checkNotReleased();
        
        State currentState = mState.get();
        if (currentState == State.PREPARING) {
            Log.w(TAG, "preLoad: Already preparing, queuing command");
            mCommandQueue.offer(CommandMessage.load(filePath));
            return true;
        }
        
        if (currentState == State.PREPARED || currentState == State.PLAYING || 
            currentState == State.PAUSED) {
            // Release existing before loading new
            sendCommand(Command.RELEASE);
        }
        
        mCommandQueue.offer(CommandMessage.load(filePath));
        startDecoderThread();
        
        // CRITICAL: Create AudioTrack immediately so session ID is available
        // This ensures equalizer can attach before playback starts
        createAudioTrackImmediately();
        
        return true;
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method internally calls {@link #preLoad(String)} to initialize
     * the decoder. The player will be ready to play immediately after this
     * method returns true.</p>
     * 
     * <p>State transition: IDLE/PREPARED/COMPLETED/ERROR -> PREPARING -> PREPARED</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false otherwise
     */
    public boolean loadSong(@NonNull String filePath) {
        return preLoad(filePath);
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>State transitions:</p>
     * <ul>
     *   <li>PREPARED -> PLAYING</li>
     *   <li>PAUSED -> PLAYING</li>
     *   <li>COMPLETED -> seeks to 0 then PLAYING</li>
     * </ul>
     */
    public void play() {
        checkNotReleased();
        
        State currentState = mState.get();
        Log.d(TAG, "play() called, currentState=" + currentState + ", formatValidated=" + mFormatValidated);
        
        if (currentState == State.PREPARED || currentState == State.COMPLETED) {
            // Ensure decoder is positioned at start if completed
            if (currentState == State.COMPLETED && mDecoder != null) {
                mDecoder.seekTo(0);
                mDecoderEOS.set(false);
            }
            
            // If format not validated yet, mark play as pending
            if (!mFormatValidated) {
                Log.d(TAG, "play() called before format validated - marking pending");
                mPlayPending = true;
                sendCommand(Command.PLAY);
                return;
            }
            
            sendCommand(Command.PLAY);
        } else if (currentState == State.PAUSED) {
            sendCommand(Command.RESUME);
        } else if (currentState == State.IDLE) {
            Log.w(TAG, "play: Called on IDLE, ignoring - load a song first");
        } else if (currentState == State.ERROR) {
            Log.w(TAG, "play: Cannot play in ERROR state");
            notifyError("Cannot play - player in error state");
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>State transition: PLAYING -> PAUSED</p>
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()} or {@link #resume()}.</p>
     */
    public void pause() {
        checkNotReleased();
        
        if (mState.get() == State.PLAYING) {
            sendCommand(Command.PAUSE);
        }
    }
    
    /**
     * Resumes playback after pause.
     * 
     * <p>State transition: PAUSED -> PLAYING</p>
     */
    public void resume() {
        checkNotReleased();
        
        if (mState.get() == State.PAUSED) {
            sendCommand(Command.RESUME);
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>After calling stop, the player remains prepared and can be restarted
     * by calling {@link #play()} which will restart from the beginning.</p>
     * 
     * <p>State transition: PLAYING/PAUSED -> PREPARED</p>
     */
    public void stop() {
        checkNotReleased();
        sendCommand(Command.STOP);
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation flushes both the decoder and AudioTrack, which is
     * critical for proper operation. According to Android CTS requirements,
     * failing to flush AudioTrack on seek causes presentation timestamp
     * mismatches in the audio HAL, resulting in no sound after seek.</p>
     * 
     * <p>Valid in states: PREPARED, PLAYING, PAUSED, COMPLETED</p>
     *
     * @param positionMs Position in milliseconds to seek to
     */
    public void seekTo(int positionMs) {
        checkNotReleased();
        
        State currentState = mState.get();
        if (currentState == State.PREPARED || currentState == State.PLAYING || 
            currentState == State.PAUSED || currentState == State.COMPLETED) {
            mSeekTarget.set(positionMs);
            sendCommand(Command.SEEK, positionMs);
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones.</p>
     *
     * @param semitones The pitch shift amount in semitones
     */
    public void setPitch(float semitones) {
        checkNotReleased();
        mCurrentPitch = semitones;
        sendCommand(Command.SET_PITCH, semitones);
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5.</p>
     *
     * @param tempo The tempo multiplier (e.g., 1.25 for 125% speed)
     */
    public void setTempo(float tempo) {
        checkNotReleased();
        mCurrentTempo = tempo;
        sendCommand(Command.SET_TEMPO, tempo);
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration.get();
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>Uses AudioTrack playback head position for accuracy when available,
     * as specified in the architecture documentation.</p>
     *
     * @return Current position in milliseconds, or 0 if not playing
     */
    public long getCurrentPosition() {
        // Prefer AudioTrack head position for playing/paused states (per spec)
        State state = mState.get();
        if ((state == State.PLAYING || state == State.PAUSED) && mAudioTrack != null) {
            try {
                long headPositionMs = mAudioTrack.getPlaybackHeadPosition() * 1000L / mSampleRate;
                if (headPositionMs > 0) {
                    return headPositionMs;
                }
            } catch (Exception e) {
                // Fall back to decoder position
            }
        }
        
        // Fallback to decoder position
        AudioDecoder decoder = mDecoder;
        if (decoder != null) {
            return decoder.getCurrentPosition();
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        if (mAudioTrack != null && mState.get() == State.PLAYING) {
            try {
                return mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING;
            } catch (Exception e) {
                return mState.get() == State.PLAYING;
            }
        }
        return mState.get() == State.PLAYING;
    }
    
    /**
     * Checks if a song is loaded and the player is ready.
     *
     * @return true if prepared (PREPARED, PLAYING, or PAUSED state), false otherwise
     */
    public boolean isPrepared() {
        State state = mState.get();
        return state == State.PREPARED || state == State.PLAYING || state == State.PAUSED;
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return The current State
     */
    @NonNull
    public State getState() {
        return mState.get();
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     * 
     * <p>State transition: Any state -> RELEASED (terminal)</p>
     */
    public void release() {
        Log.d(TAG, "release() called");
        
        sendCommand(Command.RELEASE);
        
        // Wait briefly for command processing
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        stopThreads();
        
        mState.set(State.RELEASED);
        Log.d(TAG, "release() complete, state: RELEASED");
    }
    
    // ========================================================================
    // Thread Management
    // ========================================================================
    
    /**
     * Starts the decoder thread if not already running.
     */
    private void startDecoderThread() {
        if (mDecoderThread != null && mDecoderThread.isAlive()) {
            return;
        }
        
        mDecoderThread = new HandlerThread("AudioDecoder");
        mDecoderThread.start();
        mDecoderHandler = new Handler(mDecoderThread.getLooper());
        mDecoderHandler.post(mDecoderRunnable);
        
        Log.d(TAG, "Decoder thread started");
    }
    
    /**
     * Starts the renderer thread if not already running.
     */
    private void startRendererThread() {
        if (mRendererThread != null && mRendererThread.isAlive()) {
            return;
        }
        
        mRendererThread = new HandlerThread("AudioRenderer", Process.THREAD_PRIORITY_URGENT_AUDIO);
        mRendererThread.start();
        mRendererHandler = new Handler(mRendererThread.getLooper());
        
        mRenderRunnable = new Runnable() {
            @Override
            public void run() {
                processRendering();
            }
        };
        mRendererHandler.post(mRenderRunnable);
        
        Log.d(TAG, "Renderer thread started");
    }
    
    /**
     * Starts the watchdog thread for health monitoring.
     */
    private void startWatchdogThread() {
        if (mWatchdogThread != null && mWatchdogThread.isAlive()) {
            return;
        }
        
        mWatchdogThread = new HandlerThread("AudioWatchdog", Process.THREAD_PRIORITY_BACKGROUND);
        mWatchdogThread.start();
        mWatchdogHandler = new Handler(mWatchdogThread.getLooper());
        
        mWatchdogRunnable = new Runnable() {
            @Override
            public void run() {
                while (mWatchdogThread != null && mWatchdogThread.isAlive() && 
                       mState.get() != State.RELEASED && mState.get() != State.IDLE) {
                    try {
                        Thread.sleep(WATCHDOG_INTERVAL_MS);
                        checkPlaybackHealth();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        };
        mWatchdogHandler.post(mWatchdogRunnable);
        
        Log.d(TAG, "Watchdog thread started");
    }
    
    /**
     * Stops all background threads.
     */
    private void stopThreads() {
        // Stop watchdog
        if (mWatchdogThread != null) {
            mWatchdogThread.quitSafely();
            try { mWatchdogThread.join(500); } catch (InterruptedException ignored) {}
            mWatchdogThread = null;
            mWatchdogHandler = null;
        }
        
        // Stop renderer
        if (mRendererThread != null) {
            mRendererThread.quitSafely();
            try { mRendererThread.join(500); } catch (InterruptedException ignored) {}
            mRendererThread = null;
            mRendererHandler = null;
            mRenderRunnable = null;
        }
        
        // Stop decoder
        if (mDecoderThread != null) {
            mDecoderThread.quitSafely();
            try { mDecoderThread.join(500); } catch (InterruptedException ignored) {}
            mDecoderThread = null;
            mDecoderHandler = null;
        }
    }
    
    /**
     * Sends a command to the decoder thread.
     *
     * @param command The command to send
     */
    private void sendCommand(Command command) {
        mCommandQueue.offer(new CommandMessage(command));
    }
    
    /**
     * Sends a command with an integer parameter.
     *
     * @param command The command to send
     * @param param The integer parameter
     */
    private void sendCommand(Command command, int param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    /**
     * Sends a command with a float parameter.
     *
     * @param command The command to send
     * @param param The float parameter
     */
    private void sendCommand(Command command, float param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    /**
     * Sends a command with a string parameter.
     *
     * @param command The command to send
     * @param param The string parameter
     */
    private void sendCommand(Command command, String param) {
        mCommandQueue.offer(new CommandMessage(command, param));
    }
    
    // ========================================================================
    // Decoder Thread Runnable (APPENDIX B)
    // ========================================================================
    
    /**
     * Main decoder thread loop.
     * 
     * <p>This method runs in a background thread and processes commands
     * from the command queue. It handles all MediaExtractor and MediaCodec
     * operations.</p>
     */
    private final Runnable mDecoderRunnable = new Runnable() {
        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            mDecoderActive.set(true);
            
            while (mDecoderActive.get() && mState.get() != State.RELEASED) {
                try {
                    CommandMessage cmd = mCommandQueue.poll();
                    if (cmd != null) {
                        processCommand(cmd);
                    }
                    
                    // Small sleep to prevent CPU spinning
                    Thread.sleep(IDLE_SLEEP_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Decoder thread error", e);
                    transitionToError(e.getMessage());
                }
            }
            
            Log.d(TAG, "Decoder thread exiting");
        }
    };
    
    /**
     * Processes a single command from the queue.
     *
     * @param cmd The command to process
     */
    private void processCommand(CommandMessage cmd) {
        switch (cmd.command) {
            case LOAD:
                processLoad(cmd.stringParam);
                break;
            case PLAY:
                processPlay();
                break;
            case PAUSE:
                processPause();
                break;
            case RESUME:
                processResume();
                break;
            case STOP:
                processStop();
                break;
            case SEEK:
                processSeek(cmd.intParam);
                break;
            case SET_PITCH:
                processSetPitch(cmd.floatParam);
                break;
            case SET_TEMPO:
                processSetTempo(cmd.floatParam);
                break;
            case RELEASE:
                processRelease();
                break;
            default:
                break;
        }
    }
    
    // ========================================================================
    // Command Processing (Decoder Thread)
    // ========================================================================
    
    /**
     * Processes a LOAD command.
     *
     * @param filePath The file path to load
     */
    private void processLoad(@NonNull String filePath) {
        transitionTo(State.PREPARING);
        
        try {
            // Release existing resources
            releaseDecoder();
            
            // Create and open decoder
            mDecoder = new AudioDecoder();
            if (!mDecoder.open(filePath)) {
                transitionToError("Failed to open audio file");
                return;
            }
            
            // Extract metadata
            mDuration.set(mDecoder.getDuration());
            mCurrentFilePath.set(filePath);
            mDecoderEOS.set(false);
            mSeekTarget.set(-1);
            
            Log.d(TAG, "Load complete: duration=" + mDuration.get() + "ms, " +
                  "sampleRate=" + mDecoder.getSampleRate() + ", channels=" + mDecoder.getChannels());
            
            // Start renderer thread (creates AudioTrack when format is known)
            startRendererThread();
            startWatchdogThread();
            
        } catch (Exception e) {
            Log.e(TAG, "Load failed", e);
            transitionToError(e.getMessage());
        }
    }
    
    /**
     * Processes a PLAY command.
     */
    private void processPlay() {
        State currentState = mState.get();
        Log.d(TAG, "processPlay: currentState=" + currentState + ", mFormatValidated=" + mFormatValidated);
        
        if (currentState == State.PREPARED || currentState == State.COMPLETED) {
            // Ensure decoder is positioned at start if completed
            if (currentState == State.COMPLETED && mDecoder != null) {
                mDecoder.seekTo(0);
                mDecoderEOS.set(false);
            }
            
            // CRITICAL: Make sure AudioTrack exists and is ready
            if (mAudioTrack == null) {
                Log.w(TAG, "processPlay: AudioTrack is null, creating now");
                createAudioTrack();
            }
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "processPlay: AudioTrack.play() called, playState=" + mAudioTrack.getPlayState());
                } catch (IllegalStateException e) {
                    Log.e(TAG, "processPlay: Failed to start AudioTrack", e);
                }
            }
            
            transitionTo(State.PLAYING);
        } else if (currentState == State.PAUSED) {
            processResume();
        }
    }
    
    /**
     * Processes a PAUSE command.
     */
    private void processPause() {
        transitionTo(State.PAUSED);
    }
    
    /**
     * Processes a RESUME command.
     */
    private void processResume() {
        if (mState.get() == State.PAUSED) {
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "processResume: AudioTrack.play() called");
                } catch (IllegalStateException e) {
                    Log.e(TAG, "processResume: Failed to resume AudioTrack", e);
                }
            }
            transitionTo(State.PLAYING);
        }
    }
    
    /**
     * Processes a STOP command.
     */
    private void processStop() {
        if (mDecoder != null) {
            mDecoder.seekTo(0);
            mDecoderEOS.set(false);
        }
        transitionTo(State.PREPARED);
    }
    
    /**
     * Processes a SEEK command.
     *
     * @param positionMs The position to seek to in milliseconds
     */
    private void processSeek(int positionMs) {
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mDecoderEOS.set(false);
            mSeekTarget.set(positionMs);
            
            // Notify renderer to flush
            if (mRendererHandler != null) {
                mRendererHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        flushAudioTrack();
                    }
                });
            }
        }
    }
    
    /**
     * Processes a SET_PITCH command.
     *
     * @param semitones The pitch shift in semitones
     */
    private void processSetPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
        }
    }
    
    /**
     * Processes a SET_TEMPO command.
     *
     * @param tempo The tempo multiplier
     */
    private void processSetTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
        }
    }
    
    /**
     * Processes a RELEASE command.
     */
    private void processRelease() {
        mDecoderActive.set(false);
        
        releaseRenderer();
        releaseDecoder();
        
        transitionTo(State.RELEASED);
    }
    
    /**
     * Releases decoder resources.
     */
    private void releaseDecoder() {
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
        }
        mDecoderEOS.set(false);
    }
    
    /**
     * Releases renderer resources.
     */
    private void releaseRenderer() {
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        mAudioSessionId = 0;
        mFormatValidated = false;
        mPlayPending = false;
    }
    
    // ========================================================================
    // Renderer Thread (APPENDIX B)
    // ========================================================================
    
    /**
     * Main renderer thread loop.
     * 
     * <p>This method runs in a background thread with high audio priority.
     * It reads PCM data from the decoder, processes it through SoundTouch,
     * and writes it to AudioTrack.</p>
     */
    private void processRendering() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] inputBuffer = new short[BUFFER_FRAMES * mFrameSize];
        short[] outputBuffer = new short[BUFFER_FRAMES * mFrameSize];
        long lastPositionUpdate = 0;
        
        Log.d(TAG, "Renderer thread started");
        
        while (mState.get() != State.RELEASED && mDecoderActive.get()) {
            try {
                State currentState = mState.get();
                
                // Handle seek marker
                int seekTarget = mSeekTarget.getAndSet(-1);
                if (seekTarget >= 0 && mDecoder != null) {
                    if (mPitchShifter != null) {
                        mPitchShifter.clear();
                    }
                }
                
                // Skip processing if not playing
                if (currentState != State.PLAYING) {
                    Thread.sleep(IDLE_SLEEP_MS);
                    continue;
                }
                
                // Check if decoder is at EOS
                if (mDecoderEOS.get() || (mDecoder != null && mDecoder.isEOS())) {
                    handleCompletion();
                    break;
                }
                
                // Read PCM from decoder (blocking call)
                if (mDecoder == null) {
                    Thread.sleep(IDLE_SLEEP_MS);
                    continue;
                }
                
                int framesRead = mDecoder.read(inputBuffer, BUFFER_FRAMES);
                
                if (framesRead <= 0) {
                    if (mDecoder.isEOS()) {
                        mDecoderEOS.set(true);
                        continue;
                    }
                    Thread.sleep(NO_DATA_SLEEP_MS);
                    continue;
                }
                
                // Validate format on first read and recreate AudioTrack if needed
                if (!mFormatValidated) {
                    validateFormatAndRecreateAudioTrack();
                    if (!mFormatValidated) {
                        // Check if play was pending while format was being validated
                        if (mPlayPending) {
                            Log.d(TAG, "Play was pending, starting playback now");
                            mPlayPending = false;
                            if (mAudioTrack != null) {
                                mAudioTrack.play();
                            }
                            transitionTo(State.PLAYING);
                        }
                        continue;
                    }
                }
                
                // Process through pitch shifter
                if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                    mPitchShifter.putFrames(inputBuffer, framesRead);
                    
                    int available = mPitchShifter.numFrames();
                    if (available > 0) {
                        int toRead = Math.min(available, BUFFER_FRAMES);
                        int received = mPitchShifter.receiveFrames(outputBuffer, toRead);
                        
                        if (received > 0 && mAudioTrack != null) {
                            int samplesToWrite = received * mFrameSize;
                            int written = mAudioTrack.write(outputBuffer, 0, samplesToWrite);
                            
                            if (written < 0) {
                                handleAudioTrackError(written);
                            }
                        }
                    }
                } else if (mAudioTrack != null) {
                    // Bypass pitch shifter if not available
                    int samplesToWrite = framesRead * mFrameSize;
                    int written = mAudioTrack.write(inputBuffer, 0, samplesToWrite);
                    
                    if (written < 0) {
                        handleAudioTrackError(written);
                    }
                }
                
                // Update position for UI
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    updatePositionAndNotify();
                    lastPositionUpdate = now;
                }
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Renderer error", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "Renderer thread exiting");
    }
    
    /**
     * Validates decoder output format and recreates AudioTrack with correct parameters.
     * 
     * <p>According to Android's MediaCodec documentation, the actual decoder
     * output format may differ from the container's MediaFormat. This method
     * recreates the AudioTrack with the correct parameters when the first frame
     * is decoded.</p>
     */
    private void validateFormatAndRecreateAudioTrack() {
        if (mDecoder == null) return;
        
        int newSampleRate = mDecoder.getSampleRate();
        int newChannels = mDecoder.getChannels();
        
        boolean formatChanged = (newSampleRate != mSampleRate || newChannels != mChannels);
        
        mSampleRate = newSampleRate;
        mChannels = newChannels;
        mFrameSize = mChannels;
        
        // Recreate pitch shifter with correct format
        if (PitchShifter.isLibraryAvailable()) {
            if (mPitchShifter != null) {
                mPitchShifter.close();
            }
            mPitchShifter = new PitchShifter(mSampleRate, mChannels);
            mPitchShifter.setPitch(mCurrentPitch);
            mPitchShifter.setTempo(mCurrentTempo);
            Log.d(TAG, "PitchShifter recreated with sampleRate=" + mSampleRate + ", channels=" + mChannels);
        }
        
        // Track if we need to restore playback
        boolean wasPlaying = (mState.get() == State.PLAYING);
        
        // If format changed, recreate AudioTrack with correct parameters
        if (formatChanged && mAudioTrack != null) {
            Log.d(TAG, "Format changed - recreating AudioTrack: " + 
                  "was " + mSampleRate + "/" + mChannels + 
                  ", now " + newSampleRate + "/" + newChannels +
                  ", wasPlaying=" + wasPlaying);
            
            // Release old AudioTrack
            try {
                if (mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.stop();
                }
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        // Create or recreate AudioTrack
        if (mAudioTrack == null) {
            createAudioTrack();
        }
        
        if (mAudioTrack != null) {
            mFormatValidated = true;
            
            // CRITICAL: Restore playback if we were playing before format change
            if (wasPlaying && mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "Restarted AudioTrack playback after format change");
                } catch (IllegalStateException e) {
                    Log.e(TAG, "Failed to restart AudioTrack after format change", e);
                    // Schedule retry
                    mUiHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mAudioTrack != null && mState.get() == State.PLAYING) {
                                try {
                                    mAudioTrack.play();
                                    Log.d(TAG, "Retry: AudioTrack.play() after format change");
                                } catch (IllegalStateException ex) {
                                    Log.e(TAG, "Retry failed", ex);
                                }
                            }
                        }
                    }, AUDIOTRACK_RETRY_DELAY_MS);
                }
            }
            
            // Broadcast song prepared again with correct session (if changed)
            broadcastSongPrepared();
            
            // Notify listener that player is ready
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onPrepared();
                    }
                });
            }
        }
    }
    
    /**
     * Creates AudioTrack according to Android best practices using current sample rate.
     * 
     * <p>Key points from Android documentation:</p>
     * <ul>
     *   <li>Use AudioAttributes.Builder for usage and content type</li>
     *   <li>Use AudioFormat.Builder for format specification</li>
     *   <li>Buffer size should be at least getMinBufferSize()</li>
     *   <li>Use MODE_STREAM for continuous data flow</li>
     *   <li>Call getAudioSessionId() AFTER creation</li>
     * </ul>
     */
    private void createAudioTrack() {
        int channelConfig = (mChannels == 2) ? 
            AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
        
        int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig,
            AudioFormat.ENCODING_PCM_16BIT);
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "Invalid minBufferSize: " + minBufferSize);
            return;
        }
        
        // Larger buffer for stability (per spec)
        int targetBufferSize = mSampleRate * mFrameSize * 2 * MIN_BUFFER_MS / 1000;
        mAudioTrackBufferSize = Math.max(minBufferSize, targetBufferSize);
        
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        try {
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(mAudioTrackBufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            int newSessionId = mAudioTrack.getAudioSessionId();
            if (newSessionId != mAudioSessionId) {
                mAudioSessionId = newSessionId;
                Log.d(TAG, "AudioTrack recreated with new session=" + mAudioSessionId);
            } else {
                Log.d(TAG, "AudioTrack created with session=" + mAudioSessionId);
            }
            
            // If state is PLAYING, start playback immediately
            if (mState.get() == State.PLAYING) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "createAudioTrack: Started playback (state was PLAYING)");
                } catch (IllegalStateException e) {
                    Log.e(TAG, "createAudioTrack: Failed to start playback", e);
                }
            }
            
        } catch (IllegalStateException | IllegalArgumentException e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
        }
    }
    
    /**
     * Flushes the AudioTrack to clear any pending audio data.
     * 
     * <p>This is CRITICAL after seek operations. According to Android CTS
     * documentation: "Flush the audio track when seeking... As part of a seek
     * operation, the APK player will not just flush the codecs, but also flush
     * the audio track. This is critical for resetting the presentation timestamp
     * tracking in the audio HAL for tunnel mode."</p>
     */
    private void flushAudioTrack() {
        if (mAudioTrack != null) {
            try {
                boolean wasPlaying = (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING);
                mAudioTrack.pause();
                mAudioTrack.flush();
                if (wasPlaying && mState.get() == State.PLAYING) {
                    mAudioTrack.play();
                }
                Log.d(TAG, "AudioTrack flushed");
            } catch (IllegalStateException e) {
                Log.e(TAG, "Failed to flush AudioTrack", e);
            }
        }
    }
    
    /**
     * Handles AudioTrack.write errors.
     *
     * @param errorCode The error code from AudioTrack.write
     */
    private void handleAudioTrackError(int errorCode) {
        Log.e(TAG, "AudioTrack.write error: " + errorCode);
        // Error -6 indicates bad state - need to recreate
        if (errorCode == -6) {
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onError("AudioTrack error - recreating");
                    }
                });
            }
            recreateAudioTrack();
        }
    }
    
    /**
     * Recreates the AudioTrack when it enters a bad state.
     */
    private void recreateAudioTrack() {
        if (mAudioTrack != null) {
            try { mAudioTrack.release(); } catch (Exception ignored) {}
            mAudioTrack = null;
        }
        createAudioTrack();
        if (mAudioTrack != null && mState.get() == State.PLAYING) {
            try {
                mAudioTrack.play();
            } catch (IllegalStateException e) {
                Log.e(TAG, "Failed to play after recreate", e);
            }
        }
    }
    
    /**
     * Updates the current position and notifies the listener.
     */
    private void updatePositionAndNotify() {
        long position = getCurrentPosition();
        mLastReportedPosition.set(position);
        mLastPositionChangeTime.set(System.currentTimeMillis());
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onPositionUpdate(position);
                }
            });
        }
    }
    
    /**
     * Handles song completion.
     * 
     * <p>Flushes any remaining data from the pitch shifter pipeline and
     * transitions to COMPLETED state.</p>
     */
    private void handleCompletion() {
        // Flush remaining data from pitch shifter
        if (mPitchShifter != null && mAudioTrack != null) {
            mPitchShifter.flush();
            int available = mPitchShifter.numFrames();
            if (available > 0) {
                short[] outputBuffer = new short[available * mFrameSize];
                int received = mPitchShifter.receiveFrames(outputBuffer, available);
                if (received > 0) {
                    mAudioTrack.write(outputBuffer, 0, received * mFrameSize);
                }
            }
        }
        
        transitionTo(State.COMPLETED);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onCompletion();
                }
            });
        }
        
        Log.d(TAG, "Playback completed");
    }
    
    // ========================================================================
    // Watchdog (APPENDIX B)
    // ========================================================================
    
    /**
     * Checks playback health and attempts recovery if stalled.
     * 
     * <p>The watchdog monitors the playback position. If it doesn't advance
     * for MAX_STALL_TIME_MS, a stall is counted. After MAX_STALL_COUNT stalls,
     * recovery is attempted.</p>
     */
    private void checkPlaybackHealth() {
        State state = mState.get();
        if (state != State.PLAYING) {
            mStallCount.set(0);
            return;
        }
        
        long currentPosition = getCurrentPosition();
        long lastPosition = mLastReportedPosition.get();
        long now = System.currentTimeMillis();
        long timeSinceLastChange = now - mLastPositionChangeTime.get();
        
        if (currentPosition == lastPosition && timeSinceLastChange > MAX_STALL_TIME_MS) {
            int stallCount = mStallCount.incrementAndGet();
            Log.w(TAG, "Playback stall detected! Count=" + stallCount + 
                  ", position stuck at " + currentPosition + "ms");
            
            if (stallCount >= MAX_STALL_COUNT) {
                Log.w(TAG, "Multiple stalls detected, attempting recovery");
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onError("Playback stalled - recovering");
                        }
                    });
                }
                attemptRecovery();
                mStallCount.set(0);
            }
        } else if (currentPosition != lastPosition) {
            mLastReportedPosition.set(currentPosition);
            mLastPositionChangeTime.set(now);
            mStallCount.set(0);
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     */
    private void attemptRecovery() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                Thread.sleep(50);
                mAudioTrack.flush();
                mAudioTrack.play();
                Log.d(TAG, "Recovery: AudioTrack flushed and restarted");
            } catch (Exception e) {
                Log.e(TAG, "Recovery failed", e);
                recreateAudioTrack();
            }
        }
    }
    
    // ========================================================================
    // State Management (APPENDIX A)
    // ========================================================================
    
    /**
     * Transitions the player to a new state.
     * 
     * <p>This method updates the state atomically and notifies the listener
     * of the state change. It also handles AudioTrack state changes on the
     * renderer thread.</p>
     *
     * @param newState The new state to transition to
     */
    private void transitionTo(State newState) {
        State oldState = mState.getAndSet(newState);
        
        if (oldState == newState) {
            return;
        }
        
        Log.d(TAG, "State transition: " + oldState + " -> " + newState);
        
        // Handle AudioTrack state changes on renderer thread
        if (mRendererHandler != null) {
            mRendererHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleAudioTrackForState(newState);
                }
            });
        } else {
            // If renderer thread not ready, handle on current thread
            handleAudioTrackForState(newState);
        }
        
        // Notify listener AFTER AudioTrack state change
        PlaybackListener listener = mListener;
        if (listener != null) {
            final State finalNewState = newState;
            final State finalOldState = oldState;
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onStateChanged(finalNewState, finalOldState);
                }
            });
        }
    }
    
    /**
     * Transitions the player to ERROR state.
     *
     * @param error The error message
     */
    private void transitionToError(String error) {
        State oldState = mState.getAndSet(State.ERROR);
        
        if (oldState == State.ERROR) {
            return;
        }
        
        Log.e(TAG, "Error transition: " + oldState + " -> ERROR: " + error);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onError(error);
                }
            });
        }
    }
    
    /**
     * Handles AudioTrack state changes based on player state.
     *
     * @param state The new player state
     */
    private void handleAudioTrackForState(State state) {
        if (mAudioTrack == null || mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
            Log.w(TAG, "handleAudioTrackForState: AudioTrack not ready, state=" + state);
            // If AudioTrack isn't ready but we need to play, schedule a retry
            if (state == State.PLAYING && mFormatValidated) {
                Log.d(TAG, "AudioTrack not ready for PLAYING, scheduling retry");
                mUiHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mState.get() == State.PLAYING && mAudioTrack != null) {
                            try {
                                mAudioTrack.play();
                                Log.d(TAG, "Retry: AudioTrack.play() called");
                            } catch (IllegalStateException e) {
                                Log.e(TAG, "Retry failed", e);
                            }
                        }
                    }
                }, AUDIOTRACK_RETRY_DELAY_MS);
            }
            return;
        }
        
        try {
            switch (state) {
                case PLAYING:
                    Log.d(TAG, "handleAudioTrackForState: Starting playback");
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.play();
                        Log.d(TAG, "AudioTrack.play() called, playState=" + mAudioTrack.getPlayState());
                    } else {
                        Log.d(TAG, "AudioTrack already playing");
                    }
                    break;
                    
                case PAUSED:
                    if (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.pause();
                        Log.d(TAG, "AudioTrack.pause() called");
                    }
                    break;
                    
                case PREPARED:
                case COMPLETED:
                    if (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                        mAudioTrack.pause();
                    }
                    mAudioTrack.flush();
                    break;
                    
                default:
                    break;
            }
        } catch (IllegalStateException e) {
            Log.e(TAG, "Error handling AudioTrack for state " + state, e);
        }
    }
    
    /**
     * Notifies the listener of an error.
     *
     * @param error The error message
     */
    private void notifyError(String error) {
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    listener.onError(error);
                }
            });
        }
    }
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration.get());
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath.get());
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "Broadcast SONG_PREPARED: duration=" + mDuration.get() + 
              ", session=" + mAudioSessionId);
    }
    
    /**
     * Checks if the player has been released and throws if so.
     *
     * @throws IllegalStateException if the player is in RELEASED state
     */
    private void checkNotReleased() {
        if (mState.get() == State.RELEASED) {
            throw new IllegalStateException("SoundTouchPlayer has been released");
        }
    }
}