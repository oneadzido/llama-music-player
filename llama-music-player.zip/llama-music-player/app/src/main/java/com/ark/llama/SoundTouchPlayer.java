package com.ark.llama;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This class provides a complete audio playback solution using the SoundTouch
 * native library for real-time pitch shifting and tempo adjustment. It handles
 * decoding various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV) and streams
 * the processed PCM data through Android's AudioTrack.</p>
 * 
 * <p>This implementation is inspired by VLC's audiotrack module, using a single
 * playback thread with a circular buffer for proper backpressure. This prevents
 * the "brief sound then stops" issue by ensuring the decoder blocks when the
 * AudioTrack buffer is full.</p>
 * 
 * <h3>Architecture (VLC-Inspired)</h3>
 * <pre>
 *                                    ┌────────────────────────────────────────────┐
 *                                    │                                              SoundTouchPlayer                                               │
 *                                    │                                                                                                                           │
 *  loadSong()  ────►│  ┌─────────┐           ┌──────────┐            ┌─────────┐   │
 *  play()          ────►│  │      Decoder     ├───►│       Circular       ├───►│  AudioTrack    │   │
 *  pause()       ────►│  │      Thread       │           │        Buffer         │            │  Thread           │   │
 *  seekTo()      ────►│  └─────────┘          └──────────┘            └─────────┘   │
 *                                    │              │                                         │                                       │                     │
 *                                    │             ▼                                        ▼                                      ▼                    │
 *                                    │     MediaCodec                       Backpressure                   AudioTrack              │
 *                                    │     (NDK/Java)                          (blocking)                          (write)                 │
 *                                    └────────────────────────────────────────────┘
 * </pre>
 * 
 * <h3>Circular Buffer Pattern (VLC)</h3>
 * <p>The circular buffer decouples the decoder from the AudioTrack, allowing
 * each to operate at their own pace. When the buffer is full, the decoder
 * blocks (backpressure), preventing overruns. When the buffer is empty,
 * the AudioTrack thread blocks, preventing underruns.</p>
 * 
 * <h3>State Machine</h3>
 * <pre>
 * IDLE ─► PREPARING ─► READY ─► PLAYING ⇄ PAUSED ─► COMPLETED
 *                      ▼                                        ▼                                        ▼
 *                   ERROR                                                                          RELEASED (terminal)
 * </pre>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Independent pitch control from -6 to +6 semitones</li>
 *   <li>Independent tempo control from 0.5x to 1.5x speed</li>
 *   <li>Real-time processing with low latency</li>
 *   <li>Accurate position tracking using AudioTrack playback head</li>
 *   <li>Supports both mono and stereo audio</li>
 *   <li>16-bit integer sample processing for Android compatibility</li>
 *   <li>Circular buffer with backpressure for smooth playback</li>
 *   <li>Proper format validation from actual decoder output</li>
 *   <li>Thread-safe with condition variables (no busy waiting)</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * SoundTouchPlayer player = new SoundTouchPlayer(context);
 * player.setListener(new PlaybackListener() {
 *     public void onPrepared() {
 *         // Duration and audio session available
 *         int duration = (int) player.getDuration();
 *         int sessionId = player.getAudioSessionId();
 *         player.play();
 *     }
 *     
 *     public void onCompletion() {
 *         // Play next song
 *     }
 *     
 *     public void onError(String error) {
 *         // Handle error - fallback to MediaPlayer
 *     }
 * });
 * 
 * if (player.loadSong("/sdcard/Music/song.mp3")) {
 *     player.play();
 * }
 * 
 * player.setPitch(2.5f);   // +2.5 semitones
 * player.setTempo(1.25f);  // 25% faster
 * player.seekTo(30000);    // Seek to 30 seconds
 * player.pause();
 * player.resume();
 * player.release();
 * </pre>
 * 
 * @see AudioDecoder
 * @see PitchShifter
 * @see AudioTrack
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";
    
    /** Broadcast action for song prepared event. */
    private static final String ACTION_SONG_PREPARED = "SONG_PREPARED";
    
    /** Extra key for song duration in milliseconds. */
    private static final String EXTRA_DURATION = "duration";
    
    /** Extra key for audio session ID. */
    private static final String EXTRA_AUDIO_SESSION_ID = "audio_session_id";
    
    /** Extra key for song file path. */
    private static final String EXTRA_SONG_PATH = "song_path";
    
    /** Number of frames to process per iteration (4096 frames ~93ms at 44.1kHz). */
    private static final int BUFFER_FRAMES = 4096;
    
    /** Size of circular buffer in bytes (256KB). */
    private static final int CIRCULAR_BUFFER_SIZE = 256 * 1024;
    
    /** Minimum buffer duration in milliseconds for AudioTrack (prevents underruns). */
    private static final int MIN_BUFFER_MS = 250;
    
    /** Position update interval in milliseconds for UI callbacks. */
    private static final int POSITION_UPDATE_INTERVAL_MS = 100;
    
    /** Maximum time to wait for decoder to produce output (5 seconds). */
    private static final int MAX_DECODER_WAIT_MS = 5000;
    
    /** Delay in milliseconds before retrying decoder read (5ms). */
    private static final int DECODER_RETRY_DELAY_MS = 5;
    
    // ========================================================================
    // State Machine
    // ========================================================================
    
    /**
     * Player states for the state machine.
     * 
     * <p>State transitions are synchronized on mStateLock to ensure
     * thread-safe state changes.</p>
     */
    public enum State {
        /** Initial state, no resources allocated. */
        IDLE,
        
        /** Decoder is being created and format is being validated. */
        PREPARING,
        
        /** Player is ready to play (AudioTrack created, format validated). */
        READY,
        
        /** Actively playing audio. */
        PLAYING,
        
        /** Playback paused, position preserved. */
        PAUSED,
        
        /** End of stream reached naturally. */
        COMPLETED,
        
        /** Error occurred, needs recovery or release. */
        ERROR,
        
        /** Resources released, terminal state. */
        RELEASED
    }
    
    // ========================================================================
    // Playback Listener Interface
    // ========================================================================
    
    /**
     * Playback listener interface for receiving player events.
     * 
     * <p>All callbacks are invoked on the main UI thread, making them safe
     * for updating UI components like SeekBar and TextViews.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player state changes.
         * 
         * <p>Use this to update UI elements based on playback state
         * (e.g., enable/disable play/pause buttons).</p>
         *
         * @param newState The new state
         * @param oldState The previous state (can be null for initial transition)
         */
        void onStateChanged(@NonNull State newState, @Nullable State oldState);
        
        /**
         * Called when the player has finished loading a song and is ready to play.
         * 
         * <p>At this point, the audio session ID is available via {@link #getAudioSessionId()}
         * and the duration is available via {@link #getDuration()}. This is the
         * appropriate time to attach an equalizer and update the UI with the
         * total track duration.</p>
         */
        void onPrepared();
        
        /**
         * Called when the current song completes playback naturally.
         * 
         * <p>This occurs when the end of the audio stream is reached.
         * The player will transition to COMPLETED state. Typically, you would
         * call {@link #playNext()} on MusicService in response.</p>
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * <p>This method is called approximately every 100ms to allow UI
         * components (like SeekBar) to update smoothly. The position is
         * derived from AudioTrack.getPlaybackHeadPosition() for accuracy.</p>
         *
         * @param positionMs Current position in milliseconds
         */
        void onPositionUpdate(long positionMs);
        
        /**
         * Called when an error occurs during playback.
         * 
         * <p>After this callback, the player enters ERROR state and should
         * be either recovered (by reloading the song) or released. The
         * MusicService typically falls back to MediaPlayer when this occurs.</p>
         *
         * @param error Human-readable error message for logging/debugging
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Circular Buffer (VLC Pattern)
    // ========================================================================
    
    /**
     * Circular buffer for decoupling decoder from AudioTrack.
     * 
     * <p>This is the core of VLC's audio output architecture. The circular buffer
     * provides backpressure: the decoder blocks when the buffer is full, and the
     * AudioTrack thread blocks when the buffer is empty. This prevents both
     * underruns and overruns.</p>
     * 
     * <p>The buffer uses wait/notify for efficient blocking, avoiding busy-waiting
     * loops that waste CPU and battery.</p>
     */
    private static class CircularBuffer {
        /** Internal byte array storage. */
        private final byte[] mBuffer;
        
        /** Write position (producer index). */
        private int mWritePos = 0;
        
        /** Read position (consumer index). */
        private int mReadPos = 0;
        
        /** Total bytes currently in buffer. */
        private int mAvailable = 0;
        
        /** Lock for thread synchronization. */
        private final Object mLock = new Object();
        
        /** Flag indicating end of stream (no more data will be written). */
        private boolean mEndOfStream = false;
        
        /**
         * Creates a circular buffer with the specified size.
         *
         * @param size Size of the buffer in bytes
         */
        CircularBuffer(int size) {
            mBuffer = new byte[size];
        }
        
        /**
         * Writes data to the circular buffer.
         * 
         * <p>If the buffer doesn't have enough space, the calling thread blocks
         * until space becomes available. This provides backpressure to the
         * decoder, preventing it from outrunning the AudioTrack.</p>
         *
         * @param data The data to write
         * @param offset Offset in the data array
         * @param length Number of bytes to write
         * @return Number of bytes actually written (always equals length on success)
         * @throws InterruptedException if the thread is interrupted while waiting
         */
        int write(byte[] data, int offset, int length) throws InterruptedException {
            synchronized (mLock) {
                int remaining = length;
                int written = 0;
                
                while (written < length) {
                    // Calculate available space
                    int availableSpace = mBuffer.length - mAvailable;
                    
                    if (availableSpace == 0) {
                        // Buffer full - wait for consumer to read
                        mLock.wait();
                        continue;
                    }
                    
                    // Write as much as fits
                    int bytesToWrite = Math.min(remaining, availableSpace);
                    int firstChunk = Math.min(bytesToWrite, mBuffer.length - mWritePos);
                    
                    System.arraycopy(data, offset + written, mBuffer, mWritePos, firstChunk);
                    mWritePos = (mWritePos + firstChunk) % mBuffer.length;
                    mAvailable += firstChunk;
                    written += firstChunk;
                    remaining -= firstChunk;
                    
                    // Write second chunk if we wrapped around
                    if (remaining > 0 && bytesToWrite > firstChunk) {
                        int secondChunk = bytesToWrite - firstChunk;
                        System.arraycopy(data, offset + written, mBuffer, 0, secondChunk);
                        mWritePos = secondChunk;
                        mAvailable += secondChunk;
                        written += secondChunk;
                        remaining -= secondChunk;
                    }
                    
                    // Notify consumer that data is available
                    mLock.notifyAll();
                }
                
                return written;
            }
        }
        
        /**
         * Reads data from the circular buffer.
         * 
         * <p>If the buffer is empty, the calling thread blocks until data
         * becomes available or end-of-stream is signaled.</p>
         *
         * @param output Buffer to read into
         * @param maxBytes Maximum number of bytes to read
         * @return Number of bytes actually read, or -1 if end-of-stream reached
         * @throws InterruptedException if the thread is interrupted while waiting
         */
        int read(byte[] output, int maxBytes) throws InterruptedException {
            synchronized (mLock) {
                while (mAvailable == 0 && !mEndOfStream) {
                    // Buffer empty - wait for producer
                    mLock.wait();
                }
                
                if (mAvailable == 0 && mEndOfStream) {
                    return -1; // End of stream
                }
                
                int bytesToRead = Math.min(maxBytes, mAvailable);
                int firstChunk = Math.min(bytesToRead, mBuffer.length - mReadPos);
                
                System.arraycopy(mBuffer, mReadPos, output, 0, firstChunk);
                mReadPos = (mReadPos + firstChunk) % mBuffer.length;
                mAvailable -= firstChunk;
                
                int bytesRead = firstChunk;
                
                // Read second chunk if we wrapped around
                if (bytesToRead > firstChunk) {
                    int secondChunk = bytesToRead - firstChunk;
                    System.arraycopy(mBuffer, 0, output, firstChunk, secondChunk);
                    mReadPos = secondChunk;
                    mAvailable -= secondChunk;
                    bytesRead += secondChunk;
                }
                
                // Notify producer that space is available
                mLock.notifyAll();
                return bytesRead;
            }
        }
        
        /**
         * Signals that no more data will be written to the buffer.
         * 
         * <p>This unblocks the consumer thread so it can exit when the buffer
         * becomes empty.</p>
         */
        void signalEndOfStream() {
            synchronized (mLock) {
                mEndOfStream = true;
                mLock.notifyAll();
            }
        }
        
        /**
         * Clears all data from the buffer.
         * 
         * <p>This is called during seek operations to remove stale data.</p>
         */
        void clear() {
            synchronized (mLock) {
                mWritePos = 0;
                mReadPos = 0;
                mAvailable = 0;
                mEndOfStream = false;
                mLock.notifyAll();
            }
        }
        
        /**
         * Returns the number of bytes currently available in the buffer.
         *
         * @return Available bytes
         */
        int available() {
            synchronized (mLock) {
                return mAvailable;
            }
        }
    }
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Application context for sending broadcasts. */
    @NonNull
    private final Context mContext;
    
    /** Playback event listener (UI thread callbacks). */
    @Nullable
    private PlaybackListener mListener;
    
    /** Current player state (accessed with mStateLock). */
    @NonNull
    private State mState = State.IDLE;
    
    /** Lock for thread-safe state changes. */
    private final Object mStateLock = new Object();
    
    /** Audio decoder for extracting and decoding audio. */
    @Nullable
    private AudioDecoder mDecoder;
    
    /** Native pitch shifter for tempo and pitch processing. */
    @Nullable
    private PitchShifter mPitchShifter;
    
    /** AudioTrack for PCM output. */
    @Nullable
    private AudioTrack mAudioTrack;
    
    /** Circular buffer for decoder ─► AudioTrack communication (VLC pattern). */
    @Nullable
    private CircularBuffer mCircularBuffer;
    
    /** Actual sample rate from decoder output (not container). */
    private int mSampleRate = 44100;
    
    /** Actual channel count from decoder output (not container). */
    private int mChannels = 2;
    
    /** Frame size in bytes (channels * 2 for 16-bit PCM). */
    private int mFrameSize = 4;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    /** Duration of current song in milliseconds. */
    private long mDuration = 0;
    
    /** Path of currently loaded song. */
    @Nullable
    private String mCurrentFilePath = null;
    
    /** Flag indicating format has been validated from decoder output. */
    private boolean mFormatValidated = false;
    
    /** Flag indicating playback is active. */
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    
    /** Flag indicating playback is paused. */
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    
    /** Flag indicating end of stream reached. */
    private final AtomicBoolean mIsEOS = new AtomicBoolean(false);
    
    /** Current playback position in milliseconds (cached). */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Pending seek position (-1 if no seek pending). */
    private int mPendingSeekPosition = -1;
    
    /** Current pitch setting in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Flag indicating the audio thread should continue running. */
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    /** Background audio thread (single thread - VLC pattern). */
    @Nullable
    private Thread mAudioThread;
    
    /** Lock for producer-consumer synchronization (used by decoder thread). */
    private final Object mBufferLock = new Object();
    
    /** Handler for UI thread callbacks. */
    private final Handler mUiHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>The player starts in IDLE state. Resources are allocated lazily
     * when {@link #loadSong(String)} is called.</p>
     *
     * @param context Application context for sending broadcasts and accessing resources
     * @throws IllegalArgumentException if context is null
     */
    public SoundTouchPlayer(@NonNull Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context cannot be null");
        }
        mContext = context.getApplicationContext();
        Log.d(TAG, "SoundTouchPlayer created, initial state: IDLE");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * <p>The listener will receive callbacks for state changes, completion,
     * position updates, and errors. All callbacks are delivered on the main
     * UI thread, making them safe for updating UI components.</p>
     *
     * @param listener The listener to receive events (can be null to remove)
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Loads a song and prepares it for playback.
     * 
     * <p>This method blocks until the decoder is opened and format is validated.
     * After successful load, the player enters READY state and the duration
     * and audio session ID are available.</p>
     * 
     * <p>State transition: IDLE/PREPARING/ERROR -> PREPARING -> READY</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @return true if loading was successful and player is ready, false otherwise
     */
    public boolean loadSong(@NonNull String filePath) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.e(TAG, "loadSong: Player already released");
                return false;
            }
            if (mState == State.PREPARING) {
                Log.w(TAG, "loadSong: Already preparing, waiting...");
            }
            mState = State.PREPARING;
        }
        
        mCurrentFilePath = filePath;
        
        try {
            // Step 1: Create and open decoder
            mDecoder = new AudioDecoder();
            if (!mDecoder.open(filePath)) {
                Log.e(TAG, "loadSong: Failed to open decoder for " + filePath);
                transitionToError("Failed to open audio file");
                return false;
            }
            
            // Step 2: Get format from decoder (actual output, not container)
            mSampleRate = mDecoder.getSampleRate();
            mChannels = mDecoder.getChannels();
            mDuration = mDecoder.getDuration();
            mFrameSize = mChannels * 2;
            
            Log.d(TAG, "loadSong: Format=" + mSampleRate + "Hz, " + mChannels + 
                  "ch, duration=" + mDuration + "ms");
            
            // Validate format
            if (mSampleRate <= 0 || mSampleRate > 192000) {
                Log.e(TAG, "loadSong: Invalid sample rate: " + mSampleRate);
                transitionToError("Invalid sample rate");
                return false;
            }
            
            if (mChannels < 1 || mChannels > 2) {
                Log.e(TAG, "loadSong: Invalid channel count: " + mChannels);
                transitionToError("Invalid channel count");
                return false;
            }
            
            // Step 3: Initialize PitchShifter if available
            if (PitchShifter.isLibraryAvailable()) {
                mPitchShifter = new PitchShifter(mSampleRate, mChannels);
                mPitchShifter.setPitch(mCurrentPitch);
                mPitchShifter.setTempo(mCurrentTempo);
                Log.d(TAG, "loadSong: PitchShifter initialized");
            } else {
                Log.w(TAG, "loadSong: PitchShifter not available, playing without effects");
            }
            
            // Step 4: Create AudioTrack
            createAudioTrack();
            
            if (mAudioTrack == null) {
                Log.e(TAG, "loadSong: Failed to create AudioTrack");
                transitionToError("AudioTrack creation failed");
                return false;
            }
            
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "loadSong: AudioTrack not initialized, state=" + mAudioTrack.getState());
                transitionToError("AudioTrack not initialized");
                return false;
            }
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            mFormatValidated = true;
            
            // Step 5: Create circular buffer (VLC pattern)
            mCircularBuffer = new CircularBuffer(CIRCULAR_BUFFER_SIZE);
            
            // Step 6: Broadcast that song is prepared (for UI and equalizer)
            broadcastSongPrepared();
            
            // Step 7: Transition to READY and notify listener
            synchronized (mStateLock) {
                mState = State.READY;
            }
            
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onPrepared());
                mUiHandler.post(() -> listener.onStateChanged(State.READY, State.PREPARING));
            }
            
            Log.d(TAG, "loadSong: Success, player ready");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "loadSong: Exception", e);
            transitionToError(e.getMessage());
            return false;
        }
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>If the player is in READY state, playback begins from the start.
     * If the player is in PAUSED state, playback resumes from the current position.
     * If the player is in COMPLETED state, playback restarts from the beginning.</p>
     * 
     * <p>State transitions:</p>
     * <ul>
     *   <li>READY -> PLAYING</li>
     *   <li>PAUSED -> PLAYING</li>
     *   <li>COMPLETED -> PLAYING (after seeking to 0)</li>
     * </ul>
     */
    public void play() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                Log.w(TAG, "play: Player released");
                return;
            }
            
            if (!mFormatValidated) {
                Log.w(TAG, "play: Format not validated yet");
                return;
            }
            
            Log.d(TAG, "play: Called in state " + mState);
            
            if (mState == State.READY) {
                startAudioThread();
            } else if (mState == State.PAUSED) {
                resumePlayback();
            } else if (mState == State.COMPLETED) {
                seekTo(0);
                startAudioThread();
            }
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>The current position is preserved and playback can be resumed
     * by calling {@link #play()}.</p>
     * 
     * <p>State transition: PLAYING -> PAUSED</p>
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState == State.PLAYING) {
                mIsPaused.set(true);
                mIsPlaying.set(false);
                mState = State.PAUSED;
                
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.pause();
                        Log.d(TAG, "pause: AudioTrack paused");
                    } catch (Exception e) {
                        Log.e(TAG, "pause: Failed to pause AudioTrack", e);
                    }
                }
                
                PlaybackListener listener = mListener;
                if (listener != null) {
                    mUiHandler.post(() -> listener.onStateChanged(State.PAUSED, State.PLAYING));
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player position to the beginning.
     * 
     * <p>After calling stop, the player remains in READY state and can be
     * restarted by calling {@link #play()}.</p>
     * 
     * <p>State transition: PLAYING/PAUSED -> READY</p>
     */
    public void stop() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            stopAudioThread();
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.pause();
                    mAudioTrack.flush();
                } catch (Exception e) {
                    Log.e(TAG, "stop: Failed to flush AudioTrack", e);
                }
            }
            
            if (mDecoder != null) {
                mDecoder.seekTo(0);
            }
            
            if (mCircularBuffer != null) {
                mCircularBuffer.clear();
            }
            
            if (mPitchShifter != null) {
                mPitchShifter.clear();
            }
            
            mIsPlaying.set(false);
            mIsPaused.set(false);
            mIsEOS.set(false);
            mCurrentPosition.set(0);
            mState = State.READY;
            
            Log.d(TAG, "stop: Player reset to READY");
        }
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>The seek operation flushes both the decoder and AudioTrack to ensure
     * proper synchronization after the seek. The circular buffer is also cleared
     * to remove stale data.</p>
     * 
     * <p>Valid in states: READY, PLAYING, PAUSED, COMPLETED</p>
     *
     * @param positionMs Position in milliseconds to seek to (0 = beginning)
     */
    public void seekTo(int positionMs) {
        synchronized (mStateLock) {
            if (mState == State.RELEASED || !mFormatValidated) {
                return;
            }
            
            long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
            mPendingSeekPosition = (int) clampedPosition;
            mCurrentPosition.set(clampedPosition);
            
            Log.d(TAG, "seekTo: Pending seek to " + clampedPosition + "ms");
            
            // Wake up threads to process seek immediately
            if (mCircularBuffer != null) {
                synchronized (mBufferLock) {
                    mBufferLock.notifyAll();
                }
            }
        }
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Positive values raise the pitch, negative values lower it.
     * The effective range is approximately -6 to +6 semitones, though
     * values outside this range may produce distortion.</p>
     * 
     * <p>The change takes effect on the next audio frame processed.</p>
     *
     * @param semitones The pitch shift amount in semitones (recommended: -6 to +6)
     */
    public void setPitch(float semitones) {
        mCurrentPitch = semitones;
        if (mPitchShifter != null) {
            mPitchShifter.setPitch(semitones);
            Log.d(TAG, "setPitch: " + semitones + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Values less than 1.0 slow down the audio, values greater than 1.0
     * speed it up. The effective range is approximately 0.5 to 1.5, though
     * values outside this range may produce artifacts.</p>
     * 
     * <p>The change takes effect on the next audio frame processed.</p>
     *
     * @param tempo The tempo multiplier (recommended: 0.5 to 1.5)
     */
    public void setTempo(float tempo) {
        mCurrentTempo = tempo;
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(tempo);
            Log.d(TAG, "setTempo: " + tempo + "x");
        }
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>Uses AudioTrack playback head position for accuracy when available,
     * falling back to the internally tracked position.</p>
     *
     * @return Current position in milliseconds, or 0 if not available
     */
    public long getCurrentPosition() {
        // Use AudioTrack head position for accuracy when playing
        if (mState == State.PLAYING && mAudioTrack != null) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    return positionMs;
                }
            } catch (Exception e) {
                // Fall through to cached position
            }
        }
        return mCurrentPosition.get();
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get();
    }
    
    /**
     * Checks if a song is loaded and the player is ready for playback.
     *
     * @return true if prepared (READY, PLAYING, or PAUSED state), false otherwise
     */
    public boolean isPrepared() {
        synchronized (mStateLock) {
            return mState == State.READY || mState == State.PLAYING || mState == State.PAUSED;
        }
    }
    
    /**
     * Returns the audio session ID for equalizer attachment.
     * 
     * <p>The session ID is valid after the player enters the READY state
     * (i.e., after {@link PlaybackListener#onPrepared()} is called).</p>
     *
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Returns the current player state.
     *
     * @return The current State enum value
     */
    @NonNull
    public State getState() {
        synchronized (mStateLock) {
            return mState;
        }
    }
    
    /**
     * Pre-loads a song without starting playback.
     * 
     * <p>This is an alias for {@link #loadSong(String)} for compatibility
     * with MusicService's preLoad method.</p>
     *
     * @param filePath Absolute path to the audio file
     * @return true if pre-load was successful
     */
    public boolean preLoad(@NonNull String filePath) {
        return loadSong(filePath);
    }
    
    /**
     * Resumes playback after pause.
     * 
     * <p>This is an alias for {@link #play()} for compatibility.</p>
     */
    public void resume() {
        play();
    }
    
    /**
     * Releases all resources held by the player.
     * 
     * <p>This method must be called when the player is no longer needed
     * to prevent memory leaks. The player cannot be used after release.</p>
     * 
     * <p>State transition: Any state -> RELEASED (terminal)</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState == State.RELEASED) {
                return;
            }
            
            Log.d(TAG, "release: Releasing resources");
            
            stopAudioThread();
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.stop();
                    mAudioTrack.release();
                } catch (Exception e) {
                    Log.e(TAG, "release: Error releasing AudioTrack", e);
                }
                mAudioTrack = null;
            }
            
            if (mPitchShifter != null) {
                mPitchShifter.close();
                mPitchShifter = null;
            }
            
            if (mDecoder != null) {
                mDecoder.release();
                mDecoder = null;
            }
            
            mCircularBuffer = null;
            mState = State.RELEASED;
            Log.d(TAG, "release: Complete");
        }
    }
    
    // ========================================================================
    // Private Methods - AudioTrack Creation
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack with the validated format.
     * 
     * <p>This method follows Android best practices for AudioTrack creation:
     * <ul>
     *   <li>Uses AudioAttributes.Builder for usage and content type</li>
     *   <li>Uses AudioFormat.Builder for format specification</li>
     *   <li>Calculates appropriate buffer size based on sample rate</li>
     *   <li>Verifies initialization state after creation</li>
     * </ul>
     * </p>
     */
    private void createAudioTrack() {
        // Release existing AudioTrack if any
        if (mAudioTrack != null) {
            try {
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "createAudioTrack: Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        // Determine channel configuration
        int channelConfig;
        if (mChannels == 2) {
            channelConfig = AudioFormat.CHANNEL_OUT_STEREO;
        } else {
            channelConfig = AudioFormat.CHANNEL_OUT_MONO;
        }
        
        // Calculate minimum buffer size
        int minBufferSize = AudioTrack.getMinBufferSize(
            mSampleRate,
            channelConfig,
            AudioFormat.ENCODING_PCM_16BIT
        );
        
        if (minBufferSize <= 0) {
            Log.e(TAG, "createAudioTrack: Invalid minBufferSize=" + minBufferSize);
            return;
        }
        
        // Target buffer for MIN_BUFFER_MS of audio
        int targetBufferFrames = mSampleRate * MIN_BUFFER_MS / 1000;
        int targetBufferSize = targetBufferFrames * mFrameSize;
        int bufferSize = Math.max(minBufferSize, targetBufferSize);
        
        Log.d(TAG, "createAudioTrack: bufferSize=" + bufferSize + ", minBuffer=" + minBufferSize);
        
        // Build AudioAttributes
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
        
        // Build AudioFormat
        AudioFormat audioFormat = new AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(mSampleRate)
            .setChannelMask(channelConfig)
            .build();
        
        // Create AudioTrack
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mAudioTrack = new AudioTrack.Builder()
                    .setAudioAttributes(audioAttributes)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            } else {
                //noinspection deprecation
                mAudioTrack = new AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    mSampleRate,
                    channelConfig,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize,
                    AudioTrack.MODE_STREAM
                );
            }
            
            Log.d(TAG, "createAudioTrack: AudioTrack created, state=" + 
                  (mAudioTrack != null ? mAudioTrack.getState() : "null"));
                  
        } catch (Exception e) {
            Log.e(TAG, "createAudioTrack: Exception", e);
            mAudioTrack = null;
        }
    }
    
    // ========================================================================
    // Private Methods - Audio Thread Management (VLC Pattern)
    // ========================================================================
    
    /**
     * Starts the audio thread (single thread - VLC pattern).
     * 
     * <p>This thread handles both filling the circular buffer (decoder) and
     * draining it (AudioTrack write). The circular buffer provides backpressure,
     * preventing the decoder from outrunning the AudioTrack.</p>
     */
    private void startAudioThread() {
        if (mAudioThread != null && mAudioThread.isAlive()) {
            // Thread already running, just update state
            synchronized (mStateLock) {
                mIsPlaying.set(true);
                mIsPaused.set(false);
                mState = State.PLAYING;
                
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.play();
                    } catch (Exception e) {
                        Log.e(TAG, "startAudioThread: Failed to play AudioTrack", e);
                    }
                }
            }
            return;
        }
        
        mRunning.set(true);
        mIsPlaying.set(true);
        mIsPaused.set(false);
        mIsEOS.set(false);
        
        synchronized (mStateLock) {
            mState = State.PLAYING;
        }
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.play();
            } catch (Exception e) {
                Log.e(TAG, "startAudioThread: Failed to start AudioTrack", e);
            }
        }
        
        mAudioThread = new Thread(this::audioLoop, "SoundTouch-Audio");
        mAudioThread.start();
        
        Log.d(TAG, "startAudioThread: Audio thread started");
    }
    
    /**
     * Stops the audio thread.
     */
    private void stopAudioThread() {
        mRunning.set(false);
        
        // Wake up the thread if it's waiting
        if (mCircularBuffer != null) {
            synchronized (mBufferLock) {
                mBufferLock.notifyAll();
            }
        }
        
        if (mAudioThread != null) {
            try {
                mAudioThread.interrupt();
                mAudioThread.join(1000);
            } catch (InterruptedException e) {
                Log.w(TAG, "stopAudioThread: Interrupted", e);
                Thread.currentThread().interrupt();
            }
            mAudioThread = null;
        }
    }
    
    /**
     * Resumes playback from paused state.
     */
    private void resumePlayback() {
        synchronized (mStateLock) {
            if (mState != State.PAUSED) {
                return;
            }
            
            mIsPaused.set(false);
            mIsPlaying.set(true);
            mState = State.PLAYING;
            
            if (mAudioTrack != null) {
                try {
                    mAudioTrack.play();
                    Log.d(TAG, "resumePlayback: AudioTrack resumed");
                } catch (Exception e) {
                    Log.e(TAG, "resumePlayback: Failed to resume", e);
                }
            }
            
            PlaybackListener listener = mListener;
            if (listener != null) {
                mUiHandler.post(() -> listener.onStateChanged(State.PLAYING, State.PAUSED));
            }
        }
    }
    
    // ========================================================================
    // Private Methods - Main Audio Loop (VLC Pattern)
    // ========================================================================
    
    /**
     * Main audio loop that runs on a background thread.
     * 
     * <p>This single thread handles both filling the circular buffer (decoder)
     * and draining it (AudioTrack write). The circular buffer provides
     * backpressure - the decoder blocks when the buffer is full, and the
     * AudioTrack blocks when the buffer is empty.</p>
     * 
     * <p>This is the VLC pattern that prevents the "brief sound then stops"
     * issue by ensuring smooth flow of data through the pipeline.</p>
     */
    private void audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        
        short[] pcmBuffer = new short[BUFFER_FRAMES * mChannels];
        short[] processedBuffer = new short[BUFFER_FRAMES * mChannels];
        byte[] byteBuffer = new byte[BUFFER_FRAMES * mFrameSize];
        long lastPositionUpdate = 0;
        long decoderWaitStart = 0;
        boolean decoderFinished = false;
        
        Log.d(TAG, "audioLoop: Started (VLC circular buffer pattern)");
        
        while (mRunning.get()) {
            try {
                // Check if we're paused
                if (mIsPaused.get()) {
                    Thread.sleep(DECODER_RETRY_DELAY_MS);
                    continue;
                }
                
                // Check for pending seek
                if (mPendingSeekPosition >= 0) {
                    performSeek(mPendingSeekPosition);
                    mPendingSeekPosition = -1;
                    decoderFinished = false;
                    decoderWaitStart = 0;
                }
                
                // Step 1: Fill circular buffer from decoder (if not finished)
                if (!decoderFinished && mDecoder != null && !mDecoder.isEOS()) {
                    int framesRead = mDecoder.read(pcmBuffer, BUFFER_FRAMES);
                    
                    if (framesRead < 0) {
                        Log.e(TAG, "audioLoop: Decoder read error");
                        transitionToError("Decoder read error");
                        break;
                    }
                    
                    if (framesRead == 0) {
                        // No data available yet
                        if (decoderWaitStart == 0) {
                            decoderWaitStart = System.currentTimeMillis();
                        } else if (System.currentTimeMillis() - decoderWaitStart > MAX_DECODER_WAIT_MS) {
                            Log.e(TAG, "audioLoop: Decoder timeout");
                            transitionToError("Decoder timeout");
                            break;
                        }
                        Thread.sleep(DECODER_RETRY_DELAY_MS);
                        continue;
                    }
                    
                    // Reset decoder wait timer on successful read
                    decoderWaitStart = 0;
                    
                    // Process through SoundTouch
                    short[] samplesToWrite = pcmBuffer;
                    int sampleCount = framesRead * mChannels;
                    
                    if (mPitchShifter != null && mPitchShifter.isInitialized()) {
                        mPitchShifter.putFrames(pcmBuffer, framesRead);
                        
                        int available = mPitchShifter.numFrames();
                        if (available > 0) {
                            int toRead = Math.min(available, BUFFER_FRAMES);
                            int received = mPitchShifter.receiveFrames(processedBuffer, toRead);
                            if (received > 0) {
                                samplesToWrite = processedBuffer;
                                sampleCount = received * mChannels;
                            }
                        }
                    }
                    
                    // Convert shorts to bytes and write to circular buffer
                    if (sampleCount > 0 && mCircularBuffer != null) {
                        // Convert shorts to bytes (little-endian)
                        for (int i = 0; i < sampleCount; i++) {
                            byteBuffer[i * 2] = (byte) (samplesToWrite[i] & 0xFF);
                            byteBuffer[i * 2 + 1] = (byte) ((samplesToWrite[i] >> 8) & 0xFF);
                        }
                        
                        // Write to circular buffer (blocks if full - backpressure!)
                        mCircularBuffer.write(byteBuffer, 0, sampleCount * 2);
                    }
                    
                } else if (!decoderFinished && mDecoder != null && mDecoder.isEOS()) {
                    // Decoder reached end of stream
                    Log.d(TAG, "audioLoop: Decoder EOS reached");
                    decoderFinished = true;
                    if (mCircularBuffer != null) {
                        mCircularBuffer.signalEndOfStream();
                    }
                }
                
                // Step 2: Drain circular buffer to AudioTrack
                if (mCircularBuffer != null && mAudioTrack != null && 
                    mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    
                    // Ensure AudioTrack is playing
                    if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING && !mIsPaused.get()) {
                        try {
                            mAudioTrack.play();
                        } catch (Exception e) {
                            Log.e(TAG, "audioLoop: Failed to start AudioTrack", e);
                        }
                    }
                    
                    // Read from circular buffer (blocks if empty)
                    int bytesAvailable = mCircularBuffer.available();
                    if (bytesAvailable > 0) {
                        int bytesToRead = Math.min(bytesAvailable, byteBuffer.length);
                        int bytesRead = mCircularBuffer.read(byteBuffer, bytesToRead);
                        
                        if (bytesRead > 0) {
                            int written = mAudioTrack.write(byteBuffer, 0, bytesRead);
                            
                            if (written < 0) {
                                Log.e(TAG, "audioLoop: AudioTrack.write error: " + written);
                                if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                                    Log.w(TAG, "audioLoop: AudioTrack is dead, recreating");
                                    recreateAudioTrack();
                                }
                            }
                        }
                    } else if (decoderFinished && mCircularBuffer.available() == 0) {
                        // No more data and decoder finished - completion!
                        handleCompletion();
                        break;
                    }
                }
                
                // Update position tracking and notify listeners
                updateCurrentPosition();
                
                long now = System.currentTimeMillis();
                if (now - lastPositionUpdate > POSITION_UPDATE_INTERVAL_MS) {
                    PlaybackListener listener = mListener;
                    if (listener != null) {
                        final long position = getCurrentPosition();
                        mUiHandler.post(() -> listener.onPositionUpdate(position));
                    }
                    lastPositionUpdate = now;
                }
                
                // Small yield to prevent CPU spinning
                Thread.yield();
                
            } catch (InterruptedException e) {
                Log.d(TAG, "audioLoop: Interrupted");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "audioLoop: Exception", e);
                transitionToError(e.getMessage());
                break;
            }
        }
        
        Log.d(TAG, "audioLoop: Exited");
    }
    
    /**
     * Performs a seek operation.
     * 
     * <p>This method seeks the decoder, clears the circular buffer, and flushes
     * the AudioTrack to remove stale data.</p>
     *
     * @param positionMs Position to seek to in milliseconds
     */
    private void performSeek(int positionMs) {
        Log.d(TAG, "performSeek: Seeking to " + positionMs + "ms");
        
        if (mDecoder != null) {
            mDecoder.seekTo(positionMs);
            mIsEOS.set(false);
        }
        
        // Clear circular buffer (remove stale data)
        if (mCircularBuffer != null) {
            mCircularBuffer.clear();
        }
        
        // Flush and restart AudioTrack
        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                if (!mIsPaused.get()) {
                    mAudioTrack.play();
                }
            } catch (Exception e) {
                Log.e(TAG, "performSeek: Error flushing AudioTrack", e);
            }
        }
        
        // Clear PitchShifter to remove any buffered data
        if (mPitchShifter != null) {
            mPitchShifter.clear();
        }
        
        mCurrentPosition.set(positionMs);
    }
    
    /**
     * Updates the current playback position using AudioTrack head position.
     */
    private void updateCurrentPosition() {
        if (mAudioTrack != null && !mIsPaused.get() && mState == State.PLAYING) {
            try {
                long frames = mAudioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
                long positionMs = (frames * 1000) / mSampleRate;
                if (positionMs < mDuration) {
                    mCurrentPosition.set(positionMs);
                }
            } catch (Exception e) {
                // Use cached position
            }
        }
    }
    
    /**
     * Handles song completion.
     * 
     * <p>This method transitions the player to COMPLETED state and notifies
     * the listener.</p>
     */
    private void handleCompletion() {
        Log.d(TAG, "handleCompletion: Song finished");
        
        mIsPlaying.set(false);
        mIsEOS.set(true);
        
        synchronized (mStateLock) {
            mState = State.COMPLETED;
        }
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onCompletion());
            mUiHandler.post(() -> listener.onStateChanged(State.COMPLETED, State.PLAYING));
        }
        
        mRunning.set(false);
    }
    
    /**
     * Recreates the AudioTrack when it enters a bad state.
     * 
     * <p>This is called when AudioTrack.write returns ERROR_DEAD_OBJECT (-6),
     * indicating the object is no longer valid and needs to be recreated.</p>
     */
    private void recreateAudioTrack() {
        Log.w(TAG, "recreateAudioTrack: Recreating AudioTrack");
        
        boolean wasPlaying = mIsPlaying.get() && !mIsPaused.get();
        
        if (mAudioTrack != null) {
            try {
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "recreateAudioTrack: Error releasing", e);
            }
            mAudioTrack = null;
        }
        
        createAudioTrack();
        
        if (wasPlaying && mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
            try {
                mAudioTrack.play();
                Log.d(TAG, "recreateAudioTrack: Playback restored");
            } catch (Exception e) {
                Log.e(TAG, "recreateAudioTrack: Failed to restore", e);
            }
        }
    }
    
    // ========================================================================
    // Private Methods - State Management
    // ========================================================================
    
    /**
     * Transitions the player to ERROR state.
     * 
     * <p>This stops all playback, releases resources, and notifies the listener
     * of the error.</p>
     *
     * @param error The error message
     */
    private void transitionToError(String error) {
        synchronized (mStateLock) {
            if (mState == State.ERROR || mState == State.RELEASED) {
                return;
            }
            
            Log.e(TAG, "transitionToError: " + error);
            mState = State.ERROR;
        }
        
        mRunning.set(false);
        mIsPlaying.set(false);
        
        PlaybackListener listener = mListener;
        if (listener != null) {
            mUiHandler.post(() -> listener.onError(error));
            mUiHandler.post(() -> listener.onStateChanged(State.ERROR, null));
        }
    }
    
    // ========================================================================
    // Private Methods - Broadcast
    // ========================================================================
    
    /**
     * Broadcasts that the song is prepared (duration and session available).
     * 
     * <p>This broadcast is received by MusicPlayer to update UI elements
     * such as total time display and equalizer availability before playback
     * actually begins.</p>
     */
    private void broadcastSongPrepared() {
        Intent intent = new Intent(ACTION_SONG_PREPARED);
        intent.putExtra(EXTRA_DURATION, (int) mDuration);
        intent.putExtra(EXTRA_AUDIO_SESSION_ID, mAudioSessionId);
        intent.putExtra(EXTRA_SONG_PATH, mCurrentFilePath);
        mContext.sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongPrepared: duration=" + mDuration + "ms, session=" + mAudioSessionId);
    }
}