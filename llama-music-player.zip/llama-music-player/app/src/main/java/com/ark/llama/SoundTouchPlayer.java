package com.ark.llama;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SoundTouchPlayer - High-quality audio player with independent pitch and tempo control.
 * 
 * <p>This player completely replaces Android's MediaPlayer for audio playback when
 * pitch and tempo effects are needed. It uses the SoundTouch native library for
 * high-quality, independent pitch shifting and tempo adjustment.</p>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li><b>Independent Pitch Control</b> - Adjust pitch from -6 to +6 semitones
 *       without affecting playback speed</li>
 *   <li><b>Independent Tempo Control</b> - Adjust speed from 0.5x to 1.5x
 *       without affecting pitch</li>
 *   <li><b>Gapless Playback</b> - Smooth transitions between songs</li>
 *   <li><b>Seek Support</b> - Jump to any position in the song</li>
 *   <li><b>Real-time Updates</b> - Change pitch/tempo during playback</li>
 *   <li><b>Automatic Error Recovery</b> - Handles decoder errors gracefully</li>
 *   <li><b>Equalizer Integration</b> - Provides audio session ID for system equalizer</li>
 *   <li><b>Sample Rate Fallback</b> - Automatically uses supported sample rate</li>
 * </ul>
 * 
 * <h3>State Machine (Linear Flow)</h3>
 * <pre>
 * IDLE -> LOADING -> PREPARED -> PLAYING -> PAUSED -> PLAYING -> STOPPED -> RELEASED
 *                    |                                           |                                      |                                        ^
 *                    v                                          v                                     v                                        |
 *                ERROR ----------------•••---------------•••-----------------•••
 * </pre>
 * 
 * <p>State Transitions:</p>
 * <ul>
 *   <li><b>IDLE</b> - Initial state after construction. No song loaded.</li>
 *   <li><b>LOADING</b> - loadSong() called, setting up decoder and extractor.
 *       Resources are being initialized.</li>
 *   <li><b>PREPARED</b> - Loading complete, ready for playback. Can call play(),
 *       pause(), stop(), seekTo().</li>
 *   <li><b>PLAYING</b> - play() called, audio actively playing. Can call pause(),
 *       stop(), seekTo(), setPitch(), setTempo().</li>
 *   <li><b>PAUSED</b> - pause() called, position preserved. Can call resume() to
 *       continue playback, or stop() to reset.</li>
 *   <li><b>STOPPED</b> - stop() called or song completes naturally. Position
 *       reset to 0. Can call play() to start from beginning, or loadSong()
 *       to load a new song.</li>
 *   <li><b>RELEASED</b> - release() called, all resources freed. Player cannot
 *       be used again.</li>
 *   <li><b>ERROR</b> - Any unrecoverable error occurs. Player enters error state
 *       and must be released.</li>
 * </ul>
 * 
 * <h3>Architecture Overview</h3>
 * <p>The player follows a producer-consumer pattern with three thread-safe components:</p>
 * <ol>
 *   <li><b>Decoder Thread</b> - Reads compressed audio from MediaExtractor, decodes to PCM
 *       using MediaCodec, and queues decoded frames to a thread-safe buffer</li>
 *   <li><b>Processor Thread</b> - Takes decoded PCM frames, processes them through
 *       SoundTouch (pitch/tempo), and queues processed frames</li>
 *   <li><b>Audio Thread</b> - Writes processed PCM to AudioTrack for playback,
 *       handles seek operations, and maintains position tracking</li>
 * </ol>
 * 
 * <h3>Thread Safety</h3>
 * <p>All state changes are guarded by synchronization on mStateLock. The player uses
 * BlockingQueue for inter-thread communication and AtomicInteger for state that
 * is frequently read.</p>
 * 
 * <h3>Supported Formats</h3>
 * <p>Any format supported by Android's MediaCodec, including:</p>
 * <ul>
 *   <li>MP3 (audio/mpeg)</li>
 *   <li>AAC (audio/mp4a-latm)</li>
 *   <li>FLAC (audio/flac)</li>
 *   <li>OGG (audio/ogg)</li>
 *   <li>M4A (audio/mp4)</li>
 *   <li>WAV (audio/x-wav)</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Create player
 * SoundTouchPlayer player = new SoundTouchPlayer();
 * 
 * // Set listener
 * player.setListener(new SoundTouchPlayer.PlaybackListener() {
 *     public void onPrepared() { /* ready to play * / }
 *     public void onPlaybackStarted() { /* playing * / }
 *     public void onCompletion() { /* song finished * / }
 *     public void onError(String error) { /* handle error * / }
 * });
 * 
 * // Load and play
 * player.loadSong("/sdcard/Music/song.mp3");
 * player.setPitch(2.5f);   // Raise pitch by 2.5 semitones
 * player.setTempo(1.25f);  // Speed up by 25%
 * player.play();
 * 
 * // Later, release resources
 * player.release();
 * </pre>
 * 
 * @see AudioProcessor
 * @see PitchShifter
 * @see MediaCodec
 * @see AudioTrack
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class SoundTouchPlayer {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "SoundTouchPlayer";
    
    // ========================================================================
    // State Constants
    // ========================================================================
    
    /** Initial state. No song loaded. */
    private static final int STATE_IDLE = 0;
    
    /** Loading state. Song is being loaded and decoded. */
    private static final int STATE_LOADING = 1;
    
    /** Prepared state. Song is ready for playback. */
    private static final int STATE_PREPARED = 2;
    
    /** Playing state. Audio is actively playing. */
    private static final int STATE_PLAYING = 3;
    
    /** Paused state. Playback is paused, position preserved. */
    private static final int STATE_PAUSED = 4;
    
    /** Stopped state. Playback stopped, position reset to 0. */
    private static final int STATE_STOPPED = 5;
    
    /** Released state. All resources freed. */
    private static final int STATE_RELEASED = 6;
    
    /** Error state. Unrecoverable error occurred. */
    private static final int STATE_ERROR = 7;
    
    // ========================================================================
    // Audio Constants
    // ========================================================================
    
    /** Capacity of the buffer queues between threads. */
    private static final int BUFFER_QUEUE_CAPACITY = 16;
    
    /** Multiplier for AudioTrack buffer size (2x minimum). */
    private static final int AUDIO_TRACK_BUFFER_MULTIPLIER = 2;
    
    /** Minimum AudioTrack buffer size in milliseconds. */
    private static final int MIN_AUDIO_BUFFER_MS = 200;
    
    /** Decoder timeout in microseconds (100ms). */
    private static final long DECODER_TIMEOUT_US = 100000;
    
    /** Timeout for polling frames from queues in milliseconds. */
    private static final long QUEUE_POLL_TIMEOUT_MS = 50;
    
    /** Interval for progress updates in milliseconds. */
    private static final int PROGRESS_UPDATE_INTERVAL_MS = 250;
    
    /** Maximum number of recovery attempts for errors. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Timeout for joining threads during release in milliseconds. */
    private static final long THREAD_JOIN_TIMEOUT_MS = 2000;
    
    // ========================================================================
    // Parameter Range Constants
    // ========================================================================
    
    /** Minimum tempo multiplier (0.5x = half speed). */
    private static final float MIN_TEMPO = 0.5f;
    
    /** Maximum tempo multiplier (1.5x = 150% speed). */
    private static final float MAX_TEMPO = 1.5f;
    
    /** Minimum pitch shift in semitones (-6 = lower by 6 semitones). */
    private static final float MIN_PITCH = -6.0f;
    
    /** Maximum pitch shift in semitones (+6 = raise by 6 semitones). */
    private static final float MAX_PITCH = 6.0f;
    
    /** Common sample rates to try as fallbacks in order of preference. */
    private static final int[] FALLBACK_SAMPLE_RATES = {48000, 44100, 32000, 24000, 16000};
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    /** Current player state (atomic for thread-safe reads). */
    private final AtomicInteger mState = new AtomicInteger(STATE_IDLE);
    
    /** Lock object for state transitions (synchronized blocks). */
    private final Object mStateLock = new Object();
    
    // ========================================================================
    // Audio Components
    // ========================================================================
    
    /** Absolute file path of the currently loaded song. */
    private String mFilePath;
    
    /** MediaExtractor for reading compressed audio data from file. */
    private MediaExtractor mExtractor;
    
    /** MediaCodec decoder for converting compressed audio to PCM. */
    private MediaCodec mDecoder;
    
    /** AudioTrack for playing processed PCM audio. */
    private AudioTrack mAudioTrack;
    
    /** AudioProcessor for pitch and tempo shifting via SoundTouch. */
    private AudioProcessor mAudioProcessor;
    
    // ========================================================================
    // Audio Format Parameters
    // ========================================================================
    
    /** Current sample rate in Hz (may differ from original if resampling). */
    private int mSampleRate = 44100;
    
    /** Original sample rate from the audio file. */
    private int mOriginalSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Total duration of the current song in milliseconds. */
    private long mDuration = 0;
    
    /** Audio session ID for equalizer attachment. */
    private int mAudioSessionId = 0;
    
    // ========================================================================
    // Playback Parameters
    // ========================================================================
    
    /** Current pitch shift in semitones. */
    private float mCurrentPitch = 0f;
    
    /** Current tempo multiplier. */
    private float mCurrentTempo = 1.0f;
    
    /** Current playback position in milliseconds (atomic for thread safety). */
    private final AtomicLong mCurrentPosition = new AtomicLong(0);
    
    /** Pending seek position (-1 if no seek pending). */
    private volatile long mPendingSeekPosition = -1;
    
    // ========================================================================
    // Threads
    // ========================================================================
    
    /** Thread for decoding compressed audio to PCM. */
    private DecoderThread mDecoderThread;
    
    /** Thread for processing PCM through SoundTouch (pitch/tempo). */
    private ProcessorThread mProcessorThread;
    
    /** Thread for writing processed PCM to AudioTrack. */
    private AudioThread mAudioThread;
    
    // ========================================================================
    // Callbacks and Handlers
    // ========================================================================
    
    /** Handler for posting callbacks to the main thread. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Playback event listener. */
    @Nullable
    private PlaybackListener mListener;
    
    /** Runnable for periodic progress updates. */
    private Runnable mProgressUpdater;
    
    // ========================================================================
    // Recovery and Track Info
    // ========================================================================
    
    /** Number of recovery attempts for the current error. */
    private int mRecoveryAttempts = 0;
    
    /** Index of the audio track in the extractor. */
    private int mAudioTrackIndex = -1;
    
    /** MediaFormat of the audio track. */
    private MediaFormat mAudioFormat;
    
    // ========================================================================
    // Inner Classes - Data Containers
    // ========================================================================
    
    /**
     * Container for a decoded PCM frame from MediaCodec.
     * 
     * <p>This class holds the decoded audio data along with its metadata.
     * It is passed from the decoder thread to the processor thread via a
     * thread-safe BlockingQueue.</p>
     */
    private static class DecodedFrame {
        /** The decoded PCM data buffer. */
        ByteBuffer data;
        
        /** Buffer metadata (size, flags, presentation time). */
        MediaCodec.BufferInfo info;
        
        /** The output buffer ID for release back to decoder. */
        int bufferIndex = -1;
        
        /** Flag indicating this is the end-of-stream marker. */
        boolean isEndOfStream = false;
    }
    
    /**
     * Container for a processed PCM frame after SoundTouch processing.
     * 
     * <p>This class holds the pitch/tempo shifted audio data. It is passed
     * from the processor thread to the audio thread via a thread-safe
     * BlockingQueue.</p>
     */
    private static class ProcessedFrame {
        /** The processed PCM data as short array. */
        short[] data;
        
        /** Presentation timestamp in microseconds. */
        long presentationTimeUs;
        
        /** Flag indicating this is the end-of-stream marker. */
        boolean isEndOfStream = false;
    }
    
    // ========================================================================
    // Inner Classes - Threads
    // ========================================================================
    
    /**
     * Decoder Thread - Reads compressed audio and decodes to PCM.
     * 
     * <p>This thread runs in the background and continuously reads compressed
     * audio data from the MediaExtractor, feeds it to the MediaCodec, and
     * queues decoded PCM frames to the processor thread. It stops when the
     * player enters RELEASED or ERROR state, or when shutdown() is called.</p>
     * 
     * <p>Thread priority is set to THREAD_PRIORITY_URGENT_AUDIO for low latency.</p>
     */
    private class DecoderThread extends Thread {
        /** Flag indicating the thread should continue running. */
        private volatile boolean mRunning = true;
        
        /** Queue for passing decoded frames to the processor thread. */
        private final BlockingQueue<DecodedFrame> mOutputQueue = new ArrayBlockingQueue<>(BUFFER_QUEUE_CAPACITY);
        
        /**
         * Constructs a new DecoderThread.
         */
        DecoderThread() {
            super("SoundTouchDecoder");
        }
        
        /**
         * Signals the thread to shut down gracefully.
         */
        void shutdown() {
            mRunning = false;
            interrupt();
        }
        
        /**
         * Main thread loop.
         * 
         * <p>Continuously processes decoder input and output buffers until
         * shutdown is requested or an error occurs.</p>
         */
        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            Log.d(TAG, "Decoder thread started");
            
            while (mRunning && !isInterrupted()) {
                int state = mState.get();
                if (state == STATE_RELEASED || state == STATE_ERROR) {
                    break;
                }
                
                if (mDecoder == null || mExtractor == null) {
                    try { Thread.sleep(10); } catch (InterruptedException e) { break; }
                    continue;
                }
                
                try {
                    processDecoder();
                } catch (Exception e) {
                    Log.e(TAG, "Decoder error", e);
                    if (mRunning) {
                        notifyError("Decoder error: " + e.getMessage());
                    }
                    break;
                }
            }
            
            Log.d(TAG, "Decoder thread finished");
        }
        
        /**
         * Processes a single iteration of decoder input and output.
         * 
         * <p>This method:
         * <ol>
         *   <li>Requests an input buffer from the decoder</li>
         *   <li>Reads compressed data from the extractor and queues it</li>
         *   <li>Requests output buffers from the decoder</li>
         *   <li>Queues decoded PCM frames for the processor thread</li>
         * </ol>
         * </p>
         */
        private void processDecoder() throws Exception {
            // Process input buffers
            int inputIndex = mDecoder.dequeueInputBuffer(DECODER_TIMEOUT_US);
            if (inputIndex >= 0) {
                ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                if (inputBuffer != null) {
                    int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                    long presentationTimeUs = mExtractor.getSampleTime();
                    
                    if (sampleSize < 0) {
                        // End of stream
                        mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    } else {
                        mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                        mExtractor.advance();
                    }
                }
            }
            
            // Process output buffers
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int outputIndex = mDecoder.dequeueOutputBuffer(info, DECODER_TIMEOUT_US);
            
            if (outputIndex >= 0) {
                if (info.size > 0) {
                    ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                    if (outputBuffer != null) {
                        // Create a copy of the buffer data (required for thread safety)
                        ByteBuffer copy = ByteBuffer.allocateDirect(info.size);
                        copy.order(ByteOrder.LITTLE_ENDIAN);
                        outputBuffer.position(info.offset);
                        outputBuffer.limit(info.offset + info.size);
                        copy.put(outputBuffer);
                        copy.flip();
                        
                        DecodedFrame frame = new DecodedFrame();
                        frame.data = copy;
                        frame.info = new MediaCodec.BufferInfo();
                        frame.info.set(info.offset, info.size, info.presentationTimeUs, info.flags);
                        frame.bufferIndex = outputIndex;
                        mOutputQueue.offer(frame);
                    } else {
                        mDecoder.releaseOutputBuffer(outputIndex, false);
                    }
                } else {
                    mDecoder.releaseOutputBuffer(outputIndex, false);
                }
            } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                // Format changed - ignore (we already have the format)
            }
            
            // Check for end of stream
            if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                DecodedFrame eosFrame = new DecodedFrame();
                eosFrame.isEndOfStream = true;
                mOutputQueue.offer(eosFrame);
            }
        }
        
        /**
         * Polls the next decoded frame from the output queue.
         * 
         * @return The next decoded frame, or null if timeout occurs
         * @throws InterruptedException if the thread is interrupted while waiting
         */
        @Nullable
        DecodedFrame pollOutputFrame() throws InterruptedException {
            return mOutputQueue.poll(QUEUE_POLL_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        }
    }
    
    /**
     * Processor Thread - Applies pitch and tempo effects via SoundTouch.
     * 
     * <p>This thread runs in the background, takes decoded PCM frames from
     * the decoder thread, processes them through SoundTouch for pitch and
     * tempo shifting, and queues the processed frames to the audio thread.</p>
     * 
     * <p>Thread priority is set to THREAD_PRIORITY_URGENT_AUDIO for low latency.</p>
     */
    private class ProcessorThread extends Thread {
        /** Flag indicating the thread should continue running. */
        private volatile boolean mRunning = true;
        
        /** Queue for passing processed frames to the audio thread. */
        private final BlockingQueue<ProcessedFrame> mOutputQueue = new ArrayBlockingQueue<>(BUFFER_QUEUE_CAPACITY);
        
        /**
         * Constructs a new ProcessorThread.
         */
        ProcessorThread() {
            super("SoundTouchProcessor");
        }
        
        /**
         * Signals the thread to shut down gracefully.
         */
        void shutdown() {
            mRunning = false;
            interrupt();
        }
        
        /**
         * Main thread loop.
         * 
         * <p>Continuously polls for decoded frames from the decoder thread,
         * processes them through SoundTouch, and queues the results for the
         * audio thread.</p>
         */
        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            Log.d(TAG, "Processor thread started");
            
            while (mRunning && !isInterrupted()) {
                int state = mState.get();
                if (state == STATE_RELEASED || state == STATE_ERROR) {
                    break;
                }
                
                if (mDecoderThread == null) {
                    try { Thread.sleep(10); } catch (InterruptedException e) { break; }
                    continue;
                }
                
                try {
                    DecodedFrame frame = mDecoderThread.pollOutputFrame();
                    if (frame != null) {
                        processFrame(frame);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Processor error", e);
                    if (mRunning) {
                        notifyError("Processor error: " + e.getMessage());
                    }
                    break;
                }
            }
            
            Log.d(TAG, "Processor thread finished");
        }
        
        /**
         * Processes a single decoded frame through SoundTouch.
         * 
         * @param frame The decoded frame to process
         */
        private void processFrame(DecodedFrame frame) {
            // Release decoder buffer back to MediaCodec
            if (frame.bufferIndex >= 0 && mDecoder != null) {
                try {
                    mDecoder.releaseOutputBuffer(frame.bufferIndex, false);
                } catch (IllegalStateException e) {
                    Log.w(TAG, "Failed to release buffer", e);
                }
            }
            
            if (frame.isEndOfStream) {
                ProcessedFrame eosFrame = new ProcessedFrame();
                eosFrame.isEndOfStream = true;
                mOutputQueue.offer(eosFrame);
                return;
            }
            
            if (frame.data == null || frame.info.size <= 0) {
                return;
            }
            
            // Convert ByteBuffer to short array for SoundTouch
            ByteBuffer buffer = frame.data;
            buffer.rewind();
            int sampleCount = frame.info.size / 2;
            short[] pcmData = new short[sampleCount];
            
            for (int i = 0; i < sampleCount && buffer.hasRemaining(); i++) {
                pcmData[i] = buffer.getShort();
            }
            
            int frames = pcmData.length / mChannels;
            if (frames <= 0) return;
            
            // Process through SoundTouch
            if (mAudioProcessor != null) {
                short[] processed = mAudioProcessor.process(pcmData, frames);
                
                if (processed != null && processed.length > 0) {
                    ProcessedFrame outFrame = new ProcessedFrame();
                    outFrame.data = processed;
                    outFrame.presentationTimeUs = frame.info.presentationTimeUs;
                    mOutputQueue.offer(outFrame);
                }
            }
        }
        
        /**
         * Polls the next processed frame from the output queue.
         * 
         * @return The next processed frame, or null if timeout occurs
         * @throws InterruptedException if the thread is interrupted while waiting
         */
        @Nullable
        ProcessedFrame pollOutputFrame() throws InterruptedException {
            return mOutputQueue.poll(QUEUE_POLL_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        }
    }
    
    /**
     * Audio Thread - Writes processed PCM to AudioTrack for playback.
     * 
     * <p>This thread runs in the background, takes processed frames from the
     * processor thread, writes them to AudioTrack, and handles seek operations
     * and position tracking. It also handles end-of-stream detection and
     * completion notification.</p>
     * 
     * <p>Thread priority is set to THREAD_PRIORITY_URGENT_AUDIO for low latency.</p>
     */
    private class AudioThread extends Thread {
        /** Flag indicating the thread should continue running. */
        private volatile boolean mRunning = true;
        
        /** Flag indicating playback start has been reported to listener. */
        private boolean mHasReportedPlaybackStart = false;
        
        /**
         * Constructs a new AudioThread.
         */
        AudioThread() {
            super("SoundTouchAudio");
        }
        
        /**
         * Signals the thread to shut down gracefully.
         */
        void shutdown() {
            mRunning = false;
            interrupt();
        }
        
        /**
         * Main thread loop.
         * 
         * <p>Continuously polls for processed frames, writes them to AudioTrack,
         * handles seeks, and updates position tracking.</p>
         */
        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            Log.d(TAG, "Audio thread started");
            
            while (mRunning && !isInterrupted()) {
                int state = mState.get();
                if (state == STATE_RELEASED || state == STATE_ERROR) {
                    break;
                }
                
                if (mProcessorThread == null) {
                    try { Thread.sleep(10); } catch (InterruptedException e) { break; }
                    continue;
                }
                
                try {
                    // Handle pending seek operation
                    if (mPendingSeekPosition >= 0 && mExtractor != null) {
                        performSeek(mPendingSeekPosition);
                    }
                    
                    // Process audio output
                    ProcessedFrame frame = mProcessorThread.pollOutputFrame();
                    if (frame != null) {
                        if (frame.isEndOfStream) {
                            handleEndOfStream();
                            break;
                        }
                        
                        if (frame.data != null && frame.data.length > 0 && mAudioTrack != null) {
                            int written = mAudioTrack.write(frame.data, 0, frame.data.length);
                            if (written < 0) {
                                Log.e(TAG, "AudioTrack write error: " + written);
                                if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                                    recreateAudioTrack();
                                }
                            }
                            
                            // Report playback start when we've written enough data
                            if (!mHasReportedPlaybackStart && mState.get() == STATE_PLAYING) {
                                if (mAudioTrack.getPlaybackHeadPosition() > 0 || written > 0) {
                                    mHasReportedPlaybackStart = true;
                                    notifyPlaybackStarted();
                                }
                            }
                        }
                    } else {
                        // No data available, short sleep to prevent CPU spinning
                        Thread.sleep(1);
                    }
                    
                    // Update position for UI (if playing)
                    if (mState.get() == STATE_PLAYING && mAudioTrack != null) {
                        long framesPlayed = mAudioTrack.getPlaybackHeadPosition();
                        if (framesPlayed > 0) {
                            long positionMs = framesPlayed * 1000L / mSampleRate;
                            mCurrentPosition.set(positionMs);
                        }
                    }
                    
                } catch (InterruptedException e) {
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Audio thread error", e);
                    if (mRunning) {
                        notifyError("Audio error: " + e.getMessage());
                    }
                    break;
                }
            }
            
            Log.d(TAG, "Audio thread finished");
        }
        
        /**
         * Handles end-of-stream detection.
         * 
         * <p>This method flushes any remaining audio from the SoundTouch
         * processor, transitions to STOPPED state, and notifies the listener
         * of completion.</p>
         */
        private void handleEndOfStream() {
            // Flush remaining audio from SoundTouch
            if (mAudioProcessor != null) {
                mAudioProcessor.flush();
                
                short[] remaining;
                while ((remaining = mAudioProcessor.tryReceiveOnce()) != null && remaining.length > 0) {
                    if (mAudioTrack != null) {
                        mAudioTrack.write(remaining, 0, remaining.length);
                    }
                }
            }
            
            // Transition to STOPPED state
            synchronized (mStateLock) {
                int currentState = mState.get();
                if (currentState == STATE_PLAYING || currentState == STATE_PAUSED) {
                    mState.set(STATE_STOPPED);
                    mCurrentPosition.set(mDuration);
                    Log.d(TAG, "State: PLAYING/PAUSED -> STOPPED (end of stream)");
                }
            }
            
            notifyCompletion();
        }
    }
    
    // ========================================================================
    // Listener Interface
    // ========================================================================
    
    /**
     * Listener interface for playback events.
     * 
     * <p>Implement this interface to receive callbacks about playback state
     * changes, errors, and position updates. All callbacks are delivered on
     * the main thread.</p>
     */
    public interface PlaybackListener {
        
        /**
         * Called when the player is prepared and ready for playback.
         * 
         * <p>This is called after loadSong() successfully completes.
         * The player is now in the PREPARED state.</p>
         */
        void onPrepared();
        
        /**
         * Called when playback starts.
         * 
         * <p>This is called when play() is called and audio actually begins
         * playing. The player is now in the PLAYING state.</p>
         */
        void onPlaybackStarted();
        
        /**
         * Called when playback is paused.
         * 
         * <p>This is called when pause() is called. The player is now in the
         * PAUSED state. Playback position is preserved.</p>
         */
        void onPlaybackPaused();
        
        /**
         * Called when playback resumes after being paused.
         * 
         * <p>This is called when resume() is called. The player returns to
         * the PLAYING state from PAUSED.</p>
         */
        void onPlaybackResumed();
        
        /**
         * Called when the current song finishes playing.
         * 
         * <p>This is called when the end of the song is reached. The player
         * automatically transitions to STOPPED state.</p>
         */
        void onCompletion();
        
        /**
         * Called periodically with the current playback position.
         * 
         * <p>Update interval is approximately 250ms.</p>
         * 
         * @param position Current position in milliseconds
         */
        void onPositionUpdate(long position);
        
        /**
         * Called when an error occurs during playback.
         * 
         * <p>After an error, the player enters the ERROR state and should be
         * released.</p>
         * 
         * @param error Human-readable error message
         */
        void onError(@NonNull String error);
    }
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new SoundTouchPlayer instance.
     * 
     * <p>The player starts in the IDLE state. Call loadSong() to load a song,
     * then play() to start playback.</p>
     * 
     * <p>The AudioProcessor is initialized immediately, but must be configured
     * during loadSong() with the actual sample rate and channel count.</p>
     */
    public SoundTouchPlayer() {
        mAudioProcessor = new AudioProcessor();
        
        mProgressUpdater = new Runnable() {
            @Override
            public void run() {
                if (mListener != null) {
                    int state = mState.get();
                    if (state == STATE_PLAYING || state == STATE_PAUSED) {
                        mListener.onPositionUpdate(mCurrentPosition.get());
                    }
                }
                if (mState.get() != STATE_RELEASED) {
                    mMainHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS);
                }
            }
        };
        
        Log.d(TAG, "SoundTouchPlayer created (State: IDLE)");
    }
    
    // ========================================================================
    // Public API - Lifecycle Management
    // ========================================================================
    
    /**
     * Sets the playback event listener.
     * 
     * <p>All callbacks are delivered on the main thread. Set to null to remove
     * the listener.</p>
     * 
     * @param listener The listener to receive callbacks, or null to remove
     */
    public void setListener(@Nullable PlaybackListener listener) {
        mListener = listener;
    }
    
    /**
     * Loads a song from the specified file path.
     * 
     * <p>This method transitions the player from IDLE/STOPPED/ERROR to LOADING,
     * then to PREPARED on success, or ERROR on failure.</p>
     * 
     * <p>The method performs the following steps:</p>
     * <ol>
     *   <li>Validates that the SoundTouch library is available</li>
     *   <li>Releases any existing resources</li>
     *   <li>Creates and configures MediaExtractor to find the audio track</li>
     *   <li>Creates and configures MediaCodec decoder</li>
     *   <li>Configures AudioProcessor with the audio format</li>
     *   <li>Creates AudioTrack for playback</li>
     *   <li>Starts the decoder, processor, and audio threads</li>
     * </ol>
     * 
     * @param filePath Absolute path to the audio file
     * @return true if loading was successful, false if an error occurred
     * 
     * @throws IllegalStateException if called from an invalid state
     */
    public boolean loadSong(@NonNull String filePath) {
        int currentState = mState.get();
        
        // Valid states to load from
        if (currentState != STATE_IDLE && currentState != STATE_STOPPED && currentState != STATE_ERROR) {
            Log.e(TAG, "Cannot load song from state: " + stateToString(currentState));
            return false;
        }
        
        if (!PitchShifter.isLibraryAvailable()) {
            notifyError("SoundTouch library not available");
            return false;
        }
        
        synchronized (mStateLock) {
            releaseResources();
            mState.set(STATE_LOADING);
            Log.d(TAG, "State: " + stateToString(currentState) + " -> LOADING");
        }
        
        mFilePath = filePath;
        mRecoveryAttempts = 0;
        mPendingSeekPosition = -1;
        mCurrentPosition.set(0);
        
        try {
            // Setup extractor
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);
            
            // Find audio track
            mAudioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mAudioTrackIndex = i;
                    mAudioFormat = format;
                    break;
                }
            }
            
            if (mAudioTrackIndex == -1 || mAudioFormat == null) {
                throw new IOException("No audio track found");
            }
            
            mExtractor.selectTrack(mAudioTrackIndex);
            
            // Get audio parameters
            mOriginalSampleRate = mAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mSampleRate = getBestSupportedSampleRate(mOriginalSampleRate);
            mChannels = mAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDuration = mAudioFormat.getLong(MediaFormat.KEY_DURATION) / 1000;
            
            Log.d(TAG, "Audio format: " + mSampleRate + "Hz, " + mChannels + "ch, duration=" + mDuration + "ms");
            
            // Setup decoder
            String mime = mAudioFormat.getString(MediaFormat.KEY_MIME);
            mDecoder = MediaCodec.createDecoderByType(mime);
            
            // Configure decoder (resample if needed)
            if (mSampleRate != mOriginalSampleRate) {
                mAudioFormat.setInteger(MediaFormat.KEY_SAMPLE_RATE, mSampleRate);
                Log.d(TAG, "Resampling from " + mOriginalSampleRate + " to " + mSampleRate + "Hz");
            }
            mDecoder.configure(mAudioFormat, null, null, 0);
            mDecoder.start();
            
            // Configure AudioProcessor
            if (!mAudioProcessor.configure(mSampleRate, mChannels)) {
                throw new IOException("Failed to configure AudioProcessor");
            }
            mAudioProcessor.setPitchSemitones(mCurrentPitch);
            mAudioProcessor.setTempo(mCurrentTempo);
            
            // Create AudioTrack
            if (!createAudioTrack()) {
                throw new IOException("Failed to create AudioTrack");
            }
            
            // Start threads
            mDecoderThread = new DecoderThread();
            mProcessorThread = new ProcessorThread();
            mAudioThread = new AudioThread();
            
            mDecoderThread.start();
            mProcessorThread.start();
            mAudioThread.start();
            
            synchronized (mStateLock) {
                mState.set(STATE_PREPARED);
                Log.d(TAG, "State: LOADING -> PREPARED");
            }
            
            mMainHandler.post(mProgressUpdater);
            notifyPrepared();
            
            Log.d(TAG, "Song loaded successfully: " + filePath);
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to load song", e);
            notifyError("Failed to load: " + e.getMessage());
            synchronized (mStateLock) {
                mState.set(STATE_ERROR);
                Log.d(TAG, "State: LOADING -> ERROR");
            }
            releaseResources();
            return false;
        }
    }
    
    /**
     * Starts or resumes playback.
     * 
     * <p>Valid state transitions:</p>
     * <ul>
     *   <li>PREPARED -> PLAYING (start from beginning)</li>
     *   <li>PAUSED -> PLAYING (resume from pause position)</li>
     *   <li>STOPPED -> PLAYING (start from beginning)</li>
     * </ul>
     * 
     * <p>If called from PLAYING state, does nothing.</p>
     * 
     * @throws IllegalStateException if called from an invalid state (IDLE, LOADING, ERROR, RELEASED)
     */
    public void play() {
        synchronized (mStateLock) {
            int currentState = mState.get();
            
            if (currentState == STATE_PREPARED || currentState == STATE_PAUSED || currentState == STATE_STOPPED) {
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.play();
                }
                mState.set(STATE_PLAYING);
                Log.d(TAG, "State: " + stateToString(currentState) + " -> PLAYING");
                
                // Reset playback start reported flag
                if (mAudioThread != null) {
                    mAudioThread.mHasReportedPlaybackStart = false;
                }
            } else if (currentState == STATE_PLAYING) {
                // Already playing - do nothing
            } else {
                throw new IllegalStateException("Cannot play from state: " + stateToString(currentState));
            }
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>Valid state transition: PLAYING -> PAUSED</p>
     * <p>Playback position is preserved. Call resume() to continue.</p>
     * 
     * @throws IllegalStateException if called from an invalid state
     */
    public void pause() {
        synchronized (mStateLock) {
            if (mState.get() == STATE_PLAYING) {
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.pause();
                }
                mState.set(STATE_PAUSED);
                Log.d(TAG, "State: PLAYING -> PAUSED");
                notifyPlaybackPaused();
            } else {
                throw new IllegalStateException("Cannot pause from state: " + stateToString(mState.get()));
            }
        }
    }
    
    /**
     * Resumes playback after being paused.
     * 
     * <p>Valid state transition: PAUSED -> PLAYING</p>
     * 
     * @throws IllegalStateException if called from an invalid state
     */
    public void resume() {
        synchronized (mStateLock) {
            if (mState.get() == STATE_PAUSED) {
                if (mAudioTrack != null && mAudioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                    mAudioTrack.play();
                }
                mState.set(STATE_PLAYING);
                Log.d(TAG, "State: PAUSED -> PLAYING");
                notifyPlaybackResumed();
            } else {
                throw new IllegalStateException("Cannot resume from state: " + stateToString(mState.get()));
            }
        }
    }
    
    /**
     * Stops playback and resets position to the beginning.
     * 
     * <p>Valid state transitions:</p>
     * <ul>
     *   <li>PLAYING -> STOPPED</li>
     *   <li>PAUSED -> STOPPED</li>
     * </ul>
     * 
     * <p>After stop, play() will start from the beginning of the song.</p>
     * 
     * @throws IllegalStateException if called from an invalid state
     */
    public void stop() {
        synchronized (mStateLock) {
            int currentState = mState.get();
            if (currentState == STATE_PLAYING || currentState == STATE_PAUSED) {
                if (mAudioTrack != null) {
                    try {
                        mAudioTrack.stop();
                    } catch (Exception e) {
                        Log.w(TAG, "Error stopping AudioTrack", e);
                    }
                }
                mState.set(STATE_STOPPED);
                mCurrentPosition.set(0);
                Log.d(TAG, "State: " + stateToString(currentState) + " -> STOPPED");
            } else {
                throw new IllegalStateException("Cannot stop from state: " + stateToString(currentState));
            }
        }
    }
    
    /**
     * Seeks to a specific position in the song.
     * 
     * <p>Valid states: PREPARED, PLAYING, PAUSED, STOPPED</p>
     * 
     * <p>Seek is performed asynchronously. The position will be updated
     * when the seek completes. A onPositionUpdate callback will be sent
     * with the new position.</p>
     * 
     * @param positionMs Target position in milliseconds (clamped to 0..duration)
     * 
     * @throws IllegalStateException if called from an invalid state
     */
    public void seekTo(long positionMs) {
        int currentState = mState.get();
        if (currentState != STATE_PREPARED && currentState != STATE_PLAYING && 
            currentState != STATE_PAUSED && currentState != STATE_STOPPED) {
            throw new IllegalStateException("Cannot seek from state: " + stateToString(currentState));
        }
        
        long clampedPosition = Math.max(0, Math.min(positionMs, mDuration));
        mPendingSeekPosition = clampedPosition;
        Log.d(TAG, "Seek requested to: " + clampedPosition + "ms");
    }
    
    /**
     * Sets the pitch shift amount in semitones.
     * 
     * <p>Valid states: PREPARED, PLAYING, PAUSED, STOPPED</p>
     * <p>Range: -6.0 to +6.0 semitones</p>
     * <p>Changes take effect immediately during playback.</p>
     * 
     * @param semitones Pitch shift amount (positive = higher pitch)
     */
    public void setPitch(float semitones) {
        float clamped = Math.max(MIN_PITCH, Math.min(MAX_PITCH, semitones));
        mCurrentPitch = clamped;
        if (mAudioProcessor != null && mAudioProcessor.isInitialized()) {
            mAudioProcessor.setPitchSemitones(clamped);
            Log.v(TAG, "Pitch set to: " + clamped + " semitones");
        }
    }
    
    /**
     * Sets the tempo (speed) multiplier.
     * 
     * <p>Valid states: PREPARED, PLAYING, PAUSED, STOPPED</p>
     * <p>Range: 0.5 to 1.5</p>
     * <ul>
     *   <li>0.5 = half speed (50% slower)</li>
     *   <li>1.0 = normal speed</li>
     *   <li>1.5 = 1.5x speed (50% faster)</li>
     * </ul>
     * <p>Changes take effect immediately during playback.</p>
     * 
     * @param tempo Tempo multiplier
     */
    public void setTempo(float tempo) {
        float clamped = Math.max(MIN_TEMPO, Math.min(MAX_TEMPO, tempo));
        mCurrentTempo = clamped;
        if (mAudioProcessor != null && mAudioProcessor.isInitialized()) {
            mAudioProcessor.setTempo(clamped);
            Log.v(TAG, "Tempo set to: " + clamped + "x");
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * @return Current position in milliseconds
     */
    public long getCurrentPosition() {
        return mCurrentPosition.get();
    }
    
    /**
     * Returns the total duration of the current song in milliseconds.
     * 
     * @return Song duration in milliseconds, or 0 if no song is loaded
     */
    public long getDuration() {
        return mDuration;
    }
    
    /**
     * Returns true if playback is currently active (playing and not paused).
     * 
     * @return true if playing, false otherwise
     */
    public boolean isPlaying() {
        return mState.get() == STATE_PLAYING;
    }
    
    /**
     * Returns true if the player is prepared and ready for playback.
     * 
     * <p>Valid prepared states: PREPARED, PLAYING, PAUSED, STOPPED</p>
     * 
     * @return true if prepared, false otherwise
     */
    public boolean isPrepared() {
        int state = mState.get();
        return state == STATE_PREPARED || state == STATE_PLAYING || 
               state == STATE_PAUSED || state == STATE_STOPPED;
    }
    
    /**
     * Returns the audio session ID for use with Android's equalizer.
     * 
     * <p>This ID can be used to attach a system Equalizer to this player.</p>
     * 
     * @return Audio session ID, or 0 if not available
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }
    
    /**
     * Releases all resources used by the player.
     * 
     * <p>Valid state transition: any state -> RELEASED</p>
     * <p>After release, the player cannot be used again. All threads are
     * stopped and all native resources are freed.</p>
     */
    public void release() {
        synchronized (mStateLock) {
            if (mState.get() == STATE_RELEASED) {
                return;
            }
            Log.d(TAG, "State: " + stateToString(mState.get()) + " -> RELEASED");
            mState.set(STATE_RELEASED);
        }
        
        Log.d(TAG, "Releasing SoundTouchPlayer");
        
        mMainHandler.removeCallbacks(mProgressUpdater);
        
        // Stop threads
        if (mDecoderThread != null) {
            mDecoderThread.shutdown();
            try {
                mDecoderThread.join(THREAD_JOIN_TIMEOUT_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mDecoderThread = null;
        }
        
        if (mProcessorThread != null) {
            mProcessorThread.shutdown();
            try {
                mProcessorThread.join(THREAD_JOIN_TIMEOUT_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mProcessorThread = null;
        }
        
        if (mAudioThread != null) {
            mAudioThread.shutdown();
            try {
                mAudioThread.join(THREAD_JOIN_TIMEOUT_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            mAudioThread = null;
        }
        
        releaseResources();
        
        Log.d(TAG, "SoundTouchPlayer released");
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Creates and configures the AudioTrack for PCM output.
     * 
     * <p>This method:
     * <ol>
     *   <li>Determines the channel configuration based on channel count</li>
     *   <li>Calculates the minimum buffer size</li>
     *   <li>Scales the buffer size for smooth playback</li>
     *   <li>Creates AudioTrack with appropriate attributes</li>
     *   <li>Stores the audio session ID</li>
     * </ol>
     * </p>
     * 
     * @return true if AudioTrack was created successfully, false otherwise
     */
    private boolean createAudioTrack() {
        try {
            int channelConfig = (mChannels == 1) ? 
                AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            
            int minBufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig,
                AudioFormat.ENCODING_PCM_16BIT);
            
            if (minBufferSize <= 0) {
                Log.e(TAG, "Invalid buffer size: " + minBufferSize);
                return false;
            }
            
            // Scale buffer size for smooth playback
            int bufferSize = Math.max(minBufferSize * AUDIO_TRACK_BUFFER_MULTIPLIER,
                mSampleRate * mChannels * 2 * MIN_AUDIO_BUFFER_MS / 1000);
            
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            
            AudioFormat format = new AudioFormat.Builder()
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build();
            
            mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            
            if (mAudioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed");
                return false;
            }
            
            mAudioSessionId = mAudioTrack.getAudioSessionId();
            
            Log.d(TAG, "AudioTrack created: " + mSampleRate + "Hz, buffer=" + bufferSize + " bytes");
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to create AudioTrack", e);
            return false;
        }
    }
    
    /**
     * Recreates the AudioTrack after a failure.
     * 
     * <p>This is called when AudioTrack.write() returns ERROR_DEAD_OBJECT.
     * It releases the old AudioTrack and creates a new one, then restarts
     * playback if the player is in PLAYING state.</p>
     */
    private void recreateAudioTrack() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing old AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        if (createAudioTrack()) {
            if (mState.get() == STATE_PLAYING && mAudioTrack != null) {
                mAudioTrack.play();
            }
        }
    }
    
    /**
     * Gets the best supported sample rate closest to the original.
     * 
     * <p>If the original sample rate is supported, it returns the original.
     * Otherwise, it tries common fallback rates in order of preference.</p>
     * 
     * @param originalRate The original sample rate from the audio file
     * @return A supported sample rate (always returns a valid rate)
     */
    private int getBestSupportedSampleRate(int originalRate) {
        if (isSampleRateSupported(originalRate)) {
            return originalRate;
        }
        
        Log.w(TAG, "Sample rate " + originalRate + " is NOT supported by this device");
        
        for (int rate : FALLBACK_SAMPLE_RATES) {
            if (isSampleRateSupported(rate)) {
                Log.w(TAG, "Falling back to supported sample rate: " + rate + " Hz");
                return rate;
            }
        }
        
        Log.w(TAG, "No common sample rate supported! Using 44100 Hz");
        return 44100;
    }
    
    /**
     * Checks if a sample rate is supported by AudioTrack on this device.
     * 
     * @param sampleRate The sample rate to check in Hz
     * @return true if supported, false otherwise
     */
    private boolean isSampleRateSupported(int sampleRate) {
        try {
            int bufferSize = AudioTrack.getMinBufferSize(sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT);
            return bufferSize > 0;
        } catch (Exception e) {
            Log.w(TAG, "Sample rate " + sampleRate + " check failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Performs the actual seek operation.
     * 
     * <p>This method:
     * <ol>
     *   <li>Flushes the SoundTouch processor</li>
     *   <li>Seeks the MediaExtractor to the new position</li>
     *   <li>Flushes the MediaCodec decoder</li>
     *   <li>Updates the current position</li>
     *   <li>Notifies the listener of the position change</li>
     * </ol>
     * </p>
     * 
     * @param positionMs Target position in milliseconds
     */
    private void performSeek(long positionMs) {
        mPendingSeekPosition = -1;
        
        if (mExtractor == null || mDecoder == null) {
            return;
        }
        
        try {
            boolean wasPlaying = (mState.get() == STATE_PLAYING);
            
            // Flush SoundTouch
            if (mAudioProcessor != null) {
                mAudioProcessor.flush();
                mAudioProcessor.clear();
            }
            
            // Seek extractor
            mExtractor.seekTo(positionMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            
            // Flush decoder
            try {
                mDecoder.flush();
            } catch (Exception e) {
                Log.w(TAG, "Failed to flush decoder during seek", e);
            }
            
            // Update position
            mCurrentPosition.set(positionMs);
            
            // Resume playback if it was playing
            if (wasPlaying && mAudioTrack != null) {
                mAudioTrack.play();
            }
            
            // Notify position update
            if (mListener != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mListener != null) {
                            mListener.onPositionUpdate(positionMs);
                        }
                    }
                });
            }
            
            Log.d(TAG, "Seek completed to: " + positionMs + "ms");
            
        } catch (Exception e) {
            Log.e(TAG, "Seek failed", e);
        }
    }
    
    /**
     * Releases all media resources.
     * 
     * <p>This method releases AudioTrack, MediaCodec, MediaExtractor, and
     * reinitializes AudioProcessor. It is called during release() and error
     * recovery.</p>
     */
    private void releaseResources() {
        if (mAudioTrack != null) {
            try {
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing AudioTrack", e);
            }
            mAudioTrack = null;
        }
        
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing decoder", e);
            }
            mDecoder = null;
        }
        
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing extractor", e);
            }
            mExtractor = null;
        }
        
        if (mAudioProcessor != null) {
            mAudioProcessor.release();
            mAudioProcessor = new AudioProcessor();
        }
        
        mAudioTrackIndex = -1;
        mAudioFormat = null;
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Notifies the listener that the player is prepared.
     */
    private void notifyPrepared() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPrepared();
                    }
                }
            });
        }
    }
    
    /**
     * Notifies the listener that playback has started.
     */
    private void notifyPlaybackStarted() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackStarted();
                    }
                }
            });
        }
    }
    
    /**
     * Notifies the listener that playback has paused.
     */
    private void notifyPlaybackPaused() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackPaused();
                    }
                }
            });
        }
    }
    
    /**
     * Notifies the listener that playback has resumed.
     */
    private void notifyPlaybackResumed() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onPlaybackResumed();
                    }
                }
            });
        }
    }
    
    /**
     * Notifies the listener that the song has completed.
     */
    private void notifyCompletion() {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onCompletion();
                    }
                }
            });
        }
    }
    
    /**
     * Notifies the listener of an error.
     * 
     * @param error The error message
     */
    private void notifyError(final String error) {
        if (mListener != null) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mListener != null) {
                        mListener.onError(error);
                    }
                }
            });
        }
    }
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Converts a state constant to a human-readable string.
     * 
     * @param state The state constant
     * @return The state name
     */
    private String stateToString(int state) {
        switch (state) {
            case STATE_IDLE: return "IDLE";
            case STATE_LOADING: return "LOADING";
            case STATE_PREPARED: return "PREPARED";
            case STATE_PLAYING: return "PLAYING";
            case STATE_PAUSED: return "PAUSED";
            case STATE_STOPPED: return "STOPPED";
            case STATE_RELEASED: return "RELEASED";
            case STATE_ERROR: return "ERROR";
            default: return "UNKNOWN(" + state + ")";
        }
    }
}