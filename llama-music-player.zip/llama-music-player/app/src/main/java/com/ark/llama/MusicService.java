package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with SoundTouch integration.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground. The service manages
 * playlist playback, audio effects, notification handling, and state persistence.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture to ensure reliable playback:</p>
 * <ul>
 *   <li><b>Primary Path (ExoPlayer + SoundTouchAudio)</b> - DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control using the SoundTouch native library.
 *       This path is used whenever possible for the best audio quality.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> - Used ONLY when ExoPlayer fails at runtime.
 *       Provides basic playback without pitch/tempo effects. The fallback is permanent
 *       for the remainder of the session to avoid repeated failure loops.</li>
 * </ul>
 * 
 * <h3>Why ExoPlayer as Default</h3>
 * <ul>
 *   <li><b>Production-Proven</b> - Used by Google, YouTube, Spotify, and thousands of apps</li>
 *   <li><b>Consistent Audio Pipeline</b> - Same processing path for all audio</li>
 *   <li><b>Seamless Effect Activation</b> - No transition when user adjusts pitch/tempo</li>
 *   <li><b>Better Error Recovery</b> - Graceful fallback on failure</li>
 *   <li><b>Simpler Logic</b> - Single primary path, single fallback path</li>
 *   <li><b>Handles Complexity</b> - MediaCodec, AudioTrack, seeking, gapless playback</li>
 * </ul>
 * 
 * <h3>Pitch and Tempo Ranges</h3>
 * <ul>
 *   <li><b>Pitch:</b> -6 to +6 semitones (controlled via EqualizerManager)</li>
 *   <li><b>Tempo/Speed:</b> 0.5x to 1.5x speed (controlled via EqualizerManager)</li>
 * </ul>
 * 
 * <h3>Sort Modes</h3>
 * <p>The service supports 10 sort modes for playlist ordering:</p>
 * <ul>
 *   <li>0 - Title A-Z (ascending alphabetical by title)</li>
 *   <li>1 - Title Z-A (descending alphabetical by title)</li>
 *   <li>2 - Artist A-Z (ascending alphabetical by artist)</li>
 *   <li>3 - Artist Z-A (descending alphabetical by artist)</li>
 *   <li>4 - Album A-Z (ascending alphabetical by album)</li>
 *   <li>5 - Album Z-A (descending alphabetical by album)</li>
 *   <li>6 - Genre A-Z (ascending alphabetical by genre)</li>
 *   <li>7 - Genre Z-A (descending alphabetical by genre)</li>
 *   <li>8 - Oldest First (by file modification date)</li>
 *   <li>9 - Newest First (by file modification date)</li>
 * </ul>
 * 
 * <h3>Playback State Persistence</h3>
 * <p>The service saves the following to SharedPreferences:</p>
 * <ul>
 *   <li>Current song index</li>
 *   <li>Current playback position</li>
 *   <li>Playing state (playing/paused)</li>
 *   <li>Repeat mode (off/all/one)</li>
 *   <li>Shuffle mode (on/off)</li>
 *   <li>Last song path</li>
 *   <li>Sort mode</li>
 * </ul>
 * 
 * <h3>Audio Focus Management</h3>
 * <p>The service properly handles audio focus changes from other apps, phone calls,
 * and system events. When audio focus is lost, playback pauses. When focus is
 * regained, playback resumes automatically.</p>
 * 
 * <h3>Media Session Integration</h3>
 * <p>The service provides a MediaSession for lock screen controls and headset
 * button handling. This allows users to control playback from the lock screen,
 * notification shade, and Bluetooth headsets.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Start service
 * Intent intent = new Intent(context, MusicService.class);
 * intent.setAction("PLAY_SONG");
 * intent.putExtra("song_path", "/sdcard/Music/song.mp3");
 * startService(intent);
 * 
 * // Bind to service
 * bindService(intent, connection, BIND_AUTO_CREATE);
 * 
 * // Control playback
 * musicService.play();
 * musicService.pause();
 * musicService.playNext();
 * musicService.seekTo(30000);
 * musicService.setRepeatMode(1);  // Repeat all
 * musicService.setShuffle(true);
 * </pre>
 * 
 * @see ExoPlayer
 * @see SoundTouchAudio
 * @see MediaPlayer
 * @see EqualizerManager
 * @see NotificationService
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state (true = was playing). */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state (true = enabled). */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode across components. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Intent extra key for sort mode value. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Delay for song transitions in milliseconds (prevents rapid skipping). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Broadcast action for audio session ID changes (for equalizer attachment). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds for MediaPlayer fallback. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    
    /** Maximum stall time before recovery in milliseconds. */
    private static final int MAX_STALL_TIME_MS = 5000;
    
    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    // ========================================================================
    // Sort Mode Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment. Updated whenever a new
     * audio session is created. Activities can query this value to attach their
     * equalizer to the correct audio session. */
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // ExoPlayer Members (PRIMARY PLAYER)
    // ========================================================================
    
    /** ExoPlayer instance for high-quality playback with pitch/tempo support.
     * This is the primary player used for all normal playback operations. */
    private ExoPlayer mExoPlayer;
    
    /** SoundTouch audio processor that applies pitch and tempo effects.
     * This processor is integrated with ExoPlayer's audio pipeline. */
    private SoundTouchAudio mSoundTouchAudio;
    
    /** Flag indicating if ExoPlayer is currently active. True when ExoPlayer
     * is initialized and ready for playback. */
    private boolean mIsUsingExoPlayer = false;
    
    /** Flag indicating if ExoPlayer failed at runtime. Once set to true, the
     * service will permanently use MediaPlayer fallback to avoid repeated
     * failure loops. */
    private boolean mExoPlayerFailed = false;
    
    // ========================================================================
    // MediaPlayer Members (FALLBACK ONLY)
    // ========================================================================
    
    /** Legacy MediaPlayer instance - used ONLY when ExoPlayer fails at runtime.
     * This provides basic playback without pitch/tempo effects. */
    private android.media.MediaPlayer mMediaPlayer;
    
    // ========================================================================
    // Playback State
    // ========================================================================
    
    /** Current playlist of songs. This list determines the order of playback
     * and is modified by sort operations and folder management. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song in mCurrentPlaylist. Value -1 indicates
     * no song is currently selected. */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active (playing audio). This
     * state is synchronized across threads using mPlayerLock. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0 = off (stop at end), 1 = repeat all (loop entire playlist),
     * 2 = repeat one (repeat current song indefinitely). */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled. When true, songs are played
     * in random order instead of sequential. */
    private volatile boolean mIsShuffle = false;
    
    /** Timestamp when current playback started (for health checks - MediaPlayer only).
     * Used to detect playback stalls. */
    private long mPlaybackStartTime = 0;
    
    // ========================================================================
    // Sort Mode State
    // ========================================================================
    
    /** Current sort mode for playlist display. Determines how songs are ordered
     * in the playlist. Default is SORT_TITLE_AZ. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Health Check Components (MediaPlayer only)
    // ========================================================================
    
    /** Handler for periodic health checks when using MediaPlayer fallback.
     * Used to detect and recover from playback stalls. */
    private Handler mHealthHandler;
    
    /** Runnable for health check execution. Posts to mHealthHandler at regular
     * intervals to monitor playback progress. */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts for the current song. Increments each time
     * a stall is detected and a recovery is attempted. Resets on successful
     * playback or when skipping to next song. */
    private int mRecoveryAttempts = 0;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    /** WakeLock to prevent device sleep during playback. Acquired when playback
     * starts and released when paused or stopped. Ensures audio continues
     * playing even when screen is off. */
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    /** Audio manager for focus management. Used to request and abandon audio
     * focus, and to handle ducking during audio interruptions. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. Called when another app gains or loses
     * audio focus, allowing this service to pause or duck appropriately. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for API 26+ (Android O and above). Provides a cleaner
     * API for requesting and abandoning audio focus. */
    private android.media.AudioFocusRequest mAudioFocusRequest;
    
    // ========================================================================
    // Media Session
    // ========================================================================
    
    /** MediaSession for lock screen and headset controls. Allows users to control
     * playback from the lock screen, notification shade, and Bluetooth devices. */
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    /** Flag indicating if Bluetooth headset is connected. Used to route media
     * button events correctly and handle Bluetooth-specific behaviors. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    /** Lock object for MediaPlayer operations (fallback only). Protects access
     * to mMediaPlayer and related state variables from concurrent threads. */
    private final Object mPlayerLock = new Object();
    
    /** Flag indicating if a song transition is in progress. Prevents multiple
     * concurrent next/prev operations that could cause state corruption. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if a song is being prepared (MediaPlayer fallback only).
     * Prevents duplicate preparation calls during async operations. */
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    
    /** Global preparation ID counter for async operation cancellation.
     * Incremented each time a new preparation starts. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID (used to ignore stale callbacks). When a callback
     * receives an ID that doesn't match mCurrentPrepId, it's ignored. */
    private volatile int mCurrentPrepId = -1;
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    /** Binder for activity binding. Activities can bind to this service and
     * obtain a reference to the service instance for direct method calls. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    /** History of shuffled indices (for prev/next in shuffle mode). Maintains
     * a history of recently played songs to avoid repetition when navigating
     * backward in shuffle mode. */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. Used to select random songs
     * when shuffle is enabled. */
    private Random mRandom;
    
    /** Pending playlist for soft update. When a playlist update is requested
     * but the current song is still playing, the new playlist is stored here
     * until the current song completes. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. When true, mPendingPlaylist
     * contains a playlist waiting to be applied at song completion. */
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    /** Service for managing playback notifications. Handles creating and updating
     * the media notification that appears in the notification shade. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for sync notification updates. Updates the notification when
     * playlist sync operations start or complete. */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates. Applies new pitch/tempo settings
     * when the user adjusts them in the equalizer. */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clear playlist commands. Clears the current playlist and
     * stops playback when requested. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes. Updates notification colors when the
     * app theme changes. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for getting playing state. Responds to requests from activities
     * that need to know the current playback state. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates. Applies new sort order when the user
     * changes sort mode in PlaylistActivity. */
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * 
     * <p>This class allows activities to obtain a reference to the MusicService
     * instance through the standard Android service binding mechanism. Activities
     * can then call public methods on the service directly.</p>
     * 
     * <h3>Usage Example</h3>
     * <pre>
     * private ServiceConnection connection = new ServiceConnection() {
     *     public void onServiceConnected(ComponentName name, IBinder service) {
     *         MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
     *         musicService = binder.getService();
     *     }
     * };
     * </pre>
     */
    public class LocalBinder extends Binder {
        
        /**
         * Returns the MusicService instance.
         * 
         * @return The MusicService instance for direct method calls
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes (Java 7 compatible for wide device support)
    // ========================================================================
    
    /**
     * Comparator for sorting songs by title in ascending alphabetical order (A-Z).
     * 
     * <p>Null titles are treated as empty strings for comparison purposes.</p>
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title in descending alphabetical order (Z-A).
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist name in ascending order (A-Z).
     * 
     * <p>When artists match, songs are further sorted by title to ensure
     * consistent ordering.</p>
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist name in descending order (Z-A).
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album name in ascending order (A-Z).
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album name in descending order (Z-A).
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre in ascending alphabetical order (A-Z).
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre in descending alphabetical order (Z-A).
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (oldest first).
     * 
     * <p>Uses the file's last modified timestamp. When dates match, songs
     * are further sorted by title for consistent ordering.</p>
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by file date (newest first).
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    /**
     * Sets the player state before update flag.
     * 
     * <p>This flag is used to preserve playback state during folder updates.
     * When set to true, the service will attempt to restore playback position
     * and state after the playlist is rebuilt.</p>
     *
     * @param context Application context
     * @param need True if player state should be preserved, false otherwise
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID.
     * 
     * <p>This method is used by EqualizerActivity to attach the system equalizer
     * to the correct audio session. The session ID is updated whenever a new
     * audio session is created (on song load or player recreation).</p>
     *
     * @return The current audio session ID, or 0 if no session exists
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * 
     * <p>This method initializes all components including MediaSession, audio focus,
     * notifications, and ExoPlayer as the default player. It also registers all
     * necessary broadcast receivers and loads saved settings.</p>
     * 
     * <p>The initialization sequence is:</p>
     * <ol>
     *   <li>Initialize notification service</li>
     *   <li>Initialize audio manager</li>
     *   <li>Load saved settings (repeat, shuffle, sort mode)</li>
     *   <li>Setup media session for lock screen controls</li>
     *   <li>Initialize EqualizerManager singleton</li>
     *   <li>Setup audio focus management</li>
     *   <li>Initialize WakeLock</li>
     *   <li>Initialize ExoPlayer as the default player</li>
     *   <li>Register all broadcast receivers</li>
     * </ol>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup media session for lock screen controls
        setupMediaSession();
        
        // Initialize EqualizerManager singleton
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        // Setup audio focus
        setupAudioFocus();
        
        // Initialize health check handler (for MediaPlayer fallback only)
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize ExoPlayer as the DEFAULT player
        initExoPlayer();
        
        // Register broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete - ExoPlayer is DEFAULT player");
    }
    
    /**
     * Initializes ExoPlayer as the default player with SoundTouch audio processing.
     * 
     * <p>This method creates the SoundTouchAudio processor for pitch/tempo effects,
     * builds the ExoPlayer instance with appropriate configuration, and sets up
     * event listeners for playback state changes.</p>
     * 
     * <p>In Media3, audio processors are set via {@link ExoPlayer#setAudioProcessors}
     * using a list/array of AudioProcessor instances. No custom AudioSink is needed
     * for basic processor integration.</p>
     * 
     * <p>If ExoPlayer cannot be initialized (library missing or other error),
     * the service will automatically fall back to MediaPlayer for the remainder
     * of the session. This fallback is permanent to avoid repeated failure loops.</p>
     */
    private void initExoPlayer() {
        if (mExoPlayerFailed) {
            Log.d(TAG, "ExoPlayer already failed, skipping init");
            return;
        }
        
        if (!PitchShifter.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mExoPlayerFailed = true;
            mIsUsingExoPlayer = false;
            return;
        }
        
        try {
            // Create SoundTouch audio processor for pitch/tempo effects
            mSoundTouchAudio = new SoundTouchAudio();
            
            // Build track selector for audio track selection (default is fine)
            DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);
            
            // Build ExoPlayer instance
            mExoPlayer = new ExoPlayer.Builder(this)
                .setTrackSelector(trackSelector)
                .build();
            
            // Set up audio processor for pitch/tempo manipulation
            // This integrates SoundTouchAudio into ExoPlayer's audio pipeline
            mExoPlayer.setAudioProcessors(new SoundTouchAudio[]{mSoundTouchAudio});
            
            // Set up player event listeners
            setupExoPlayerListeners();
            
            mIsUsingExoPlayer = true;
            Log.d(TAG, "ExoPlayer initialized successfully as DEFAULT player");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize ExoPlayer", e);
            mExoPlayerFailed = true;
            mIsUsingExoPlayer = false;
        }
    }
    
    /**
     * Sets up event listeners for ExoPlayer.
     * 
     * <p>This method configures callbacks for playback state changes, playing
     * state changes, and player errors. It handles:</p>
     * <ul>
     *   <li>Updating audio session ID for equalizer attachment</li>
     *   <li>Managing WakeLock based on playback state</li>
     *   <li>Handling song completion and advancing to next song</li>
     *   <li>Falling back to MediaPlayer on unrecoverable errors</li>
     *   <li>Broadcasting state updates to UI components</li>
     * </ul>
     */
    private void setupExoPlayerListeners() {
        if (mExoPlayer == null) return;
        
        mExoPlayer.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                switch (playbackState) {
                    case Player.STATE_READY:
                        // Player is ready to play - update audio session for equalizer
                        sCurrentAudioSessionId = mExoPlayer.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        
                        synchronized (mPlayerLock) {
                            mIsPlaying = mExoPlayer.isPlaying();
                        }
                        
                        // Acquire WakeLock if playing
                        if (mIsPlaying && mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                            Log.d(TAG, "WakeLock acquired");
                        }
                        break;
                        
                    case Player.STATE_ENDED:
                        // Song completed - handle next song or repeat
                        handleCompletion();
                        break;
                }
                
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
            }
            
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                synchronized (mPlayerLock) {
                    mIsPlaying = isPlaying;
                }
                
                // Manage WakeLock based on playback state
                if (isPlaying) {
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                        Log.d(TAG, "WakeLock acquired");
                    }
                } else {
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released");
                    }
                }
                
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
            }
            
            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                Log.e(TAG, "ExoPlayer error: " + error.getMessage());
                mExoPlayerFailed = true;
                fallbackToMediaPlayer();
            }
        });
    }
    
    /**
     * Falls back to MediaPlayer when ExoPlayer fails.
     * 
     * <p>This method preserves the current playback position and song index
     * before switching to MediaPlayer. The fallback is permanent for the
     * remainder of the session.</p>
     * 
     * <p>The fallback sequence:</p>
     * <ol>
     *   <li>Mark ExoPlayer as failed (prevents further attempts)</li>
     *   <li>Save current playback position and song index</li>
     *   <li>Release ExoPlayer resources</li>
     *   <li>Restart playback using MediaPlayer at the same position</li>
     * </ol>
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingExoPlayer) {
            return; // Already using MediaPlayer
        }
        
        Log.w(TAG, "FALLBACK: Switching from ExoPlayer to MediaPlayer");
        mIsUsingExoPlayer = false;
        mExoPlayerFailed = true;
        
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        
        if (mExoPlayer != null) {
            currentPosition = (int) mExoPlayer.getCurrentPosition();
            mExoPlayer.release();
            mExoPlayer = null;
        }
        
        if (currentIndex >= 0 && mCurrentPlaylist != null && 
            currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex + 
                  " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
        }
        
        Log.d(TAG, "Fallback to MediaPlayer complete");
    }
    
    /**
     * Called when the service is started via startService().
     * 
     * <p>Handles various actions including play/pause toggle, next/previous song,
     * direct song playback by path or position, and notification updates.</p>
     *
     * @param intent The intent that started the service (may contain action and extras)
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed by the system
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     * 
     * <p>Returns the LocalBinder instance that allows activities to obtain a
     * reference to this service for direct method calls.</p>
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * 
     * <p>Releases all resources, saves playback state to SharedPreferences,
     * stops the notification, unregisters broadcast receivers, and releases
     * all media players and audio focus.</p>
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        
        if (mExoPlayer != null) {
            mExoPlayer.release();
            mExoPlayer = null;
        }
        
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     * 
     * <p>Forwards the memory warning to the MediaPlayer fallback to check
     * if the player is still in a valid state and recover if necessary.</p>
     *
     * @param level The memory trim level (e.g., TRIM_MEMORY_RUNNING_MODERATE)
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        // Only relevant for MediaPlayer fallback (ExoPlayer handles this internally)
        if (mIsUsingExoPlayer) return;
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     * 
     * <p>Saves the current playback state before the task is removed to ensure
     * state can be restored if the app is reopened.</p>
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * 
     * <p>Default is SORT_TITLE_AZ if no saved value exists.</p>
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant (SORT_TITLE_AZ, SORT_GENRE_ZA, etc.)
     * @return A Comparator for sorting songs according to the requested mode
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the file last modified timestamp for a song.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds, or 0 if path is null
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     * 
     * <p>This method preserves the currently playing song's position in the
     * sorted list by finding its path after sorting and updating mCurrentIndex.</p>
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return;
        }
        
        // Save current song path to find it after sorting
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) {
                currentSongPath = currentSong.getPath();
            }
        }
        
        // Sort the playlist
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        // Find the current song's new position
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                Log.d(TAG, "Current song repositioned to index: " + newIndex);
            }
        }
        
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers the notification receiver for sync updates.
     * 
     * <p>Listens for SYNC_STARTED and SYNC_COMPLETE broadcasts to update the
     * notification when playlist sync operations begin or end.</p>
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver.
     * 
     * <p>Listens for UPDATE_PLAYBACK_PARAMS broadcasts to apply new pitch and
     * tempo settings from the equalizer during playback.</p>
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    /**
     * Registers the clear playlist receiver.
     * 
     * <p>Listens for CLEAR_PLAYLIST broadcasts to completely clear the current
     * playlist and stop playback.</p>
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    /**
     * Registers the theme color change receiver.
     * 
     * <p>Listens for THEME_COLOR_CHANGED broadcasts to update notification
     * colors when the app theme changes.</p>
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the receiver for getting playing state.
     * 
     * <p>Responds to GET_PLAYING_STATE broadcasts by sending a
     * PLAYING_STATE_RESPONSE broadcast with the current playing state.</p>
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    /**
     * Registers the sort mode update receiver.
     * 
     * <p>Listens for UPDATE_SORT_MODE broadcasts to apply new sort order when
     * the user changes sort mode in PlaylistActivity.</p>
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    /**
     * Safely unregisters a broadcast receiver, catching any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // ========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer.
     * 
     * <p>This prevents memory leaks and ensures that stale callbacks don't
     * trigger after the player is released.</p>
     *
     * @param player The MediaPlayer to clean (can be null)
     */
    private void removeAllListeners(android.media.MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
        }
    }
    
    /**
     * Safely resets the MediaPlayer.
     * 
     * <p>Stops playback and resets the player to its initial state while
     * preserving the instance for reuse.</p>
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on media player release");
            }
            
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) {
                }
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance for fallback playback.
     *
     * @return The MediaPlayer instance (never null)
     */
    private android.media.MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new android.media.MediaPlayer();
                mMediaPlayer.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparing.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            Log.d(TAG, "Attempting recovery from error - resetting player");
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     *
     * @return True if the player is in a valid state and ready for playback
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
    
    // ========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // ========================================================================
    
    /**
     * Starts the playback health monitoring.
     * 
     * <p>Only used for MediaPlayer fallback. ExoPlayer handles its own health
     * monitoring internally.</p>
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) {
            mHealthHandler = new Handler(Looper.getMainLooper());
        }
        
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        
        Log.d(TAG, "Health monitoring started");
    }
    
    /**
     * Stops the playback health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     * 
     * <p>Only used for MediaPlayer fallback. Detects when playback position
     * hasn't advanced for MAX_STALL_TIME_MS and triggers recovery.</p>
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingExoPlayer) return; // ExoPlayer handles its own health
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition + 
                          ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     * 
     * <p>If max recovery attempts are reached, skips to the next song.
     * Otherwise, attempts to restart the current song at the saved position.</p>
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying) {
                    mMediaPlayer.pause();
                }
            } catch (Exception ignored) {}
            
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && 
                    currentIndex < mCurrentPlaylist.size()) {
                    Log.d(TAG, "Restarting playback at index " + currentIndex);
                    prepareAndPlay(currentIndex, currentPosition);
                    
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }
    
    // ========================================================================
    // Async Operation Management
    // ========================================================================
    
    /**
     * Invalidates all pending preparations.
     * 
     * <p>Increments the global preparation ID, causing any stale async
     * callbacks to be ignored.</p>
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock.
     *
     * @return True if the lock was acquired, false if already locked
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates and updates the playback notification.
     * 
     * <p>Sets the current song information and playing state in the
     * notification that appears in the notification shade.</p>
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    /**
     * Refreshes the notification.
     * 
     * <p>Forces the notification to be recreated, useful after theme changes
     * or sync state updates.</p>
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap (can be null)
     * @param placeholder The placeholder bitmap (can be null)
     * @param artPath The file path of the album art (for caching)
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            
            if (art != null && !art.isRecycled()) {
                safeArt = art;
            }
            if (placeholder != null && !placeholder.isRecycled()) {
                safePlaceholder = placeholder;
            }
            
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     * 
     * <p>Saves current index, position, playing state, repeat mode, shuffle
     * state, and last song path.</p>
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state (including position to restore after resume).
     */
    private void saveFullState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_CURRENT_POSITION, getCurrentPosition());
        editor.putBoolean(KEY_LAST_PLAYING, mIsPlaying);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        if (getCurrentSong() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }
        editor.apply();
    }
    
    /**
     * Gets the saved playback position from SharedPreferences.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before restart.
     *
     * @return True if was playing before last shutdown
     */
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path from SharedPreferences.
     *
     * @return The saved song path, or null if not saved
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state (position and playing flag) to SharedPreferences.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Sets the current playlist.
     *
     * @param playlist The new playlist (can be null or empty)
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            // Save current position to preferences BEFORE any changes
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                // Get current position from active player
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    currentPosition = (int) mExoPlayer.getCurrentPosition();
                    wasPlaying = mExoPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                // Save to SharedPreferences immediately
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            
            // Handle empty playlist
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    mExoPlayer.stop();
                }
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            
            // Sort the new playlist according to current sort mode
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // Check if playlist is actually different (optimization)
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                boolean same = true;
                for (int i = 0; i < playlist.size(); i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    broadcastUpdate();
                    return;
                }
            }
            
            // Force player reset when not preserving current song
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                invalidateAllPreparations();
                resetPlayerSafely();
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    mExoPlayer.stop();
                }
                mIsPlaying = false;
            }
            
            // Find the current song in the new playlist (if preserveCurrentSong is true)
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                // Fallback to saved path if current song not found
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            // Replace the entire playlist
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            // Set the current index - respects preserveCurrentSong flag
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                // Only restore saved index when preserving the current song
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex = 0;
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                mCurrentIndex = -1;
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            
            saveCurrentPlayingIndex();
            
            // Resume playback if needed (only when preserving current song)
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                // Need to restart playback from saved position
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    playSongAtPosition(correctIndex, savedPosition);
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    playSongAtPosition(mCurrentIndex, savedPosition);
                }
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                // Just prepare the song without playing
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    prepareExoPlayer(mCurrentIndex);
                } else {
                    prepareOnly(mCurrentIndex);
                }
                mIsPlaying = false;
                createNotification();
            } else if (!preserveCurrentSong) {
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mExoPlayer != null && mIsUsingExoPlayer) {
                mExoPlayer.stop();
            }
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on stop");
            }
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) {
                mNotificationService.stopForeground();
            }
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist (waits for current song to finish).
     *
     * @param newPlaylist The new playlist to apply at the end of current song
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     * 
     * <p>ExoPlayer is the DEFAULT player for ALL playback. MediaPlayer is used
     * ONLY as a fallback when ExoPlayer fails.</p>
     *
     * @param index The song index in the current playlist
     */
    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // DEFAULT: Use ExoPlayer for ALL playback
        if (!mExoPlayerFailed && mExoPlayer != null && mIsUsingExoPlayer) {
            playSongWithExoPlayer(index);
        } 
        // FALLBACK: Only if ExoPlayer failed at runtime
        else {
            Log.w(TAG, "ExoPlayer unavailable, using MediaPlayer fallback");
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Plays a song using ExoPlayer (DEFAULT).
     *
     * @param index Index of song to play
     */
    private void playSongWithExoPlayer(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "Invalid song at index " + index);
            fallbackToMediaPlayer();
            return;
        }
        
        if (mExoPlayer == null) {
            initExoPlayer();
        }
        
        if (mExoPlayer == null || !mIsUsingExoPlayer) {
            Log.e(TAG, "ExoPlayer is null or not active, falling back");
            fallbackToMediaPlayer();
            prepareAndPlay(index, 0);
            return;
        }
        
        try {
            // Update audio processor with current pitch/tempo
            updatePlaybackParams();
            
            // Build media item and play
            MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(new File(song.getPath())));
            mExoPlayer.setMediaItem(mediaItem);
            mExoPlayer.prepare();
            mExoPlayer.play();
            
            mCurrentIndex = index;
            savePlayerState();
            
            createNotification();
            broadcastUpdate();
            
            Log.d(TAG, "ExoPlayer playing: " + song.getPath());
            
        } catch (Exception e) {
            Log.e(TAG, "Error playing with ExoPlayer", e);
            fallbackToMediaPlayer();
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Prepares ExoPlayer without starting playback.
     *
     * @param index Index of song to prepare
     */
    private void prepareExoPlayer(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "Invalid song at index " + index);
            return;
        }
        
        if (mExoPlayer == null || !mIsUsingExoPlayer) {
            return;
        }
        
        try {
            MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(new File(song.getPath())));
            mExoPlayer.setMediaItem(mediaItem);
            mExoPlayer.prepare();
            mCurrentIndex = index;
            
        } catch (Exception e) {
            Log.e(TAG, "Error preparing ExoPlayer", e);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // DEFAULT: Use ExoPlayer for ALL playback
        if (!mExoPlayerFailed && mExoPlayer != null && mIsUsingExoPlayer) {
            playSongWithExoPlayer(index);
            if (position > 0) {
                mExoPlayer.seekTo(position);
            }
        } 
        // FALLBACK: Only if ExoPlayer failed at runtime
        else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The file path of the song to play
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        // If currently playing, just pause
        if (mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying()) {
            pause();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
            pause();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        // Not playing - start playback
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            String songPath = null;
            
            // Get current song path, or first song if none
            if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                Song current = mCurrentPlaylist.get(mCurrentIndex);
                if (current != null) {
                    songPath = current.getPath();
                }
            }
            
            if (songPath == null && !mCurrentPlaylist.isEmpty()) {
                songPath = mCurrentPlaylist.get(0).getPath();
            }
            
            if (songPath != null) {
                playSongByPath(songPath);
            }
        }
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        // DEFAULT: Use ExoPlayer
        if (mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying()) {
            mExoPlayer.pause();
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on pause");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            stopHealthMonitoring();
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.pause();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot pause - invalid state", e);
                    }
                    mIsPlaying = false;
                    
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released on pause");
                    }
                    
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            }
        }
    }
    
    /**
     * Resumes playback after being paused.
     */
    public void resume() {
        // DEFAULT: Use ExoPlayer
        if (mExoPlayer != null && mIsUsingExoPlayer && !mExoPlayer.isPlaying() && mExoPlayer.getPlaybackState() == Player.STATE_READY) {
            mExoPlayer.play();
            mIsPlaying = true;
            
            if (mWakeLock != null && !mWakeLock.isHeld()) {
                mWakeLock.acquire();
                Log.d(TAG, "WakeLock acquired on resume");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                    try {
                        if (!mIsPlaying) {
                            requestAudioFocus();
                            updatePlaybackParams();
                            mMediaPlayer.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired on resume");
                            }
                            
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Resume failed - invalid state", e);
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                    playSong(0);
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player to the beginning of the song.
     */
    public void stop() {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            mExoPlayer.stop();
            mIsPlaying = false;
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot stop - invalid state", e);
                    }
                    mIsPlaying = false;
                }
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        // DEFAULT: Use ExoPlayer
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            mExoPlayer.seekTo(position);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        int duration = mMediaPlayer.getDuration();
                        if (position >= 0 && position < duration) {
                            mMediaPlayer.seekTo(position);
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            savePlayerState();
                            saveFullState();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot seek - invalid state", e);
                    }
                }
            }
        }
    }
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     * 
     * <p>This method is called when the user adjusts the equalizer controls
     * and applies the new tempo and pitch settings to the active player.</p>
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        // DEFAULT: Use SoundTouchAudio processor with ExoPlayer
        if (mSoundTouchAudio != null) {
            mSoundTouchAudio.setParameters(tempo, semitones);
            Log.d(TAG, "SoundTouchAudio: tempo=" + tempo + ", pitch=" + semitones + "st");
            return;
        }
        
        // FALLBACK: Use MediaPlayer's PlaybackParams (API 23+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>Determines the next action based on repeat mode and playlist state.
     * Also handles pending playlist updates that were waiting for the current
     * song to finish.</p>
     */
    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        // Apply pending playlist if exists
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                mCurrentIndex = savedIndex;
            } else {
                mCurrentIndex = 0;
            }
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        
        // Handle repeat modes
        if (mRepeatMode == 2) {
            // Repeat one: restart the same song
            playSong(mCurrentIndex);
        } else if (mRepeatMode == 1) {
            // Repeat all: play next song (wraps around)
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            // Normal playback: play next song
            playNext();
        } else {
            // End of playlist: stop playback
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            if (mExoPlayer != null && mIsUsingExoPlayer) {
                mExoPlayer.stop();
            } else {
                synchronized (mPlayerLock) {
                    if (mMediaPlayer != null) {
                        try {
                            mMediaPlayer.pause();
                        } catch (Exception ignored) {}
                        try {
                            mMediaPlayer.seekTo(0);
                        } catch (Exception ignored) {}
                    }
                }
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position, or 0 if not available
     */
    public int getCurrentPosition() {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            return (int) mExoPlayer.getCurrentPosition();
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            long duration = mExoPlayer.getDuration();
            return duration > 0 ? (int) duration : 0;
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if ExoPlayer is prepared and ready for playback.
     *
     * @return True if ExoPlayer has a loaded and prepared song
     */
    public boolean isExoPlayerPrepared() {
        return mExoPlayer != null && mIsUsingExoPlayer && 
               mExoPlayer.getPlaybackState() == Player.STATE_READY;
    }
    
    /**
     * Checks if ExoPlayer is currently playing audio.
     *
     * @return True if ExoPlayer is playing
     */
    public boolean isExoPlayerPlaying() {
        return mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying();
    }
    
    /**
     * Checks if MediaPlayer (fallback) is prepared and ready for playback.
     *
     * @return True if MediaPlayer has a loaded and prepared song
     */
    public boolean isMediaPlayerPrepared() {
        return mMediaPlayer != null && isPlayerReady();
    }
    
    /**
     * Checks if MediaPlayer (fallback) is currently playing audio.
     *
     * @return True if MediaPlayer is playing
     */
    public boolean isMediaPlayerPlaying() {
        return mMediaPlayer != null && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if any player is prepared and ready for playback.
     *
     * @return True if either ExoPlayer or MediaPlayer has a loaded and prepared song
     */
    public boolean isAnyPlayerPrepared() {
        return isExoPlayerPrepared() || isMediaPlayerPrepared();
    }
    
    /**
     * Checks if any player is currently playing audio.
     *
     * @return True if either ExoPlayer or MediaPlayer is playing
     */
    public boolean isAnyPlayerPlaying() {
        if (isExoPlayerPlaying()) {
            return true;
        }
        if (isMediaPlayerPlaying()) {
            return true;
        }
        return false;
    }
    
    /**
     * Checks if playback is currently active (any player playing).
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        return isAnyPlayerPlaying();
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(android.media.MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song, or null if no song is playing
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index, or -1 if no song selected
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth headset is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // MediaPlayer Fallback Methods
    // ========================================================================
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     * This is the FALLBACK method used ONLY when ExoPlayer fails.
     *
     * @param index The song index
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            android.media.MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration: " + duration);
                                mIsPlaying = false;
                                broadcastUpdate();
                                return;
                            }
                            
                            if (finalSeek > 0 && finalSeek < duration - 500) {
                                mp.seekTo(finalSeek);
                            }
                            
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mCurrentIndex = finalIndex;
                            saveCurrentPlayingIndex();
                            
                            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(android.media.MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired");
                            }
                            
                            updateMediaSessionPlaybackState();
                            broadcastUpdate();
                            createNotification();
                            updatePlaybackParams();
                            
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying = false;
                            broadcastUpdate();
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    /**
     * Prepares a song without starting playback (MediaPlayer fallback only).
     *
     * @param index The song index
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            android.media.MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance in prepareOnly, ignoring");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(android.media.MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     * 
     * <p>Creates a MediaSession that responds to play/pause, next/previous,
     * and stop commands from lock screen controls and Bluetooth devices.</p>
     */
    private void setupMediaSession() {
        try {
            mMediaSession = new MediaSession(this, "LlamaMusicService");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override
                public void onPlay() {
                    if (!mIsPlaying && mCurrentIndex >= 0) {
                        resume();
                    } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                        playSong(0);
                    }
                }
                
                @Override
                public void onPause() {
                    if (mIsPlaying) {
                        pause();
                    }
                }
                
                @Override
                public void onSkipToNext() {
                    playNext();
                }
                
                @Override
                public void onSkipToPrevious() {
                    playPrevious();
                }
                
                @Override
                public void onStop() {
                    pause();
                }
                
                @Override
                public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId != null) {
                        try {
                            playSong(Integer.parseInt(mediaId));
                        } catch (NumberFormatException ignored) {}
                    }
                }
            });
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception e) {
            Log.e(TAG, "Failed to setup MediaSession", e);
        }
    }
    
    /**
     * Sets up audio focus for proper audio ducking and interruption handling.
     * 
     * <p>Requests audio focus when playback starts and handles focus changes
     * from other apps (phone calls, notifications, other music apps).</p>
     */
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.media.AudioAttributes audioAttributes = new android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     *
     * @param songPath The path of the song to update
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }
    
    /**
     * Handles the close action from the notification.
     * 
     * <p>Stops playback, clears the playlist, and closes the app.</p>
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            mExoPlayer.stop();
        }
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus from the system.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a playback state update to activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) {
                    pause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // SoundTouch doesn't need special handling, AudioTrack handles it
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                // No action needed - playback can resume if it was playing
                if (!mIsPlaying && wasPlayingBeforeRestart()) {
                    resume();
                }
                break;
            default:
                break;
        }
    }
}