/**
 * Llama Music Player – MusicService
 * ============================================================================
 * Background service that handles audio playback with independent pitch and
 * tempo control using a custom MediaExtractor/MediaCodec pipeline and the
 * SoundTouch native library. Supports all audio formats, repeat and shuffle
 * modes, and works from Android 5.0 (API 21) upward.
 *
 * <p>This service integrates with EqualizerManager for audio effects and
 * NotificationService for media notifications. All public methods are
 * thread-safe.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * MusicService – Background playback service with pitch/tempo shifting.
 * All public methods are thread-safe and can be called from any thread.
 */
public class MusicService extends Service implements AudioManager.OnAudioFocusChangeListener {

    // ========================================================================
    // Constants
    // ========================================================================
    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";

    // Preference Keys
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_WAS_PLAYING = "was_playing";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_SORT_MODE = "sort_mode";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SPEED_LEVEL = "speed_level";
    private static final String KEY_PITCH_LEVEL = "pitch_level";
    private static final String KEY_BLUETOOTH_CONNECTED = "bluetooth_connected";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    // Broadcast Actions
    public static final String ACTION_PLAY = "ACTION_PLAY";
    public static final String ACTION_PAUSE = "ACTION_PAUSE";
    public static final String ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE";
    public static final String ACTION_NEXT = "ACTION_NEXT";
    public static final String ACTION_PREV = "ACTION_PREV";
    public static final String ACTION_STOP = "ACTION_STOP";
    public static final String ACTION_SEEK = "ACTION_SEEK";
    public static final String ACTION_UPDATE_PLAYER = "UPDATE_PLAYER";
    public static final String ACTION_PLAYLIST_UPDATED = "PLAYLIST_UPDATED";
    public static final String ACTION_STOP_NOTIFICATION = "ACTION_STOP_NOTIFICATION";

    // Repeat Modes
    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;

    // Effect Ranges
    private static final float MIN_SPEED = 0.5f;
    private static final float MAX_SPEED = 1.5f;
    private static final float MIN_PITCH_SEMITONES = -6.0f;
    private static final float MAX_PITCH_SEMITONES = 6.0f;

    // Audio Processing Constants
    private static final int QUEUE_CAPACITY = 16;
    private static final int TIMEOUT_US = 10000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    private static final int RECOVERY_DELAY_MS = 500;

    // ========================================================================
    // Member Variables - Core Components
    // ========================================================================
    private final IBinder mBinder = new LocalBinder();
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread mDecodeThread;
    private Handler mDecodeHandler;
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;

    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private PitchShifter mPitchShifter;
    private BlockingQueue<short[]> mAudioQueue;
    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;
    private MediaSession mMediaSession;
    private NotificationService mNotificationService;

    // ========================================================================
    // Member Variables - Playback State
    // ========================================================================
    private ArrayList<Song> mPlaylist = new ArrayList<>();
    private int mCurrentIndex = -1;
    private boolean mIsPlaying = false;
    private boolean mIsPaused = false;
    private int mRepeatMode = REPEAT_OFF;
    private boolean mIsShuffle = false;
    private Random mRandom = new Random();
    private ArrayList<Integer> mShuffleHistory = new ArrayList<>();

    // ========================================================================
    // Member Variables - Audio Format
    // ========================================================================
    private int mSampleRate = 44100;
    private int mChannelCount = 2;
    private int mAudioSessionId = 0;
    private long mDurationUs = 0;
    private long mCurrentPositionUs = 0;

    // ========================================================================
    // Member Variables - Effect State
    // ========================================================================
    private float mCurrentSpeed = 1.0f;
    private float mCurrentPitchSemitones = 0.0f;
    private int mSpeedLevel = 1000;
    private int mPitchLevel = 1000;
    private boolean mSoundTouchAvailable;

    // ========================================================================
    // Member Variables - Control Flags
    // ========================================================================
    private final AtomicBoolean mIsDecoding = new AtomicBoolean(false);
    private final AtomicBoolean mIsPlayingAudio = new AtomicBoolean(false);
    private final AtomicBoolean mInputEOS = new AtomicBoolean(false);
    private final AtomicBoolean mOutputEOS = new AtomicBoolean(false);
    private final AtomicLong mSeekPositionUs = new AtomicLong(-1);
    private final AtomicBoolean mSeekPending = new AtomicBoolean(false);
    private final AtomicInteger mRecoveryAttempts = new AtomicInteger(0);
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);

    // ========================================================================
    // Member Variables - Bluetooth & State Management
    // ========================================================================
    private boolean mBluetoothConnected = false;
    private boolean mPlayerStateBeforeUpdate = false;

    // ========================================================================
    // Member Variables - Audio Focus
    // ========================================================================
    private Object mAudioFocusRequest;

    // ========================================================================
    // Member Variables - Broadcast Receivers
    // ========================================================================
    private BroadcastReceiver mControlReceiver;
    private BroadcastReceiver mEffectReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Binder for activities to obtain a reference to this service.
     */
    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Lifecycle Methods
    // ========================================================================

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate - SoundTouch available: " + PitchShifter.isLibraryAvailable());

        mSoundTouchAvailable = PitchShifter.isLibraryAvailable();
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        // Load saved state
        loadState();

        // Setup wake lock
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Llama:Playback");
        mWakeLock.setReferenceCounted(false);

        // Setup queue
        mAudioQueue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);

        // Setup threads
        mDecodeThread = new HandlerThread("AudioDecoder");
        mDecodeThread.start();
        mDecodeHandler = new Handler(mDecodeThread.getLooper());

        mPlaybackThread = new HandlerThread("AudioPlayback");
        mPlaybackThread.start();
        mPlaybackHandler = new Handler(mPlaybackThread.getLooper());

        // Setup notification service
        mNotificationService = new NotificationService(this);

        // Setup media session
        setupMediaSession();

        // Setup audio focus
        setupAudioFocus();

        // Register receivers
        registerControlReceiver();
        registerEffectReceiver();

        // Apply saved effects
        applyEffectLevels();

        Log.d(TAG, "onCreate complete");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            handleControlAction(action);
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");

        saveState();
        stopPlayback();

        // Clean up threads
        if (mDecodeThread != null) mDecodeThread.quitSafely();
        if (mPlaybackThread != null) mPlaybackThread.quitSafely();

        // Release wake lock
        if (mWakeLock.isHeld()) mWakeLock.release();

        // Release notification service
        if (mNotificationService != null) mNotificationService.release();

        // Release media session
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
        }

        // Unregister receivers
        try {
            if (mControlReceiver != null) unregisterReceiver(mControlReceiver);
            if (mEffectReceiver != null) unregisterReceiver(mEffectReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering receivers", e);
        }

        // Abandon audio focus
        abandonAudioFocus();

        // Detach equalizer
        EqualizerManager.getInstance(this).detach();

        super.onDestroy();
    }

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private void registerControlReceiver() {
        mControlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null && intent.getAction() != null) {
                    handleControlAction(intent.getAction());
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_PLAY);
        filter.addAction(ACTION_PAUSE);
        filter.addAction(ACTION_PLAY_PAUSE);
        filter.addAction(ACTION_NEXT);
        filter.addAction(ACTION_PREV);
        filter.addAction(ACTION_STOP);
        filter.addAction(ACTION_SEEK);
        filter.addAction("PLAY_SONG");
        registerReceiver(mControlReceiver, filter);
    }

    private void registerEffectReceiver() {
        mEffectReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    int speed = intent.getIntExtra("speed", 1000);
                    int pitch = intent.getIntExtra("pitch", 1000);
                    setSpeedLevel(speed);
                    setPitchLevel(pitch);
                }
            }
        };

        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mEffectReceiver, filter);
    }

    private void handleControlAction(String action) {
        switch (action) {
            case ACTION_PLAY:
                play();
                break;
            case ACTION_PAUSE:
                pause();
                break;
            case ACTION_PLAY_PAUSE:
                if (mIsPlaying && !mIsPaused) pause();
                else play();
                break;
            case ACTION_NEXT:
                next();
                break;
            case ACTION_PREV:
                previous();
                break;
            case ACTION_STOP:
                stop();
                break;
            case ACTION_SEEK:
                // Seek handled via intent extras in onStartCommand
                break;
            case "PLAY_SONG":
                // Handled in onStartCommand with extras
                break;
        }
    }

    // ========================================================================
    // Public Playback Control API
    // ========================================================================

    /**
     * Plays the song at the specified index.
     *
     * @param index playlist index
     */
    public void playSong(int index) {
        if (mPlaylist == null || index < 0 || index >= mPlaylist.size()) {
            Log.e(TAG, "playSong: invalid index " + index);
            return;
        }

        if (!mIsTransitioning.compareAndSet(false, true)) {
            Log.d(TAG, "playSong: transition already in progress");
            return;
        }

        try {
            stopPlayback();
            mCurrentIndex = index;
            mIsPlaying = true;
            mIsPaused = false;
            mRecoveryAttempts.set(0);
            mCurrentPositionUs = 0;
            mInputEOS.set(false);
            mOutputEOS.set(false);

            if (mAudioQueue != null) mAudioQueue.clear();

            Song song = mPlaylist.get(mCurrentIndex);
            String filePath = song.getPath();

            if (filePath == null) {
                Log.e(TAG, "playSong: null file path");
                handlePlaybackError();
                return;
            }

            File audioFile = new File(filePath);
            if (!audioFile.exists()) {
                Log.e(TAG, "playSong: file not found - " + filePath);
                handlePlaybackError();
                return;
            }

            if (mSoundTouchAvailable) {
                startSoundTouchPlayback(audioFile);
            } else {
                Log.w(TAG, "SoundTouch not available, cannot play");
                handlePlaybackError();
                return;
            }

            saveCurrentSong();
            broadcastStateUpdate();
            updateMediaSession();
            updateNotification();

            Log.d(TAG, "playSong: started " + song.getTitle());

        } finally {
            mMainHandler.postDelayed(() -> mIsTransitioning.set(false), 500);
        }
    }

    /**
     * Plays the song identified by its file path.
     *
     * @param filePath absolute file path
     */
    public void playSongByPath(@NonNull String filePath) {
        if (mPlaylist == null || filePath == null) return;

        for (int i = 0; i < mPlaylist.size(); i++) {
            Song song = mPlaylist.get(i);
            if (song != null && filePath.equals(song.getPath())) {
                playSong(i);
                return;
            }
        }
    }

    /**
     * Plays or resumes playback.
     */
    public void play() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;
        if (mCurrentIndex < 0) mCurrentIndex = 0;

        if (mAudioTrack != null && mIsPaused) {
            requestAudioFocus();
            mAudioTrack.play();
            mIsPaused = false;
            mIsPlaying = true;
            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);
            broadcastStateUpdate();
            updateNotification();
        } else if (mCurrentIndex >= 0) {
            playSong(mCurrentIndex);
        }
    }

    /**
     * Resumes playback from paused state.
     */
    public void resume() {
        play();
    }

    /**
     * Pauses playback.
     */
    public void pause() {
        if (mAudioTrack != null && mIsPlaying && !mIsPaused) {
            mAudioTrack.pause();
            mIsPaused = true;
            mIsPlaying = false;
            if (mWakeLock.isHeld()) mWakeLock.release();
            broadcastStateUpdate();
            updateNotification();
            Log.d(TAG, "pause: playback paused");
        }
    }

    /**
     * Stops playback and releases resources.
     */
    public void stop() {
        stopPlayback();
        mIsPlaying = false;
        mIsPaused = false;
        if (mWakeLock.isHeld()) mWakeLock.release();
        broadcastStateUpdate();
        updateNotification();
        Log.d(TAG, "stop: playback stopped");
    }

    /**
     * Skips to the next song.
     */
    public void next() {
        playNext();
    }

    /**
     * Skips to the next song.
     */
    public void playNext() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;

        int nextIndex;
        if (mIsShuffle) {
            nextIndex = getNextShuffleIndex();
        } else {
            nextIndex = (mCurrentIndex + 1) % mPlaylist.size();
        }

        playSong(nextIndex);
    }

    /**
     * Skips to the previous song.
     */
    public void previous() {
        playPrevious();
    }

    /**
     * Skips to the previous song.
     */
    public void playPrevious() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;

        int prevIndex;
        if (mIsShuffle && mShuffleHistory.size() >= 2) {
            prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
        } else {
            prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mPlaylist.size() - 1;
        }

        playSong(prevIndex);
    }

    /**
     * Seeks to the specified position in milliseconds.
     *
     * @param positionMs position in milliseconds
     */
    public void seekTo(int positionMs) {
        if (mExtractor != null) {
            long seekUs = positionMs * 1000L;
            mSeekPositionUs.set(seekUs);
            mSeekPending.set(true);
            mExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            if (mDecoder != null) mDecoder.flush();
            if (mAudioQueue != null) mAudioQueue.clear();
            mCurrentPositionUs = seekUs;
            broadcastStateUpdate();
        }
    }

    // ========================================================================
    // Playlist Management
    // ========================================================================

    /**
     * Sets the current playlist.
     *
     * @param playlist the list of songs
     */
    public void setPlaylist(@NonNull ArrayList<Song> playlist) {
        mPlaylist = new ArrayList<>(playlist);
        if (mIsShuffle) buildShuffleHistory();

        // Try to restore previous song
        String lastSongPath = getLastSongPath();
        if (lastSongPath != null) {
            for (int i = 0; i < mPlaylist.size(); i++) {
                Song song = mPlaylist.get(i);
                if (song != null && lastSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    break;
                }
            }
        }

        if (mCurrentIndex < 0 && !mPlaylist.isEmpty()) {
            mCurrentIndex = 0;
        }

        broadcastPlaylistUpdate();
        updateNotification();
        Log.d(TAG, "Playlist set: " + mPlaylist.size() + " songs");
    }

    /**
     * Returns the current playlist.
     *
     * @return the playlist
     */
    @NonNull
    public ArrayList<Song> getPlaylist() {
        return mPlaylist;
    }

    /**
     * Returns the currently playing song.
     *
     * @return the current song, or null if none
     */
    @Nullable
    public Song getCurrentSong() {
        if (mCurrentIndex >= 0 && mCurrentIndex < mPlaylist.size()) {
            return mPlaylist.get(mCurrentIndex);
        }
        return null;
    }

    /**
     * Returns the current playlist index.
     *
     * @return current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return position in ms
     */
    public int getCurrentPosition() {
        return (int) (mCurrentPositionUs / 1000);
    }

    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return duration in ms
     */
    public int getDuration() {
        return (int) (mDurationUs / 1000);
    }

    /**
     * Returns true if playback is active.
     *
     * @return true if playing
     */
    public boolean isPlaying() {
        return mIsPlaying && !mIsPaused;
    }

    /**
     * Returns true if any player is playing.
     *
     * @return true if playing
     */
    public boolean isAnyPlayerPlaying() {
        return mIsPlaying && !mIsPaused;
    }

    /**
     * Returns true if any player is prepared (has audio to play).
     *
     * @return true if prepared
     */
    public boolean isAnyPlayerPrepared() {
        return mAudioTrack != null || mDecoder != null;
    }

    // ========================================================================
    // Repeat and Shuffle
    // ========================================================================

    /**
     * Sets repeat mode.
     *
     * @param mode 0=off, 1=all, 2=one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        saveRepeatMode();
        Log.d(TAG, "Repeat mode set to: " + mode);
        updateNotification();
    }

    /**
     * Returns the current repeat mode.
     *
     * @return repeat mode
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }

    /**
     * Enables or disables shuffle.
     *
     * @param shuffle true to enable
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle) buildShuffleHistory();
        saveShuffleMode();
        Log.d(TAG, "Shuffle set to: " + shuffle);
        updateNotification();
    }

    /**
     * Returns true if shuffle is enabled.
     *
     * @return shuffle state
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }

    // ========================================================================
    // Effect Control
    // ========================================================================

    /**
     * Sets the speed level (0-2000 mapping to 0.5x-1.5x).
     *
     * @param level speed level
     */
    public void setSpeedLevel(int level) {
        mSpeedLevel = Math.max(0, Math.min(2000, level));
        mCurrentSpeed = MIN_SPEED + (mSpeedLevel / 2000.0f) * (MAX_SPEED - MIN_SPEED);

        if (mPitchShifter != null) {
            mPitchShifter.setTempo(mCurrentSpeed);
        }

        saveEffectLevels();
        Log.d(TAG, "Speed set to: " + mCurrentSpeed);
        updateNotification();
    }

    /**
     * Sets the pitch level (0-2000 mapping to -6 to +6 semitones).
     *
     * @param level pitch level
     */
    public void setPitchLevel(int level) {
        mPitchLevel = Math.max(0, Math.min(2000, level));
        mCurrentPitchSemitones = MIN_PITCH_SEMITONES + (mPitchLevel / 2000.0f) * (MAX_PITCH_SEMITONES - MIN_PITCH_SEMITONES);

        if (mPitchShifter != null) {
            mPitchShifter.setPitch(mCurrentPitchSemitones);
        }

        saveEffectLevels();
        Log.d(TAG, "Pitch set to: " + mCurrentPitchSemitones + " semitones");
        updateNotification();
    }

    /**
     * Returns the current speed.
     *
     * @return speed (0.5-1.5)
     */
    public float getCurrentSpeed() {
        return mCurrentSpeed;
    }

    /**
     * Returns the current pitch shift in semitones.
     *
     * @return semitones (-6 to +6)
     */
    public float getCurrentPitchSemitones() {
        return mCurrentPitchSemitones;
    }

    /**
     * Returns the speed level (0-2000).
     *
     * @return speed level
     */
    public int getSpeedLevel() {
        return mSpeedLevel;
    }

    /**
     * Returns the pitch level (0-2000).
     *
     * @return pitch level
     */
    public int getPitchLevel() {
        return mPitchLevel;
    }

    /**
     * Returns true if SoundTouch is available.
     *
     * @return true if available
     */
    public boolean isSoundTouchAvailable() {
        return mSoundTouchAvailable;
    }

    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return audio session ID
     */
    public int getAudioSessionId() {
        return mAudioSessionId;
    }

    // ========================================================================
    // Notification & UI Updates
    // ========================================================================

    /**
     * Refreshes the notification with current playback state.
     */
    public void refreshNotification() {
        updateNotification();
    }

    /**
     * Sets the notification album art.
     *
     * @param art         album art bitmap
     * @param placeholder placeholder bitmap
     * @param artPath     path to the art
     */
    public void setNotificationAlbumArt(@Nullable android.graphics.Bitmap art,
                                        @Nullable android.graphics.Bitmap placeholder,
                                        @Nullable String artPath) {
        if (mNotificationService != null) {
            mNotificationService.setAlbumArt(art, placeholder, artPath);
        }
    }

    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        editor.putInt(KEY_SPEED_LEVEL, mSpeedLevel);
        editor.putInt(KEY_PITCH_LEVEL, mPitchLevel);
        editor.putBoolean(KEY_BLUETOOTH_CONNECTED, mBluetoothConnected);
        editor.putBoolean(KEY_WAS_PLAYING, mIsPlaying && !mIsPaused);

        if (getCurrentSong() != null && getCurrentSong().getPath() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }

        editor.apply();
        Log.d(TAG, "Player state saved");
    }

    /**
     * Static method to set player state before update.
     *
     * @param context context
     * @param state   state to set
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean state) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, state).apply();
    }

    /**
     * Static method to clear player state before update.
     *
     * @param context context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Sets Bluetooth connection state.
     *
     * @param connected true if connected
     */
    public void setBluetoothConnected(boolean connected) {
        mBluetoothConnected = connected;
        savePlayerState();
        Log.d(TAG, "Bluetooth connected: " + connected);
    }

    /**
     * Handles media button events.
     *
     * @param keyCode the key code
     */
    public void handleMediaButton(int keyCode) {
        switch (keyCode) {
            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (mIsPlaying && !mIsPaused) pause();
                else play();
                break;
            case android.view.KeyEvent.KEYCODE_MEDIA_NEXT:
                next();
                break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                previous();
                break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY:
                play();
                break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PAUSE:
                pause();
                break;
            case android.view.KeyEvent.KEYCODE_MEDIA_STOP:
                stop();
                break;
        }
    }

    /**
     * Refreshes metadata for a specific song after editing.
     *
     * @param songPath        path of the song
     * @param title           new title
     * @param artist          new artist
     * @param album           new album
     * @param genre           new genre
     * @param albumArtBytes   new album art bytes
     * @param albumArtRemoved true if album art was removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, @Nullable String title,
                                       @Nullable String artist, @Nullable String album,
                                       @Nullable String genre, @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        // Update in-memory playlist
        for (int i = 0; i < mPlaylist.size(); i++) {
            Song song = mPlaylist.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                if (title != null) song.setTitle(title);
                if (artist != null) song.setArtist(artist);
                if (album != null) song.setAlbum(album);
                if (genre != null) song.setGenre(genre);
                break;
            }
        }

        // Update current song display
        Song currentSong = getCurrentSong();
        if (currentSong != null && songPath.equals(currentSong.getPath())) {
            broadcastStateUpdate();
            updateNotification();
        }

        Log.d(TAG, "Metadata refreshed for: " + songPath);
    }

    // ========================================================================
    // Internal Playback Implementation
    // ========================================================================

    private void startSoundTouchPlayback(File audioFile) {
        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(audioFile.getAbsolutePath());

            int audioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrackIndex = i;
                    break;
                }
            }

            if (audioTrackIndex == -1) {
                Log.e(TAG, "No audio track found");
                handlePlaybackError();
                return;
            }

            mExtractor.selectTrack(audioTrackIndex);
            MediaFormat format = mExtractor.getTrackFormat(audioTrackIndex);
            mSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mChannelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDurationUs = format.containsKey(MediaFormat.KEY_DURATION) ? format.getLong(MediaFormat.KEY_DURATION) : 0;

            String mime = format.getString(MediaFormat.KEY_MIME);
            mDecoder = MediaCodec.createDecoderByType(mime);
            mDecoder.configure(format, null, null, 0);
            mDecoder.start();

            mPitchShifter = new PitchShifter(mSampleRate, mChannelCount);
            mPitchShifter.setTempo(mCurrentSpeed);
            mPitchShifter.setPitch(mCurrentPitchSemitones);

            initAudioTrack();

            requestAudioFocus();

            mAudioTrack.play();

            mIsDecoding.set(true);
            mIsPlayingAudio.set(true);
            mDecodeHandler.post(this::decodeLoop);
            mPlaybackHandler.post(this::playbackLoop);

            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);

            Log.d(TAG, "SoundTouch playback started: " + mSampleRate + "Hz, " + mChannelCount + "ch");

        } catch (Exception e) {
            Log.e(TAG, "Failed to start SoundTouch playback", e);
            handlePlaybackError();
        }
    }

    private void initAudioTrack() {
        if (mAudioTrack != null) {
            try {
                if (mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing audio track", e);
            }
        }

        int channelConfig = (mChannelCount == 1) ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
        int bufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        bufferSize = Math.max(bufferSize, mSampleRate * mChannelCount * 2 / 10);

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        AudioFormat format = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .build();
        mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();

        mAudioSessionId = mAudioTrack.getAudioSessionId();
        EqualizerManager.getInstance(this).attachToAudioSession(mAudioSessionId);
    }

    private void decodeLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;

        while (mIsDecoding.get() && !mOutputEOS.get()) {
            if (mSeekPending.getAndSet(false)) {
                mDecoder.flush();
                inputDone = false;
                mInputEOS.set(false);
                continue;
            }

            if (!inputDone) {
                int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
                if (inputIndex >= 0) {
                    ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                    if (inputBuffer != null) {
                        int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                        if (sampleSize < 0) {
                            mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                            mInputEOS.set(true);
                        } else {
                            long presentationUs = mExtractor.getSampleTime();
                            mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationUs, 0);
                            mExtractor.advance();
                        }
                    }
                }
            }

            int outputIndex = mDecoder.dequeueOutputBuffer(info, TIMEOUT_US);
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                if (outputBuffer != null && info.size > 0) {
                    int sampleCount = info.size / 2;
                    short[] pcm = new short[sampleCount];
                    outputBuffer.order(ByteOrder.LITTLE_ENDIAN);
                    outputBuffer.asShortBuffer().get(pcm);

                    try {
                        mAudioQueue.offer(pcm, 50, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }

                    if (info.presentationTimeUs > 0) {
                        mCurrentPositionUs = info.presentationTimeUs;
                    }
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    mOutputEOS.set(true);
                    mAudioQueue.offer(new short[0]);
                }
            }
        }
    }

    private void playbackLoop() {
        while (mIsPlayingAudio.get() && !mOutputEOS.get()) {
            short[] pcm;
            try {
                pcm = mAudioQueue.poll(50, TimeUnit.MILLISECONDS);
                if (pcm == null) continue;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            if (pcm.length == 0) break;

            short[] processed = pcm;
            if (mPitchShifter != null && (mCurrentSpeed != 1.0f || mCurrentPitchSemitones != 0f)) {
                int frames = pcm.length / mChannelCount;
                mPitchShifter.putFrames(pcm, frames);
                int avail = mPitchShifter.numFrames();
                if (avail > 0) {
                    short[] shifted = new short[avail * mChannelCount];
                    int received = mPitchShifter.receiveFrames(shifted, avail);
                    if (received > 0) processed = shifted;
                }
            }

            if (mAudioTrack != null && mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                mAudioTrack.write(processed, 0, processed.length);
            }
        }

        mMainHandler.post(this::onSongCompletion);
    }

    private void onSongCompletion() {
        if (mRepeatMode == REPEAT_ONE) {
            playSong(mCurrentIndex);
        } else if (mRepeatMode == REPEAT_ALL) {
            int nextIndex = (mCurrentIndex + 1) % mPlaylist.size();
            if (nextIndex == 0) mShuffleHistory.clear();
            playSong(nextIndex);
        } else if (mCurrentIndex + 1 < mPlaylist.size()) {
            playSong(mCurrentIndex + 1);
        } else {
            stop();
        }
    }

    private void stopPlayback() {
        mIsDecoding.set(false);
        mIsPlayingAudio.set(false);

        if (mAudioTrack != null) {
            try {
                mAudioTrack.pause();
                mAudioTrack.flush();
                mAudioTrack.stop();
                mAudioTrack.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing audio track", e);
            }
            mAudioTrack = null;
        }

        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }

        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing decoder", e);
            }
            mDecoder = null;
        }

        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing extractor", e);
            }
            mExtractor = null;
        }

        if (mAudioQueue != null) mAudioQueue.clear();
    }

    private void handlePlaybackError() {
        int attempts = mRecoveryAttempts.incrementAndGet();
        Log.w(TAG, "handlePlaybackError: attempt " + attempts);

        if (attempts <= MAX_RECOVERY_ATTEMPTS) {
            mMainHandler.postDelayed(() -> {
                if (mCurrentIndex >= 0 && mPlaylist != null && mCurrentIndex < mPlaylist.size()) {
                    playSong(mCurrentIndex);
                } else if (mPlaylist != null && !mPlaylist.isEmpty()) {
                    playSong(0);
                }
            }, RECOVERY_DELAY_MS);
        } else {
            mRecoveryAttempts.set(0);
            mMainHandler.post(this::next);
        }
    }

    // ========================================================================
    // Shuffle Helpers
    // ========================================================================

    private void buildShuffleHistory() {
        mShuffleHistory.clear();
        for (int i = 0; i < mPlaylist.size(); i++) mShuffleHistory.add(i);
        Collections.shuffle(mShuffleHistory, mRandom);
    }

    private int getNextShuffleIndex() {
        if (mShuffleHistory.isEmpty()) buildShuffleHistory();
        int next = mShuffleHistory.remove(0);
        mShuffleHistory.add(next);
        return next;
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    private void setupAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            mAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(this)
                    .build();
        }
    }

    private void requestAudioFocus() {
        if (mAudioManager == null) return;
        int result;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            result = mAudioManager.requestAudioFocus((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            result = mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Log.w(TAG, "Audio focus request denied");
        }
    }

    private void abandonAudioFocus() {
        if (mAudioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            mAudioManager.abandonAudioFocusRequest((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            mAudioManager.abandonAudioFocus(this);
        }
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                pause();
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (!mIsPlaying && mIsPaused) {
                    play();
                }
                break;
        }
    }

    // ========================================================================
    // Media Session
    // ========================================================================

    private void setupMediaSession() {
        mMediaSession = new MediaSession(this, "LlamaMusicPlayer");
        mMediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() { play(); }
            @Override
            public void onPause() { pause(); }
            @Override
            public void onSkipToNext() { next(); }
            @Override
            public void onSkipToPrevious() { previous(); }
            @Override
            public void onStop() { stop(); }
            @Override
            public void onSeekTo(long pos) { seekTo((int) pos); }
        });
        mMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mMediaSession.setActive(true);
        updateMediaSession();
    }

    private void updateMediaSession() {
        if (mMediaSession == null) return;
        int state = (mIsPlaying && !mIsPaused) ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                       PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                       PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
        PlaybackState playbackState = new PlaybackState.Builder()
                .setState(state, getCurrentPosition(), mCurrentSpeed)
                .setActions(actions)
                .build();
        mMediaSession.setPlaybackState(playbackState);

        Song currentSong = getCurrentSong();
        if (currentSong != null) {
            android.media.session.MediaMetadataCompat metadata =
                    new android.media.session.MediaMetadataCompat.Builder()
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_TITLE,
                            currentSong.getTitle() != null ? currentSong.getTitle() : "")
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_ARTIST,
                            currentSong.getArtist() != null ? currentSong.getArtist() : "")
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_ALBUM,
                            currentSong.getAlbum() != null ? currentSong.getAlbum() : "")
                    .putLong(android.media.session.MediaMetadataCompat.METADATA_KEY_DURATION, getDuration())
                    .build();
            mMediaSession.setMetadata(metadata);
        }
    }

    // ========================================================================
    // Notification Updates
    // ========================================================================

    private void updateNotification() {
        if (mNotificationService == null) return;

        Song currentSong = getCurrentSong();
        if (currentSong != null && (mIsPlaying || mIsPaused)) {
            mNotificationService.updateSongInfo(currentSong.getTitle(), currentSong.getArtist(),
                    currentSong.getPath());
            mNotificationService.setPlayingState(mIsPlaying && !mIsPaused);
        } else if (mPlaylist != null && !mPlaylist.isEmpty()) {
            Song firstSong = mPlaylist.get(0);
            mNotificationService.updateSongInfo(firstSong.getTitle(), firstSong.getArtist(),
                    firstSong.getPath());
            mNotificationService.setPlayingState(false);
        } else {
            mNotificationService.updateSongInfo("", "", null);
            mNotificationService.setPlayingState(false);
        }
    }

    // ========================================================================
    // Broadcast Updates
    // ========================================================================

    private void broadcastStateUpdate() {
        Intent intent = new Intent(ACTION_UPDATE_PLAYER);
        intent.putExtra("is_playing", mIsPlaying && !mIsPaused);
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("position", getCurrentPosition());
        intent.putExtra("duration", getDuration());
        intent.putExtra("speed_level", mSpeedLevel);
        intent.putExtra("pitch_level", mPitchLevel);
        sendBroadcast(intent);
    }

    private void broadcastPlaylistUpdate() {
        Intent intent = new Intent(ACTION_PLAYLIST_UPDATED);
        intent.putExtra("size", mPlaylist != null ? mPlaylist.size() : 0);
        sendBroadcast(intent);
    }

    // ========================================================================
    // State Persistence
    // ========================================================================

    private void loadState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, REPEAT_OFF);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
        mSpeedLevel = prefs.getInt(KEY_SPEED_LEVEL, 1000);
        mPitchLevel = prefs.getInt(KEY_PITCH_LEVEL, 1000);
        mCurrentPositionUs = prefs.getLong(KEY_CURRENT_POSITION, 0);
        mBluetoothConnected = prefs.getBoolean(KEY_BLUETOOTH_CONNECTED, false);
        mPlayerStateBeforeUpdate = prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    private void saveState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        editor.putInt(KEY_SPEED_LEVEL, mSpeedLevel);
        editor.putInt(KEY_PITCH_LEVEL, mPitchLevel);
        editor.putBoolean(KEY_BLUETOOTH_CONNECTED, mBluetoothConnected);

        if (getCurrentSong() != null && getCurrentSong().getPath() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }

        editor.apply();
    }

    private void saveCurrentSong() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
                .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
                .apply();
    }

    private void saveEffectLevels() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_SPEED_LEVEL, mSpeedLevel)
                .putInt(KEY_PITCH_LEVEL, mPitchLevel)
                .apply();
    }

    private void saveRepeatMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putInt(KEY_REPEAT_MODE, mRepeatMode)
                .apply();
    }

    private void saveShuffleMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SHUFFLE, mIsShuffle)
                .apply();
    }

    private String getLastSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_LAST_SONG_PATH, null);
    }

    private void applyEffectLevels() {
        mCurrentSpeed = MIN_SPEED + (mSpeedLevel / 2000.0f) * (MAX_SPEED - MIN_SPEED);
        mCurrentPitchSemitones = MIN_PITCH_SEMITONES + (mPitchLevel / 2000.0f) * (MAX_PITCH_SEMITONES - MIN_PITCH_SEMITONES);
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(mCurrentSpeed);
            mPitchShifter.setPitch(mCurrentPitchSemitones);
        }
    }
}