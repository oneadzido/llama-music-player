package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with SoundTouch integration.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture:</p>
 * <ul>
 *   <li><b>Primary Path (SoundTouchPlayer)</b> - DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control with high quality.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> - Used ONLY when SoundTouchPlayer
 *       fails at runtime (library missing, initialization error, or crash).</li>
 * </ul>
 * 
 * <h3>Pre-initialization Feature</h3>
 * <p>When a playlist is set, the service automatically pre-initializes the first
 * song using {@link SoundTouchPlayer#preLoad(String)}. This provides:</p>
 * <ul>
 *   <li>Immediate song duration for UI display (no need to press play)</li>
 *   <li>Early audio session creation for equalizer attachment</li>
 *   <li>Faster response when user presses play</li>
 * </ul>
 * 
 * <h3>Why SoundTouch as Default</h3>
 * <ul>
 *   <li><b>Consistent Audio Pipeline</b> - Same processing path for all audio</li>
 *   <li><b>Seamless Effect Activation</b> - No transition when user adjusts pitch/tempo</li>
 *   <li><b>Better Error Recovery</b> - Graceful fallback on failure</li>
 *   <li><b>Simpler Logic</b> - Single primary path, single fallback path</li>
 * </ul>
 * 
 * <h3>Pitch and Tempo Ranges</h3>
 * <ul>
 *   <li><b>Pitch:</b> -6 to +6 semitones (controlled via EqualizerManager)</li>
 *   <li><b>Tempo/Speed:</b> 0.5x to 1.5x speed (controlled via EqualizerManager)</li>
 * </ul>
 * 
 * <h3>Sort Modes</h3>
 * <p>The service supports 10 sort modes for playlist ordering:</p>
 * <ul>
 *   <li>0 - Title A-Z (ascending alphabetical by title)</li>
 *   <li>1 - Title Z-A (descending alphabetical by title)</li>
 *   <li>2 - Artist A-Z (ascending alphabetical by artist)</li>
 *   <li>3 - Artist Z-A (descending alphabetical by artist)</li>
 *   <li>4 - Album A-Z (ascending alphabetical by album)</li>
 *   <li>5 - Album Z-A (descending alphabetical by album)</li>
 *   <li>6 - Genre A-Z (ascending alphabetical by genre)</li>
 *   <li>7 - Genre Z-A (descending alphabetical by genre)</li>
 *   <li>8 - Oldest First (by file modification date)</li>
 *   <li>9 - Newest First (by file modification date)</li>
 * </ul>
 * 
 * <h3>Playback State Persistence</h3>
 * <p>The service saves the following to SharedPreferences:</p>
 * <ul>
 *   <li>Current song index</li>
 *   <li>Current playback position</li>
 *   <li>Playing state (playing/paused)</li>
 *   <li>Repeat mode</li>
 *   <li>Shuffle mode</li>
 *   <li>Last song path</li>
 *   <li>Sort mode</li>
 * </ul>
 * 
 * <h3>Diagnostic Toasts</h3>
 * <p>When the player initializes, a broadcast is sent to MusicPlayer to show
 * a toast indicating which audio player is active (SoundTouch or MediaPlayer).</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Start service
 * Intent intent = new Intent(context, MusicService.class);
 * intent.setAction("PLAY_SONG");
 * intent.putExtra("song_path", "/sdcard/Music/song.mp3");
 * startService(intent);
 * 
 * // Bind to service
 * bindService(intent, connection, BIND_AUTO_CREATE);
 * 
 * // Control playback
 * musicService.play();
 * musicService.pause();
 * musicService.playNext();
 * musicService.seekTo(30000);
 * </pre>
 * 
 * @see SoundTouchPlayer
 * @see MediaPlayer
 * @see EqualizerManager
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Delay for song transitions in milliseconds. */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Intent action for audio session changed broadcast. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    
    /** Maximum time in milliseconds without progress before recovery. */
    private static final int MAX_STALL_TIME_MS = 5000;
    
    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Broadcast action for player status update (diagnostic). */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Delay before pre-initializing the first song (milliseconds). */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay for seek reset flag in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 300;
    
    // ========================================================================
    // Sort Mode Constants
    // ========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name). */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name). */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name). */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name). */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre). */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre). */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp). */
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;
    
    // ========================================================================
    // SoundTouch Player Members (PRIMARY PLAYER)
    // ========================================================================
    
    /** SoundTouch-based audio player - DEFAULT for ALL playback. */
    private SoundTouchPlayer mSoundTouchPlayer;
    
    /** Flag indicating if SoundTouch is currently active. */
    private boolean mIsUsingSoundTouch = false;
    
    /** Flag indicating if SoundTouch failed (prevents retry loop). */
    private boolean mSoundTouchFailed = false;
    
    // ========================================================================
    // MediaPlayer Members (FALLBACK ONLY)
    // ========================================================================
    
    /** Legacy MediaPlayer instance - used ONLY when SoundTouch fails. */
    private MediaPlayer mMediaPlayer;
    
    // ========================================================================
    // Playback State
    // ========================================================================
    
    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song. */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Timestamp when current playback started (for health checks - MediaPlayer only). */
    private long mPlaybackStartTime = 0;
    
    // ========================================================================
    // Sort Mode State
    // ========================================================================
    
    /** Current sort mode for playlist display. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // ========================================================================
    // Health Check Components (MediaPlayer only)
    // ========================================================================
    
    /** Handler for periodic health checks. */
    private Handler mHealthHandler;
    
    /** Runnable for health check. */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts for current song. */
    private int mRecoveryAttempts = 0;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    /** WakeLock to prevent device sleep during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    /** Audio manager for focus management. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for API 26+. */
    private AudioFocusRequest mAudioFocusRequest;
    
    // ========================================================================
    // Media Session
    // ========================================================================
    
    /** MediaSession for lock screen and headset controls. */
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    /** Lock object for MediaPlayer operations (fallback only). */
    private final Object mPlayerLock = new Object();
    
    /** Flag indicating if a song transition is in progress. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if a song is being prepared (MediaPlayer fallback only). */
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);
    
    /** Global preparation ID counter for async operation cancellation. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID (used to ignore stale callbacks). */
    private volatile int mCurrentPrepId = -1;
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    /** History of shuffled indices (for prev/next in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft update. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for sync notification updates. */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates. */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clear playlist commands. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for getting playing state. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates. */
    private BroadcastReceiver mSortModeReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * Allows activities to obtain a reference to the service.
     */
    public class LocalBinder extends Binder {
        
        /**
         * Returns the service instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes (Java 7 compatible)
    // ========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by oldest first (by file date), then by title.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by newest first (by file date), then by title.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Static Methods
    // ========================================================================
    
    /**
     * Sets the player state before update flag.
     * Used to preserve playback state during folder updates.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID.
     * Used by EqualizerActivity to attach to the correct audio session.
     *
     * @return The current audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the service is created.
     * Initializes all components including MediaSession, audio focus, notifications,
     * and SoundTouch player as the default player.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparing.set(false);
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup media session for lock screen controls
        setupMediaSession();
        
        // Initialize EqualizerManager singleton
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        // Setup audio focus
        setupAudioFocus();
        
        // Initialize health check handler (for MediaPlayer fallback only)
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize SoundTouch player as the DEFAULT player
        initSoundTouchPlayer();
        
        // Register broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete - SoundTouch is DEFAULT player");
    }
    
    /**
     * Initializes the SoundTouch player as the default player.
     * 
     * <p>If SoundTouch library is not available or fails to initialize,
     * the service will automatically fall back to MediaPlayer for the
     * remainder of the session. This fallback is permanent.</p>
     * 
     * <p>When initialization completes (or falls back), a broadcast is sent
     * to MusicPlayer to show a diagnostic toast indicating which player is active.</p>
     */
    private void initSoundTouchPlayer() {
        if (mSoundTouchFailed) {
            Log.d(TAG, "SoundTouch already failed, skipping init");
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        if (!PitchShifter.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        try {
            // Pass context to SoundTouchPlayer constructor
            mSoundTouchPlayer = new SoundTouchPlayer(this);
            mSoundTouchPlayer.setListener(new SoundTouchPlayer.PlaybackListener() {
                @Override
                public void onPlaybackStarted() {
                    Log.d(TAG, "SoundTouchPlayer: playback started");
                    synchronized (mPlayerLock) {
                        mIsPlaying = true;
                    }
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                        Log.d(TAG, "WakeLock acquired");
                    }
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionPlaybackState();
                }
                
                @Override
                public void onPlaybackPaused() {
                    Log.d(TAG, "SoundTouchPlayer: playback paused");
                    synchronized (mPlayerLock) {
                        mIsPlaying = false;
                    }
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released on pause");
                    }
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionPlaybackState();
                }
                
                @Override
                public void onPlaybackResumed() {
                    Log.d(TAG, "SoundTouchPlayer: playback resumed");
                    synchronized (mPlayerLock) {
                        mIsPlaying = true;
                    }
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                        Log.d(TAG, "WakeLock re-acquired");
                    }
                    broadcastUpdate();
                    createNotification();
                    updateMediaSessionPlaybackState();
                }
                
                @Override
                public void onCompletion() {
                    Log.d(TAG, "SoundTouchPlayer: song completed");
                    handleCompletion();
                }
                
                @Override
                public void onPositionUpdate(long position) {
                    // Position updates handled by UI polling
                }
                
                @Override
                public void onError(@NonNull String error) {
                    Log.e(TAG, "SoundTouchPlayer error: " + error);
                    fallbackToMediaPlayer();
                }
                
                @Override
                public void onPrepared() {
                    Log.d(TAG, "SoundTouchPlayer: prepared");
                    sendPlayerStatusBroadcast(true);
                    updatePlaybackParams();
                    sCurrentAudioSessionId = mSoundTouchPlayer.getAudioSessionId();
                    broadcastAudioSessionChanged(sCurrentAudioSessionId);
                    EqualizerManager.getInstance(MusicService.this)
                        .attachToAudioSession(sCurrentAudioSessionId);
                    broadcastUpdate();
                    createNotification();
                }
            });
            
            mIsUsingSoundTouch = true;
            Log.d(TAG, "SoundTouchPlayer initialized successfully as DEFAULT player");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize SoundTouchPlayer", e);
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
        }
    }
    
    /**
     * Sends a broadcast to MusicPlayer to show which player is active.
     * Used for diagnostic purposes to verify the correct player is running.
     *
     * @param isSoundTouchActive True if SoundTouch is active, false if using MediaPlayer fallback
     */
    private void sendPlayerStatusBroadcast(boolean isSoundTouchActive) {
        Intent intent = new Intent(ACTION_PLAYER_STATUS_UPDATE);
        intent.putExtra("player_type", isSoundTouchActive ? "SoundTouch" : "MediaPlayer");
        sendBroadcast(intent);
        Log.d(TAG, "Player status broadcast sent: " + (isSoundTouchActive ? "SoundTouch" : "MediaPlayer"));
    }
    
    /**
     * Falls back to MediaPlayer when SoundTouch fails.
     * 
     * <p>This method preserves the current playback position and song
     * index before switching to MediaPlayer. The fallback is permanent
     * for the remainder of the session.</p>
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingSoundTouch) {
            return; // Already using MediaPlayer
        }
        
        Log.w(TAG, "FALLBACK: Switching from SoundTouchPlayer to MediaPlayer");
        mIsUsingSoundTouch = false;
        mSoundTouchFailed = true;
        
        // Notify UI that fallback occurred
        sendPlayerStatusBroadcast(false);
        
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        
        if (mSoundTouchPlayer != null) {
            currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        if (currentIndex >= 0 && mCurrentPlaylist != null && 
            currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex + 
                  " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
        }
        
        Log.d(TAG, "Fallback to MediaPlayer complete");
    }
    
    // ========================================================================
    // Pre-initialization Methods
    // ========================================================================
    
    /**
     * Pre-initializes the current song without starting playback.
     * 
     * <p>This method calls {@link SoundTouchPlayer#preLoad(String)} to:
     * <ul>
     *   <li>Read the song duration from the audio file</li>
     *   <li>Create an audio session for equalizer attachment</li>
     *   <li>Prepare the decoder for immediate playback when user presses play</li>
     * </ul>
     * </p>
     * 
     * <p>This fixes two critical issues:
     * <ol>
     *   <li>The timer showing 00:00 after folder import (duration is now known)</li>
     *   <li>The equalizer being disabled until play is pressed (session now exists)</li>
     * </ol>
     * </p>
     */
    private void preInitializeCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "preInitializeCurrentSong: No playlist, skipping");
            return;
        }
        
        int index = mCurrentIndex >= 0 ? mCurrentIndex : 0;
        if (index >= mCurrentPlaylist.size()) {
            index = 0;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.d(TAG, "preInitializeCurrentSong: Invalid song at index " + index);
            return;
        }
        
        // Use SoundTouch player for pre-initialization (DEFAULT)
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            boolean success = mSoundTouchPlayer.preLoad(song.getPath());
            if (success) {
                Log.d(TAG, "preInitializeCurrentSong: Successfully pre-loaded: " + song.getTitle());
                
                // Update audio session for equalizer (now available before play)
                sCurrentAudioSessionId = mSoundTouchPlayer.getAudioSessionId();
                broadcastAudioSessionChanged(sCurrentAudioSessionId);
                EqualizerManager.getInstance(this).attachToAudioSession(sCurrentAudioSessionId);
            } else {
                Log.w(TAG, "preInitializeCurrentSong: Failed to pre-load: " + song.getTitle());
            }
        } else {
            Log.d(TAG, "preInitializeCurrentSong: SoundTouch not available, skipping pre-init");
        }
    }
    
    // ========================================================================
    // Service Lifecycle Methods (continued)
    // ========================================================================
    
    /**
     * Called when the service is started via startService().
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and saves playback state.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        // Only relevant for MediaPlayer fallback
        if (mIsUsingSoundTouch) return;
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Public API Methods for MusicPlayer
    // ========================================================================
    
    /**
     * Returns true if any player (SoundTouch or MediaPlayer) is actively playing.
     * Used by MusicPlayer to determine play/pause button state.
     *
     * <p>This method checks both the primary SoundTouchPlayer and the fallback
     * MediaPlayer to determine if audio is currently playing.</p>
     *
     * @return True if audio is currently playing from either player
     */
    public boolean isAnyPlayerPlaying() {
        if (mSoundTouchPlayer != null) {
            return mSoundTouchPlayer.isPlaying();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                return mMediaPlayer.isPlaying();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * Returns true if any player is prepared and ready for playback (may be paused).
     * Used by MusicPlayer to determine if resume is possible without restarting.
     *
     * <p>A player is considered "prepared" when it has successfully loaded a song
     * and is ready to play, regardless of whether it is currently playing or paused.
     * This method checks both the primary SoundTouchPlayer and the fallback
     * MediaPlayer.</p>
     *
     * @return True if a player has a loaded song ready to play
     */
    public boolean isAnyPlayerPrepared() {
        if (mSoundTouchPlayer != null) {
            return mSoundTouchPlayer.isPrepared();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            return true;
        }
        return false;
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ:
                return new TitleAZComparator();
            case SORT_TITLE_ZA:
                return new TitleZAComparator();
            case SORT_ARTIST_AZ:
                return new ArtistAZComparator();
            case SORT_ARTIST_ZA:
                return new ArtistZAComparator();
            case SORT_ALBUM_AZ:
                return new AlbumAZComparator();
            case SORT_ALBUM_ZA:
                return new AlbumZAComparator();
            case SORT_GENRE_AZ:
                return new GenreAZComparator();
            case SORT_GENRE_ZA:
                return new GenreZAComparator();
            case SORT_OLDEST:
                return new OldestFirstComparator();
            case SORT_NEWEST:
                return new NewestFirstComparator();
            default:
                return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            return;
        }
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) {
                currentSongPath = currentSong.getPath();
            }
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                Log.d(TAG, "Current song repositioned to index: " + newIndex);
            }
        }
        
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    /**
     * Registers the notification receiver for sync updates.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }
    
    /**
     * Registers the clear playlist receiver.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }
    
    /**
     * Registers the theme color change receiver.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }
    
    /**
     * Registers the receiver for getting playing state.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }
    
    /**
     * Registers the sort mode update receiver.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // ========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {
        }
    }
    
    /**
     * Safely resets the MediaPlayer.
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on media player release");
            }
            
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.stop();
                    }
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) {
                }
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) {
                }
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparing.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            Log.d(TAG, "Attempting recovery from error - resetting player");
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     *
     * @return True if the player is ready
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
    
    // ========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // ========================================================================
    
    /**
     * Starts the playback health monitoring.
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) {
            mHealthHandler = new Handler(Looper.getMainLooper());
        }
        
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        
        Log.d(TAG, "Health monitoring started");
    }
    
    /**
     * Stops the playback health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     * Only used for MediaPlayer fallback.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingSoundTouch) return; // SoundTouch handles its own health
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition + 
                          ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying) {
                    mMediaPlayer.pause();
                }
            } catch (Exception ignored) {}
            
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && 
                    currentIndex < mCurrentPlaylist.size()) {
                    Log.d(TAG, "Restarting playback at index " + currentIndex);
                    prepareAndPlay(currentIndex, currentPosition);
                    
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }
    
    // ========================================================================
    // Async Operation Management
    // ========================================================================
    
    /**
     * Invalidates all pending preparations.
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock.
     *
     * @return True if the lock was acquired
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    /**
     * Creates and updates the playback notification.
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    /**
     * Refreshes the notification.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null;
            Bitmap safePlaceholder = null;
            
            if (art != null && !art.isRecycled()) {
                safeArt = art;
            }
            if (placeholder != null && !placeholder.isRecycled()) {
                safePlaceholder = placeholder;
            }
            
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state.
     */
    private void saveFullState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_CURRENT_POSITION, getCurrentPosition());
        editor.putBoolean(KEY_LAST_PLAYING, mIsPlaying);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        if (getCurrentSong() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }
        editor.apply();
    }
    
    /**
     * Gets the saved playback position.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before restart.
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path.
     *
     * @return The saved song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Playlist Management Methods
    // ========================================================================
    
    /**
     * Sets the current playlist.
     * 
     * <p>This method now includes pre-initialization of the first song to
     * ensure duration and audio session are available immediately.</p>
     *
     * @param playlist The new playlist
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            // Save current position to preferences BEFORE any changes
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                // Get current position from active player
                if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
                    currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
                    wasPlaying = mSoundTouchPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                // Save to SharedPreferences immediately
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            
            // Handle empty playlist
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            
            // Step 1: Sort the new playlist according to current sort mode
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // Step 2: Check if playlist is actually different (optimization)
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                boolean same = true;
                for (int i = 0; i < playlist.size(); i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    broadcastUpdate();
                    return;
                }
            }
            
            // Force player reset when not preserving current song
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                invalidateAllPreparations();
                resetPlayerSafely();
                if (mSoundTouchPlayer != null) {
                    mSoundTouchPlayer.stop();
                }
                mIsPlaying = false;
            }
            
            // Step 3: Find the current song in the new playlist (if preserveCurrentSong is true)
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                // Fallback to saved path if current song not found
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            // Step 4: Check if we actually need to reset the player
            boolean currentSongPositionChanged = (newIndex != -1 && newIndex != mCurrentIndex);
            boolean playlistStructureChanged = (mCurrentPlaylist != null && 
                                               mCurrentPlaylist.size() != sortedPlaylist.size());
            
            // Also check if the current song's path is different (song actually changed)
            boolean currentSongChanged = false;
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                String oldPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                if (newIndex >= 0 && newIndex < sortedPlaylist.size()) {
                    String newPath = sortedPlaylist.get(newIndex).getPath();
                    currentSongChanged = !oldPath.equals(newPath);
                }
            }
            
            boolean needsReset = currentSongPositionChanged || playlistStructureChanged || currentSongChanged;
            
            if (needsReset && preserveCurrentSong) {
                Log.d(TAG, "Playlist/song changed, resetting player");
                resetPlayerSafely();
            } else if (!preserveCurrentSong) {
                // Already reset above, but ensure we are clean
                Log.d(TAG, "Playlist completely replaced, player already reset");
            }
            
            // Step 5: Replace the entire playlist
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            // Step 6: Set the current index - respects preserveCurrentSong flag
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                // Only restore saved index when preserving the current song
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex = 0;
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                // When preserveCurrentSong == false, do NOT restore any saved index.
                // The caller must use a path-based method (playSongByPath) to set the correct index.
                mCurrentIndex = -1;
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            
            saveCurrentPlayingIndex();
            
            // Step 7: Resume playback if needed (only when preserving current song)
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (needsReset) {
                    // Need to restart playback from saved position
                    if (isFolderUpdate) {
                        int correctIndex = mCurrentIndex;
                        String savedPath = getSavedSongPath();
                        if (savedPath != null) {
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                    correctIndex = i;
                                    break;
                                }
                            }
                        }
                        prepareAndPlay(correctIndex, savedPosition);
                        clearPlayerStateBeforeUpdate(this);
                    } else {
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                } else if (!mIsPlaying) {
                    // Same song, just resume if it was playing
                    Log.d(TAG, "Same song, resuming playback without reset");
                    resume();
                }
                
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0 && needsReset) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            } else if (!preserveCurrentSong) {
                // Do not start playback automatically - wait for caller to call playSong or playSongByPath
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            
            // ====================================================================
            // Pre-initialize the current song for duration and session
            // This ensures the timer shows total time and equalizer is ready before play
            // ====================================================================
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        preInitializeCurrentSong();
                    }
                }, PRE_INIT_DELAY_MS);
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mSoundTouchPlayer != null) {
                mSoundTouchPlayer.stop();
            }
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on stop");
            }
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) {
                mShuffleHistory.clear();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) {
                mNotificationService.stopForeground();
            }
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist.
     *
     * @param newPlaylist The new playlist
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // ========================================================================
    // Playback Control Methods
    // ========================================================================
    
    /**
     * Plays a song at the specified index.
     * SoundTouchPlayer is the DEFAULT player for ALL playback.
     * MediaPlayer is used ONLY as a fallback when SoundTouch fails.
     *
     * @param index The song index
     */
    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            playSongWithSoundTouch(index);
        } 
        // FALLBACK: Only if SoundTouch failed at runtime
        else {
            Log.w(TAG, "SoundTouch unavailable, using MediaPlayer fallback");
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Plays a song using SoundTouchPlayer (DEFAULT).
     *
     * @param index Index of song to play
     */
    private void playSongWithSoundTouch(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "Invalid song at index " + index);
            fallbackToMediaPlayer();
            return;
        }
        
        try {
            if (mSoundTouchPlayer.isPlaying()) {
                mSoundTouchPlayer.stop();
            }
            
            if (mSoundTouchPlayer.loadSong(song.getPath())) {
                mCurrentIndex = index;
                mSoundTouchPlayer.play();
                
                createNotification();
                broadcastUpdate();
                savePlayerState();
            } else {
                Log.e(TAG, "SoundTouchPlayer.loadSong failed for: " + song.getPath());
                fallbackToMediaPlayer();
                prepareAndPlay(index, 0);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error playing with SoundTouch", e);
            fallbackToMediaPlayer();
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     * This is the FALLBACK method used ONLY when SoundTouch fails.
     *
     * @param index The song index
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration: " + duration);
                                mIsPlaying = false;
                                broadcastUpdate();
                                return;
                            }
                            
                            if (finalSeek > 0 && finalSeek < duration - 500) {
                                mp.seekTo(finalSeek);
                            }
                            
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mCurrentIndex = finalIndex;
                            saveCurrentPlayingIndex();
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired");
                            }
                            
                            updateMediaSessionPlaybackState();
                            broadcastUpdate();
                            createNotification();
                            updatePlaybackParams();
                            
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying = false;
                            broadcastUpdate();
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    /**
     * Prepares a song without starting playback.
     *
     * @param index The song index
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance in prepareOnly, ignoring");
                            return;
                        }
                        
                        mIsPreparing.set(false);
                        
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                            
                            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            playSongWithSoundTouch(index);
            if (position > 0) {
                mSoundTouchPlayer.seekTo(position);
            }
        } 
        // FALLBACK: Only if SoundTouch failed at runtime
        else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The file path of the song
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause.
     * Used by headset buttons, lock screen controls, and direct calls.
     */
    public void togglePlayPause() {
        // SoundTouchPlayer is active and has a loaded song
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            if (mSoundTouchPlayer.isPlaying()) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        // MediaPlayer fallback is active
        if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
            if (mIsPlaying) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        // No active player but playlist exists - start playback by path (matches playlist tap)
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            Song firstSong = mCurrentPlaylist.get(0);
            if (firstSong != null && firstSong.getPath() != null) {
                playSongByPath(firstSong.getPath());
            } else {
                playSong(0);
            }
        }
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPlaying()) {
            mSoundTouchPlayer.pause();
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on pause");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            stopHealthMonitoring();
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.pause();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot pause - invalid state", e);
                    }
                    mIsPlaying = false;
                    
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released on pause");
                    }
                    
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            }
        }
    }
    
    /**
     * Resumes playback.
     */
    public void resume() {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && !mSoundTouchPlayer.isPlaying()) {
            mSoundTouchPlayer.resume();
            mIsPlaying = true;
            
            if (mWakeLock != null && !mWakeLock.isHeld()) {
                mWakeLock.acquire();
                Log.d(TAG, "WakeLock acquired on resume");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                    try {
                        if (!mIsPlaying) {
                            requestAudioFocus();
                            updatePlaybackParams();
                            mMediaPlayer.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired on resume");
                            }
                            
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Resume failed - invalid state", e);
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                    playSong(0);
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     */
    public void stop() {
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
            mIsPlaying = false;
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot stop - invalid state", e);
                    }
                    mIsPlaying = false;
                }
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position.
     * 
     * <p>This method handles seek operations for both SoundTouchPlayer
     * and MediaPlayer fallback.</p>
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.seekTo(position);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        int duration = mMediaPlayer.getDuration();
                        if (position >= 0 && position < duration) {
                            mMediaPlayer.seekTo(position);
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            savePlayerState();
                            saveFullState();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot seek - invalid state", e);
                    }
                }
            }
        }
    }
    
    // ========================================================================
    // Playback Parameter Methods
    // ========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.setPitch(semitones);
            mSoundTouchPlayer.setTempo(tempo);
            Log.d(TAG, "SoundTouch: pitch=" + semitones + ", tempo=" + tempo);
            return;
        }
        
        // FALLBACK: Use MediaPlayer's PlaybackParams (API 23+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }
    
    // ========================================================================
    // Completion Handler
    // ========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>This method sends a completion broadcast with the full duration
     * to ensure the UI seekbar fills completely to 100%.</p>
     */
    private void handleCompletion() {
        // Broadcast completion with full duration for seekbar fill
        broadcastSongCompletion();
        
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) {
                mCurrentIndex = savedIndex;
            } else {
                mCurrentIndex = 0;
            }
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        
        if (mRepeatMode == 2) {
            // Repeat one: seek to 0 and play again
            if (mSoundTouchPlayer != null) {
                mSoundTouchPlayer.seekTo(0);
                mSoundTouchPlayer.play();
            }
        } else if (mRepeatMode == 1) {
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            if (mSoundTouchPlayer != null) {
                mSoundTouchPlayer.stop();
                // Ensure position is at end
                mSoundTouchPlayer.seekTo((int) mSoundTouchPlayer.getDuration());
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, getDuration())
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            
            // Send final completion broadcast
            broadcastSongCompletion();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }
    
    /**
     * Broadcasts song completion with full duration for UI seekbar fill.
     * 
     * <p>This ensures the seekbar reaches 100% when the song ends,
     * fixing the issue where the seekbar would stop at 97-99%.</p>
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongCompletion: duration=" + duration + "ms");
    }
    
    // ========================================================================
    // Getter Methods
    // ========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getCurrentPosition();
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getDuration();
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mSoundTouchPlayer != null) {
            return mSoundTouchPlayer.isPlaying();
        }
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song, or null
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                });
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Sets up audio focus for proper audio ducking and interruption handling.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     *
     * @param songPath The path of the song
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }
    
    /**
     * Handles the close action from the notification.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
        }
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus from the system.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a playback state update to activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) {
                    pause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // SoundTouch doesn't need special handling, AudioTrack handles it
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                // No action needed
                break;
            default:
                break;
        }
    }
}