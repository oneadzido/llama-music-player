package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class MusicService extends Service implements AudioManager.OnAudioFocusChangeListener {

    private static final String TAG = "MusicService";
    private static final String PREFS_NAME = "LlamaPrefs";

    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    private static final String KEY_CURRENT_POSITION = "current_position";
    private static final String KEY_WAS_PLAYING = "was_playing";
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    private static final String KEY_SHUFFLE = "shuffle";
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    private static final String KEY_SPEED_LEVEL = "speed_level";
    private static final String KEY_PITCH_LEVEL = "pitch_level";
    private static final String KEY_BLUETOOTH_CONNECTED = "bluetooth_connected";
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    public static final String ACTION_UPDATE_PLAYER = "UPDATE_PLAYER";
    public static final String ACTION_PLAYLIST_UPDATED = "PLAYLIST_UPDATED";

    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;

    private static final float MIN_SPEED = 0.5f;
    private static final float MAX_SPEED = 1.5f;
    private static final float MIN_PITCH_SEMITONES = -6.0f;
    private static final float MAX_PITCH_SEMITONES = 6.0f;

    private static final int QUEUE_CAPACITY = 16;
    private static final int TIMEOUT_US = 10000;
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    private static final int RECOVERY_DELAY_MS = 500;

    private final IBinder mBinder = new LocalBinder();
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread mDecodeThread;
    private Handler mDecodeHandler;
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;

    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private PitchShifter mPitchShifter;
    private BlockingQueue<short[]> mAudioQueue;
    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;
    private MediaSession mMediaSession;
    private NotificationService mNotificationService;

    private ArrayList<Song> mPlaylist = new ArrayList<>();
    private int mCurrentIndex = -1;
    private boolean mIsPlaying = false;
    private boolean mIsPaused = false;
    private int mRepeatMode = REPEAT_OFF;
    private boolean mIsShuffle = false;
    private Random mRandom = new Random();
    private ArrayList<Integer> mShuffleHistory = new ArrayList<>();

    private int mSampleRate = 44100;
    private int mChannelCount = 2;
    private int mAudioSessionId = 0;
    private long mDurationUs = 0;
    private long mCurrentPositionUs = 0;

    private float mCurrentSpeed = 1.0f;
    private float mCurrentPitchSemitones = 0.0f;
    private int mSpeedLevel = 1000;
    private int mPitchLevel = 1000;
    private boolean mSoundTouchAvailable;

    private final AtomicBoolean mIsDecoding = new AtomicBoolean(false);
    private final AtomicBoolean mIsPlayingAudio = new AtomicBoolean(false);
    private final AtomicBoolean mInputEOS = new AtomicBoolean(false);
    private final AtomicBoolean mOutputEOS = new AtomicBoolean(false);
    private final AtomicLong mSeekPositionUs = new AtomicLong(-1);
    private final AtomicBoolean mSeekPending = new AtomicBoolean(false);
    private final AtomicInteger mRecoveryAttempts = new AtomicInteger(0);
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);

    private boolean mBluetoothConnected = false;
    private boolean mPlayerStateBeforeUpdate = false;
    private Object mAudioFocusRequest;

    private BroadcastReceiver mControlReceiver;
    private BroadcastReceiver mEffectReceiver;

    public class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        mSoundTouchAvailable = PitchShifter.isLibraryAvailable();
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        loadState();

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Llama:Playback");
        mWakeLock.setReferenceCounted(false);

        mAudioQueue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);

        mDecodeThread = new HandlerThread("AudioDecoder");
        mDecodeThread.start();
        mDecodeHandler = new Handler(mDecodeThread.getLooper());

        mPlaybackThread = new HandlerThread("AudioPlayback");
        mPlaybackThread.start();
        mPlaybackHandler = new Handler(mPlaybackThread.getLooper());

        mNotificationService = new NotificationService(this);
        setupMediaSession();
        setupAudioFocus();
        registerReceivers();
        applyEffectLevels();

        Log.d(TAG, "onCreate complete");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if (action.equals("PLAY_SONG") && intent.hasExtra("song_path")) {
                playSongByPath(intent.getStringExtra("song_path"));
            } else if (action.equals("ACTION_SEEK") && intent.hasExtra("position")) {
                seekTo(intent.getIntExtra("position", 0));
            }
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        saveState();
        stopPlayback();
        if (mDecodeThread != null) mDecodeThread.quitSafely();
        if (mPlaybackThread != null) mPlaybackThread.quitSafely();
        if (mWakeLock.isHeld()) mWakeLock.release();
        if (mNotificationService != null) mNotificationService.release();
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
        }
        try {
            if (mControlReceiver != null) unregisterReceiver(mControlReceiver);
            if (mEffectReceiver != null) unregisterReceiver(mEffectReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering receivers", e);
        }
        abandonAudioFocus();
        EqualizerManager.getInstance(this).detach();
        super.onDestroy();
    }

    private void registerReceivers() {
        mControlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action == null) return;
                switch (action) {
                    case "ACTION_PLAY": play(); break;
                    case "ACTION_PAUSE": pause(); break;
                    case "ACTION_PLAY_PAUSE": if (mIsPlaying && !mIsPaused) pause(); else play(); break;
                    case "ACTION_NEXT": next(); break;
                    case "ACTION_PREV": previous(); break;
                    case "ACTION_STOP": stop(); break;
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("ACTION_PLAY");
        filter.addAction("ACTION_PAUSE");
        filter.addAction("ACTION_PLAY_PAUSE");
        filter.addAction("ACTION_NEXT");
        filter.addAction("ACTION_PREV");
        filter.addAction("ACTION_STOP");
        registerReceiver(mControlReceiver, filter);

        mEffectReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    setSpeedLevel(intent.getIntExtra("speed", 1000));
                    setPitchLevel(intent.getIntExtra("pitch", 1000));
                }
            }
        };
        registerReceiver(mEffectReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }

    public void playSong(int index) {
        if (mPlaylist == null || index < 0 || index >= mPlaylist.size()) return;
        if (!mIsTransitioning.compareAndSet(false, true)) return;

        try {
            stopPlayback();
            mCurrentIndex = index;
            mIsPlaying = true;
            mIsPaused = false;
            mRecoveryAttempts.set(0);
            mCurrentPositionUs = 0;
            mInputEOS.set(false);
            mOutputEOS.set(false);
            if (mAudioQueue != null) mAudioQueue.clear();

            Song song = mPlaylist.get(mCurrentIndex);
            String filePath = song.getPath();
            if (filePath == null) {
                handlePlaybackError();
                return;
            }
            File audioFile = new File(filePath);
            if (!audioFile.exists()) {
                handlePlaybackError();
                return;
            }

            if (mSoundTouchAvailable) {
                startSoundTouchPlayback(audioFile);
            } else {
                handlePlaybackError();
                return;
            }

            saveCurrentSong();
            broadcastStateUpdate();
            updateMediaSession();
            updateNotification();
        } finally {
            mMainHandler.postDelayed(() -> mIsTransitioning.set(false), 500);
        }
    }

    public void playSongByPath(String filePath) {
        if (mPlaylist == null || filePath == null) return;
        for (int i = 0; i < mPlaylist.size(); i++) {
            Song song = mPlaylist.get(i);
            if (song != null && filePath.equals(song.getPath())) {
                playSong(i);
                return;
            }
        }
    }

    public void play() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;
        if (mCurrentIndex < 0) mCurrentIndex = 0;
        if (mAudioTrack != null && mIsPaused) {
            requestAudioFocus();
            mAudioTrack.play();
            mIsPaused = false;
            mIsPlaying = true;
            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);
            broadcastStateUpdate();
            updateNotification();
        } else if (mCurrentIndex >= 0) {
            playSong(mCurrentIndex);
        }
    }

    public void resume() { play(); }

    public void pause() {
        if (mAudioTrack != null && mIsPlaying && !mIsPaused) {
            mAudioTrack.pause();
            mIsPaused = true;
            mIsPlaying = false;
            if (mWakeLock.isHeld()) mWakeLock.release();
            broadcastStateUpdate();
            updateNotification();
        }
    }

    public void stop() {
        stopPlayback();
        mIsPlaying = false;
        mIsPaused = false;
        if (mWakeLock.isHeld()) mWakeLock.release();
        broadcastStateUpdate();
        updateNotification();
    }

    public void next() { playNext(); }
    public void playNext() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;
        int nextIndex = mIsShuffle ? getNextShuffleIndex() : (mCurrentIndex + 1) % mPlaylist.size();
        playSong(nextIndex);
    }

    public void previous() { playPrevious(); }
    public void playPrevious() {
        if (mPlaylist == null || mPlaylist.isEmpty()) return;
        int prevIndex;
        if (mIsShuffle && mShuffleHistory.size() >= 2) {
            prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
        } else {
            prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mPlaylist.size() - 1;
        }
        playSong(prevIndex);
    }

    public void seekTo(int positionMs) {
        if (mExtractor != null) {
            long seekUs = positionMs * 1000L;
            mSeekPositionUs.set(seekUs);
            mSeekPending.set(true);
            mExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            if (mDecoder != null) mDecoder.flush();
            if (mAudioQueue != null) mAudioQueue.clear();
            mCurrentPositionUs = seekUs;
            broadcastStateUpdate();
        }
    }

    public void setPlaylist(ArrayList<Song> playlist) {
        mPlaylist = new ArrayList<>(playlist);
        if (mIsShuffle) buildShuffleHistory();
        String lastSongPath = getLastSongPath();
        if (lastSongPath != null) {
            for (int i = 0; i < mPlaylist.size(); i++) {
                Song song = mPlaylist.get(i);
                if (song != null && lastSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    break;
                }
            }
        }
        if (mCurrentIndex < 0 && !mPlaylist.isEmpty()) mCurrentIndex = 0;
        broadcastPlaylistUpdate();
        updateNotification();
    }

    public ArrayList<Song> getPlaylist() { return mPlaylist; }
    public Song getCurrentSong() {
        if (mCurrentIndex >= 0 && mCurrentIndex < mPlaylist.size()) return mPlaylist.get(mCurrentIndex);
        return null;
    }
    public int getCurrentIndex() { return mCurrentIndex; }
    public int getCurrentPosition() { return (int) (mCurrentPositionUs / 1000); }
    public int getDuration() { return (int) (mDurationUs / 1000); }
    public boolean isPlaying() { return mIsPlaying && !mIsPaused; }
    public boolean isAnyPlayerPlaying() { return mIsPlaying && !mIsPaused; }
    public boolean isAnyPlayerPrepared() { return mAudioTrack != null || mDecoder != null; }

    public void setRepeatMode(int mode) { mRepeatMode = mode; saveRepeatMode(); updateNotification(); }
    public int getRepeatMode() { return mRepeatMode; }
    public void setShuffle(boolean shuffle) { mIsShuffle = shuffle; if (shuffle) buildShuffleHistory(); saveShuffleMode(); updateNotification(); }
    public boolean isShuffle() { return mIsShuffle; }

    public void setSpeedLevel(int level) {
        mSpeedLevel = Math.max(0, Math.min(2000, level));
        mCurrentSpeed = MIN_SPEED + (mSpeedLevel / 2000.0f) * (MAX_SPEED - MIN_SPEED);
        if (mPitchShifter != null) mPitchShifter.setTempo(mCurrentSpeed);
        saveEffectLevels();
    }

    public void setPitchLevel(int level) {
        mPitchLevel = Math.max(0, Math.min(2000, level));
        mCurrentPitchSemitones = MIN_PITCH_SEMITONES + (mPitchLevel / 2000.0f) * (MAX_PITCH_SEMITONES - MIN_PITCH_SEMITONES);
        if (mPitchShifter != null) mPitchShifter.setPitch(mCurrentPitchSemitones);
        saveEffectLevels();
    }

    public float getCurrentSpeed() { return mCurrentSpeed; }
    public float getCurrentPitchSemitones() { return mCurrentPitchSemitones; }
    public int getSpeedLevel() { return mSpeedLevel; }
    public int getPitchLevel() { return mPitchLevel; }
    public boolean isSoundTouchAvailable() { return mSoundTouchAvailable; }
    public int getAudioSessionId() { return mAudioSessionId; }

    public void refreshNotification() { updateNotification(); }

    public void setNotificationAlbumArt(android.graphics.Bitmap art, android.graphics.Bitmap placeholder, String artPath) {
        if (mNotificationService != null) mNotificationService.setAlbumArt(art, placeholder, artPath);
    }

    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        editor.putInt(KEY_SPEED_LEVEL, mSpeedLevel);
        editor.putInt(KEY_PITCH_LEVEL, mPitchLevel);
        editor.putBoolean(KEY_BLUETOOTH_CONNECTED, mBluetoothConnected);
        editor.putBoolean(KEY_WAS_PLAYING, mIsPlaying && !mIsPaused);
        if (getCurrentSong() != null && getCurrentSong().getPath() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }
        editor.apply();
    }

    public static void setPlayerStateBeforeUpdate(Context context, boolean state) {
        context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, state).apply();
    }

    public static void clearPlayerStateBeforeUpdate(Context context) {
        context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    public void setBluetoothConnected(boolean connected) { mBluetoothConnected = connected; savePlayerState(); }
    public void handleMediaButton(int keyCode) {
        switch (keyCode) {
            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: if (mIsPlaying && !mIsPaused) pause(); else play(); break;
            case android.view.KeyEvent.KEYCODE_MEDIA_NEXT: next(); break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS: previous(); break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY: play(); break;
            case android.view.KeyEvent.KEYCODE_MEDIA_PAUSE: pause(); break;
            case android.view.KeyEvent.KEYCODE_MEDIA_STOP: stop(); break;
        }
    }

    public void refreshMetadataForSong(String songPath, String title, String artist, String album, String genre, byte[] albumArtBytes, boolean albumArtRemoved) {
        for (int i = 0; i < mPlaylist.size(); i++) {
            Song song = mPlaylist.get(i);
            if (song != null && songPath.equals(song.getPath())) {
                if (title != null) song.setTitle(title);
                if (artist != null) song.setArtist(artist);
                if (album != null) song.setAlbum(album);
                if (genre != null) song.setGenre(genre);
                break;
            }
        }
        Song currentSong = getCurrentSong();
        if (currentSong != null && songPath.equals(currentSong.getPath())) {
            broadcastStateUpdate();
            updateNotification();
        }
    }

    private void startSoundTouchPlayback(File audioFile) {
        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(audioFile.getAbsolutePath());

            int audioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrackIndex = i;
                    break;
                }
            }
            if (audioTrackIndex == -1) { handlePlaybackError(); return; }

            mExtractor.selectTrack(audioTrackIndex);
            MediaFormat format = mExtractor.getTrackFormat(audioTrackIndex);
            mSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mChannelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDurationUs = format.containsKey(MediaFormat.KEY_DURATION) ? format.getLong(MediaFormat.KEY_DURATION) : 0;

            mDecoder = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));
            mDecoder.configure(format, null, null, 0);
            mDecoder.start();

            mPitchShifter = new PitchShifter(mSampleRate, mChannelCount);
            mPitchShifter.setTempo(mCurrentSpeed);
            mPitchShifter.setPitch(mCurrentPitchSemitones);

            initAudioTrack();
            requestAudioFocus();
            mAudioTrack.play();

            mIsDecoding.set(true);
            mIsPlayingAudio.set(true);
            mDecodeHandler.post(this::decodeLoop);
            mPlaybackHandler.post(this::playbackLoop);

            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start playback", e);
            handlePlaybackError();
        }
    }

    private void initAudioTrack() {
        if (mAudioTrack != null) {
            try { mAudioTrack.stop(); mAudioTrack.release(); } catch (Exception e) {}
        }
        int channelConfig = (mChannelCount == 1) ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
        int bufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        bufferSize = Math.max(bufferSize, mSampleRate * mChannelCount * 2 / 10);

        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        AudioFormat format = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(mSampleRate).setChannelMask(channelConfig).build();
        mAudioTrack = new AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(format).setBufferSizeInBytes(bufferSize).setTransferMode(AudioTrack.MODE_STREAM).build();

        mAudioSessionId = mAudioTrack.getAudioSessionId();
        EqualizerManager.getInstance(this).attachToAudioSession(mAudioSessionId);
    }

    private void decodeLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;
        while (mIsDecoding.get() && !mOutputEOS.get()) {
            if (mSeekPending.getAndSet(false)) { mDecoder.flush(); inputDone = false; mInputEOS.set(false); continue; }
            if (!inputDone) {
                int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
                if (inputIndex >= 0) {
                    ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                    if (inputBuffer != null) {
                        int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                        if (sampleSize < 0) {
                            mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                            mInputEOS.set(true);
                        } else {
                            mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, mExtractor.getSampleTime(), 0);
                            mExtractor.advance();
                        }
                    }
                }
            }
            int outputIndex = mDecoder.dequeueOutputBuffer(info, TIMEOUT_US);
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                if (outputBuffer != null && info.size > 0) {
                    int sampleCount = info.size / 2;
                    short[] pcm = new short[sampleCount];
                    outputBuffer.order(ByteOrder.LITTLE_ENDIAN);
                    outputBuffer.asShortBuffer().get(pcm);
                    try { mAudioQueue.offer(pcm, 50, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                    if (info.presentationTimeUs > 0) mCurrentPositionUs = info.presentationTimeUs;
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) { mOutputEOS.set(true); mAudioQueue.offer(new short[0]); }
            }
        }
    }

    private void playbackLoop() {
        while (mIsPlayingAudio.get() && !mOutputEOS.get()) {
            short[] pcm;
            try { pcm = mAudioQueue.poll(50, TimeUnit.MILLISECONDS); if (pcm == null) continue; } catch (InterruptedException e) { break; }
            if (pcm.length == 0) break;
            short[] processed = pcm;
            if (mPitchShifter != null && (mCurrentSpeed != 1.0f || mCurrentPitchSemitones != 0f)) {
                int frames = pcm.length / mChannelCount;
                mPitchShifter.putFrames(pcm, frames);
                int avail = mPitchShifter.numFrames();
                if (avail > 0) {
                    short[] shifted = new short[avail * mChannelCount];
                    int received = mPitchShifter.receiveFrames(shifted, avail);
                    if (received > 0) processed = shifted;
                }
            }
            if (mAudioTrack != null && mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                mAudioTrack.write(processed, 0, processed.length);
            }
        }
        mMainHandler.post(this::onSongCompletion);
    }

    private void onSongCompletion() {
        if (mRepeatMode == REPEAT_ONE) playSong(mCurrentIndex);
        else if (mRepeatMode == REPEAT_ALL) playSong((mCurrentIndex + 1) % mPlaylist.size());
        else if (mCurrentIndex + 1 < mPlaylist.size()) playSong(mCurrentIndex + 1);
        else stop();
    }

    private void stopPlayback() {
        mIsDecoding.set(false);
        mIsPlayingAudio.set(false);
        if (mAudioTrack != null) { try { mAudioTrack.stop(); mAudioTrack.release(); } catch (Exception e) {} mAudioTrack = null; }
        if (mPitchShifter != null) { mPitchShifter.close(); mPitchShifter = null; }
        if (mDecoder != null) { try { mDecoder.stop(); mDecoder.release(); } catch (Exception e) {} mDecoder = null; }
        if (mExtractor != null) { try { mExtractor.release(); } catch (Exception e) {} mExtractor = null; }
        if (mAudioQueue != null) mAudioQueue.clear();
    }

    private void handlePlaybackError() {
        int attempts = mRecoveryAttempts.incrementAndGet();
        if (attempts <= MAX_RECOVERY_ATTEMPTS) {
            mMainHandler.postDelayed(() -> {
                if (mCurrentIndex >= 0 && mPlaylist != null && mCurrentIndex < mPlaylist.size()) playSong(mCurrentIndex);
                else if (mPlaylist != null && !mPlaylist.isEmpty()) playSong(0);
            }, RECOVERY_DELAY_MS);
        } else {
            mRecoveryAttempts.set(0);
            mMainHandler.post(this::next);
        }
    }

    private void buildShuffleHistory() {
        mShuffleHistory.clear();
        for (int i = 0; i < mPlaylist.size(); i++) mShuffleHistory.add(i);
        Collections.shuffle(mShuffleHistory, mRandom);
    }

    private int getNextShuffleIndex() {
        if (mShuffleHistory.isEmpty()) buildShuffleHistory();
        int next = mShuffleHistory.remove(0);
        mShuffleHistory.add(next);
        return next;
    }

    private void setupAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            mAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs).setOnAudioFocusChangeListener(this).build();
        }
    }

    private void requestAudioFocus() {
        if (mAudioManager == null) return;
        int result;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            result = mAudioManager.requestAudioFocus((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            result = mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) Log.w(TAG, "Audio focus request denied");
    }

    private void abandonAudioFocus() {
        if (mAudioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            mAudioManager.abandonAudioFocusRequest((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            mAudioManager.abandonAudioFocus(this);
        }
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause();
        else if (focusChange == AudioManager.AUDIOFOCUS_GAIN && !mIsPlaying && mIsPaused) play();
    }

    private void setupMediaSession() {
        mMediaSession = new MediaSession(this, "LlamaMusicPlayer");
        mMediaSession.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { play(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onStop() { stop(); }
            @Override public void onSeekTo(long pos) { seekTo((int) pos); }
        });
        mMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mMediaSession.setActive(true);
        updateMediaSession();
    }

    private void updateMediaSession() {
        if (mMediaSession == null) return;
        int state = (mIsPlaying && !mIsPaused) ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
        PlaybackState playbackState = new PlaybackState.Builder().setState(state, getCurrentPosition(), mCurrentSpeed).setActions(actions).build();
        mMediaSession.setPlaybackState(playbackState);
        Song currentSong = getCurrentSong();
        if (currentSong != null) {
            android.media.session.MediaMetadataCompat metadata = new android.media.session.MediaMetadataCompat.Builder()
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_TITLE, currentSong.getTitle() != null ? currentSong.getTitle() : "")
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_ARTIST, currentSong.getArtist() != null ? currentSong.getArtist() : "")
                    .putString(android.media.session.MediaMetadataCompat.METADATA_KEY_ALBUM, currentSong.getAlbum() != null ? currentSong.getAlbum() : "")
                    .putLong(android.media.session.MediaMetadataCompat.METADATA_KEY_DURATION, getDuration())
                    .build();
            mMediaSession.setMetadata(metadata);
        }
    }

    private void updateNotification() {
        if (mNotificationService == null) return;
        Song currentSong = getCurrentSong();
        if (currentSong != null && (mIsPlaying || mIsPaused)) {
            mNotificationService.updateSongInfo(currentSong.getTitle(), currentSong.getArtist(), currentSong.getPath());
            mNotificationService.setPlayingState(mIsPlaying && !mIsPaused);
        } else if (mPlaylist != null && !mPlaylist.isEmpty()) {
            Song firstSong = mPlaylist.get(0);
            mNotificationService.updateSongInfo(firstSong.getTitle(), firstSong.getArtist(), firstSong.getPath());
            mNotificationService.setPlayingState(false);
        } else {
            mNotificationService.updateSongInfo("", "", null);
            mNotificationService.setPlayingState(false);
        }
    }

    private void broadcastStateUpdate() {
        Intent intent = new Intent(ACTION_UPDATE_PLAYER);
        intent.putExtra("is_playing", mIsPlaying && !mIsPaused);
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("position", getCurrentPosition());
        intent.putExtra("duration", getDuration());
        intent.putExtra("speed_level", mSpeedLevel);
        intent.putExtra("pitch_level", mPitchLevel);
        sendBroadcast(intent);
    }

    private void broadcastPlaylistUpdate() {
        Intent intent = new Intent(ACTION_PLAYLIST_UPDATED);
        intent.putExtra("size", mPlaylist != null ? mPlaylist.size() : 0);
        sendBroadcast(intent);
    }

    private void loadState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, REPEAT_OFF);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
        mSpeedLevel = prefs.getInt(KEY_SPEED_LEVEL, 1000);
        mPitchLevel = prefs.getInt(KEY_PITCH_LEVEL, 1000);
        mCurrentPositionUs = prefs.getLong(KEY_CURRENT_POSITION, 0);
        mBluetoothConnected = prefs.getBoolean(KEY_BLUETOOTH_CONNECTED, false);
        mPlayerStateBeforeUpdate = prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    private void saveState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        editor.putInt(KEY_SPEED_LEVEL, mSpeedLevel);
        editor.putInt(KEY_PITCH_LEVEL, mPitchLevel);
        editor.putBoolean(KEY_BLUETOOTH_CONNECTED, mBluetoothConnected);
        if (getCurrentSong() != null && getCurrentSong().getPath() != null) {
            editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        }
        editor.apply();
    }

    private void saveCurrentSong() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
                .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
                .apply();
    }

    private void saveEffectLevels() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putInt(KEY_SPEED_LEVEL, mSpeedLevel)
                .putInt(KEY_PITCH_LEVEL, mPitchLevel)
                .apply();
    }

    private void saveRepeatMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_REPEAT_MODE, mRepeatMode).apply();
    }

    private void saveShuffleMode() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_SHUFFLE, mIsShuffle).apply();
    }

    private String getLastSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }

    private void applyEffectLevels() {
        mCurrentSpeed = MIN_SPEED + (mSpeedLevel / 2000.0f) * (MAX_SPEED - MIN_SPEED);
        mCurrentPitchSemitones = MIN_PITCH_SEMITONES + (mPitchLevel / 2000.0f) * (MAX_PITCH_SEMITONES - MIN_PITCH_SEMITONES);
        if (mPitchShifter != null) {
            mPitchShifter.setTempo(mCurrentSpeed);
            mPitchShifter.setPitch(mCurrentPitchSemitones);
        }
    }
}