package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with LlamaPlayer integration.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground. The service follows
 * Android's standard service lifecycle and integrates with the system's
 * audio focus, media session, and notification systems.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture to ensure reliable playback:</p>
 * <ul>
 *   <li><b>Primary Path (LlamaPlayer)</b> - DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control with high quality.
 *       Follows MediaPlayer lifecycle pattern for consistency and predictability.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> - Used ONLY when LlamaPlayer
 *       fails at runtime (library missing, initialization error, or crash).
 *       This ensures playback never fails completely.</li>
 * </ul>
 * 
 * <h3>Thread Safety</h3>
 * <p>MusicService implements comprehensive thread safety measures:</p>
 * <ul>
 *   <li><b>Synchronized blocks</b> on mPlayerLock for critical sections</li>
 *   <li><b>AtomicBoolean</b> for transition flags (mIsTransitioning, mIsCompleting)</li>
 *   <li><b>AtomicInteger</b> for preparation IDs to cancel stale operations</li>
 *   <li><b>Volatile variables</b> for state flags shared across threads</li>
 *   <li><b>Main Handler</b> for UI thread callbacks and delayed operations</li>
 * </ul>
 * 
 * <h3>Playlist Management</h3>
 * <p>The service supports:</p>
 * <ul>
 *   <li>Full playlist replacement with current song preservation</li>
 *   <li>Sort mode persistence (Title A-Z, Artist, Album, Genre, Date)</li>
 *   <li>Shuffle mode with history to prevent immediate repeats</li>
 *   <li>Repeat modes: Off, All, Single</li>
 *   <li>Soft updates and pending playlists for sync operations</li>
 * </ul>
 * 
 * <h3>Audio Focus Integration</h3>
 * <p>The service properly handles audio focus changes from other apps:</p>
 * <ul>
 *   <li><b>AUDIOFOCUS_LOSS</b> - Pause playback immediately</li>
 *   <li><b>AUDIOFOCUS_LOSS_TRANSIENT</b> - Pause temporarily</li>
 *   <li><b>AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK</b> - Duck volume to 30%</li>
 *   <li><b>AUDIOFOCUS_GAIN</b> - Restore normal volume</li>
 * </ul>
 * 
 * <h3>Playback Recovery</h3>
 * <p>The service includes automatic recovery mechanisms:</p>
 * <ul>
 *   <li><b>Health Monitoring</b> - Tracks playback position every 1.5 seconds</li>
 *   <li><b>Stall Detection</b> - If position doesn't advance for 3 seconds, trigger recovery</li>
 *   <li><b>Recovery Attempts</b> - Up to 3 attempts before skipping to next song</li>
 *   <li><b>Fallback Player</b> - Automatic switch to MediaPlayer if LlamaPlayer fails</li>
 * </ul>
 * 
 * @see LlamaPlayer
 * @see MediaPlayer
 * @see EqualizerManager
 * @see NotificationService
 * @see android.media.MediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // =========================================================================
    // Constants
    // =========================================================================
    
    /** Tag for logging messages from this class. */
    private static final String TAG = "MusicService";
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Notification ID for foreground service. */
    private static final int NOTIFICATION_ID = 1;
    
    /** Key for storing current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before app update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Action indicating player is ready. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Delay for song transition completion (milliseconds). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Action for audio session change broadcasts. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Interval for health check monitoring (milliseconds). */
    private static final int HEALTH_CHECK_INTERVAL_MS = 1500;
    
    /** Maximum stall time before recovery (milliseconds). */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Delay before pre-initializing next song (milliseconds). */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay before resetting seek flag (milliseconds). */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    /** Timeout for player preparation (milliseconds). */
    private static final int PREPARE_TIMEOUT_MS = 500;
    
    /** Interval for MediaPlayer position polling (milliseconds). */
    private static final int MEDIA_PLAYER_POLLING_INTERVAL_MS = 150;
    
    // Sort Mode Constants
    /** Sort by title A-Z. */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort by title Z-A. */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort by artist A-Z. */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort by artist Z-A. */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort by album A-Z. */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort by album Z-A. */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort by genre A-Z. */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort by genre Z-A. */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort by oldest first (by file date). */
    private static final int SORT_OLDEST = 8;
    
    /** Sort by newest first (by file date). */
    private static final int SORT_NEWEST = 9;
    
    // =========================================================================
    // Static Members
    // =========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;
    
    // =========================================================================
    // LlamaPlayer Members (PRIMARY PLAYER)
    // =========================================================================
    
    /** Primary audio player with SoundTouch processing. */
    private LlamaPlayer mLlamaPlayer;
    
    /** True if LlamaPlayer is currently active. */
    private boolean mIsUsingLlamaPlayer = false;
    
    /** True if LlamaPlayer has failed and fallback should be used. */
    private boolean mLlamaPlayerFailed = false;
    
    /** Atomic flag for LlamaPlayer preparation state. */
    private final AtomicBoolean mIsPreparingLlamaPlayer = new AtomicBoolean(false);
    
    /** Handler for preparation timeouts. */
    private final Handler mPrepareTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable for preparation timeout callback. */
    private Runnable mPrepareTimeoutRunnable = null;
    
    /** Flag indicating if playback should start after preparation completes. */
    private boolean mShouldStartAfterPrepare = false;
    
    // =========================================================================
    // Seek Queue Members
    // =========================================================================
    
    /** Pending seek position during preparation (-1 if none). */
    private final AtomicInteger mPendingSeekPosition = new AtomicInteger(-1);
    
    /** Sequence number for pending seek (to handle multiple seeks). */
    private final AtomicInteger mPendingSeekSequence = new AtomicInteger(0);
    
    /** Last applied seek sequence (prevents stale seeks). */
    private volatile int mLastAppliedSeekSequence = -1;
    
    // =========================================================================
    // MediaPlayer Members (FALLBACK PLAYER)
    // =========================================================================
    
    /** Fallback Android MediaPlayer instance. */
    private MediaPlayer mMediaPlayer;
    
    // =========================================================================
    // MediaPlayer Polling Components
    // =========================================================================
    
    /** Handler for MediaPlayer position polling. */
    private Handler mMediaPlayerPollingHandler;
    
    /** Runnable for MediaPlayer position polling. */
    private Runnable mMediaPlayerPollingRunnable;
    
    /** True if MediaPlayer polling is active. */
    private boolean mIsPollingForMediaPlayer = false;
    
    // =========================================================================
    // Playback State
    // =========================================================================
    
    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of currently playing song in playlist. */
    private volatile int mCurrentIndex = -1;
    
    /** True if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0=off, 1=all, 2=one. */
    private volatile int mRepeatMode = 0;
    
    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Timestamp when current playback started (for stall detection). */
    private long mPlaybackStartTime = 0;
    
    /** Position to restore when fallback player is used. */
    private int mPendingRestorePosition = 0;
    
    // =========================================================================
    // Sort Mode State
    // =========================================================================
    
    /** Current playlist sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // =========================================================================
    // Health Check Components (MediaPlayer only)
    // =========================================================================
    
    /** Handler for health check monitoring. */
    private Handler mHealthHandler;
    
    /** Runnable for health check monitoring. */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts made so far. */
    private int mRecoveryAttempts = 0;
    
    // =========================================================================
    // Wake Lock for Background Playback
    // =========================================================================
    
    /** Wake lock to prevent CPU sleep during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // =========================================================================
    // Audio Focus Management
    // =========================================================================
    
    /** Audio manager for focus and volume control. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O and above. */
    private AudioFocusRequest mAudioFocusRequest;
    
    // =========================================================================
    // Media Session
    // =========================================================================
    
    /** Media session for lock screen controls. */
    private MediaSession mMediaSession;
    
    // =========================================================================
    // Bluetooth State
    // =========================================================================
    
    /** True if a Bluetooth device is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // =========================================================================
    // Thread Safety and Async Operations
    // =========================================================================
    
    /** Lock for player operations. */
    private final Object mPlayerLock = new Object();
    
    /** Atomic flag for transition lock. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Atomic flag for fallback preparation state. */
    private final AtomicBoolean mIsPreparingFallback = new AtomicBoolean(false);
    
    /** Atomic integer for global preparation ID. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID for validation. */
    private volatile int mCurrentPrepId = -1;
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** True if playback restoration is in progress. */
    private boolean mIsRestoringPlayback = false;
    
    // =========================================================================
    // Completion Handler Race Condition Prevention
    // =========================================================================
    
    /** Prevents re-entrant completion handling. */
    private final AtomicBoolean mIsCompleting = new AtomicBoolean(false);
    
    // =========================================================================
    // PlaybackController
    // =========================================================================
    
    /** Centralized playback state controller. */
    @Nullable
    private PlaybackController mPlaybackController;
    
    // =========================================================================
    // Binder
    // =========================================================================
    
    /** Binder for service binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // =========================================================================
    // Playlist Management
    // =========================================================================
    
    /** History of shuffled indices to prevent immediate repeats. */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft updates. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** True if a pending playlist is waiting. */
    private boolean mHasPendingPlaylist = false;
    
    // =========================================================================
    // Notification Service
    // =========================================================================
    
    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;
    
    // =========================================================================
    // Sync State
    // =========================================================================
    
    /** Flag indicating if a sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    // =========================================================================
    // Broadcast Receivers
    // =========================================================================
    
    /** Receiver for notification updates. */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates. */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for playlist clear commands. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme change events. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for playing state queries. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode changes. */
    private BroadcastReceiver mSortModeReceiver;
    
    /** Receiver for restoring playback state after sync. */
    private BroadcastReceiver mPlaybackRestoreReceiver;
    
    /** Receiver for sync state changes. */
    private BroadcastReceiver mSyncStateReceiver;
    
    // =========================================================================
    // Inner Classes
    // =========================================================================
    
    /**
     * Local binder for service binding.
     * 
     * <p>This binder allows activities to obtain a reference to the MusicService
     * instance for direct method calls, enabling efficient communication without
     * the overhead of AIDL.</p>
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the MusicService instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // =========================================================================
    // Sort Comparator Classes
    // =========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by oldest first (by file modification date).
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by newest first (by file modification date).
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // =========================================================================
    // Static Methods
    // =========================================================================
    
    /**
     * Sets a flag indicating player state should be preserved before app update.
     *
     * @param context The application context
     * @param need True if state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Checks if player state should be preserved before app update.
     *
     * @param context The application context
     * @return True if state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state preservation flag.
     *
     * @param context The application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID for equalizer attachment.
     *
     * @return The audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // =========================================================================
    // Service Lifecycle Methods
    // =========================================================================
    
    /**
     * Called when the service is created.
     * 
     * <p>This method initializes all service components:</p>
     * <ul>
     *   <li>Notification service for foreground playback</li>
     *   <li>Audio manager for focus management</li>
     *   <li>Media session for lock screen controls</li>
     *   <li>Equalizer manager</li>
     *   <li>Wake lock for background playback</li>
     *   <li>LlamaPlayer as the primary audio player</li>
     *   <li>Broadcast receivers for inter-component communication</li>
     *   <li>PlaybackController listener registration</li>
     * </ul>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparingFallback.set(false);
        
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        createForegroundNotificationChannel();
        Notification notification = createMinimalForegroundNotification();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.d(TAG, "Foreground service started");
        
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        loadRepeatAndShuffle();
        loadSortMode();
        
        setupMediaSession();
        EqualizerManager.getInstance(this);
        
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        setupAudioFocus();
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        initLlamaPlayer();
        
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerPlaybackRestoreReceiver();
        registerSyncStateReceiver();
        
        mPlaybackController = PlaybackController.getInstance();
        
        NavigationController.getInstance().registerListener(new NavigationController.ButtonStateListener() {
            @Override
            public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
                if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS && mNotificationService != null) {
                    // Sync state is now handled by mIsSyncInProgress flag
                    Log.d(TAG, "Folder actions state changed: " + disabled);
                }
            }
        });
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Creates the notification channel for foreground service (Android O+).
     */
    private void createForegroundNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "foreground_channel",
                "Music Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Required for background music playback");
            channel.setSound(null, null);
            channel.enableVibration(false);
            
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * Creates a minimal notification for foreground service startup.
     *
     * @return The notification to display
     */
    private Notification createMinimalForegroundNotification() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, MusicPlayer.class), flags);
        
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("foreground_channel");
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
               .setContentTitle("Llama Music Player")
               .setContentText("Starting...")
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setVisibility(Notification.VISIBILITY_PUBLIC);
        
        return builder.build();
    }
    
    /**
     * Initializes the LlamaPlayer as the default player.
     * 
     * <p>This method checks if the SoundTouch native library is available.
     * If not, it sets the fallback flag so MediaPlayer will be used instead.</p>
     */
    private void initLlamaPlayer() {
        if (mLlamaPlayerFailed) {
            Log.d(TAG, "LlamaPlayer already failed, skipping init");
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        if (!SoundTouch.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mLlamaPlayerFailed = true;
            mIsUsingLlamaPlayer = false;
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        try {
            mLlamaPlayer = new LlamaPlayer(this);
            mLlamaPlayer.setListener(new LlamaPlayer.PlaybackListener() {
                @Override
                public void onStateChanged(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
                    handleLlamaPlayerStateChange(newState, oldState);
                }
                
                @Override
                public void onPrepared() {
                    Log.d(TAG, "LlamaPlayer: onPrepared()");
                    mIsPreparingLlamaPlayer.set(false);
                    
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    
                    sendPlayerStatusBroadcast(true);
                    updatePlaybackParams();
                    
                    sCurrentAudioSessionId = mLlamaPlayer.getAudioSessionId();
                    broadcastAudioSessionChanged(sCurrentAudioSessionId);
                    EqualizerManager.getInstance(MusicService.this)
                        .attachToAudioSession(sCurrentAudioSessionId);
                    
                    updateMediaSessionMetadata();
                    
                    int pendingPos = mPendingSeekPosition.getAndSet(-1);
                    if (pendingPos >= 0) {
                        int sequence = mPendingSeekSequence.get();
                        if (sequence > mLastAppliedSeekSequence) {
                            mLlamaPlayer.seekTo(pendingPos);
                            mLastAppliedSeekSequence = sequence;
                            Log.d(TAG, "Applied pending seek after prepare: " + pendingPos + "ms");
                        }
                    } else if (mPendingRestorePosition > 0) {
                        mLlamaPlayer.seekTo(mPendingRestorePosition);
                        mPendingRestorePosition = 0;
                    }
                    
                    if (mPlaybackController != null) {
                        mPlaybackController.setDuration(mLlamaPlayer.getDuration(), "LlamaPlayer.onPrepared");
                        if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                            mCurrentIndex < mCurrentPlaylist.size()) {
                            mPlaybackController.updateSong(mCurrentPlaylist.get(mCurrentIndex), "LlamaPlayer.onPrepared");
                        }
                    }
                    
                    if (mShouldStartAfterPrepare) {
                        mShouldStartAfterPrepare = false;
                        mLlamaPlayer.start();
                    } else {
                        if (mPlaybackController != null) {
                            mPlaybackController.setPrepared(true, "LlamaPlayer.onPrepared");
                            mPlaybackController.setPlaying(false, "LlamaPlayer.onPrepared");
                        }
                    }
                    
                    broadcastUpdate();
                    createNotification();
                    
                    Intent readyIntent = new Intent(ACTION_PLAYER_READY);
                    sendBroadcast(readyIntent);
                    Log.d(TAG, "Broadcasted ACTION_PLAYER_READY (LlamaPlayer)");
                }
                
                @Override
                public void onCompletion() {
                    Log.d(TAG, "LlamaPlayer: onCompletion()");
                    handleCompletion();
                }
                
                @Override
                public void onPositionUpdate(long position) {
                    if (mPlaybackController != null) {
                        mPlaybackController.updatePosition(position, "LlamaPlayer.onPositionUpdate");
                    }
                }
                
                @Override
                public void onError(String error) {
                    Log.e(TAG, "LlamaPlayer error: " + error);
                    mIsPreparingLlamaPlayer.set(false);
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    
                    if (mPlaybackController != null) {
                        mPlaybackController.notifyOperationFailed("play", error);
                    }
                    
                    fallbackToMediaPlayer();
                }
            });
            
            mIsUsingLlamaPlayer = true;
            Log.d(TAG, "LlamaPlayer initialized successfully");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize LlamaPlayer", e);
            mLlamaPlayerFailed = true;
            mIsUsingLlamaPlayer = false;
            sendPlayerStatusBroadcast(false);
            
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("initialize", e.getMessage());
            }
        }
    }
    
    // =========================================================================
    // MediaPlayer Polling Methods
    // =========================================================================
    
    /**
     * Starts polling MediaPlayer for position updates.
     * 
     * <p>MediaPlayer does not provide continuous position callbacks like LlamaPlayer,
     * so polling is necessary to keep the UI updated during playback.</p>
     */
    private void startMediaPlayerPolling() {
        if (mIsPollingForMediaPlayer) return;
        if (mIsUsingLlamaPlayer) return;
        
        if (mMediaPlayerPollingHandler == null) {
            mMediaPlayerPollingHandler = new Handler(Looper.getMainLooper());
        }
        
        stopMediaPlayerPolling();
        
        mMediaPlayerPollingRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mIsUsingLlamaPlayer && mMediaPlayer != null && mIsPlaying) {
                    try {
                        int position = mMediaPlayer.getCurrentPosition();
                        int duration = mMediaPlayer.getDuration();
                        
                        if (mPlaybackController != null) {
                            mPlaybackController.updatePosition(position, "MediaPlayer.polling");
                            if (duration > 0) {
                                mPlaybackController.setDuration(duration, "MediaPlayer.polling");
                            }
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "MediaPlayer polling: illegal state", e);
                    } catch (Exception e) {
                        Log.w(TAG, "MediaPlayer polling error", e);
                    }
                }
                
                if (mMediaPlayerPollingHandler != null && !mIsUsingLlamaPlayer && mMediaPlayer != null) {
                    mMediaPlayerPollingHandler.postDelayed(this, MEDIA_PLAYER_POLLING_INTERVAL_MS);
                } else {
                    mIsPollingForMediaPlayer = false;
                }
            }
        };
        
        mIsPollingForMediaPlayer = true;
        mMediaPlayerPollingHandler.post(mMediaPlayerPollingRunnable);
        Log.d(TAG, "MediaPlayer polling started");
    }
    
    /**
     * Stops polling MediaPlayer for position updates.
     */
    private void stopMediaPlayerPolling() {
        if (mMediaPlayerPollingHandler != null && mMediaPlayerPollingRunnable != null) {
            mMediaPlayerPollingHandler.removeCallbacks(mMediaPlayerPollingRunnable);
        }
        mIsPollingForMediaPlayer = false;
        Log.d(TAG, "MediaPlayer polling stopped");
    }
    
    // =========================================================================
    // Centralized Playback State Management
    // =========================================================================
    
    /**
     * Sets the centralized playback state and manages related resources.
     * 
     * <p>This method:</p>
     * <ul>
     *   <li>Updates PlaybackController with new playing/prepared states</li>
     *   <li>Starts/stops MediaPlayer polling based on player type</li>
     *   <li>Acquires/releases wake lock based on playing state</li>
     *   <li>Requests/abandons audio focus based on playing state</li>
     *   <li>Broadcasts updates and refreshes notifications</li>
     *   <li>Updates MediaSession playback state</li>
     * </ul>
     *
     * @param isPlaying True if playback should start
     * @param isPrepared True if player is prepared
     */
    private void setPlaybackState(boolean isPlaying, boolean isPrepared) {
        synchronized (mPlayerLock) {
            boolean wasPlaying = mIsPlaying;
            mIsPlaying = isPlaying;
            
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(isPlaying, "MusicService.setPlaybackState");
                mPlaybackController.setPrepared(isPrepared, "MusicService.setPlaybackState");
            }
            
            if (isPlaying && !mIsUsingLlamaPlayer && mMediaPlayer != null) {
                startMediaPlayerPolling();
            } else if (!isPlaying) {
                stopMediaPlayerPolling();
            }
            
            if (isPlaying && !wasPlaying) {
                if (mWakeLock != null && !mWakeLock.isHeld()) {
                    mWakeLock.acquire(3600000);
                    Log.d(TAG, "WakeLock acquired");
                }
                requestAudioFocus();
            } else if (!isPlaying && wasPlaying) {
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released");
                }
                abandonAudioFocus();
            }
        }
        
        broadcastUpdate();
        createNotification();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Handles LlamaPlayer state change events.
     *
     * @param newState The new player state
     * @param oldState The previous player state
     */
    private void handleLlamaPlayerStateChange(LlamaPlayer.State newState, LlamaPlayer.State oldState) {
        Log.d(TAG, "LlamaPlayer state: " + oldState + " -> " + newState);
        
        switch (newState) {
            case STARTED:
                setPlaybackState(true, true);
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(true, "LlamaPlayer.STARTED");
                    mPlaybackController.setPrepared(true, "LlamaPlayer.STARTED");
                }
                break;
            case PAUSED:
                setPlaybackState(false, true);
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "LlamaPlayer.PAUSED");
                    mPlaybackController.setPrepared(true, "LlamaPlayer.PAUSED");
                }
                break;
            case COMPLETED:
                setPlaybackState(false, false);
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "LlamaPlayer.COMPLETED");
                    mPlaybackController.setPrepared(false, "LlamaPlayer.COMPLETED");
                    mPlaybackController.updatePosition(0, "LlamaPlayer.COMPLETED");
                }
                break;
            case ERROR:
            case RELEASED:
                setPlaybackState(false, false);
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                }
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "LlamaPlayer.ERROR");
                    mPlaybackController.setPrepared(false, "LlamaPlayer.ERROR");
                }
                break;
            case PREPARED:
                if (mPlaybackController != null) {
                    mPlaybackController.setPrepared(true, "LlamaPlayer.PREPARED");
                    if (mLlamaPlayer != null) {
                        mPlaybackController.setDuration(mLlamaPlayer.getDuration(), "LlamaPlayer.PREPARED");
                        Song currentSong = getCurrentSong();
                        if (currentSong != null) {
                            mPlaybackController.updateSong(currentSong, "LlamaPlayer.PREPARED");
                        }
                    }
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Broadcasts which player is currently active (LlamaPlayer or MediaPlayer).
     *
     * @param isLlamaPlayerActive True if LlamaPlayer is active
     */
    private void sendPlayerStatusBroadcast(boolean isLlamaPlayerActive) {
        Intent intent = new Intent(ACTION_PLAYER_STATUS_UPDATE);
        intent.putExtra("player_type", isLlamaPlayerActive ? "LlamaPlayer" : "MediaPlayer");
        sendBroadcast(intent);
    }
    
    /**
     * Falls back to MediaPlayer when LlamaPlayer fails.
     * 
     * <p>This method preserves the current playback position and attempts
     * to resume playback using the fallback MediaPlayer.</p>
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingLlamaPlayer) {
            return;
        }
        
        Log.w(TAG, "FALLBACK: Switching from LlamaPlayer to MediaPlayer");
        mIsUsingLlamaPlayer = false;
        mLlamaPlayerFailed = true;
        
        sendPlayerStatusBroadcast(false);
        
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        boolean wasPlaying = mIsPlaying;
        
        if (mLlamaPlayer != null) {
            currentPosition = (int) mLlamaPlayer.getCurrentPosition();
            mLlamaPlayer.release();
            mLlamaPlayer = null;
        }
        
        if (currentIndex >= 0 && mCurrentPlaylist != null && 
            currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex + 
                  " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
            
            if (!wasPlaying && mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                mIsPlaying = false;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "fallbackToMediaPlayer");
                }
            }
        }
    }
    
    /**
     * Pre-initializes the current song for faster playback when needed.
     */
    private void preInitializeCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "preInitializeCurrentSong: No playlist, skipping");
            return;
        }
        
        int index = mCurrentIndex >= 0 ? mCurrentIndex : 0;
        if (index >= mCurrentPlaylist.size()) {
            index = 0;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.d(TAG, "preInitializeCurrentSong: Invalid song at index " + index);
            return;
        }
        
        if (!mLlamaPlayerFailed && mLlamaPlayer != null) {
            mShouldStartAfterPrepare = false;
            mLlamaPlayer.reset();
            mLlamaPlayer.setDataSource(song.getPath());
            mLlamaPlayer.prepareAsync();
            Log.d(TAG, "preInitializeCurrentSong: Started pre-load for: " + song.getTitle());
        }
    }
    
    /**
     * Called when the service is started via startService().
     * 
     * <p>Handles various actions from notifications and other components.</p>
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return The service's return code (START_STICKY for automatic restart)
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a component binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for communication with the service
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is being destroyed.
     * 
     * <p>Performs comprehensive cleanup:</p>
     * <ul>
     *   <li>Saves full player state to SharedPreferences</li>
     *   <li>Stops health monitoring and polling</li>
     *   <li>Releases wake lock if held</li>
     *   <li>Releases LlamaPlayer and MediaPlayer resources</li>
     *   <li>Stops notification service</li>
     *   <li>Releases MediaSession</li>
     *   <li>Abandons audio focus</li>
     *   <li>Unregisters broadcast receivers</li>
     * </ul>
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        stopMediaPlayerPolling();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.release();
            mLlamaPlayer = null;
        }
        
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        if (mMediaPlayerPollingHandler != null) {
            mMediaPlayerPollingHandler.removeCallbacksAndMessages(null);
            mMediaPlayerPollingHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlaybackRestoreReceiver);
        unregisterReceiverSafely(mSyncStateReceiver);
        
        super.onDestroy();
    }
    
    /**
     * Called when the system requests memory trimming.
     * 
     * <p>For MediaPlayer fallback, attempts to reinitialize the player
     * if memory pressure is moderate or higher.</p>
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mIsUsingLlamaPlayer) return;
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // =========================================================================
    // Public API Methods for MusicPlayer
    // =========================================================================
    
    /**
     * Checks if any player (LlamaPlayer or MediaPlayer) is currently playing.
     *
     * @return True if audio is playing
     */
    public boolean isAnyPlayerPlaying() {
        if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
            return mLlamaPlayer.isPlaying();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                return mMediaPlayer.isPlaying();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * Checks if any player is prepared for playback.
     *
     * @return True if a player is prepared
     */
    public boolean isAnyPlayerPrepared() {
        if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
            return mLlamaPlayer.isPrepared();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            return true;
        }
        return false;
    }
    
    /**
     * Checks if LlamaPlayer is currently active.
     *
     * @return True if LlamaPlayer is active
     */
    public boolean isUsingLlamaPlayer() {
        return mIsUsingLlamaPlayer;
    }
    
    /**
     * Sets the sync in progress flag.
     * Called by FolderManager when a sync operation starts/ends.
     *
     * @param inProgress True if sync is in progress
     */
    public void setSyncInProgress(boolean inProgress) {
        mIsSyncInProgress = inProgress;
        Log.d(TAG, "setSyncInProgress: " + inProgress);
    }
    
    // =========================================================================
    // Sort Mode Methods
    // =========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    /**
     * Returns the comparator for the given sort mode.
     *
     * @param sortMode The sort mode constant
     * @return The comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the file modification date for a song.
     *
     * @param song The song to query
     * @return The last modified timestamp, or 0 if path is null
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    /**
     * Reorders the playlist according to the current sort mode.
     * 
     * <p>Preserves the current playing song by finding its new index
     * after sorting.</p>
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    saveCurrentPlayingIndex();
                    break;
                }
            }
        }
    }
    
    // =========================================================================
    // Broadcast Receiver Registration
    // =========================================================================
    
    /**
     * Registers receiver for notification updates during sync operations.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers receiver for playback parameter updates from equalizer.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }
    
    /**
     * Registers receiver for playlist clear commands.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }
    
    /**
     * Registers receiver for theme change events.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }
    
    /**
     * Registers receiver for playing state queries.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }
    
    /**
     * Registers receiver for sort mode change events.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }
    
    /**
     * Registers receiver to restore playback state after folder sync completes.
     * This allows the service to resume playback from the exact position and song
     * that was playing before the sync operation.
     */
    private void registerPlaybackRestoreReceiver() {
        mPlaybackRestoreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("RESTORE_PLAYBACK_STATE".equals(intent.getAction())) {
                    String songPath = intent.getStringExtra("song_path");
                    int position = intent.getIntExtra("position", 0);
                    boolean shouldPlay = intent.getBooleanExtra("should_play", false);
                    
                    Log.d(TAG, "Playback restore received: path=" + songPath + 
                          ", position=" + position + ", play=" + shouldPlay);
                    
                    if (songPath != null && !songPath.isEmpty() && mCurrentPlaylist != null) {
                        // Find the song in the current playlist by path
                        int newIndex = -1;
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            Song song = mCurrentPlaylist.get(i);
                            if (song != null && songPath.equals(song.getPath())) {
                                newIndex = i;
                                break;
                            }
                        }
                        
                        if (newIndex >= 0) {
                            Log.d(TAG, "Restoring playback at index " + newIndex + 
                                  ", position " + position + "ms");
                            
                            // Play the song at the restored position
                            playSongAtPosition(newIndex, position);
                            
                            // Restore playing state if it was playing before sync
                            if (shouldPlay && !isAnyPlayerPlaying()) {
                                resume();
                            }
                        } else {
                            Log.w(TAG, "Song not found in playlist after sync: " + songPath);
                        }
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("RESTORE_PLAYBACK_STATE");
        registerReceiver(mPlaybackRestoreReceiver, filter);
        Log.d(TAG, "Playback restore receiver registered");
    }
    
    /**
     * Registers receiver for sync state changes from FolderManager.
     */
    private void registerSyncStateReceiver() {
        mSyncStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTING".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    Log.d(TAG, "Sync starting - notification updates suppressed");
                } else if ("SYNC_ENDING".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    Log.d(TAG, "Sync ending - notification updates resumed");
                    // Force a notification update to refresh the display
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTING");
        filter.addAction("SYNC_ENDING");
        registerReceiver(mSyncStateReceiver, filter);
        Log.d(TAG, "Sync state receiver registered");
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // =========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // =========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer to prevent memory leaks.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }
    
    /**
     * Safely resets the MediaPlayer to its initial state.
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and frees all resources.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        stopMediaPlayerPolling();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
                try { mMediaPlayer.release(); } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates a MediaPlayer instance with error handling.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparingFallback.set(false);
                        
                        if (mPlaybackController != null) {
                            mPlaybackController.notifyOperationFailed("play", "MediaPlayer error: " + what);
                        }
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            new Handler(Looper.getMainLooper()).postDelayed(() -> 
                                prepareAndPlay(recoverIndex, recoverPosition), 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for operations.
     *
     * @return True if MediaPlayer is in a valid state
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try { 
                mMediaPlayer.getDuration(); 
                return true; 
            } catch (Exception e) { 
                return false; 
            }
        }
    }
    
    // =========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // =========================================================================
    
    /**
     * Starts health monitoring for MediaPlayer playback stall detection.
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) mHealthHandler = new Handler(Looper.getMainLooper());
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
    }
    
    /**
     * Stops health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks playback health and triggers recovery if stalled.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingLlamaPlayer) return;
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            recoverFromStall();
        }
    }
    
    /**
     * Recovers from a playback stall by reinitializing the player.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        stopMediaPlayerPolling();
        
        if (mMediaPlayer != null) {
            try { if (mIsPlaying) mMediaPlayer.pause(); } catch (Exception ignored) {}
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (currentIndex >= 0 && mCurrentPlaylist != null && 
                currentIndex < mCurrentPlaylist.size()) {
                prepareAndPlay(currentIndex, currentPosition);
                sendBroadcast(new Intent("PLAYBACK_RECOVERED"));
            }
        }, 500);
    }
    
    // =========================================================================
    // Async Operation Management
    // =========================================================================
    
    /**
     * Invalidates all ongoing preparation operations.
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Attempts to acquire the transition lock.
     *
     * @return True if lock was acquired
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // =========================================================================
    // Notification Methods
    // =========================================================================
    
    /**
     * Updates the notification playback state.
     *
     * @param isPlaying True if playing
     */
    private void updateNotificationPlaybackState(boolean isPlaying) {
        if (mNotificationService != null) {
            mNotificationService.setPlayingState(isPlaying);
            mNotificationService.forceUpdate();
            Log.d(TAG, "Notification playback state updated: " + (isPlaying ? "PLAYING" : "PAUSED"));
        }
    }
    
    /**
     * Creates and updates the playback notification.
     * Skips notification update during sync to prevent interruption.
     */
    private void createNotification() {
        // Skip notification update during sync to prevent interruption
        if (mIsSyncInProgress) {
            Log.d(TAG, "createNotification: Sync in progress, skipping");
            return;
        }
        
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
                mNotificationService.setPlayingState(mIsPlaying);
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        mNotificationService.forceUpdate();
    }
    
    /**
     * Refreshes the notification (called after sync state changes).
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // =========================================================================
    // State Persistence Methods
    // =========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves full player state (calls savePlayerState).
     */
    private void saveFullState() {
        savePlayerState();
    }
    
    /**
     * Gets the saved playback position from SharedPreferences.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before app restart.
     *
     * @return True if playback was active
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved last song path from SharedPreferences.
     *
     * @return The last song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state (isPlaying and position) to SharedPreferences.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // =========================================================================
    // Playlist Management Methods
    // =========================================================================
    
    /**
     * Sets the current playlist.
     * 
     * <p>This method handles:</p>
     * <ul>
     *   <li>Sorting the playlist according to current sort mode</li>
     *   <li>Preserving the currently playing song if requested</li>
     *   <li>Restoring playback state from SharedPreferences</li>
     *   <li>Pre-initializing the next song for faster response</li>
     * </ul>
     *
     * @param playlist The new playlist (can be null to clear)
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        // Skip if sync is in progress - let FolderManager handle restoration
        if (mIsSyncInProgress) {
            Log.d(TAG, "setPlaylist: Sync in progress, deferring full replacement");
            if (playlist != null && !playlist.isEmpty()) {
                // Just update the reference without resetting playback
                mCurrentPlaylist = new ArrayList<>(playlist);
            }
            return;
        }
        
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
                    currentPosition = (int) mLlamaPlayer.getCurrentPosition();
                    wasPlaying = mLlamaPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
            }
            
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                if (mLlamaPlayer != null) mLlamaPlayer.reset();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                    mNotificationService.setPlayingState(false);
                }
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mPlaybackController != null) {
                    mPlaybackController.reset();
                }
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            boolean playlistUnchanged = false;
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                playlistUnchanged = true;
                for (int i = 0; i < playlist.size() && playlistUnchanged; i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        playlistUnchanged = false;
                    }
                }
            }
            
            if (playlistUnchanged && preserveCurrentSong) {
                if (!sortedPlaylist.equals(mCurrentPlaylist)) {
                    String currentPath = (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) 
                        ? mCurrentPlaylist.get(mCurrentIndex).getPath() : null;
                    mCurrentPlaylist = sortedPlaylist;
                    if (currentPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(currentPath)) {
                                mCurrentIndex = i;
                                break;
                            }
                        }
                    }
                }
                broadcastUpdate();
                return;
            }
            
            if (!preserveCurrentSong) {
                invalidateAllPreparations();
                if (mLlamaPlayer != null) mLlamaPlayer.reset();
                resetPlayerSafely();
                mIsPlaying = false;
            }
            
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
            } else {
                mCurrentIndex = -1;
            }
            
            saveCurrentPlayingIndex();
            
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            mIsRestoringPlayback = true;
            
            mMainHandler.postDelayed(() -> {
                if (mIsRestoringPlayback) {
                    mIsRestoringPlayback = false;
                    Log.w(TAG, "Restoration timeout - flag reset");
                }
            }, 3000);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    if (!mLlamaPlayerFailed && mLlamaPlayer != null) {
                        playSongWithLlamaPlayer(correctIndex, true);
                        if (savedPosition > 0) {
                            mLlamaPlayer.seekTo(savedPosition);
                        }
                    } else {
                        prepareAndPlay(correctIndex, savedPosition);
                    }
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    if (!mLlamaPlayerFailed && mLlamaPlayer != null) {
                        playSongWithLlamaPlayer(mCurrentIndex, true);
                        if (savedPosition > 0) {
                            mLlamaPlayer.seekTo(savedPosition);
                        }
                    } else {
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                }
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            }
            
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                mMainHandler.postDelayed(this::preInitializeCurrentSong, PRE_INIT_DELAY_MS);
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist (convenience overload).
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops all playback and clears all playlist data.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        stopMediaPlayerPolling();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparingFallback.set(false);
            mIsPreparingLlamaPlayer.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mLlamaPlayer != null) mLlamaPlayer.reset();
            
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            if (mPlaybackController != null) {
                mPlaybackController.reset();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Performs a soft update of the playlist (used during sync operations).
     *
     * @param newPlaylist The new playlist to apply later
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    /**
     * Updates the playlist WITHOUT interrupting current playback.
     * This is the key method that fixes the sync interruption problem.
     * 
     * <p>Unlike setPlaylist(), this method preserves the currently playing song
     * by finding it in the new playlist by its file path (not index). It also
     * restores the playback position and playing state.</p>
     *
     * @param newPlaylist The new playlist from the database
     * @param currentSongPath The path of the currently playing song (can be null)
     * @param currentPosition The current playback position in milliseconds
     * @param wasPlaying True if playback was active before sync
     */
    public void softUpdatePlaylist(@NonNull ArrayList<Song> newPlaylist, 
                                    @Nullable String currentSongPath,
                                    int currentPosition, 
                                    boolean wasPlaying) {
        synchronized (mPlayerLock) {
            Log.d(TAG, "softUpdatePlaylist: preserving playback state");
            
            // Find the same song in the new playlist by PATH (not index!)
            int newIndex = -1;
            if (currentSongPath != null) {
                for (int i = 0; i < newPlaylist.size(); i++) {
                    Song song = newPlaylist.get(i);
                    if (song != null && currentSongPath.equals(song.getPath())) {
                        newIndex = i;
                        Log.d(TAG, "Found current song at new index: " + newIndex);
                        break;
                    }
                }
            }
            
            // Update the playlist reference
            mCurrentPlaylist = new ArrayList<>(newPlaylist);
            
            if (newIndex >= 0) {
                // Song still exists - update index and restore position
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                
                // Restore position if needed (skip if position is 0 or if difference is small)
                int currentPlayerPos = getCurrentPosition();
                if (Math.abs(currentPlayerPos - currentPosition) > 1000 && currentPosition > 0) {
                    Log.d(TAG, "Restoring position from " + currentPlayerPos + " to " + currentPosition + "ms");
                    seekTo(currentPosition);
                }
                
                // Update the PlaybackController with the restored song
                if (mPlaybackController != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                    Song restoredSong = mCurrentPlaylist.get(mCurrentIndex);
                    if (restoredSong != null) {
                        mPlaybackController.updateSong(restoredSong, "softUpdatePlaylist");
                        mPlaybackController.setDuration(restoredSong.getDuration(), "softUpdatePlaylist");
                    }
                }
            } else if (currentSongPath != null) {
                // Current song was removed from playlist - stop gracefully
                Log.d(TAG, "Current song no longer in playlist, stopping playback");
                if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                    mLlamaPlayer.pause();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    mMediaPlayer.pause();
                }
                mIsPlaying = false;
                mCurrentIndex = -1;
                
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "softUpdatePlaylist.songRemoved");
                    mPlaybackController.setPrepared(false, "softUpdatePlaylist.songRemoved");
                    mPlaybackController.updateSong(null, "softUpdatePlaylist.songRemoved");
                }
            }
            
            // Restore playing state if it was playing before sync and we have a valid index
            if (wasPlaying && newIndex >= 0 && !isAnyPlayerPlaying()) {
                Log.d(TAG, "Restoring playing state after sync");
                if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                    mLlamaPlayer.start();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    mMediaPlayer.start();
                }
                mIsPlaying = true;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(true, "softUpdatePlaylist");
                }
            }
            
            // Update UI and notification
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "softUpdatePlaylist completed - playback preserved");
        }
    }
    
    // =========================================================================
    // Playback Control Methods
    // =========================================================================
    
    /**
     * Immediately updates the UI with song information for the given index.
     *
     * @param index The playlist index
     */
    private void updateUIImmediately(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || mPlaybackController == null) {
            return;
        }
        
        mPlaybackController.updateSong(song, "MusicService.updateUIImmediately");
    }
    
    /**
     * Plays a song with SoundTouch-based LlamaPlayer.
     * 
     * <p>Validates file exists before attempting to play.
     * If file is missing, removes it from playlist and plays next.</p>
     *
     * @param index Index of song to play
     * @param autoStart Whether to start playback immediately after preparation
     */
    private void playSongWithLlamaPlayer(int index, boolean autoStart) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.e(TAG, "playSongWithLlamaPlayer: Invalid index " + index);
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", "Invalid song index");
            }
            return;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "playSongWithLlamaPlayer: Song or path is null");
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", "Song metadata missing");
            }
            fallbackToMediaPlayer();
            return;
        }
        
        // Validate file exists before attempting to play
        File songFile = new File(song.getPath());
        if (!songFile.exists()) {
            Log.e(TAG, "playSongWithLlamaPlayer: File does not exist: " + song.getPath());
            mCurrentPlaylist.remove(index);
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", "File not found: " + song.getTitle());
            }
            if (mCurrentPlaylist.isEmpty()) {
                stopCompletely();
            } else {
                playNext();
            }
            return;
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(false, "playSongWithLlamaPlayer");
            mPlaybackController.setPrepared(false, "playSongWithLlamaPlayer");
            mPlaybackController.updateSong(song, "playSongWithLlamaPlayer");
        }
        
        try {
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            
            mPrepareTimeoutRunnable = () -> {
                mIsPreparingLlamaPlayer.set(false);
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("prepare", "Preparation timeout");
                }
                fallbackToMediaPlayer();
            };
            mPrepareTimeoutHandler.postDelayed(mPrepareTimeoutRunnable, PREPARE_TIMEOUT_MS);
            
            mIsPreparingLlamaPlayer.set(true);
            mCurrentIndex = index;
            mShouldStartAfterPrepare = autoStart;
            
            mLlamaPlayer.reset();
            mLlamaPlayer.setDataSource(song.getPath());
            mLlamaPlayer.prepareAsync();
            
            createNotification();
            broadcastUpdate();
            savePlayerState();
            
        } catch (Exception e) {
            Log.e(TAG, "playSongWithLlamaPlayer exception", e);
            mIsPreparingLlamaPlayer.set(false);
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", e.getMessage());
            }
            fallbackToMediaPlayer();
        }
    }
    
    /**
     * Plays a song at the specified index with the given auto-start preference.
     *
     * @param index The playlist index
     * @param autoStart True to start playback immediately
     */
    public synchronized void playSong(int index, boolean autoStart) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        updateUIImmediately(index);
        
        if (!mLlamaPlayerFailed && mLlamaPlayer != null) {
            playSongWithLlamaPlayer(index, autoStart);
        } else {
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Plays a song at the specified index (auto-start true).
     *
     * @param index The playlist index
     */
    public synchronized void playSong(int index) {
        playSong(index, true);
    }
    
    /**
     * Prepares and starts playback using MediaPlayer (FALLBACK).
     * 
     * <p>Validates file exists before trying to play.
     * If file is missing, removes it from playlist and plays next.</p>
     *
     * @param index The song index
     * @param seekPosition The position to seek to
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (mIsPreparingFallback.get()) return;
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null) {
            Log.e(TAG, "prepareAndPlay: Song is null at index " + index);
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", "Song is null");
            }
            playNext();
            return;
        }
        
        String songPath = song.getPath();
        if (songPath == null || songPath.isEmpty()) {
            Log.e(TAG, "prepareAndPlay: Song path is null or empty");
            mCurrentPlaylist.remove(index);
            if (mCurrentPlaylist.isEmpty()) {
                stopCompletely();
            } else {
                playNext();
            }
            return;
        }
        
        // Validate file exists before trying to play
        File songFile = new File(songPath);
        if (!songFile.exists()) {
            Log.e(TAG, "prepareAndPlay: Song file does not exist: " + songPath);
            mCurrentPlaylist.remove(index);
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", "File not found: " + song.getTitle());
            }
            if (mCurrentPlaylist.isEmpty()) {
                stopCompletely();
            } else {
                playNext();
            }
            return;
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.updateSong(song, "prepareAndPlay");
            mPlaybackController.setPrepared(false, "prepareAndPlay");
            mPlaybackController.setPlaying(false, "prepareAndPlay");
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            player.setDataSource(songPath);
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) return;
                    if (mMediaPlayer != mp) return;
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        int duration = mp.getDuration();
                        if (duration <= 0) {
                            mIsPlaying = false;
                            broadcastUpdate();
                            return;
                        }
                        
                        int safeSeek = finalSeek;
                        if (safeSeek > 0 && safeSeek >= duration - 500) {
                            safeSeek = 0;
                            Log.d(TAG, "Adjusted seek position from " + finalSeek + " to 0 (near end)");
                        }
                        if (safeSeek > 0 && safeSeek < duration - 500) {
                            mp.seekTo(safeSeek);
                        }
                        
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        
                        mCurrentIndex = finalIndex;
                        saveCurrentPlayingIndex();
                        
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                        mp.start();
                        mIsPlaying = true;
                        
                        startMediaPlayerPolling();
                        
                        if (mPlaybackController != null) {
                            mPlaybackController.setPlaying(true, "MediaPlayer.prepared");
                            mPlaybackController.setPrepared(true, "MediaPlayer.prepared");
                            mPlaybackController.setDuration(duration, "MediaPlayer.prepared");
                        }
                        mIsRestoringPlayback = false;
                        mPlaybackStartTime = System.currentTimeMillis();
                        startHealthMonitoring();
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        requestAudioFocus();
                        
                        if (mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                        }
                        
                        updateMediaSessionPlaybackState();
                        broadcastUpdate();
                        createNotification();
                        updatePlaybackParams();
                        
                        updateMediaSessionMetadata();
                        
                        Intent readyIntent = new Intent(ACTION_PLAYER_READY);
                        sendBroadcast(readyIntent);
                        Log.d(TAG, "Broadcasted ACTION_PLAYER_READY (MediaPlayer fallback)");
                        
                    } catch (IllegalStateException e) {
                        mIsPlaying = false;
                        broadcastUpdate();
                        if (mPlaybackController != null) {
                            mPlaybackController.notifyOperationFailed("play", e.getMessage());
                        }
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            Log.e(TAG, "prepareAndPlay exception", e);
            mIsPreparingFallback.set(false);
            if (mPlaybackController != null) {
                mPlaybackController.notifyOperationFailed("play", e.getMessage());
            }
        }
    }
    
    /**
     * Prepares a song without starting playback (for preloading).
     *
     * @param index The index of the song to prepare
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) return;
                    if (mMediaPlayer != mp) return;
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                        if (mPlaybackController != null) {
                            mPlaybackController.setPrepared(true, "prepareOnly");
                            mPlaybackController.setDuration(mp.getDuration(), "prepareOnly");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error in prepareOnly onPrepared", e);
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            mIsPreparingFallback.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seeks to the given position.
     *
     * @param index The playlist index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        if (!mLlamaPlayerFailed && mLlamaPlayer != null) {
            playSongWithLlamaPlayer(index, true);
            if (position > 0) {
                mLlamaPlayer.seekTo(position);
            }
        } else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The absolute file path of the song
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                updateUIImmediately(i);
                playSong(i, true);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     * 
     * <p>Handles pending playlists, shuffle mode, and repeat mode.
     * Cancels ongoing preparation and resets seek sequence.</p>
     */
    public synchronized void playNext() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "playNext: Ignoring - restore in progress");
            return;
        }
        
        if (mIsPreparingLlamaPlayer.get() || mIsPreparingFallback.get()) {
            Log.d(TAG, "playNext: Cancelling ongoing preparation");
            invalidateAllPreparations();
            mIsPreparingLlamaPlayer.set(false);
            mIsPreparingFallback.set(false);
        }
        
        // Reset seek sequence on song change
        mPendingSeekPosition.set(-1);
        mPendingSeekSequence.incrementAndGet();
        
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparingLlamaPlayer.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "playNext: playlist is empty");
                return;
            }
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            boolean shouldAutoStart = true;
            
            playSong(nextIndex, shouldAutoStart);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * 
     * <p>Handles shuffle history to navigate backwards through shuffled songs.
     * Cancels ongoing preparation and resets seek sequence.</p>
     */
    public synchronized void playPrevious() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "playPrevious: Ignoring - restore in progress");
            return;
        }
        
        if (mIsPreparingLlamaPlayer.get() || mIsPreparingFallback.get()) {
            Log.d(TAG, "playPrevious: Cancelling ongoing preparation");
            invalidateAllPreparations();
            mIsPreparingLlamaPlayer.set(false);
            mIsPreparingFallback.set(false);
        }
        
        // Reset seek sequence on song change
        mPendingSeekPosition.set(-1);
        mPendingSeekSequence.incrementAndGet();
        
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparingLlamaPlayer.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            boolean shouldAutoStart = true;
            
            playSong(prevIndex, shouldAutoStart);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        boolean isPlaying = isAnyPlayerPlaying();
        boolean isPrepared = isAnyPlayerPrepared();
        
        if (isPlaying) {
            pause();
        } else if (isPrepared) {
            resume();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            playSong(0, true);
        }
    }

    /**
     * Pauses playback.
     * Notifies PlaybackController on failure.
     */
    public void pause() {
        // Cache position before pausing to prevent seek bar reset
        if (mPlaybackController != null) {
            mPlaybackController.onPause();
        }
        
        if (mLlamaPlayer != null && mIsUsingLlamaPlayer && mLlamaPlayer.isPlaying()) {
            mLlamaPlayer.pause();
            savePlayingState();
            savePlayerState();
            saveFullState();
            return;
        }
        
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.pause();
                    } else {
                        Log.d(TAG, "pause called but MediaPlayer already paused");
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "pause error", e);
                    if (mPlaybackController != null) {
                        mPlaybackController.notifyOperationFailed("pause", e.getMessage());
                    }
                }
                setPlaybackState(false, true);
                savePlayingState();
                savePlayerState();
                saveFullState();
            } else {
                Log.d(TAG, "pause called but no player available");
            }
        }
    }
    
    /**
     * Resumes playback from a paused state.
     * Notifies PlaybackController on failure.
     */
    public void resume() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "resume: Ignoring - restore in progress");
            return;
        }
        
        if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(true, "resume.LlamaPlayer");
            }
            
            if (mLlamaPlayer.isPrepared() || mLlamaPlayer.getState() == LlamaPlayer.State.PREPARED) {
                mLlamaPlayer.start();
                savePlayingState();
                savePlayerState();
                saveFullState();
                // Restore cached position after resume
                if (mPlaybackController != null) {
                    mPlaybackController.onResume();
                }
                return;
            } else {
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("resume", "Player not prepared");
                }
                return;
            }
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    requestAudioFocus();
                    updatePlaybackParams();
                    mMediaPlayer.start();
                    mPlaybackStartTime = System.currentTimeMillis();
                    startHealthMonitoring();
                    startMediaPlayerPolling();
                    setPlaybackState(true, true);
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    // Restore cached position after resume
                    if (mPlaybackController != null) {
                        mPlaybackController.onResume();
                    }
                } catch (IllegalStateException e) {
                    Log.e(TAG, "resume error", e);
                    if (mPlaybackController != null) {
                        mPlaybackController.notifyOperationFailed("resume", e.getMessage());
                    }
                }
            } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                playSong(0, true);
            } else {
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("resume", "No songs in playlist");
                }
            }
        }
    }
    
    /**
     * Stops playback without clearing playlist.
     */
    public void stop() {
        if (mLlamaPlayer != null) {
            mLlamaPlayer.stop();
            mIsPlaying = false;
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(false, "stop");
            }
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {}
                    mIsPlaying = false;
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "stop");
                    }
                }
            }
        }
        stopMediaPlayerPolling();
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>If the player is still preparing, the seek is queued with a sequence
     * number to handle multiple seek requests before playback starts.</p>
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            mLlamaPlayer.seekTo(position);
            mPendingSeekPosition.set(-1);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
            return;
        }
        
        if (mLlamaPlayer != null && !mLlamaPlayer.isPrepared()) {
            int sequence = mPendingSeekSequence.incrementAndGet();
            mPendingSeekPosition.set(position);
            Log.d(TAG, "seekTo during preparation, storing for restore: " + position + 
                  " (seq=" + sequence + ")");
            return;
        }
        
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && isPlayerReady()) {
                try {
                    int duration = mMediaPlayer.getDuration();
                    if (position >= 0 && position < duration) {
                        mMediaPlayer.seekTo(position);
                        broadcastUpdate();
                        updateMediaSessionPlaybackState();
                        savePlayerState();
                        saveFullState();
                    }
                } catch (IllegalStateException e) {}
            }
        }
    }
    
    // =========================================================================
    // Playback Parameter Methods
    // =========================================================================
    
    /**
     * Updates playback parameters (tempo and pitch) from the equalizer.
     * 
     * <p>For LlamaPlayer, tempo and pitch are set directly.
     * For MediaPlayer (API 23+), PlaybackParams are used.</p>
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            mLlamaPlayer.setPitch(semitones);
            mLlamaPlayer.setTempo(tempo);
            return;
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
            } catch (Exception e) {}
        }
    }
    
    // =========================================================================
    // Completion Handler
    // =========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>Uses AtomicBoolean to prevent re-entrant calls.
     * Handles repeat modes and automatic next song playback.</p>
     */
    private void handleCompletion() {
        if (!mIsCompleting.compareAndSet(false, true)) {
            Log.d(TAG, "handleCompletion already in progress, ignoring duplicate call");
            return;
        }
        
        try {
            broadcastSongCompletion();
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                mIsPlaying = false;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "handleCompletion");
                    mPlaybackController.setPrepared(false, "handleCompletion");
                }
                updateNotificationPlaybackState(false);
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mRepeatMode == 2) {
                if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                    mLlamaPlayer.seekTo(0);
                    mLlamaPlayer.start();
                } else if (mMediaPlayer != null) {
                    try {
                        mMediaPlayer.seekTo(0);
                        mMediaPlayer.start();
                    } catch (Exception e) {
                        Log.e(TAG, "Error restarting MediaPlayer for repeat one", e);
                        playNext();
                    }
                }
            } else if (mRepeatMode == 1) {
                playNext();
            } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
                playNext();
            } else {
                mIsPlaying = false;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "handleCompletion.end");
                    mPlaybackController.setPrepared(false, "handleCompletion.end");
                }
                updateNotificationPlaybackState(false);
                
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                
                if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                    mLlamaPlayer.stop();
                } else if (mMediaPlayer != null) {
                    try {
                        mMediaPlayer.seekTo(getDuration());
                        mMediaPlayer.pause();
                    } catch (Exception e) {
                        Log.e(TAG, "Error pausing MediaPlayer at end", e);
                    }
                }
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, getDuration())
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .apply();
                savePlayingState();
                savePlayerState();
                saveFullState();
                
                broadcastSongCompletion();
                updateMediaSessionPlaybackState();
            
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                    mNotificationService.setPlayingState(false);
                    mNotificationService.forceUpdate();
                }
            }
        } finally {
            mIsCompleting.set(false);
        }
    }
    
    /**
     * Broadcasts that the current song has completed.
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
    }
    
    // =========================================================================
    // Getter Methods
    // =========================================================================
    
    /**
     * Gets the current playback position.
     *
     * @return Position in milliseconds
     */
    public int getCurrentPosition() {
        if (mPlaybackController != null) {
            long pos = mPlaybackController.getCurrentPosition();
            if (pos > 0 || mPlaybackController.isPrepared()) return (int) pos;
        }
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            return (int) mLlamaPlayer.getCurrentPosition();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Gets the duration of the current song.
     *
     * @return Duration in milliseconds
     */
    public int getDuration() {
        if (mPlaybackController != null) {
            return (int) mPlaybackController.getDuration();
        }
        if (mLlamaPlayer != null && mLlamaPlayer.isPrepared()) {
            return (int) mLlamaPlayer.getDuration();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mPlaybackController != null) return mPlaybackController.isPlaying();
        if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
            return mLlamaPlayer.isPlaying();
        }
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if a MediaPlayer is actually playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Gets the currently playing song.
     *
     * @return The current Song, or null
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Gets the current playlist index.
     *
     * @return The current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Gets the current repeat mode.
     *
     * @return 0=off, 1=all, 2=one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0=off, 1=all, 2=one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets Bluetooth connection state.
     *
     * @param connected True if a Bluetooth device is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // =========================================================================
    // Media Session Methods
    // =========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        Log.d(TAG, "MediaSession.onSeekTo: " + pos + "ms");
                        seekTo((int) pos);
                        
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                            long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                                          PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                                          PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                            int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                            stateBuilder.setState(state, pos, 1.0f);
                            stateBuilder.setActions(actions);
                            mMediaSession.setPlaybackState(stateBuilder.build());
                        }
                    }
                });
                
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
                
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {}
        }
    }
    
    /**
     * Updates the MediaSession metadata with current song info.
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            return;
        }
        
        android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
        builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                          currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                          currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                          currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album");
        builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
        
        mMediaSession.setMetadata(builder.build());
        Log.d(TAG, "MediaSession metadata updated: " + currentSong.getTitle());
    }
    
    /**
     * Sets up audio focus management.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Refreshes metadata for a song in the playlist.
     *
     * @param songPath The file path of the song to update
     * @param newTitle New title (or null to keep existing)
     * @param newArtist New artist (or null to keep existing)
     * @param newAlbum New album (or null to keep existing)
     * @param newGenre New genre (or null to keep existing)
     * @param albumArtBytes New album art bytes (or null)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) return;
            if (!songPath.equals(current.getPath())) return;
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mPlaybackController != null) {
                mPlaybackController.updateSong(updated, "refreshMetadataForSong");
            }
            
            updateMediaSessionMetadata();
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        }
    }
    
    /**
     * Handles the close action from the notification.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        stopMediaPlayerPolling();
        
        if (mLlamaPlayer != null) {
            mLlamaPlayer.stop();
        }
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus for playback.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a player update to registered receivers.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change event.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {}
        }
    }
    
    /**
     * Handles media button events from Bluetooth and wired headsets.
     *
     * @param keyCode The key code of the media button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Handles audio focus changes.
     * 
     * <p>When focus is lost permanently or transiently, playback pauses.
     * When focus is lost with CAN_DUCK, volume is reduced to 30%.
     * When focus is regained, volume is restored to normal.</p>
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                Log.d(TAG, "Audio focus LOSS - pausing playback");
                if (mIsPlaying) {
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                Log.d(TAG, "Audio focus LOSS_TRANSIENT - pausing playback");
                if (mIsPlaying) {
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                Log.d(TAG, "Audio focus LOSS_TRANSIENT_CAN_DUCK - ducking volume");
                if (mIsPlaying) {
                    if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                        mLlamaPlayer.duck();
                        Log.d(TAG, "Ducked LlamaPlayer volume");
                    } else if (mMediaPlayer != null && isPlayerReady()) {
                        try {
                            float duckVolume = 0.3f;
                            mMediaPlayer.setVolume(duckVolume, duckVolume);
                            Log.d(TAG, "Ducked MediaPlayer volume to " + duckVolume);
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to duck MediaPlayer", e);
                        }
                    }
                }
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                Log.d(TAG, "Audio focus GAIN - restoring volume");
                if (mLlamaPlayer != null && mIsUsingLlamaPlayer) {
                    mLlamaPlayer.unduck();
                    Log.d(TAG, "Unducked LlamaPlayer volume");
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        mMediaPlayer.setVolume(1.0f, 1.0f);
                        Log.d(TAG, "Unducked MediaPlayer volume");
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to unduck MediaPlayer", e);
                    }
                }
                break;
                
            default:
                Log.d(TAG, "Unhandled audio focus change: " + focusChange);
                break;
        }
    }
}