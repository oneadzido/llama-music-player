package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.media3.common.AudioProcessor;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService – Background service for music playback with SoundTouch integration.
 *
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground. The service manages
 * playlist playback, audio effects, notification handling, and state persistence.</p>
 *
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture to ensure reliable playback:</p>
 * <ul>
 *   <li><b>Primary Path (ExoPlayer + SoundTouchAudio)</b> – DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control using the SoundTouch native library.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> – Used ONLY when ExoPlayer fails at runtime.
 *       Provides basic playback without pitch/tempo effects.</li>
 * </ul>
 *
 * <h3>Pitch and Tempo Ranges</h3>
 * <ul>
 *   <li><b>Pitch:</b> -6 to +6 semitones (controlled via EqualizerManager)</li>
 *   <li><b>Tempo/Speed:</b> 0.5x to 1.5x speed</li>
 * </ul>
 *
 * <h3>Sort Modes</h3>
 * <p>Supports 10 sort modes for playlist ordering (Title A‑Z, Title Z‑A, Artist A‑Z,
 * Artist Z‑A, Album A‑Z, Album Z‑A, Genre A‑Z, Genre Z‑A, Oldest First, Newest First).</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Log tag for debugging. */
    private static final String TAG = "MusicService";

    /** Shared preferences file name. */
    private static final String PREFS_NAME = "LlamaPrefs";

    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";

    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";

    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";

    /** Key for storing repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";

    /** Key for storing shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";

    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";

    /** Key for storing the last played song file path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";

    /** Key for storing playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";

    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";

    /** Intent extra key for sort mode. */
    private static final String EXTRA_SORT_MODE = "sort_mode";

    /** Delay for song transitions (prevents rapid skipping). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;

    /** Broadcast action for audio session changes (for equalizer attachment). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";

    /** Health check interval for MediaPlayer fallback. */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;

    /** Maximum stall time before recovery. */
    private static final int MAX_STALL_TIME_MS = 5000;

    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;

    // ------------------------------------------------------------------------
    // Sort mode constants
    // ------------------------------------------------------------------------
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;

    // ========================================================================
    // Static Members
    // ========================================================================

    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;

    // ========================================================================
    // ExoPlayer Members (Primary Player)
    // ========================================================================

    /** ExoPlayer instance for high‑quality playback with pitch/tempo support. */
    private ExoPlayer mExoPlayer;

    /** SoundTouch audio processor that applies pitch and tempo effects. */
    private SoundTouchAudio mSoundTouchAudio;

    /** True if ExoPlayer is active. */
    private boolean mIsUsingExoPlayer = false;

    /** True if ExoPlayer failed at runtime; once set, fallback to MediaPlayer permanently. */
    private boolean mExoPlayerFailed = false;

    // ========================================================================
    // MediaPlayer Members (Fallback Only)
    // ========================================================================

    /** Legacy MediaPlayer – used ONLY when ExoPlayer fails at runtime. */
    private android.media.MediaPlayer mMediaPlayer;

    // ========================================================================
    // Playback State
    // ========================================================================

    /** Current playlist. */
    private ArrayList<Song> mCurrentPlaylist;

    /** Index of currently playing song. */
    private volatile int mCurrentIndex = -1;

    /** True if playback is active. */
    private volatile boolean mIsPlaying = false;

    /** Repeat mode: 0 = off, 1 = all, 2 = one. */
    private volatile int mRepeatMode = 0;

    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;

    /** Timestamp when current playback started (for health checks). */
    private long mPlaybackStartTime = 0;

    // ========================================================================
    // Sort Mode State
    // ========================================================================

    /** Current sort mode for playlist display. */
    private int mCurrentSortMode = SORT_TITLE_AZ;

    // ========================================================================
    // Health Check Components (MediaPlayer only)
    // ========================================================================

    /** Handler for periodic health checks when using MediaPlayer fallback. */
    private Handler mHealthHandler;

    /** Runnable for health check execution. */
    private Runnable mHealthCheckRunnable;

    /** Number of recovery attempts for the current song. */
    private int mRecoveryAttempts = 0;

    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================

    /** WakeLock to prevent device sleep during playback. */
    private PowerManager.WakeLock mWakeLock;

    // ========================================================================
    // Audio Focus Management
    // ========================================================================

    /** Audio manager for focus management. */
    private AudioManager mAudioManager;

    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;

    /** Audio focus request for API 26+. */
    private android.media.AudioFocusRequest mAudioFocusRequest;

    // ========================================================================
    // Media Session
    // ========================================================================

    /** MediaSession for lock screen and headset controls. */
    private MediaSession mMediaSession;

    // ========================================================================
    // Bluetooth State
    // ========================================================================

    /** True if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;

    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================

    /** Lock object for MediaPlayer operations. */
    private final Object mPlayerLock = new Object();

    /** True if a song transition is in progress. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);

    /** True if a song is being prepared (MediaPlayer fallback). */
    private final AtomicBoolean mIsPreparing = new AtomicBoolean(false);

    /** Global preparation ID counter for async operation cancellation. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);

    /** Current preparation ID (used to ignore stale callbacks). */
    private volatile int mCurrentPrepId = -1;

    // ========================================================================
    // Binder
    // ========================================================================

    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();

    // ========================================================================
    // Playlist Management
    // ========================================================================

    /** History of shuffled indices (for prev/next in shuffle mode). */
    private ArrayList<Integer> mShuffleHistory;

    /** Random number generator for shuffle mode. */
    private Random mRandom;

    /** Pending playlist for soft update. */
    private ArrayList<Song> mPendingPlaylist = null;

    /** True if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;

    // ========================================================================
    // Notification Service
    // ========================================================================

    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;

    // ========================================================================
    // Broadcast Receivers
    // ========================================================================

    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Local binder for service binding.
     * Allows activities to obtain a reference to the MusicService instance.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the MusicService instance.
         *
         * @return The MusicService instance for direct method calls
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Sort Comparator Classes
    // ========================================================================

    /** Comparator for sorting songs by title in ascending order (A‑Z). */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }

    /** Comparator for sorting songs by title in descending order (Z‑A). */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }

    /** Comparator for sorting songs by artist in ascending order. */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }

    /** Comparator for sorting songs by artist in descending order. */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }

    /** Comparator for sorting songs by album in ascending order. */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }

    /** Comparator for sorting songs by album in descending order. */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }

    /** Comparator for sorting songs by genre in ascending order. */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }

    /** Comparator for sorting songs by genre in descending order. */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }

    /** Comparator for sorting songs by file date (oldest first). */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }

    /** Comparator for sorting songs by file date (newest first). */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }

    // ========================================================================
    // Static Methods
    // ========================================================================

    /**
     * Sets the player state before update flag.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }

    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }

    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }

    /**
     * Returns the current audio session ID.
     *
     * @return The current audio session ID, or 0 if none
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }

    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");

        mIsTransitioning.set(false);
        mIsPreparing.set(false);

        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Song Title", "Artist", null);
        mNotificationService.setPlayingState(false);

        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        loadRepeatAndShuffle();
        loadSortMode();

        setupMediaSession();

        EqualizerManager.getInstance(this);

        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();

        setupAudioFocus();

        mHealthHandler = new Handler(Looper.getMainLooper());

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }

        // Initialize ExoPlayer as DEFAULT player
        initExoPlayer();

        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();

        Log.d(TAG, "MusicService onCreate complete - ExoPlayer is DEFAULT player");
    }

    /**
     * Initializes ExoPlayer as the default player with SoundTouch audio processing.
     * <p>Fixes: uses {@link ExoPlayer.Builder#setAudioProcessors(AudioProcessor[])}.</p>
     */
    private void initExoPlayer() {
        if (mExoPlayerFailed) {
            Log.d(TAG, "ExoPlayer already failed, skipping init");
            return;
        }
        if (!PitchShifter.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mExoPlayerFailed = true;
            mIsUsingExoPlayer = false;
            return;
        }
        try {
            // Create SoundTouch audio processor
            mSoundTouchAudio = new SoundTouchAudio();
            // Build track selector
            DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);
            // Build ExoPlayer and attach the audio processor
            mExoPlayer = new ExoPlayer.Builder(this)
                    .setTrackSelector(trackSelector)
                    .setAudioProcessors(new AudioProcessor[]{mSoundTouchAudio})
                    .build();
            setupExoPlayerListeners();
            mIsUsingExoPlayer = true;
            Log.d(TAG, "ExoPlayer initialized successfully as DEFAULT player");
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize ExoPlayer", e);
            mExoPlayerFailed = true;
            mIsUsingExoPlayer = false;
        }
    }

    /**
     * Sets up event listeners for ExoPlayer.
     */
    private void setupExoPlayerListeners() {
        if (mExoPlayer == null) return;
        mExoPlayer.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                switch (playbackState) {
                    case Player.STATE_READY:
                        sCurrentAudioSessionId = mExoPlayer.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                                .attachToAudioSession(sCurrentAudioSessionId);
                        synchronized (mPlayerLock) {
                            mIsPlaying = mExoPlayer.isPlaying();
                        }
                        if (mIsPlaying && mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                            Log.d(TAG, "WakeLock acquired");
                        }
                        break;
                    case Player.STATE_ENDED:
                        handleCompletion();
                        break;
                }
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                synchronized (mPlayerLock) {
                    mIsPlaying = isPlaying;
                }
                if (isPlaying) {
                    if (mWakeLock != null && !mWakeLock.isHeld()) {
                        mWakeLock.acquire();
                        Log.d(TAG, "WakeLock acquired");
                    }
                } else {
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released");
                    }
                }
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                Log.e(TAG, "ExoPlayer error: " + error.getMessage());
                mExoPlayerFailed = true;
                fallbackToMediaPlayer();
            }
        });
    }

    /**
     * Falls back to MediaPlayer when ExoPlayer fails.
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingExoPlayer) return;
        Log.w(TAG, "FALLBACK: Switching from ExoPlayer to MediaPlayer");
        mIsUsingExoPlayer = false;
        mExoPlayerFailed = true;
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        if (mExoPlayer != null) {
            currentPosition = (int) mExoPlayer.getCurrentPosition();
            mExoPlayer.release();
            mExoPlayer = null;
        }
        if (currentIndex >= 0 && mCurrentPlaylist != null && currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex +
                    " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
        }
        Log.d(TAG, "Fallback to MediaPlayer complete");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            Log.d(TAG, "WakeLock released on destroy");
        }
        if (mExoPlayer != null) {
            mExoPlayer.release();
            mExoPlayer = null;
        }
        releaseMediaPlayer();
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        abandonAudioFocus();
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mIsUsingExoPlayer) return;
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }

    // ========================================================================
    // Sort Mode Methods
    // ========================================================================

    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }

    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }

    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }

    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }

    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        if (currentSongPath != null) {
            int newIndex = -1;
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    newIndex = i;
                    break;
                }
            }
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                Log.d(TAG, "Current song repositioned to index: " + newIndex);
            }
        }
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }

    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================

    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }

    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        IntentFilter filter = new IntentFilter("UPDATE_PLAYBACK_PARAMS");
        registerReceiver(mPlaybackParamsReceiver, filter);
    }

    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        IntentFilter filter = new IntentFilter("CLEAR_PLAYLIST");
        registerReceiver(mClearPlaylistReceiver, filter);
    }

    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        IntentFilter filter = new IntentFilter("THEME_COLOR_CHANGED");
        registerReceiver(mThemeReceiver, filter);
    }

    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        IntentFilter filter = new IntentFilter("GET_PLAYING_STATE");
        registerReceiver(mGetPlayingStateReceiver, filter);
    }

    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_SORT_MODE);
        registerReceiver(mSortModeReceiver, filter);
    }

    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }

    // ========================================================================
    // MediaPlayer Management (Fallback Only)
    // ========================================================================

    private void removeAllListeners(android.media.MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) { }
    }

    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) { }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) { }
            }
            mIsPlaying = false;
        }
    }

    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on media player release");
            }
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) { }
                try {
                    mMediaPlayer.reset();
                } catch (Exception ignored) { }
                try {
                    mMediaPlayer.release();
                } catch (Exception ignored) { }
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }

    private android.media.MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new android.media.MediaPlayer();
                mMediaPlayer.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparing.set(false);
                        createNotification();
                        broadcastUpdate();
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() &&
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            Log.d(TAG, "Attempting recovery from error - resetting player");
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            releaseMediaPlayer();
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    prepareAndPlay(recoverIndex, recoverPosition);
                                }
                            }, 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }

    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try {
                mMediaPlayer.getDuration();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    // ========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // ========================================================================

    private void startHealthMonitoring() {
        if (mHealthHandler == null) mHealthHandler = new Handler(Looper.getMainLooper());
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health monitoring started");
    }

    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }

    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingExoPlayer) return;
        try {
            int currentPosition = getCurrentPosition();
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition +
                            ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }

    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        stopHealthMonitoring();
        if (mMediaPlayer != null) {
            try {
                if (mIsPlaying) mMediaPlayer.pause();
            } catch (Exception ignored) { }
            releaseMediaPlayer();
        }
        mIsPlaying = false;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (currentIndex >= 0 && mCurrentPlaylist != null && currentIndex < mCurrentPlaylist.size()) {
                    Log.d(TAG, "Restarting playback at index " + currentIndex);
                    prepareAndPlay(currentIndex, currentPosition);
                    Intent recoveryIntent = new Intent("PLAYBACK_RECOVERED");
                    sendBroadcast(recoveryIntent);
                }
            }
        }, 500);
    }

    // ========================================================================
    // Async Operation Management
    // ========================================================================

    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }

    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }

    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }

    // ========================================================================
    // Notification Methods
    // ========================================================================

    private void createNotification() {
        if (mNotificationService == null) return;
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() &&
                mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() &&
                getCurrentSong() != null);
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }

    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }

    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = null, safePlaceholder = null;
            if (art != null && !art.isRecycled()) safeArt = art;
            if (placeholder != null && !placeholder.isRecycled()) safePlaceholder = placeholder;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }

    // ========================================================================
    // State Persistence Methods
    // ========================================================================

    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
                .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
                .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
                .putInt(KEY_REPEAT_MODE, mRepeatMode)
                .putBoolean(KEY_SHUFFLE, mIsShuffle)
                .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
                .apply();
    }

    private void saveFullState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_CURRENT_INDEX, mCurrentIndex);
        editor.putInt(KEY_CURRENT_POSITION, getCurrentPosition());
        editor.putBoolean(KEY_LAST_PLAYING, mIsPlaying);
        editor.putInt(KEY_REPEAT_MODE, mRepeatMode);
        editor.putBoolean(KEY_SHUFFLE, mIsShuffle);
        if (getCurrentSong() != null) editor.putString(KEY_LAST_SONG_PATH, getCurrentSong().getPath());
        editor.apply();
    }

    public int getSavedPosition() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_CURRENT_POSITION, 0);
    }

    public boolean wasPlayingBeforeRestart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LAST_PLAYING, false);
    }

    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }

    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
                .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
                .apply();
    }

    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
                .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
                .apply();
    }

    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }

    // ========================================================================
    // Playlist Management Methods
    // ========================================================================

    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    currentPosition = (int) mExoPlayer.getCurrentPosition();
                    wasPlaying = mExoPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                        .putInt(KEY_CURRENT_POSITION, currentPosition)
                        .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                        .putString(KEY_LAST_SONG_PATH, currentSongPath)
                        .apply();
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                if (mExoPlayer != null && mIsUsingExoPlayer) mExoPlayer.stop();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                        .putInt(KEY_CURRENT_INDEX, -1)
                        .putInt(KEY_CURRENT_POSITION, 0)
                        .putBoolean(KEY_LAST_PLAYING, false)
                        .putString(KEY_LAST_SONG_PATH, null)
                        .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                        .apply();
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                boolean same = true;
                for (int i = 0; i < playlist.size(); i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    broadcastUpdate();
                    return;
                }
            }
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                invalidateAllPreparations();
                resetPlayerSafely();
                if (mExoPlayer != null && mIsUsingExoPlayer) mExoPlayer.stop();
                mIsPlaying = false;
            }
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex = 0;
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                mCurrentIndex = -1;
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            saveCurrentPlayingIndex();
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 &&
                    mCurrentIndex < mCurrentPlaylist.size()) {
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    playSongAtPosition(correctIndex, savedPosition);
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    playSongAtPosition(mCurrentIndex, savedPosition);
                }
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                if (mExoPlayer != null && mIsUsingExoPlayer) {
                    prepareExoPlayer(mCurrentIndex);
                } else {
                    prepareOnly(mCurrentIndex);
                }
                mIsPlaying = false;
                createNotification();
            } else if (!preserveCurrentSong) {
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            broadcastUpdate();
        }
    }

    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }

    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparing.set(false);
            invalidateAllPreparations();
            resetPlayerSafely();
            if (mExoPlayer != null && mIsUsingExoPlayer) mExoPlayer.stop();
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            EqualizerManager.getInstance(this).detach();
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_CURRENT_INDEX, -1)
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .putString(KEY_LAST_SONG_PATH, null)
                .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                .apply();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }

    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }

    // ========================================================================
    // Playback Control Methods
    // ========================================================================

    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (!mExoPlayerFailed && mExoPlayer != null && mIsUsingExoPlayer) {
            playSongWithExoPlayer(index);
        } else {
            Log.w(TAG, "ExoPlayer unavailable, using MediaPlayer fallback");
            prepareAndPlay(index, 0);
        }
    }

    private void playSongWithExoPlayer(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "Invalid song at index " + index);
            fallbackToMediaPlayer();
            return;
        }
        if (mExoPlayer == null) initExoPlayer();
        if (mExoPlayer == null || !mIsUsingExoPlayer) {
            Log.e(TAG, "ExoPlayer is null or not active, falling back");
            fallbackToMediaPlayer();
            prepareAndPlay(index, 0);
            return;
        }
        try {
            updatePlaybackParams();
            MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(new File(song.getPath())));
            mExoPlayer.setMediaItem(mediaItem);
            mExoPlayer.prepare();
            mExoPlayer.play();
            mCurrentIndex = index;
            savePlayerState();
            createNotification();
            broadcastUpdate();
            Log.d(TAG, "ExoPlayer playing: " + song.getPath());
        } catch (Exception e) {
            Log.e(TAG, "Error playing with ExoPlayer", e);
            fallbackToMediaPlayer();
            prepareAndPlay(index, 0);
        }
    }

    private void prepareExoPlayer(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        if (mExoPlayer == null || !mIsUsingExoPlayer) return;
        try {
            MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(new File(song.getPath())));
            mExoPlayer.setMediaItem(mediaItem);
            mExoPlayer.prepare();
            mCurrentIndex = index;
        } catch (Exception e) {
            Log.e(TAG, "Error preparing ExoPlayer", e);
        }
    }

    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (!mExoPlayerFailed && mExoPlayer != null && mIsUsingExoPlayer) {
            playSongWithExoPlayer(index);
            if (position > 0) mExoPlayer.seekTo(position);
        } else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }

    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }

    public synchronized void playNext() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) mCurrentIndex = savedIndex;
                else mCurrentIndex = 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) mShuffleHistory.clear();
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) mShuffleHistory.remove(0);
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }

    public synchronized void playPrevious() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        try {
            if (mIsPreparing.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) mCurrentIndex = savedIndex;
                else mCurrentIndex = 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    broadcastUpdate();
                    createNotification();
                }
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseTransitionLock();
                }
            }, SONG_TRANSITION_DELAY_MS);
        }
    }

    public void togglePlayPause() {
        if (mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying()) {
            pause();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
            pause();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            String songPath = null;
            if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                Song current = mCurrentPlaylist.get(mCurrentIndex);
                if (current != null) songPath = current.getPath();
            }
            if (songPath == null && !mCurrentPlaylist.isEmpty()) {
                songPath = mCurrentPlaylist.get(0).getPath();
            }
            if (songPath != null) playSongByPath(songPath);
        }
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    public void pause() {
        if (mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying()) {
            mExoPlayer.pause();
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } else {
            stopHealthMonitoring();
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.pause();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot pause - invalid state", e);
                    }
                    mIsPlaying = false;
                    if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            }
        }
    }

    public void resume() {
        if (mExoPlayer != null && mIsUsingExoPlayer && !mExoPlayer.isPlaying() && mExoPlayer.getPlaybackState() == Player.STATE_READY) {
            mExoPlayer.play();
            mIsPlaying = true;
            if (mWakeLock != null && !mWakeLock.isHeld()) mWakeLock.acquire();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                    try {
                        if (!mIsPlaying) {
                            requestAudioFocus();
                            updatePlaybackParams();
                            mMediaPlayer.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            if (mWakeLock != null && !mWakeLock.isHeld()) mWakeLock.acquire();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Resume failed - invalid state", e);
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                    playSong(0);
                }
            }
        }
    }

    public void stop() {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            mExoPlayer.stop();
            mIsPlaying = false;
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot stop - invalid state", e);
                    }
                    mIsPlaying = false;
                }
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }

    public void seekTo(int position) {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            mExoPlayer.seekTo(position);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        int duration = mMediaPlayer.getDuration();
                        if (position >= 0 && position < duration) {
                            mMediaPlayer.seekTo(position);
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            savePlayerState();
                            saveFullState();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot seek - invalid state", e);
                    }
                }
            }
        }
    }

    /**
     * Updates playback parameters (tempo and pitch) from the EqualizerManager.
     * <p>When ExoPlayer is active, changes are applied to the SoundTouchAudio processor.
     * When using the MediaPlayer fallback (API 23+), native PlaybackParams are used.</p>
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);

        if (mSoundTouchAudio != null) {
            mSoundTouchAudio.setParameters(tempo, semitones);
            Log.d(TAG, "SoundTouchAudio: tempo=" + tempo + ", pitch=" + semitones + "st");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }

    // ========================================================================
    // Completion Handler
    // ========================================================================

    private void handleCompletion() {
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            return;
        }
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            if (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) mCurrentIndex = savedIndex;
            else mCurrentIndex = 0;
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        if (mRepeatMode == 2) {
            playSong(mCurrentIndex);
        } else if (mRepeatMode == 1) {
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mExoPlayer != null && mIsUsingExoPlayer) {
                mExoPlayer.stop();
            } else {
                synchronized (mPlayerLock) {
                    if (mMediaPlayer != null) {
                        try { mMediaPlayer.pause(); } catch (Exception ignored) {}
                        try { mMediaPlayer.seekTo(0); } catch (Exception ignored) {}
                    }
                }
            }
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }

    // ========================================================================
    // Getter Methods
    // ========================================================================

    public int getCurrentPosition() {
        if (mExoPlayer != null && mIsUsingExoPlayer) return (int) mExoPlayer.getCurrentPosition();
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try { return mMediaPlayer.getCurrentPosition(); } catch (Exception e) { return 0; }
            }
        }
        return 0;
    }

    public int getDuration() {
        if (mExoPlayer != null && mIsUsingExoPlayer) {
            long duration = mExoPlayer.getDuration();
            return duration > 0 ? (int) duration : 0;
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try { return mMediaPlayer.getDuration(); } catch (Exception e) { return 0; }
            }
        }
        return 0;
    }

    public boolean isExoPlayerPrepared() {
        return mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.getPlaybackState() == Player.STATE_READY;
    }

    public boolean isExoPlayerPlaying() {
        return mExoPlayer != null && mIsUsingExoPlayer && mExoPlayer.isPlaying();
    }

    public boolean isMediaPlayerPrepared() {
        return mMediaPlayer != null && isPlayerReady();
    }

    public boolean isMediaPlayerPlaying() {
        return mMediaPlayer != null && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }

    public boolean isAnyPlayerPrepared() {
        return isExoPlayerPrepared() || isMediaPlayerPrepared();
    }

    public boolean isAnyPlayerPlaying() {
        return isExoPlayerPlaying() || isMediaPlayerPlaying();
    }

    public boolean isPlaying() {
        return isAnyPlayerPlaying();
    }

    private boolean isMediaPlayerPlaying(android.media.MediaPlayer player) {
        if (player == null) return false;
        try { return player.isPlaying(); } catch (Exception e) { return false; }
    }

    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && mCurrentIndex < mCurrentPlaylist.size())
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }

    public int getCurrentIndex() { return mCurrentIndex; }

    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }

    public int getRepeatMode() { return mRepeatMode; }

    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }

    public boolean isShuffle() { return mIsShuffle; }

    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) mShuffleHistory.clear();
        savePlayerState();
        saveFullState();
    }

    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }

    // ========================================================================
    // MediaPlayer Fallback Methods
    // ========================================================================

    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (mIsPreparing.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        try {
            android.media.MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            try { player.reset(); } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            player.setDataSource(song.getPath());
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            player.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) {
                            Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                            return;
                        }
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                            return;
                        }
                        mIsPreparing.set(false);
                        try {
                            int duration = mp.getDuration();
                            if (duration <= 0) {
                                Log.e(TAG, "Invalid duration: " + duration);
                                mIsPlaying = false;
                                broadcastUpdate();
                                return;
                            }
                            if (finalSeek > 0 && finalSeek < duration - 500) mp.seekTo(finalSeek);
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this).attachToAudioSession(sCurrentAudioSessionId);
                            mCurrentIndex = finalIndex;
                            saveCurrentPlayingIndex();
                            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(android.media.MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                            mp.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            requestAudioFocus();
                            if (mWakeLock != null && !mWakeLock.isHeld()) mWakeLock.acquire();
                            updateMediaSessionPlaybackState();
                            broadcastUpdate();
                            createNotification();
                            updatePlaybackParams();
                        } catch (IllegalStateException e) {
                            Log.e(TAG, "Player in illegal state during onPrepared", e);
                            mIsPlaying = false;
                            broadcastUpdate();
                        }
                    }
                }
            });
            player.prepareAsync();
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }

    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        try {
            android.media.MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            try { player.reset(); } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            player.setDataSource(song.getPath());
            final int finalIndex = index;
            mIsPreparing.set(true);
            mCurrentIndex = finalIndex;
            player.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer mp) {
                    synchronized (mPlayerLock) {
                        if (mCurrentPrepId != myPrepId) return;
                        if (mMediaPlayer != mp) {
                            Log.w(TAG, "Stale player instance in prepareOnly, ignoring");
                            return;
                        }
                        mIsPreparing.set(false);
                        try {
                            sCurrentAudioSessionId = mp.getAudioSessionId();
                            broadcastAudioSessionChanged(sCurrentAudioSessionId);
                            EqualizerManager.getInstance(MusicService.this).attachToAudioSession(sCurrentAudioSessionId);
                            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(android.media.MediaPlayer mp) {
                                    handleCompletion();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "Error in prepareOnly onPrepared", e);
                        }
                    }
                }
            });
            player.prepareAsync();
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparing.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparing.set(false);
        }
    }

    // ========================================================================
    // Media Session Methods
    // ========================================================================

    private void setupMediaSession() {
        try {
            mMediaSession = new MediaSession(this, "LlamaMusicService");
            mMediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() {
                    if (!mIsPlaying && mCurrentIndex >= 0) resume();
                    else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) playSong(0);
                }
                @Override public void onPause() { if (mIsPlaying) pause(); }
                @Override public void onSkipToNext() { playNext(); }
                @Override public void onSkipToPrevious() { playPrevious(); }
                @Override public void onStop() { pause(); }
                @Override
                public void onPlayFromMediaId(String mediaId, Bundle extras) {
                    if (mediaId != null) {
                        try { playSong(Integer.parseInt(mediaId)); } catch (NumberFormatException ignored) {}
                    }
                }
            });
            mMediaSession.setActive(true);
            updateMediaSessionPlaybackState();
        } catch (Exception e) {
            Log.e(TAG, "Failed to setup MediaSession", e);
        }
    }

    private void setupAudioFocus() {
        mAudioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                handleAudioFocusChange(focusChange);
            }
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.media.AudioAttributes audioAttributes = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            mAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setOnAudioFocusChangeListener(mAudioFocusListener)
                    .setAudioAttributes(audioAttributes)
                    .build();
        }
    }

    public void refreshMetadataForSong(@NonNull String songPath,
                                       @Nullable String newTitle,
                                       @Nullable String newArtist,
                                       @Nullable String newAlbum,
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null || !songPath.equals(current.getPath())) return;
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) updated.setUri(current.getUri());
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            if (mMediaSession != null) mMediaSession.setMetadata(null);
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }

    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        invalidateAllPreparations();
        if (mExoPlayer != null && mIsUsingExoPlayer) mExoPlayer.stop();
        resetPlayerSafely();
        if (mCurrentPlaylist != null) mCurrentPlaylist.clear();
        mCurrentIndex = -1;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
                .putInt(KEY_CURRENT_POSITION, 0)
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        stopSelf();
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }

    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) mAudioManager.requestAudioFocus(mAudioFocusRequest);
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }

    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }

    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }

    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                        PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                        PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }

    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) playNext();
            else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) playPrevious();
            return;
        }
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: togglePlayPause(); break;
            case KeyEvent.KEYCODE_MEDIA_NEXT: playNext(); break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: playPrevious(); break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: if (!mIsPlaying && mCurrentIndex >= 0) resume(); break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: if (mIsPlaying) pause(); break;
            default: break;
        }
    }

    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // SoundTouch doesn't need special handling
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (!mIsPlaying && wasPlayingBeforeRestart()) resume();
                break;
            default: break;
        }
    }
}