package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with seamless dual-player architecture.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground.</p>
 * 
 * <h3>Seamless Dual-Player Architecture</h3>
 * <p>The service uses a bridge that manages two players with seamless transition:</p>
 * <ul>
 *   <li><b>Phase 1 (Immediate):</b> NativeMediaPlayer starts instantly when the first
 *       song is loaded. Playback begins with no delay.</li>
 *   <li><b>Phase 2 (Background):</b> LlamaPlayer initializes in the background while
 *       music is already playing. SoundTouch library loading happens without
 *       user-visible delay.</li>
 *   <li><b>Phase 3 (Seamless Transition):</b> When LlamaPlayer is ready, the bridge
 *       performs a seamless handover - capturing position, pausing Native briefly,
 *       starting LlamaPlayer at the same position. Transition is under 100ms.</li>
 *   <li><b>Phase 4 (Steady State):</b> LlamaPlayer becomes the primary player with
 *       independent pitch and tempo control. NativeMediaPlayer remains as fallback.</li>
 * </ul>
 * 
 * <h3>Playlist Management with Path-Based Preservation</h3>
 * <p><b>The player is NEVER touched unless:</b>
 * <ul>
 *   <li><b>Case 0:</b> Current song exists in new playlist -> DO ABSOLUTELY NOTHING.
 *       Just update index and force UI refresh. Playback continues uninterrupted.</li>
 *   <li><b>Case 1:</b> No songs before AND new playlist has songs -> prepare first song,
 *       NO auto-play. Initialize players NOW that we have songs.</li>
 *   <li><b>Case 2:</b> Current song was REMOVED -> stop playback, load first song,
 *       NO auto-play.</li>
 * </ul>
 * </p>
 * 
 * <h3>Audio Focus Integration</h3>
 * <p>The service properly handles audio focus changes from other apps:
 * <ul>
 *   <li><b>AUDIOFOCUS_LOSS</b> - Pause playback immediately</li>
 *   <li><b>AUDIOFOCUS_LOSS_TRANSIENT</b> - Pause temporarily</li>
 *   <li><b>AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK</b> - Duck volume to 30%</li>
 *   <li><b>AUDIOFOCUS_GAIN</b> - Restore normal volume</li>
 * </ul>
 * </p>
 * 
 * <h3>Thread Safety</h3>
 * <p>All public methods are thread-safe. Uses synchronized blocks, atomic variables,
 * and Handler for main thread operations. All delays use Handler.postDelayed().</p>
 * 
 * @see AudioPlayerBridge
 * @see NativeMediaPlayer
 * @see LlamaPlayer
 * @see EqualizerManager
 * @see NotificationService
 * @see PlaybackController
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Name of shared preferences file for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Notification ID for foreground service. */
    private static final int NOTIFICATION_ID = 1;
    
    /** Key for storing current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing current playback position. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing repeat mode. */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before app update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing playlist sort mode. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Extra key for sort mode data. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Action indicating player is ready. */
    private static final String ACTION_PLAYER_READY = "PLAYER_READY";
    
    /** Delay for song transition completion (milliseconds). */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Action for audio session change broadcasts. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Action for player status updates. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Action for position update broadcasts. */
    private static final String ACTION_UPDATE_PLAYER_POSITION = "UPDATE_PLAYER_POSITION";
    
    /** Action for force UI refresh. */
    private static final String ACTION_FORCE_UI_REFRESH = "FORCE_UI_REFRESH";
    
    /** Delay before pre-initializing next song (milliseconds). */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay before resetting seek flag (milliseconds). */
    private static final int SEEK_RESET_DELAY_MS = 250;
    
    // Sort Mode Constants
    private static final int SORT_TITLE_AZ = 0;
    private static final int SORT_TITLE_ZA = 1;
    private static final int SORT_ARTIST_AZ = 2;
    private static final int SORT_ARTIST_ZA = 3;
    private static final int SORT_ALBUM_AZ = 4;
    private static final int SORT_ALBUM_ZA = 5;
    private static final int SORT_GENRE_AZ = 6;
    private static final int SORT_GENRE_ZA = 7;
    private static final int SORT_OLDEST = 8;
    private static final int SORT_NEWEST = 9;
    
    // ========================================================================
    // Static Members
    // ========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;
    
    /**
     * Returns the current audio session ID for equalizer attachment.
     *
     * @return The audio session ID
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    /**
     * Sets a flag indicating player state should be preserved before app update.
     *
     * @param context The application context
     * @param need True if state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Checks if player state should be preserved before app update.
     *
     * @param context The application context
     * @return True if state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state preservation flag.
     *
     * @param context The application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    // ========================================================================
    // Core Components
    // ========================================================================
    
    /** AudioPlayerBridge - orchestrates NativeMediaPlayer and LlamaPlayer with seamless transition. */
    @Nullable private AudioPlayerBridge mAudioBridge;
    
    // ========================================================================
    // Playlist Management
    // ========================================================================
    
    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of currently playing song in playlist. */
    private volatile int mCurrentIndex = -1;
    
    /** True if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0=off, 1=all, 2=one. */
    private volatile int mRepeatMode = 0;
    
    /** True if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Current playlist sort mode. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    /** History of shuffled indices to prevent immediate repeats. */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft updates. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** True if a pending playlist is waiting. */
    private boolean mHasPendingPlaylist = false;
    
    // ========================================================================
    // Seek State
    // ========================================================================
    
    /** Flag to prevent position revert during seek. */
    private final AtomicBoolean mSeekInProgress = new AtomicBoolean(false);
    
    /** Last seek position applied. */
    private volatile int mLastSeekPosition = -1;
    
    // ========================================================================
    // Wake Lock for Background Playback
    // ========================================================================
    
    /** Wake lock to prevent CPU sleep during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // ========================================================================
    // Audio Focus Management
    // ========================================================================
    
    /** Audio manager for focus and volume control. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for Android O and above. */
    private AudioFocusRequest mAudioFocusRequest;
    
    // ========================================================================
    // Media Session
    // ========================================================================
    
    /** Media session for lock screen controls. */
    private MediaSession mMediaSession;
    
    // ========================================================================
    // Bluetooth State
    // ========================================================================
    
    /** True if a Bluetooth device is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // ========================================================================
    // Thread Safety and Async Operations
    // ========================================================================
    
    /** Lock for player operations. */
    private final Object mPlayerLock = new Object();
    
    /** Atomic flag for transition lock. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Prevents re-entrant completion handling. */
    private final AtomicBoolean mIsCompleting = new AtomicBoolean(false);
    
    // ========================================================================
    // PlaybackController
    // ========================================================================
    
    /** Centralized playback state controller. */
    @Nullable private PlaybackController mPlaybackController;
    
    // ========================================================================
    // Notification Service
    // ========================================================================
    
    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;
    
    // ========================================================================
    // Sync State
    // ========================================================================
    
    /** Flag indicating if a sync operation is in progress. */
    private volatile boolean mIsSyncInProgress = false;
    
    // ========================================================================
    // Binder
    // ========================================================================
    
    /** Binder for service binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // ========================================================================
    // Broadcast Receivers
    // ========================================================================
    
    /** Receiver for notification updates. */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates. */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for playlist clear commands. */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme change events. */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for playing state queries. */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode changes. */
    private BroadcastReceiver mSortModeReceiver;
    
    /** Receiver for restoring playback state after sync. */
    private BroadcastReceiver mPlaybackRestoreReceiver;
    
    /** Receiver for sync state changes. */
    private BroadcastReceiver mSyncStateReceiver;
    
    // ========================================================================
    // Inner Classes
    // ========================================================================
    
    /**
     * Local binder for service binding.
     * 
     * <p>This binder allows activities to obtain a reference to the MusicService
     * instance for direct method calls, enabling efficient communication without
     * the overhead of AIDL.</p>
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the MusicService instance.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // ========================================================================
    // Sort Comparator Classes
    // ========================================================================
    
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle() != null ? a.getTitle() : "";
            String titleB = b.getTitle() != null ? b.getTitle() : "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle() != null ? a.getTitle() : "";
            String titleB = b.getTitle() != null ? b.getTitle() : "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist() != null ? a.getArtist() : "";
            String artistB = b.getArtist() != null ? b.getArtist() : "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist() != null ? a.getArtist() : "";
            String artistB = b.getArtist() != null ? b.getArtist() : "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum() != null ? a.getAlbum() : "";
            String albumB = b.getAlbum() != null ? b.getAlbum() : "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum() != null ? a.getAlbum() : "";
            String albumB = b.getAlbum() != null ? b.getAlbum() : "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre() != null ? a.getGenre() : "";
            String genreB = b.getGenre() != null ? b.getGenre() : "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre() != null ? a.getGenre() : "";
            String genreB = b.getGenre() != null ? b.getGenre() : "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle() != null ? a.getTitle() : "";
                String titleB = b.getTitle() != null ? b.getTitle() : "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // ========================================================================
    // Service Lifecycle Methods
    // ========================================================================
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        
        // Initialize notification service
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Create notification channel and start foreground service
        createForegroundNotificationChannel();
        Notification notification = createMinimalForegroundNotification();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.d(TAG, "Foreground service started");
        
        // Initialize audio manager
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved preferences
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup media session for lock screen controls
        setupMediaSession();
        
        // Initialize equalizer manager
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle tracking
        mShuffleHistory = new ArrayList<>();
        mRandom = new Random();
        
        // Setup audio focus
        setupAudioFocus();
        
        // Initialize wake lock for background playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize AudioPlayerBridge (Phase 1 - NativeMediaPlayer ready immediately)
        initializeAudioBridge();
        
        // Register all broadcast receivers
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        registerPlaybackRestoreReceiver();
        registerSyncStateReceiver();
        
        // Initialize PlaybackController
        mPlaybackController = PlaybackController.getInstance();
        
        // Register with NavigationController for global button state
        NavigationController.getInstance().registerListener(new NavigationController.ButtonStateListener() {
            @Override
            public void onButtonStateChanged(NavigationController.ButtonGroup group, boolean disabled) {
                if (group == NavigationController.ButtonGroup.FOLDER_ACTIONS && mNotificationService != null) {
                    Log.d(TAG, "Folder actions state changed: " + disabled);
                }
            }
        });
        
        Log.d(TAG, "MusicService onCreate complete - AudioPlayerBridge ready");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        saveFullState();
        savePlayerState();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        // Release AudioPlayerBridge
        if (mAudioBridge != null) {
            mAudioBridge.release();
            mAudioBridge = null;
        }
        
        // Stop notification service
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        // Release MediaSession
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Unregister receivers
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        unregisterReceiverSafely(mPlaybackRestoreReceiver);
        unregisterReceiverSafely(mSyncStateReceiver);
        
        super.onDestroy();
    }
    
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // AudioPlayerBridge handles its own memory management
    }
    
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // ========================================================================
    // Notification Channel Methods
    // ========================================================================
    
    private void createForegroundNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "foreground_channel",
                "Music Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Required for background music playback");
            channel.setSound(null, null);
            channel.enableVibration(false);
            
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    private Notification createMinimalForegroundNotification() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, MusicPlayer.class), flags);
        
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("foreground_channel");
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
               .setContentTitle("Llama Music Player")
               .setContentText("ENJOY THE WAVES")
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setVisibility(Notification.VISIBILITY_PUBLIC);
        
        return builder.build();
    }
    
    // ========================================================================
    // AudioPlayerBridge Initialization
    // ========================================================================
    
    /**
     * Initializes the AudioPlayerBridge which manages NativeMediaPlayer (immediate)
     * and LlamaPlayer (background initialization with seamless transition).
     */
    private void initializeAudioBridge() {
        mAudioBridge = new AudioPlayerBridge(this);
        mAudioBridge.setListener(new AudioPlayerBridge.AudioPlayerListener() {
            @Override
            public void onPrepared() {
                handlePlayerPrepared();
            }
            
            @Override
            public void onCompletion() {
                handleCompletion();
            }
            
            @Override
            public void onPositionUpdate(long positionMs) {
                if (mPlaybackController != null && !mSeekInProgress.get()) {
                    mPlaybackController.updatePosition(positionMs, "AudioBridge.onPositionUpdate");
                }
            }
            
            @Override
            public void onError(String error) {
                Log.e(TAG, "AudioBridge error: " + error);
                if (mPlaybackController != null) {
                    mPlaybackController.notifyOperationFailed("playback", error);
                }
                createNotification();
            }
            
            @Override
            public void onAudioSessionAvailable(int sessionId) {
                sCurrentAudioSessionId = sessionId;
                broadcastAudioSessionChanged(sessionId);
                EqualizerManager.getInstance(MusicService.this).attachToAudioSession(sessionId);
            }
            
            @Override
            public void onStateChanged(boolean isPlaying, boolean isPrepared) {
                setPlaybackState(isPlaying, isPrepared);
            }
            
            @Override
            public void onLlamaPlayerAvailable() {
                Log.d(TAG, "LlamaPlayer now available - pitch/tempo controls enabled");
                // Apply any pending pitch/tempo settings
                updatePlaybackParams();
                // Broadcast that enhanced features are now available
                Intent readyIntent = new Intent(ACTION_PLAYER_READY);
                readyIntent.putExtra("llama_available", true);
                sendBroadcast(readyIntent);
            }
            
            @Override
            public void onTransitionProgress(int progress) {
                Log.v(TAG, "Transition progress: " + progress + "%");
            }
            
            @Override
            public void onTransitionComplete() {
                Log.d(TAG, "Seamless transition to LlamaPlayer complete");
                // Ensure pitch/tempo are applied after transition
                updatePlaybackParams();
                // Refresh notification to show enhanced capabilities
                createNotification();
            }
        });
        
        Log.d(TAG, "AudioPlayerBridge initialized - NativeMediaPlayer ready for immediate playback");
    }
    
    private void handlePlayerPrepared() {
        Log.d(TAG, "AudioPlayerBridge: onPrepared");
        
        if (mPlaybackController != null) {
            mPlaybackController.setPrepared(true, "AudioBridge.onPrepared");
            mPlaybackController.setDuration(getDuration(), "AudioBridge.onPrepared");
            if (mCurrentIndex >= 0 && mCurrentIndex < getPlaylistSize()) {
                Song song = getCurrentSong();
                if (song != null) {
                    mPlaybackController.updateSong(song, "AudioBridge.onPrepared");
                }
            }
        }
        
        broadcastUpdate();
        createNotification();
        
        Intent readyIntent = new Intent(ACTION_PLAYER_READY);
        sendBroadcast(readyIntent);
    }
    
    // ========================================================================
    // Centralized Playback State Management
    // ========================================================================
    
    private void setPlaybackState(boolean isPlaying, boolean isPrepared) {
        synchronized (mPlayerLock) {
            boolean wasPlaying = mIsPlaying;
            mIsPlaying = isPlaying;
            
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(isPlaying, "MusicService.setPlaybackState");
                mPlaybackController.setPrepared(isPrepared, "MusicService.setPlaybackState");
            }
            
            // Manage wake lock based on playback state
            if (isPlaying && !wasPlaying) {
                if (mWakeLock != null && !mWakeLock.isHeld()) {
                    mWakeLock.acquire(3600000);
                    Log.d(TAG, "WakeLock acquired");
                }
                requestAudioFocus();
            } else if (!isPlaying && wasPlaying) {
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released");
                }
                abandonAudioFocus();
            }
        }
        
        broadcastUpdate();
        createNotification();
        updateMediaSessionPlaybackState();
    }
    
    // ========================================================================
    // Public API Methods for MusicPlayer
    // ========================================================================
    
    /**
     * Checks if any player is currently playing.
     *
     * @return True if playing
     */
    public boolean isAnyPlayerPlaying() {
        return mAudioBridge != null && mAudioBridge.isPlaying();
    }
    
    /**
     * Checks if any player is prepared for playback.
     *
     * @return True if prepared
     */
    public boolean isAnyPlayerPrepared() {
        return mAudioBridge != null && mAudioBridge.isPrepared();
    }
    
    /**
     * Checks if LlamaPlayer is available (pitch/tempo controls enabled).
     *
     * @return True if LlamaPlayer is active
     */
    public boolean isLlamaPlayerAvailable() {
        return mAudioBridge != null && mAudioBridge.isLlamaPlayerAvailable();
    }
    
    /**
     * Sets the sync in progress flag.
     *
     * @param inProgress True if sync is in progress
     */
    public void setSyncInProgress(boolean inProgress) {
        mIsSyncInProgress = inProgress;
        Log.d(TAG, "setSyncInProgress: " + inProgress);
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        int currentPosition = getCurrentPosition();
        
        if (mPlaybackController != null) {
            mPlaybackController.onPause();
            mPlaybackController.updatePosition(currentPosition, "pause.forceUpdate");
        }
        
        if (mAudioBridge != null) {
            mAudioBridge.pause();
        }
        
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastPositionUpdate(currentPosition);
    }
    
    /**
     * Resumes playback from a paused state.
     */
    public void resume() {
        if (mAudioBridge != null && mAudioBridge.isPrepared()) {
            if (mPlaybackController != null) {
                mPlaybackController.setPlaying(true, "resume");
                mPlaybackController.onResume();
            }
            mAudioBridge.start();
            savePlayingState();
            savePlayerState();
            saveFullState();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            playSong(0, true);
        } else if (mPlaybackController != null) {
            mPlaybackController.notifyOperationFailed("resume", "No songs in playlist");
        }
    }
    
    /**
     * Stops playback without clearing playlist.
     */
    public void stop() {
        if (mAudioBridge != null) {
            mAudioBridge.stop();
        }
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(false, "stop");
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position.
     *
     * @param position The position in milliseconds to seek to
     */
    public void seekTo(int position) {
        mSeekInProgress.set(true);
        mLastSeekPosition = position;
        
        if (mPlaybackController != null) {
            mPlaybackController.updatePosition(position, "MusicService.seekTo");
        }
        
        if (mAudioBridge != null) {
            mAudioBridge.seekTo(position);
        }
        
        mMainHandler.postDelayed(() -> {
            mSeekInProgress.set(false);
            mLastSeekPosition = -1;
        }, SEEK_RESET_DELAY_MS);
    }
    
    /**
     * Gets the current playback position.
     *
     * @return Current position in milliseconds
     */
    public int getCurrentPosition() {
        if (mSeekInProgress.get() && mLastSeekPosition >= 0) {
            return mLastSeekPosition;
        }
        
        if (mPlaybackController != null) {
            long pos = mPlaybackController.getCurrentPosition();
            if (pos > 0 || mPlaybackController.isPrepared()) return (int) pos;
        }
        
        if (mAudioBridge != null) {
            return mAudioBridge.getCurrentPosition();
        }
        return 0;
    }
    
    /**
     * Gets the duration of the current song.
     *
     * @return Duration in milliseconds
     */
    public int getDuration() {
        if (mPlaybackController != null) {
            return (int) mPlaybackController.getDuration();
        }
        if (mAudioBridge != null) {
            return mAudioBridge.getDuration();
        }
        return 0;
    }
    
    /**
     * Checks if playback is active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mPlaybackController != null) return mPlaybackController.isPlaying();
        return mIsPlaying;
    }
    
    /**
     * Gets the currently playing song.
     *
     * @return The current song, or null if none
     */
    @Nullable
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Gets the current playlist index.
     *
     * @return The current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Gets the current repeat mode.
     *
     * @return 0=off, 1=all, 2=one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0=off, 1=all, 2=one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Sets Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The index to play
     * @param autoStart Whether to auto-start playback
     */
    public synchronized void playSong(int index, boolean autoStart) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.w(TAG, "playSong: Invalid index " + index);
            return;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.w(TAG, "playSong: Song or path is null");
            return;
        }
        
        File songFile = new File(song.getPath());
        if (!songFile.exists()) {
            Log.e(TAG, "playSong: File does not exist: " + song.getPath());
            mCurrentPlaylist.remove(index);
            if (mCurrentPlaylist.isEmpty()) {
                stopCompletely();
            } else {
                playNext();
            }
            return;
        }
        
        if (mPlaybackController != null) {
            mPlaybackController.setPlaying(false, "playSong");
            mPlaybackController.setPrepared(false, "playSong");
            mPlaybackController.updateSong(song, "playSong");
        }
        
        mCurrentIndex = index;
        mAudioBridge.initialize(song.getPath());
        mAudioBridge.prepare(autoStart);
        
        createNotification();
        broadcastUpdate();
        savePlayerState();
        
        Log.d(TAG, "playSong: " + song.getTitle() + " at index " + index + ", autoStart=" + autoStart);
    }
    
    /**
     * Plays a song at the specified index (auto-start true).
     *
     * @param index The index to play
     */
    public synchronized void playSong(int index) {
        playSong(index, true);
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The file path of the song to play
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i, true);
                return;
            }
        }
        Log.w(TAG, "playSongByPath: Song not found in playlist: " + filePath);
    }
    
    /**
     * Plays the next song in the playlist.
     */
    public synchronized void playNext() {
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "playNext: playlist is empty");
                return;
            }
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex, true);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     */
    public synchronized void playPrevious() {
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex, true);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        boolean isPlaying = isAnyPlayerPlaying();
        boolean isPrepared = isAnyPlayerPrepared();
        
        if (isPlaying) {
            pause();
        } else if (isPrepared) {
            resume();
        } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            playSong(0, true);
        }
    }
    
    // ========================================================================
    // Sort Mode Methods
    // ========================================================================
    
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    saveCurrentPlayingIndex();
                    break;
                }
            }
        }
    }
    
    // ========================================================================
    // Playlist Management - CRITICAL: Path-Based Preservation
    // ========================================================================
    
    /**
     * Sets the current playlist with path-based preservation.
     * 
     * <p><b>The player is NEVER touched unless:</b>
     * <ul>
     *   <li><b>Case 0:</b> Songs existed before AND current song exists -> DO NOTHING</li>
     *   <li><b>Case 1:</b> No songs before - first load -> prepare first, NO auto-play</li>
     *   <li><b>Case 2:</b> Current song was REMOVED -> stop, load first, NO auto-play</li>
     * </ul>
     * </p>
     *
     * @param playlist The new playlist (can be null to clear)
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        if (mIsSyncInProgress) {
            Log.d(TAG, "setPlaylist: Sync in progress, deferring");
            if (playlist != null && !playlist.isEmpty()) {
                mCurrentPlaylist = new ArrayList<>(playlist);
            }
            return;
        }
        
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            String currentSongPath = null;
            boolean hadSongs = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty());
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
                if (currentSong != null) {
                    currentSongPath = currentSong.getPath();
                }
            }
            
            if (playlist == null || playlist.isEmpty()) {
                handleEmptyPlaylist();
                return;
            }
            
            ArrayList<Song> sortedPlaylist = new ArrayList<>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            int newIndex = -1;
            if (preserveCurrentSong && currentSongPath != null) {
                for (int i = 0; i < sortedPlaylist.size(); i++) {
                    Song song = sortedPlaylist.get(i);
                    if (song != null && currentSongPath.equals(song.getPath())) {
                        newIndex = i;
                        Log.d(TAG, "Found current song in new playlist at index " + newIndex);
                        break;
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            boolean songExistsInNewPlaylist = (newIndex >= 0);
            
            // CASE 0: Songs existed AND current song exists - PLAYBACK UNTOUCHED
            if (hadSongs && songExistsInNewPlaylist) {
                Log.d(TAG, "CASE 0: Songs existed, current song exists - PLAYBACK UNTOUCHED");
                mCurrentIndex = newIndex;
                saveCurrentPlayingIndex();
                
                if (mPlaybackController != null && currentSongPath != null) {
                    for (Song s : mCurrentPlaylist) {
                        if (s != null && currentSongPath.equals(s.getPath())) {
                            mPlaybackController.updateSong(s, "setPlaylist.metadata.force");
                            mPlaybackController.setDuration(s.getDuration(), "setPlaylist.metadata.force");
                            break;
                        }
                    }
                    int currentPos = getCurrentPosition();
                    mPlaybackController.updatePosition(currentPos, "setPlaylist.position.sync");
                }
                
                Intent forceRefreshIntent = new Intent(ACTION_FORCE_UI_REFRESH);
                forceRefreshIntent.putExtra("refresh_metadata", true);
                sendBroadcast(forceRefreshIntent);
            }
            // CASE 1: No songs before - first load
            else if (!hadSongs && sortedPlaylist.size() > 0) {
                Log.d(TAG, "CASE 1: First load - preparing first song, NO auto-play");
                mCurrentIndex = 0;
                
                if (mPlaybackController != null) {
                    Song firstSong = sortedPlaylist.get(0);
                    if (firstSong != null) {
                        mPlaybackController.updateSong(firstSong, "setPlaylist.firstLoad");
                        mPlaybackController.setDuration(firstSong.getDuration(), "setPlaylist.firstLoad");
                        mPlaybackController.setPlaying(false, "setPlaylist.firstLoad");
                    }
                }
                
                // Pre-load the first song without auto-play
                if (mAudioBridge != null && sortedPlaylist.size() > 0) {
                    Song firstSong = sortedPlaylist.get(0);
                    if (firstSong != null && firstSong.getPath() != null) {
                        mAudioBridge.initialize(firstSong.getPath());
                        mAudioBridge.prepare(false);
                    }
                }
            }
            // CASE 2: Current song was REMOVED
            else if (hadSongs && !songExistsInNewPlaylist) {
                Log.d(TAG, "CASE 2: Current song removed - stopping, loading first, NO auto-play");
                
                if (mAudioBridge != null) {
                    mAudioBridge.stop();
                }
                mIsPlaying = false;
                
                if (sortedPlaylist.size() > 0) {
                    mCurrentIndex = 0;
                    if (mPlaybackController != null) {
                        mPlaybackController.setPlaying(false, "setPlaylist.songRemoved");
                        mPlaybackController.updatePosition(0, "setPlaylist.songRemoved");
                    }
                    
                    if (mAudioBridge != null) {
                        Song firstSong = sortedPlaylist.get(0);
                        if (firstSong != null && firstSong.getPath() != null) {
                            mAudioBridge.initialize(firstSong.getPath());
                            mAudioBridge.prepare(false);
                        }
                    }
                } else {
                    mCurrentIndex = -1;
                    if (mPlaybackController != null) {
                        mPlaybackController.updateSong(null, "setPlaylist.empty");
                        mPlaybackController.setPrepared(false, "setPlaylist.empty");
                    }
                }
            }
            
            saveCurrentPlayingIndex();
            savePlayerState();
            
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                mMainHandler.postDelayed(() -> preInitializeCurrentSong(), PRE_INIT_DELAY_MS);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        }
    }
    
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    private void preInitializeCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        int index = mCurrentIndex >= 0 ? mCurrentIndex : 0;
        if (index >= mCurrentPlaylist.size()) index = 0;
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) return;
        
        if (mAudioBridge != null) {
            // Don't auto-start, just pre-load
            mAudioBridge.initialize(song.getPath());
            mAudioBridge.prepare(false);
            Log.d(TAG, "preInitializeCurrentSong: Pre-loaded: " + song.getTitle());
        }
    }
    
    private void handleEmptyPlaylist() {
        if (mAudioBridge != null) {
            mAudioBridge.stop();
        }
        mCurrentPlaylist = null;
        mCurrentIndex = -1;
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .apply();
        
        if (mPlaybackController != null) {
            mPlaybackController.reset();
        }
        
        if (mShuffleHistory != null) mShuffleHistory.clear();
        createNotification();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    public void stopCompletely() {
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            
            if (mAudioBridge != null) {
                mAudioBridge.stop();
                mAudioBridge.release();
                mAudioBridge = null;
            }
            
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            if (mPlaybackController != null) {
                mPlaybackController.reset();
            }
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        // Re-initialize bridge for future use
        initializeAudioBridge();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    private int getPlaylistSize() {
        return mCurrentPlaylist != null ? mCurrentPlaylist.size() : 0;
    }
    
    // ========================================================================
    // Playlist Loading Methods
    // ========================================================================
    
    /**
     * Loads the full playlist from MusicLibrary.
     * This is called when the service first binds to MusicPlayer.
     *
     * @param songs The list of songs to set as the playlist
     */
    public void loadPlaylist(ArrayList<Song> songs) {
        if (songs == null || songs.isEmpty()) {
            Log.d(TAG, "loadPlaylist: Empty playlist");
            return;
        }
        
        Log.d(TAG, "loadPlaylist: Loading " + songs.size() + " songs");
        setPlaylist(songs, false);
    }
    
    // ========================================================================
    // Completion and Broadcast Methods
    // ========================================================================
    
    private void handleCompletion() {
        if (!mIsCompleting.compareAndSet(false, true)) {
            Log.d(TAG, "handleCompletion already in progress, ignoring");
            return;
        }
        
        try {
            broadcastSongCompletion();
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                mIsPlaying = false;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "handleCompletion");
                    mPlaybackController.setPrepared(false, "handleCompletion");
                }
                updateNotificationPlaybackState(false);
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex, true);
                return;
            }
            
            if (mRepeatMode == 2) {
                if (mAudioBridge != null) {
                    mAudioBridge.seekTo(0);
                    mAudioBridge.start();
                }
            } else if (mRepeatMode == 1) {
                playNext();
            } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
                playNext();
            } else {
                mIsPlaying = false;
                if (mPlaybackController != null) {
                    mPlaybackController.setPlaying(false, "handleCompletion.end");
                    mPlaybackController.setPrepared(false, "handleCompletion.end");
                }
                updateNotificationPlaybackState(false);
                
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                
                if (mAudioBridge != null) {
                    mAudioBridge.stop();
                }
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, getDuration())
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .apply();
                savePlayingState();
                savePlayerState();
                saveFullState();
                
                broadcastSongCompletion();
                updateMediaSessionPlaybackState();
            
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                    mNotificationService.setPlayingState(false);
                    mNotificationService.forceUpdate();
                }
            }
        } finally {
            mIsCompleting.set(false);
        }
    }
    
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
    }
    
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    private void broadcastPositionUpdate(int positionMs) {
        Intent intent = new Intent(ACTION_UPDATE_PLAYER_POSITION);
        intent.putExtra("position", positionMs);
        sendBroadcast(intent);
        Log.d(TAG, "Broadcast position update: " + positionMs + "ms");
    }
    
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    // ========================================================================
    // Playback Parameter Methods
    // ========================================================================
    
    public void updatePlaybackParams() {
        if (mAudioBridge != null && mAudioBridge.isLlamaPlayerAvailable()) {
            EqualizerManager eq = EqualizerManager.getInstance(this);
            int speedLevel = eq.getSpeed();
            float tempo = 0.5f + (speedLevel / 2000.0f);
            int pitchLevel = eq.getPitch();
            float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
            
            mAudioBridge.setPitch(semitones);
            mAudioBridge.setTempo(tempo);
            Log.d(TAG, "Playback params updated: tempo=" + tempo + ", pitch=" + semitones);
        }
    }
    
    // ========================================================================
    // Media Button and Close Handling
    // ========================================================================
    
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        if (mAudioBridge != null) {
            mAudioBridge.stop();
        }
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) return;
            if (!songPath.equals(current.getPath())) return;
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mPlaybackController != null) {
                mPlaybackController.updateSong(updated, "refreshMetadataForSong");
            }
            
            updateMediaSessionMetadata();
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        }
    }
    
    // ========================================================================
    // Notification Methods
    // ========================================================================
    
    private void updateNotificationPlaybackState(boolean isPlaying) {
        if (mNotificationService != null) {
            mNotificationService.setPlayingState(isPlaying);
            mNotificationService.forceUpdate();
        }
    }
    
    private void createNotification() {
        if (mIsSyncInProgress) {
            Log.d(TAG, "createNotification: Sync in progress, skipping");
            return;
        }
        
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
                mNotificationService.setPlayingState(mIsPlaying);
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        mNotificationService.forceUpdate();
    }
    
    public void refreshNotification() {
        if (mNotificationService != null) {
            createNotification();
        }
    }
    
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // ========================================================================
    // State Persistence Methods
    // ========================================================================
    
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    private void saveFullState() {
        savePlayerState();
    }
    
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }
    
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }
    
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // ========================================================================
    // Media Session Methods
    // ========================================================================
    
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                    
                    @Override
                    public void onSeekTo(long pos) {
                        Log.d(TAG, "MediaSession.onSeekTo: " + pos + "ms");
                        seekTo((int) pos);
                        
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                            long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                                          PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                                          PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                            int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                            stateBuilder.setState(state, pos, 1.0f);
                            stateBuilder.setActions(actions);
                            mMediaSession.setPlaybackState(stateBuilder.build());
                        }
                    }
                });
                
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
                
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            return;
        }
        
        android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
        builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                          currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                          currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                          currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album");
        builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
        
        mMediaSession.setMetadata(builder.build());
        Log.d(TAG, "MediaSession metadata updated: " + currentSong.getTitle());
    }
    
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    // ========================================================================
    // Audio Focus Methods
    // ========================================================================
    
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                Log.d(TAG, "Audio focus LOSS - pausing playback");
                if (mIsPlaying) {
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                Log.d(TAG, "Audio focus LOSS_TRANSIENT - pausing playback");
                if (mIsPlaying) {
                    pause();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                Log.d(TAG, "Audio focus LOSS_TRANSIENT_CAN_DUCK - ducking volume");
                if (mIsPlaying && mAudioBridge != null) {
                    mAudioBridge.duck();
                }
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                Log.d(TAG, "Audio focus GAIN - restoring volume");
                if (mAudioBridge != null) {
                    mAudioBridge.unduck();
                }
                break;
                
            default:
                break;
        }
    }
    
    // ========================================================================
    // Helper Methods
    // ========================================================================
    
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // ========================================================================
    // Broadcast Receiver Registration
    // ========================================================================
    
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }
    
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }
    
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }
    
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }
    
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }
    
    private void registerPlaybackRestoreReceiver() {
        mPlaybackRestoreReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("RESTORE_PLAYBACK_STATE".equals(intent.getAction())) {
                    String songPath = intent.getStringExtra("song_path");
                    int position = intent.getIntExtra("position", 0);
                    boolean shouldPlay = intent.getBooleanExtra("should_play", false);
                    
                    Log.d(TAG, "Playback restore received: path=" + songPath + 
                          ", position=" + position + ", play=" + shouldPlay);
                    
                    if (songPath != null && !songPath.isEmpty() && mCurrentPlaylist != null) {
                        int newIndex = -1;
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            Song song = mCurrentPlaylist.get(i);
                            if (song != null && songPath.equals(song.getPath())) {
                                newIndex = i;
                                break;
                            }
                        }
                        
                        if (newIndex >= 0) {
                            Log.d(TAG, "Restoring playback at index " + newIndex + 
                                  ", position " + position + "ms");
                            playSongAtPosition(newIndex, position);
                            if (shouldPlay && !isAnyPlayerPlaying()) {
                                resume();
                            }
                        } else {
                            Log.w(TAG, "Song not found in playlist after sync: " + songPath);
                        }
                    }
                }
            }
        };
        
        IntentFilter filter = new IntentFilter("RESTORE_PLAYBACK_STATE");
        registerReceiver(mPlaybackRestoreReceiver, filter);
        Log.d(TAG, "Playback restore receiver registered");
    }
    
    private void registerSyncStateReceiver() {
        mSyncStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("SYNC_STARTING".equals(intent.getAction())) {
                    mIsSyncInProgress = true;
                    Log.d(TAG, "Sync starting - notification updates suppressed");
                } else if ("SYNC_ENDING".equals(intent.getAction())) {
                    mIsSyncInProgress = false;
                    Log.d(TAG, "Sync ending - notification updates resumed");
                    createNotification();
                }
            }
        };
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTING");
        filter.addAction("SYNC_ENDING");
        registerReceiver(mSyncStateReceiver, filter);
        Log.d(TAG, "Sync state receiver registered");
    }
    
    private void playSongAtPosition(int index, int position) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        if (mAudioBridge != null) {
            Song song = mCurrentPlaylist.get(index);
            if (song != null && song.getPath() != null) {
                mAudioBridge.initialize(song.getPath());
                mAudioBridge.prepare(true);
                if (position > 0) {
                    mAudioBridge.seekTo(position);
                }
            }
        }
        saveFullState();
    }
}