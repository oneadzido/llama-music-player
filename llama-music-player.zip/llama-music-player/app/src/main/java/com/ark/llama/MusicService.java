package com.ark.llama;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with SoundTouch integration.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground. The service follows
 * Android's standard service lifecycle and integrates with the system's
 * audio focus, media session, and notification systems.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture to ensure reliable playback:</p>
 * <ul>
 *   <li><b>Primary Path (SoundTouchPlayer)</b> - DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control with high quality.
 *       Follows MediaPlayer lifecycle pattern for consistency and predictability.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> - Used ONLY when SoundTouchPlayer
 *       fails at runtime (library missing, initialization error, or crash).
 *       This ensures playback never fails completely.</li>
 * </ul>
 * 
 * <h3>Playback State Machine</h3>
 * <p>The service maintains a playback state machine that coordinates with the
 * underlying SoundTouchPlayer and MediaPlayer instances.</p>
 * 
 * <h3>MediaPlayer-like API for SoundTouchPlayer</h3>
 * <p>The SoundTouchPlayer follows the same pattern as MediaPlayer:
 * reset() -> setDataSource() -> prepareAsync() -> onPrepared() -> start()</p>
 * 
 * <h3>Multiple Press Handling</h3>
 * <p>The service properly handles rapid button presses that could cause crashes
 * or state inconsistencies in naive implementations.</p>
 * 
 * <h3>Pre-initialization Feature</h3>
 * <p>When a playlist is set, the service automatically pre-initializes the first
 * song to provide immediate song duration and early audio session creation.</p>
 * 
 * <h3>Playback State Persistence</h3>
 * <p>The service saves playback state to SharedPreferences to restore on restart.</p>
 * 
 * @see SoundTouchPlayer
 * @see MediaPlayer
 * @see EqualizerManager
 * @see NotificationService
 * @see android.media.MediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // =========================================================================
    // Constants
    // =========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "MusicService";
    
    /** Shared preferences file name for persistent storage. */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Notification ID for foreground service. */
    private static final int NOTIFICATION_ID = 1;
    
    /** Key for storing the current playing index. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state. */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state. */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update. */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song path. */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the sort mode for playlist display. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** Delay for song transitions in milliseconds. */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Intent action for audio session changed broadcast. */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds (MediaPlayer fallback only). */
    private static final int HEALTH_CHECK_INTERVAL_MS = 1500;
    
    /** Maximum time in milliseconds without progress before recovery. */
    private static final int MAX_STALL_TIME_MS = 3000;
    
    /** Maximum recovery attempts before skipping song. */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Broadcast action for player status update. */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Delay before pre-initializing the first song. */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay for seek reset flag in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 300;
    
    /** Timeout for waiting on SoundTouch preparation. */
    private static final int PREPARE_TIMEOUT_MS = 1500;
    
    // =========================================================================
    // Sort Mode Constants
    // =========================================================================
    
    /** Sort mode: Title A-Z. */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A. */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z. */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A. */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z. */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A. */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z. */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A. */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First. */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First. */
    private static final int SORT_NEWEST = 9;
    
    // =========================================================================
    // Static Members
    // =========================================================================
    
    /** Current audio session ID for equalizer attachment. */
    private static int sCurrentAudioSessionId = 0;
    
    // =========================================================================
    // SoundTouch Player Members (PRIMARY PLAYER)
    // =========================================================================
    
    /** SoundTouch-based audio player - DEFAULT for ALL playback. */
    private SoundTouchPlayer mSoundTouchPlayer;
    
    /** Flag indicating if SoundTouch is currently active. */
    private boolean mIsUsingSoundTouch = false;
    
    /** Flag indicating if SoundTouch failed (prevents retry loop). */
    private boolean mSoundTouchFailed = false;
    
    /** Flag indicating if SoundTouch is currently preparing. */
    private final AtomicBoolean mIsPreparingSoundTouch = new AtomicBoolean(false);
    
    /** Handler for preparation timeout. */
    private final Handler mPrepareTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** Timeout runnable for SoundTouch preparation. */
    private Runnable mPrepareTimeoutRunnable = null;
    
    /** Flag indicating if playback should start immediately after prepare. */
    private boolean mShouldStartAfterPrepare = false;
    
    // =========================================================================
    // MediaPlayer Members (FALLBACK PLAYER)
    // =========================================================================
    
    /** Legacy MediaPlayer instance - used ONLY when SoundTouch fails. */
    private MediaPlayer mMediaPlayer;
    
    // =========================================================================
    // Playback State
    // =========================================================================
    
    /** Current playlist of songs. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song. */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active. */
    private volatile boolean mIsPlaying = false;
    
    /** Repeat mode: 0 = off, 1 = repeat all, 2 = repeat one. */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled. */
    private volatile boolean mIsShuffle = false;
    
    /** Timestamp when current playback started (for health checks). */
    private long mPlaybackStartTime = 0;
    
    // =========================================================================
    // Sort Mode State
    // =========================================================================
    
    /** Current sort mode for playlist display. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // =========================================================================
    // Health Check Components (MediaPlayer only)
    // =========================================================================
    
    /** Handler for periodic health checks. */
    private Handler mHealthHandler;
    
    /** Runnable for health check. */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts for current song. */
    private int mRecoveryAttempts = 0;
    
    // =========================================================================
    // Wake Lock for Background Playback
    // =========================================================================
    
    /** WakeLock to prevent device sleep during playback. */
    private PowerManager.WakeLock mWakeLock;
    
    // =========================================================================
    // Audio Focus Management
    // =========================================================================
    
    /** Audio manager for focus management. */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes. */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** Audio focus request for API 26+. */
    private AudioFocusRequest mAudioFocusRequest;
    
    // =========================================================================
    // Media Session
    // =========================================================================
    
    /** MediaSession for lock screen and headset controls. */
    private MediaSession mMediaSession;
    
    // =========================================================================
    // Bluetooth State
    // =========================================================================
    
    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // =========================================================================
    // Thread Safety and Async Operations
    // =========================================================================
    
    /** Lock object for MediaPlayer operations. */
    private final Object mPlayerLock = new Object();
    
    /** Flag indicating if a song transition is in progress. */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** Flag indicating if a song is being prepared (MediaPlayer fallback only). */
    private final AtomicBoolean mIsPreparingFallback = new AtomicBoolean(false);
    
    /** Global preparation ID counter. */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** Current preparation ID. */
    private volatile int mCurrentPrepId = -1;
    
    /** Main thread handler for delayed operations. */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    /** Flag to prevent double playback during state restoration. */
    private boolean mIsRestoringPlayback = false;
    
    // =========================================================================
    // Binder
    // =========================================================================
    
    /** Binder for activity binding. */
    private final IBinder mBinder = new LocalBinder();
    
    // =========================================================================
    // Playlist Management
    // =========================================================================
    
    /** History of shuffled indices. */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft update. */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    // =========================================================================
    // Notification Service
    // =========================================================================
    
    /** Service for managing playback notifications. */
    private NotificationService mNotificationService;
    
    // =========================================================================
    // Broadcast Receivers
    // =========================================================================
    
    private BroadcastReceiver mUpdateNotificationReceiver;
    private BroadcastReceiver mPlaybackParamsReceiver;
    private BroadcastReceiver mClearPlaylistReceiver;
    private BroadcastReceiver mThemeReceiver;
    private BroadcastReceiver mGetPlayingStateReceiver;
    private BroadcastReceiver mSortModeReceiver;
    
    // =========================================================================
    // Inner Classes
    // =========================================================================
    
    /**
     * Local binder for service binding.
     * 
     * <p>This class implements Android's standard Binder pattern for service binding.
     * Activities call {@link android.content.Context#bindService} with an Intent
     * targeting this service, and receive this binder in the
     * {@link android.content.ServiceConnection#onServiceConnected} callback.</p>
     */
    public class LocalBinder extends Binder {
        
        /**
         * Returns the MusicService instance for the calling activity.
         *
         * @return The MusicService instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // =========================================================================
    // Sort Comparator Classes
    // =========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     * Null-safe: treats null titles as empty strings.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     * Null-safe: treats null titles as empty strings.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title A-Z.
     * Null-safe: treats null artists/titles as empty strings.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title A-Z.
     * Null-safe: treats null artists/titles as empty strings.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title A-Z.
     * Null-safe: treats null albums/titles as empty strings.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title A-Z.
     * Null-safe: treats null albums/titles as empty strings.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title A-Z.
     * Null-safe: treats null genres/titles as empty strings.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title A-Z.
     * Null-safe: treats null genres/titles as empty strings.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by oldest first (by file date), then by title.
     * Uses file.lastModified() timestamp for date comparison.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by newest first (by file date), then by title.
     * Uses file.lastModified() timestamp for date comparison.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // =========================================================================
    // Static Methods
    // =========================================================================
    
    /**
     * Sets the player state before update flag.
     * Used to preserve playback state during folder updates.
     *
     * @param context Application context
     * @param need True if player state should be preserved
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context
     * @return True if player state should be preserved
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     *
     * @param context Application context
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID for equalizer attachment.
     *
     * @return The current audio session ID (0 if no session exists)
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // =========================================================================
    // Service Lifecycle Methods
    // =========================================================================
    
    /**
     * Called when the service is created.
     * Initializes all service components including notification service,
     * audio manager, media session, equalizer, wake lock, and SoundTouchPlayer.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        mIsTransitioning.set(false);
        mIsPreparingFallback.set(false);
        
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Start foreground service to prevent Android from killing the process
        createForegroundNotificationChannel();
        Notification notification = createMinimalForegroundNotification();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.d(TAG, "Foreground service started");
        
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        loadRepeatAndShuffle();
        loadSortMode();
        
        setupMediaSession();
        EqualizerManager.getInstance(this);
        
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        setupAudioFocus();
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        initSoundTouchPlayer();
        
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete");
    }
    
    /**
     * Creates notification channel for foreground service (Android 8+ required).
     */
    private void createForegroundNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "foreground_channel",
                "Music Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Required for background music playback");
            channel.setSound(null, null);
            channel.enableVibration(false);
            
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * Creates a minimal notification for starting the foreground service.
     * Once the service is running, NotificationService updates it with full controls.
     *
     * @return Minimal notification for foreground service start
     */
    private Notification createMinimalForegroundNotification() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, MusicPlayer.class), flags);
        
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("foreground_channel");
        }
        
        builder.setSmallIcon(R.drawable.ic_notification)
               .setContentTitle("Llama Music Player")
               .setContentText("Starting...")
               .setContentIntent(contentIntent)
               .setOngoing(true)
               .setVisibility(Notification.VISIBILITY_PUBLIC);
        
        return builder.build();
    }
    
    /**
     * Initializes the SoundTouch player as the default player.
     * Falls back to MediaPlayer if SoundTouch library is not available.
     */
    private void initSoundTouchPlayer() {
        if (mSoundTouchFailed) {
            Log.d(TAG, "SoundTouch already failed, skipping init");
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        if (!SoundTouch.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        try {
            mSoundTouchPlayer = new SoundTouchPlayer(this);
            mSoundTouchPlayer.setListener(new SoundTouchPlayer.PlaybackListener() {
                @Override
                public void onStateChanged(SoundTouchPlayer.State newState, SoundTouchPlayer.State oldState) {
                    handleSoundTouchStateChange(newState, oldState);
                }
                
                @Override
                public void onPrepared() {
                    Log.d(TAG, "SoundTouchPlayer: onPrepared()");
                    mIsPreparingSoundTouch.set(false);
                    
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    
                    sendPlayerStatusBroadcast(true);
                    updatePlaybackParams();
                    
                    sCurrentAudioSessionId = mSoundTouchPlayer.getAudioSessionId();
                    broadcastAudioSessionChanged(sCurrentAudioSessionId);
                    EqualizerManager.getInstance(MusicService.this)
                        .attachToAudioSession(sCurrentAudioSessionId);
                    
                    // Update MediaSession metadata for lock screen display
                    updateMediaSessionMetadata();
                    
                    // Only start if not already playing
                    if (mShouldStartAfterPrepare && !mIsPlaying) {
                        mShouldStartAfterPrepare = false;
                        mSoundTouchPlayer.start();
                    } else {
                        mShouldStartAfterPrepare = false;
                    }
                    
                    broadcastUpdate();
                    createNotification();
                }
                
                @Override
                public void onCompletion() {
                    Log.d(TAG, "SoundTouchPlayer: onCompletion()");
                    handleCompletion();
                }
                
                @Override
                public void onPositionUpdate(long position) {
                    // Position updates handled by MusicPlayer's polling
                }
                
                @Override
                public void onError(@NonNull String error) {
                    Log.e(TAG, "SoundTouchPlayer error: " + error);
                    mIsPreparingSoundTouch.set(false);
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    fallbackToMediaPlayer();
                }
            });
            
            mIsUsingSoundTouch = true;
            Log.d(TAG, "SoundTouchPlayer initialized successfully");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize SoundTouchPlayer", e);
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
        }
    }
    
    /**
     * Handles SoundTouchPlayer state changes and manages WakeLock and AudioFocus accordingly.
     *
     * @param newState The new state from SoundTouchPlayer
     * @param oldState The previous state
     */
    private void handleSoundTouchStateChange(SoundTouchPlayer.State newState, SoundTouchPlayer.State oldState) {
        switch (newState) {
            case STARTED:
                synchronized (mPlayerLock) {
                    mIsPlaying = true;
                }
                // Acquire wake lock with 1 hour timeout as safety net
                if (mWakeLock != null && !mWakeLock.isHeld()) {
                    mWakeLock.acquire(3600000);
                    Log.d(TAG, "WakeLock acquired for SoundTouch playback (1 hour timeout)");
                }
                // Request audio focus for SoundTouch playback
                requestAudioFocus();
                updateNotificationPlaybackState(true);
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                break;
                
            case PAUSED:
                synchronized (mPlayerLock) {
                    mIsPlaying = false;
                }
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on SoundTouch pause");
                }
                // Abandon audio focus on pause
                abandonAudioFocus();
                updateNotificationPlaybackState(false);
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                break;
                
            case COMPLETED:
                updateNotificationPlaybackState(false);
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on SoundTouch completion");
                }
                // Abandon audio focus on completion
                abandonAudioFocus();
                break;
                
            case ERROR:
            case RELEASED:
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on SoundTouch error/release");
                }
                // Abandon audio focus on error/release
                abandonAudioFocus();
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                    mNotificationService.setPlayingState(false);
                }
                break;
                
            default:
                break;
        }
    }
    
    /**
     * Sends a broadcast to MusicPlayer to show which player is active.
     *
     * @param isSoundTouchActive True if SoundTouch is active
     */
    private void sendPlayerStatusBroadcast(boolean isSoundTouchActive) {
        Intent intent = new Intent(ACTION_PLAYER_STATUS_UPDATE);
        intent.putExtra("player_type", isSoundTouchActive ? "SoundTouch" : "MediaPlayer");
        sendBroadcast(intent);
    }
    
    /**
     * Falls back to MediaPlayer when SoundTouch fails.
     * Preserves current playback position and song index.
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingSoundTouch) {
            return;
        }
        
        Log.w(TAG, "FALLBACK: Switching from SoundTouchPlayer to MediaPlayer");
        mIsUsingSoundTouch = false;
        mSoundTouchFailed = true;
        
        sendPlayerStatusBroadcast(false);
        
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        boolean wasPlaying = mIsPlaying;
        
        if (mSoundTouchPlayer != null) {
            currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        if (currentIndex >= 0 && mCurrentPlaylist != null && 
            currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex + 
                  " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
            
            if (!wasPlaying && mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                mIsPlaying = false;
            }
        }
    }
    
    /**
     * Pre-initializes the current song without starting playback.
     * Provides immediate song duration and audio session for equalizer.
     */
    private void preInitializeCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "preInitializeCurrentSong: No playlist, skipping");
            return;
        }
        
        int index = mCurrentIndex >= 0 ? mCurrentIndex : 0;
        if (index >= mCurrentPlaylist.size()) {
            index = 0;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.d(TAG, "preInitializeCurrentSong: Invalid song at index " + index);
            return;
        }
        
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            mShouldStartAfterPrepare = false;
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(song.getPath());
            mSoundTouchPlayer.prepareAsync();
            Log.d(TAG, "preInitializeCurrentSong: Started pre-load for: " + song.getTitle());
        }
    }
    
    /**
     * Called when the service is started via startService().
     * Handles playback commands from MusicPlayer and other components.
     *
     * @param intent The intent that started the service
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * Releases all resources and saves playback state.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        invalidateAllPreparations();
        saveFullState();
        savePlayerState();
        stopHealthMonitoring();
        
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        releaseMediaPlayer();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        abandonAudioFocus();
        
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
    }
    
    /**
     * Called when the system is running low on memory.
     *
     * @param level The memory trim level
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        if (mIsUsingSoundTouch) return;
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // =========================================================================
    // Public API Methods for MusicPlayer
    // =========================================================================
    
    /**
     * Returns true if any player (SoundTouch or MediaPlayer) is actively playing.
     *
     * @return True if audio is currently playing
     */
    public boolean isAnyPlayerPlaying() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPlaying();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                return mMediaPlayer.isPlaying();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * Returns true if any player is prepared and ready for playback.
     *
     * @return True if a player has a loaded song ready to play
     */
    public boolean isAnyPlayerPrepared() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPrepared();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            return true;
        }
        return false;
    }
    
    /**
     * Returns true if the primary SoundTouch player is active.
     *
     * @return True if using SoundTouch
     */
    public boolean isUsingSoundTouch() {
        return mIsUsingSoundTouch;
    }
    
    // =========================================================================
    // Sort Mode Methods
    // =========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     *
     * @param sortMode The sort mode constant
     * @return A Comparator for sorting songs
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator();
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        return new File(song.getPath()).lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        if (currentSongPath != null) {
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    saveCurrentPlayingIndex();
                    break;
                }
            }
        }
    }
    
    // =========================================================================
    // Broadcast Receiver Registration
    // =========================================================================
    
    /**
     * Registers the notification receiver for sync updates.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver for pitch/tempo updates.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }
    
    /**
     * Registers the clear playlist receiver.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }
    
    /**
     * Registers the theme color change receiver.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }
    
    /**
     * Registers the receiver for getting playing state.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }
    
    /**
     * Registers the sort mode update receiver from PlaylistActivity.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }
    
    /**
     * Safely unregisters a broadcast receiver.
     *
     * @param receiver The receiver to unregister
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // =========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // =========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer.
     *
     * @param player The MediaPlayer to clean
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }
    
    /**
     * Safely resets the MediaPlayer.
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
                try { mMediaPlayer.release(); } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance.
     *
     * @return The MediaPlayer instance
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparingFallback.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            releaseMediaPlayer();
                            new Handler(Looper.getMainLooper()).postDelayed(() -> 
                                prepareAndPlay(recoverIndex, recoverPosition), 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     *
     * @return True if the player is ready
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try { 
                mMediaPlayer.getDuration(); 
                return true; 
            } catch (Exception e) { 
                return false; 
            }
        }
    }
    
    // =========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // =========================================================================
    
    /**
     * Starts the playback health monitoring.
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) mHealthHandler = new Handler(Looper.getMainLooper());
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
    }
    
    /**
     * Stops the playback health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingSoundTouch) return;
        
        try {
            int currentPosition = getCurrentPosition();
            
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall.
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try { if (mIsPlaying) mMediaPlayer.pause(); } catch (Exception ignored) {}
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (currentIndex >= 0 && mCurrentPlaylist != null && 
                currentIndex < mCurrentPlaylist.size()) {
                prepareAndPlay(currentIndex, currentPosition);
                sendBroadcast(new Intent("PLAYBACK_RECOVERED"));
            }
        }, 500);
    }
    
    // =========================================================================
    // Async Operation Management
    // =========================================================================
    
    /**
     * Invalidates all pending preparations.
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock.
     *
     * @return True if the lock was acquired
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // =========================================================================
    // Notification Methods
    // =========================================================================
    
    /**
     * Forces an immediate update of the notification playback state.
     * 
     * <p>This method ensures the notification's play/pause button icon matches
     * the actual playback state without delay. It is called on every state
     * change (STARTED, PAUSED, COMPLETED) and after song transitions.</p>
     *
     * @param isPlaying True if currently playing, false if paused
     */
    private void updateNotificationPlaybackState(boolean isPlaying) {
        if (mNotificationService != null) {
            mNotificationService.setPlayingState(isPlaying);
            mNotificationService.forceUpdate();
            Log.d(TAG, "Notification playback state updated: " + (isPlaying ? "PLAYING" : "PAUSED"));
        }
    }
    
    /**
     * Creates and updates the playback notification.
     * 
     * <p>This method updates the notification with current song information.
     * If no song is playing, it clears the notification content.</p>
     * 
     * <p>The notification is forced to update immediately using forceUpdate()
     * to ensure UI responsiveness.</p>
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
                mNotificationService.setPlayingState(mIsPlaying);
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
        }
        mNotificationService.forceUpdate();
    }
    
    /**
     * Refreshes the notification.
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     *
     * @param art The album art bitmap
     * @param placeholder The placeholder bitmap
     * @param artPath The file path of the album art
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // =========================================================================
    // State Persistence Methods
    // =========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state.
     */
    private void saveFullState() {
        savePlayerState();
    }
    
    /**
     * Gets the saved playback position.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before restart.
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path.
     *
     * @return The saved song path, or null
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
    }
    
    // =========================================================================
    // Playlist Management Methods
    // =========================================================================
    
    /**
     * Sets the current playlist.
     *
     * @param playlist The new playlist
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
                    currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
                    wasPlaying = mSoundTouchPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
            }
            
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                if (mNotificationService != null) {
                    mNotificationService.updateSongInfo(null, null, null);
                    mNotificationService.setPlayingState(false);
                }
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            
            // Always apply sort mode to new playlist to respect playlist order
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            boolean playlistUnchanged = false;
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                playlistUnchanged = true;
                for (int i = 0; i < playlist.size() && playlistUnchanged; i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        playlistUnchanged = false;
                    }
                }
            }
            
            if (playlistUnchanged && preserveCurrentSong) {
                // Same playlist content, just update sort if needed
                if (!sortedPlaylist.equals(mCurrentPlaylist)) {
                    String currentPath = (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) 
                        ? mCurrentPlaylist.get(mCurrentIndex).getPath() : null;
                    mCurrentPlaylist = sortedPlaylist;
                    if (currentPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(currentPath)) {
                                mCurrentIndex = i;
                                break;
                            }
                        }
                    }
                }
                broadcastUpdate();
                return;
            }
            
            if (!preserveCurrentSong) {
                invalidateAllPreparations();
                if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
                resetPlayerSafely();
                mIsPlaying = false;
            }
            
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                } else {
                    mCurrentIndex = 0;
                }
            } else {
                mCurrentIndex = -1;
            }
            
            saveCurrentPlayingIndex();
            
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            // Add flag to prevent double playback during restore
            mIsRestoringPlayback = true;
            
            // Safety timeout for restore flag
            mMainHandler.postDelayed(() -> {
                if (mIsRestoringPlayback) {
                    mIsRestoringPlayback = false;
                    Log.w(TAG, "Restoration timeout - flag reset");
                }
            }, 3000);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (isFolderUpdate) {
                    int correctIndex = mCurrentIndex;
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                            if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                correctIndex = i;
                                break;
                            }
                        }
                    }
                    // Use SoundTouch for restoration when available
                    if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
                        playSongWithSoundTouch(correctIndex);
                        if (savedPosition > 0) {
                            mSoundTouchPlayer.seekTo(savedPosition);
                        }
                    } else {
                        prepareAndPlay(correctIndex, savedPosition);
                    }
                    clearPlayerStateBeforeUpdate(this);
                } else {
                    // Use SoundTouch for restoration when available
                    if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
                        playSongWithSoundTouch(mCurrentIndex);
                        if (savedPosition > 0) {
                            mSoundTouchPlayer.seekTo(savedPosition);
                        }
                    } else {
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                }
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            }
            
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                mMainHandler.postDelayed(this::preInitializeCurrentSong, PRE_INIT_DELAY_MS);
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparingFallback.set(false);
            mIsPreparingSoundTouch.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
            
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist for next transition.
     *
     * @param newPlaylist The new playlist to apply on next transition
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
    }
    
    // =========================================================================
    // Playback Control Methods
    // =========================================================================
    
    /**
     * Plays a song at the specified index.
     *
     * @param index The song index in the current playlist
     */
    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            playSongWithSoundTouch(index);
        } else {
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Plays a song using SoundTouchPlayer with MediaPlayer-like API.
     *
     * @param index Index of song to play
     */
    private void playSongWithSoundTouch(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            fallbackToMediaPlayer();
            return;
        }
        
        try {
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            
            mPrepareTimeoutRunnable = () -> {
                mIsPreparingSoundTouch.set(false);
                fallbackToMediaPlayer();
            };
            mPrepareTimeoutHandler.postDelayed(mPrepareTimeoutRunnable, PREPARE_TIMEOUT_MS);
            
            mIsPreparingSoundTouch.set(true);
            mCurrentIndex = index;
            mShouldStartAfterPrepare = true;
            
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(song.getPath());
            mSoundTouchPlayer.prepareAsync();
            
            createNotification();
            broadcastUpdate();
            savePlayerState();
            
        } catch (Exception e) {
            mIsPreparingSoundTouch.set(false);
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            fallbackToMediaPlayer();
        }
    }
    
    /**
     * Prepares and starts playback using MediaPlayer (FALLBACK).
     *
     * @param index The song index
     * @param seekPosition The position to seek to
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        if (mIsPreparingFallback.get()) return;
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) return;
                    if (mMediaPlayer != mp) return;
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        int duration = mp.getDuration();
                        if (duration <= 0) {
                            mIsPlaying = false;
                            broadcastUpdate();
                            return;
                        }
                        
                        if (finalSeek > 0 && finalSeek < duration - 500) {
                            mp.seekTo(finalSeek);
                        }
                        
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        
                        mCurrentIndex = finalIndex;
                        saveCurrentPlayingIndex();
                        
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                        mp.start();
                        mIsPlaying = true;
                        mIsRestoringPlayback = false;
                        mPlaybackStartTime = System.currentTimeMillis();
                        startHealthMonitoring();
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        requestAudioFocus();
                        
                        if (mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                        }
                        
                        updateMediaSessionPlaybackState();
                        broadcastUpdate();
                        createNotification();
                        updatePlaybackParams();
                        
                        // Update MediaSession metadata for lock screen display
                        updateMediaSessionMetadata();
                        
                    } catch (IllegalStateException e) {
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            mIsPreparingFallback.set(false);
        }
    }
    
    /**
     * Prepares a song without starting playback, using MediaPlayer (FALLBACK).
     *
     * @param index The song index to prepare
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) return;
                    if (mMediaPlayer != mp) return;
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                    } catch (Exception e) {
                        Log.e(TAG, "Error in prepareOnly onPrepared", e);
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException | IllegalStateException e) {
            mIsPreparingFallback.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) return;
        
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            mShouldStartAfterPrepare = true;
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(mCurrentPlaylist.get(index).getPath());
            mSoundTouchPlayer.prepareAsync();
            if (position > 0) {
                mSoundTouchPlayer.seekTo(position);
            }
        } else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     *
     * @param filePath The file path of the song to play
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) return;
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
    }
    
    /**
     * Plays the next song in the playlist.
     * 
     * <p>This method handles the transition to the next song, respecting
     * shuffle mode if enabled. If a pending playlist exists, it is applied
     * before playing the next song.</p>
     */
    public synchronized void playNext() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "playNext: Ignoring - restore in progress");
            return;
        }
        
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparingSoundTouch.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "playNext: playlist is empty");
                return;
            }
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * 
     * <p>This method handles the transition to the previous song, respecting
     * shuffle history if shuffle mode is enabled. If a pending playlist exists,
     * it is applied before playing the previous song.</p>
     */
    public synchronized void playPrevious() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "playPrevious: Ignoring - restore in progress");
            return;
        }
        
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparingSoundTouch.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            updateNotificationPlaybackState(true);
            
            mMainHandler.post(() -> {
                broadcastUpdate();
                createNotification();
            });
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause states.
     */
    public void togglePlayPause() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "togglePlayPause: Ignoring - restore in progress");
            return;
        }
        
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            if (mSoundTouchPlayer.isPlaying()) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
            if (mIsPlaying) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            Song firstSong = mCurrentPlaylist.get(0);
            if (firstSong != null && firstSong.getPath() != null) {
                playSongByPath(firstSong.getPath());
            } else {
                playSong(0);
            }
        }
    }
    
    /**
     * Pauses playback.
     */
    public void pause() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPlaying()) {
            mSoundTouchPlayer.pause();
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } else {
            stopHealthMonitoring();
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.pause();
                    } catch (IllegalStateException e) {}
                    mIsPlaying = false;
                    
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                    }
                    
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            }
        }
    }
    
    /**
     * Resumes playback from a paused state.
     */
    public void resume() {
        if (mIsRestoringPlayback) {
            Log.d(TAG, "resume: Ignoring - restore in progress");
            return;
        }
        
        if (mSoundTouchPlayer != null && !mSoundTouchPlayer.isPlaying() && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.start();
            mIsPlaying = true;
            
            if (mWakeLock != null && !mWakeLock.isHeld()) {
                mWakeLock.acquire(3600000);
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                    try {
                        if (!mIsPlaying) {
                            requestAudioFocus();
                            updatePlaybackParams();
                            mMediaPlayer.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                            }
                            
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();
                        }
                    } catch (IllegalStateException e) {
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                    playSong(0);
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     */
    public void stop() {
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
            mIsPlaying = false;
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {}
                    mIsPlaying = false;
                }
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.seekTo(position);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        int duration = mMediaPlayer.getDuration();
                        if (position >= 0 && position < duration) {
                            mMediaPlayer.seekTo(position);
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            savePlayerState();
                            saveFullState();
                        }
                    } catch (IllegalStateException e) {}
                }
            }
        }
    }
    
    // =========================================================================
    // Playback Parameter Methods
    // =========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from EqualizerManager.
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.setPitch(semitones);
            mSoundTouchPlayer.setTempo(tempo);
            return;
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
            } catch (Exception e) {}
        }
    }
    
    // =========================================================================
    // Completion Handler
    // =========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>This method is called when the current song finishes playing.
     * It determines the next action based on repeat mode, shuffle mode,
     * and playlist size. If repeat one is enabled, the song replays from
     * the beginning. If repeat all is enabled, it advances to the next song.
     * If at the end of the playlist, playback stops.</p>
     */
    private void handleCompletion() {
        broadcastSongCompletion();
        
        if (mCurrentPlaylist == null) {
            mIsPlaying = false;
            updateNotificationPlaybackState(false);
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
            }
            return;
        }
        
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        
        if (mRepeatMode == 2) {
            if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
                mSoundTouchPlayer.seekTo(0);
                mSoundTouchPlayer.start();
            } else if (mMediaPlayer != null) {
                mMediaPlayer.seekTo(0);
                mMediaPlayer.start();
            }
        } else if (mRepeatMode == 1) {
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            playNext();
        } else {
            mIsPlaying = false;
            updateNotificationPlaybackState(false);
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
            }
            
            if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
                mSoundTouchPlayer.stop();
            } else if (mMediaPlayer != null) {
                mMediaPlayer.seekTo(getDuration());
                mMediaPlayer.pause();
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, getDuration())
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            
            broadcastSongCompletion();
            updateMediaSessionPlaybackState();
        
            if (mNotificationService != null) {
                mNotificationService.updateSongInfo(null, null, null);
                mNotificationService.setPlayingState(false);
                mNotificationService.forceUpdate();
            }
        }
    }
    
    /**
     * Broadcasts song completion with full duration for UI seekbar fill.
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
    }
    
    // =========================================================================
    // Getter Methods
    // =========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position
     */
    public int getCurrentPosition() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getCurrentPosition();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     *
     * @return Duration
     */
    public int getDuration() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getDuration();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     *
     * @return True if playing
     */
    public boolean isPlaying() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPlaying();
        }
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
    }
    
    // =========================================================================
    // Media Session Methods
    // =========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                });
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
            } catch (Exception e) {}
        }
    }
    
    /**
     * Updates MediaSession metadata (song title, artist, album) for lock screen display.
     * 
     * <p>This method sets the current song information on the MediaSession so that
     * the system can display it on the lock screen, in notifications, and on
     * connected devices like Android Auto or Wear OS. Without this, the lock screen
     * would show "LlamaMusicService" instead of the actual song title.</p>
     * 
     * <p>Call this method whenever the current song changes, including:</p>
     * <ul>
     *   <li>When a new song starts playing (playSong, playNext, playPrevious)</li>
     *   <li>When metadata is edited (refreshMetadataForSong)</li>
     *   <li>When the player is prepared (onPrepared callback)</li>
     * </ul>
     */
    private void updateMediaSessionMetadata() {
        if (mMediaSession == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        
        Song currentSong = getCurrentSong();
        if (currentSong == null) {
            mMediaSession.setMetadata(null);
            return;
        }
        
        android.media.MediaMetadata.Builder builder = new android.media.MediaMetadata.Builder();
        builder.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, 
                          currentSong.getTitle() != null ? currentSong.getTitle() : "Unknown Title");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, 
                          currentSong.getArtist() != null ? currentSong.getArtist() : "Unknown Artist");
        builder.putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, 
                          currentSong.getAlbum() != null ? currentSong.getAlbum() : "Unknown Album");
        builder.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, currentSong.getDuration());
        
        mMediaSession.setMetadata(builder.build());
        Log.d(TAG, "MediaSession metadata updated: " + currentSong.getTitle());
    }
    
    /**
     * Sets up audio focus for proper audio ducking.
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     *
     * @param songPath The path of the song
     * @param newTitle The new title
     * @param newArtist The new artist
     * @param newAlbum The new album
     * @param newGenre The new genre
     * @param albumArtBytes The new album art bytes
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) return;
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) return;
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) return;
            if (!songPath.equals(current.getPath())) return;
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            SongDatabase.getInstance(this).insertSong(updated);
            
            // Update MediaSession metadata to reflect edited song info
            updateMediaSessionMetadata();
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
        }
    }
    
    /**
     * Handles the close action from the notification.
     */
    private void handleCloseAction() {
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
        }
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus from the system.
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a playback state update to activities.
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
    }
    
    /**
     * Updates the MediaSession playback state.
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {}
        }
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     *
     * @param keyCode The key code of the pressed button
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                break;
        }
    }
    
    /**
     * Handles audio focus changes.
     *
     * @param focusChange The type of focus change
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (mIsPlaying) {
                    pause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // SoundTouch doesn't need special handling
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                // No action needed
                break;
            default:
                break;
        }
    }
}