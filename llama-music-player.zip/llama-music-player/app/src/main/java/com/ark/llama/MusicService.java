package com.ark.llama;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MusicService - Background service for music playback with SoundTouch integration.
 * 
 * <p>This service provides the core music playback functionality for the Llama
 * Music Player application. It runs in the background to allow continuous
 * playback even when the app is not in the foreground. The service follows
 * Android's standard service lifecycle and integrates with the system's
 * audio focus, media session, and notification systems.</p>
 * 
 * <h3>Audio Processing Architecture</h3>
 * <p>The service uses a primary/fallback architecture to ensure reliable playback:</p>
 * <ul>
 *   <li><b>Primary Path (SoundTouchPlayer)</b> - DEFAULT player for ALL playback.
 *       Provides independent pitch and tempo control with high quality.
 *       Follows MediaPlayer lifecycle pattern for consistency and predictability.</li>
 *   <li><b>Fallback Path (MediaPlayer)</b> - Used ONLY when SoundTouchPlayer
 *       fails at runtime (library missing, initialization error, or crash).
 *       This ensures playback never fails completely.</li>
 * </ul>
 * 
 * <h3>Playback State Machine</h3>
 * <p>The service maintains a playback state machine that coordinates with the
 * underlying SoundTouchPlayer and MediaPlayer instances:</p>
 * <pre>
 * ┌─────────────────────────────────────────────────────────────────────────────┐
 * │                                                                                                   PLAYBACK STATE MACHINE                                                                         │
 * ├─────────────────────────────────────────────────────────────────────────────┤
 * │                                                                                                                                                                                                                        │
 * │   setPlaylist() ──> Loading ──> preInitialize() ──> PREPARED                                                                                                              │
 * │        │                                                                       (duration, session)                                                                                                       │
 * │        │                                                                                    │                                                                                                                      │
 * │        │                                                                                    ▼                                                                                                                     │
 * │        │     ┌─────────────────────────────────────────────────────────┐                                   │
 * │        │     │                                                                       PLAYING                                                                           │                                  │
 * │        │     │                                       (mIsPlaying = true, SoundTouchPlayer.STARTED)                                         │                                   │
 * │        │     └───────────────────────┬─────────────────────────────────┘                                   │
 * │        │                                                                        │                                                                                                                                  │
 * │        │                                                                    pause()                                                                                                                            │
 * │        │                                                                        │                                                                                                                                  │
 * │        │                                                                        ▼                                                                                                                                 │
 * │        │     ┌─────────────────────────────────────────────────────────┐                                   │
 * │        │     │                                                              PAUSED                                                                                     │                                   │
 * │        │     │                                        (mIsPlaying = false, SoundTouchPlayer.PAUSED)                                         │                                   │
 * │        │     └───────────────────────┬─────────────────────────────────┘                                   │
 * │        │                                                                        │                                                                                                                                  │
 * │        │                                                                    start()                                                                                                                             │
 * │        │                                                                        │                                                                                                                                  │
 * │        │                                                                       ▼                                                                                                                                  │
 * │        │     ┌─────────────────────────────────────────────────────────┐                                   │
 * │        │     │                                                  COMPLETED / STOPPED                                                                       │                                   │
 * │        │     │                          (Song ended or stop() called, need reset to play again)                                          │                                   │
 * │        │     └─────────────────────────────────────────────────────────┘                                   │
 * │        │                                                                         │                                                                                                                                 │
 * │        └──────────────────────────┘                                                                                                                                 │
*  │                                                                                                                                                                                                                        │                                             
*  └─────────────────────────────────────────────────────────────────────────────┘                              
 * </pre>
 * 
 * <h3>MediaPlayer-like API for SoundTouchPlayer</h3>
 * <p>The SoundTouchPlayer now follows the same pattern as MediaPlayer:</p>
 * <pre>
 * reset() > setDataSource() > prepareAsync() > onPrepared() > start()
 * </pre>
 * <p>This provides several benefits:</p>
 * <ul>
 *   <li><b>Consistency:</b> Developers familiar with MediaPlayer can use the same pattern</li>
 *   <li><b>Reliability:</b> State machine prevents invalid operations</li>
 *   <li><b>Performance:</b> Single player instance reused for all songs</li>
 *   <li><b>Thread Safety:</b> Proper synchronization for all operations</li>
 * </ul>
 * 
 * <h3>Multiple Press Handling</h3>
 * <p>The service properly handles rapid button presses that could cause crashes
 * or state inconsistencies in naive implementations:</p>
 * <ul>
 *   <li><b>Rapid play/pause:</b> State checks prevent invalid transitions.
 *       If already playing, pause is ignored; if already paused, play is ignored.</li>
 *   <li><b>Rapid next/prev:</b> Atomic transition lock prevents concurrent song changes.
 *       Only one transition executes at a time; others are queued or dropped.</li>
 *   <li><b>Seek during playback:</b> Seek requests are queued and processed safely
 *       by the playback thread. Multiple seeks only execute the last position.</li>
 *   <li><b>Prepare while playing:</b> Previous playback is stopped cleanly via reset()
 *       before preparing the next song.</li>
 *   <li><b>Preparation timeout:</b> 5-second timeout prevents infinite waiting
 *       if SoundTouchPlayer gets stuck during preparation.</li>
 * </ul>
 * 
 * <h3>Pre-initialization Feature</h3>
 * <p>When a playlist is set, the service automatically pre-initializes the first
 * song using {@link SoundTouchPlayer#preLoad(String)}. This provides:</p>
 * <ul>
 *   <li><b>Immediate song duration:</b> UI can display total time without pressing play</li>
 *   <li><b>Early audio session creation:</b> Equalizer can attach before playback starts</li>
 *   <li><b>Faster response:</b> When user presses play, the song is already prepared</li>
 * </ul>
 * 
 * <h3>Playback State Persistence</h3>
 * <p>The service saves the following to SharedPreferences (Key: LlamaPrefs):</p>
 * <ul>
 *   <li><b>current_playing_index:</b> Index of the currently playing song in the playlist</li>
 *   <li><b>current_position:</b> Playback position in milliseconds</li>
 *   <li><b>last_playing:</b> Whether playback was active when app was closed</li>
 *   <li><b>repeat_mode:</b> Current repeat mode (0=off, 1=all, 2=one)</li>
 *   <li><b>shuffle:</b> Whether shuffle mode is enabled</li>
 *   <li><b>last_song_path:</b> File path of the last played song</li>
 *   <li><b>playlist_sort_mode:</b> Current sort mode for playlist display</li>
 *   <li><b>player_state_before_update:</b> Temporary flag for folder update preservation</li>
 * </ul>
 * 
 * <h3>Sort Modes</h3>
 * <p>The service supports 10 sort modes for playlist ordering.
 * All sorts use secondary sorting by Title (A-Z) when primary keys match:</p>
 * <table border="1">
 *   <tr><th>Mode</th><th>Constant</th><th>Description</th></tr>
 *   <tr><td>0</td><td>SORT_TITLE_AZ</td><td>Title A-Z (ascending alphabetical)</td></tr>
 *   <tr><td>1</td><td>SORT_TITLE_ZA</td><td>Title Z-A (descending alphabetical)</td></tr>
 *   <tr><td>2</td><td>SORT_ARTIST_AZ</td><td>Artist A-Z, then Title A-Z</td></tr>
 *   <tr><td>3</td><td>SORT_ARTIST_ZA</td><td>Artist Z-A, then Title A-Z</td></tr>
 *   <tr><td>4</td><td>SORT_ALBUM_AZ</td><td>Album A-Z, then Title A-Z</td></tr>
 *   <tr><td>5</td><td>SORT_ALBUM_ZA</td><td>Album Z-A, then Title A-Z</td></tr>
 *   <tr><td>6</td><td>SORT_GENRE_AZ</td><td>Genre A-Z, then Title A-Z</td></tr>
 *   <tr><td>7</td><td>SORT_GENRE_ZA</td><td>Genre Z-A, then Title A-Z</td></tr>
 *   <tr><td>8</td><td>SORT_OLDEST</td><td>Oldest First (by file modification date)</td></tr>
 *   <tr><td>9</td><td>SORT_NEWEST</td><td>Newest First (by file modification date)</td></tr>
 * </table>
 * 
 * <h3>Broadcast Communications</h3>
 * <p>The service communicates with activities via local broadcasts:</p>
 * <ul>
 *   <li><b>UPDATE_PLAYER:</b> Sent when playback state changes (play/pause, next/prev, completion)</li>
 *   <li><b>AUDIO_SESSION_CHANGED:</b> Sent when audio session ID changes (for equalizer attachment)</li>
 *   <li><b>PLAYER_STATUS_UPDATE:</b> Sent to show which player is active (SoundTouch vs MediaPlayer)</li>
 *   <li><b>PLAYBACK_RECOVERED:</b> Sent when playback recovers from a stall</li>
 * </ul>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * // Start the service
 * Intent intent = new Intent(context, MusicService.class);
 * intent.setAction("PLAY_SONG");
 * intent.putExtra("song_path", "/sdcard/Music/song.mp3");
 * startService(intent);
 * 
 * // Bind to the service (for activity communication)
 * bindService(intent, connection, BIND_AUTO_CREATE);
 * 
 * // Control playback via bound service
 * musicService.playSong(5);
 * musicService.pause();
 * musicService.resume();
 * musicService.playNext();
 * musicService.seekTo(30000);
 * musicService.setRepeatMode(1);  // repeat all
 * musicService.setShuffle(true);
 * 
 * // Unbind when done
 * unbindService(connection);
 * </pre>
 * 
 * <h3>Resource Management</h3>
 * <p>The service properly manages system resources:</p>
 * <ul>
 *   <li><b>WakeLock:</b> Acquired during playback to prevent device sleep,
 *       released when paused or stopped</li>
 *   <li><b>Audio Focus:</b> Requested when starting playback, abandoned when paused/stopped</li>
 *   <li><b>MediaSession:</b> Provides lock screen controls and headset button support</li>
 *   <li><b>Notification:</b> Foreground service notification for user visibility</li>
 * </ul>
 * 
 * @see SoundTouchPlayer
 * @see MediaPlayer
 * @see EqualizerManager
 * @see NotificationService
 * @see android.media.MediaPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class MusicService extends Service {

    // =========================================================================
    // Constants
    // =========================================================================
    
    /** 
     * Log tag for debugging and error tracking. 
     * Used with {@link Log#d(String, String)} and related methods.
     */
    private static final String TAG = "MusicService";
    
    /** 
     * Shared preferences file name for persistent storage.
     * Located at: /data/data/com.ark.llama/shared_prefs/LlamaPrefs.xml
     */
    private static final String PREFS_NAME = "LlamaPrefs";
    
    /** Key for storing the current playing index in SharedPreferences. */
    private static final String KEY_CURRENT_INDEX = "current_playing_index";
    
    /** Key for storing the last playing state (true = playing, false = paused/stopped). */
    private static final String KEY_LAST_PLAYING = "last_playing";
    
    /** Key for storing the current playback position in milliseconds. */
    private static final String KEY_CURRENT_POSITION = "current_position";
    
    /** Key for storing the repeat mode (0=off, 1=all, 2=one). */
    private static final String KEY_REPEAT_MODE = "repeat_mode";
    
    /** Key for storing the shuffle state (true = enabled, false = disabled). */
    private static final String KEY_SHUFFLE = "shuffle";
    
    /** Key for storing player state before folder update (temporary flag). */
    private static final String KEY_PLAYER_STATE_BEFORE_UPDATE = "player_state_before_update";
    
    /** Key for storing the last played song path (absolute file path). */
    private static final String KEY_LAST_SONG_PATH = "last_song_path";
    
    /** Key for storing the sort mode for playlist display. */
    private static final String KEY_SORT_MODE = "playlist_sort_mode";
    
    /** Broadcast action for updating sort mode from PlaylistActivity to MusicService. */
    private static final String ACTION_UPDATE_SORT_MODE = "UPDATE_SORT_MODE";
    
    /** Key for sort mode in intent extras for ACTION_UPDATE_SORT_MODE broadcasts. */
    private static final String EXTRA_SORT_MODE = "sort_mode";
    
    /** 
     * Delay for song transitions in milliseconds. 
     * Prevents rapid successive transitions from causing race conditions.
     */
    private static final int SONG_TRANSITION_DELAY_MS = 500;
    
    /** Intent action for audio session changed broadcast (for equalizer attachment). */
    private static final String ACTION_AUDIO_SESSION_CHANGED = "com.ark.llama.AUDIO_SESSION_CHANGED";
    
    /** Health check interval in milliseconds (MediaPlayer fallback only). */
    private static final int HEALTH_CHECK_INTERVAL_MS = 3000;
    
    /** Maximum time in milliseconds without progress before recovery (MediaPlayer fallback only). */
    private static final int MAX_STALL_TIME_MS = 5000;
    
    /** Maximum recovery attempts before skipping song (MediaPlayer fallback only). */
    private static final int MAX_RECOVERY_ATTEMPTS = 3;
    
    /** Broadcast action for player status update (diagnostic toast showing which player is active). */
    private static final String ACTION_PLAYER_STATUS_UPDATE = "PLAYER_STATUS_UPDATE";
    
    /** Delay before pre-initializing the first song (milliseconds). */
    private static final int PRE_INIT_DELAY_MS = 100;
    
    /** Delay for seek reset flag in milliseconds. */
    private static final int SEEK_RESET_DELAY_MS = 300;
    
    /** 
     * Timeout for waiting on SoundTouch preparation (milliseconds).
     * If preparation takes longer than this, fall back to MediaPlayer.
     */
    private static final int PREPARE_TIMEOUT_MS = 5000;
    
    // =========================================================================
    // Sort Mode Constants
    // =========================================================================
    
    /** Sort mode: Title A-Z (ascending alphabetical by title). This is the default. */
    private static final int SORT_TITLE_AZ = 0;
    
    /** Sort mode: Title Z-A (descending alphabetical by title). */
    private static final int SORT_TITLE_ZA = 1;
    
    /** Sort mode: Artist A-Z (ascending alphabetical by artist name), then by title. */
    private static final int SORT_ARTIST_AZ = 2;
    
    /** Sort mode: Artist Z-A (descending alphabetical by artist name), then by title. */
    private static final int SORT_ARTIST_ZA = 3;
    
    /** Sort mode: Album A-Z (ascending alphabetical by album name), then by title. */
    private static final int SORT_ALBUM_AZ = 4;
    
    /** Sort mode: Album Z-A (descending alphabetical by album name), then by title. */
    private static final int SORT_ALBUM_ZA = 5;
    
    /** Sort mode: Genre A-Z (ascending alphabetical by genre), then by title. */
    private static final int SORT_GENRE_AZ = 6;
    
    /** Sort mode: Genre Z-A (descending alphabetical by genre), then by title. */
    private static final int SORT_GENRE_ZA = 7;
    
    /** Sort mode: Oldest First (by file last modified timestamp), then by title. */
    private static final int SORT_OLDEST = 8;
    
    /** Sort mode: Newest First (by file last modified timestamp), then by title. */
    private static final int SORT_NEWEST = 9;
    
    // =========================================================================
    // Static Members
    // =========================================================================
    
    /** 
     * Current audio session ID for equalizer attachment.
     * This is set by the active player (SoundTouchPlayer or MediaPlayer) and
     * broadcast to EqualizerActivity via AUDIO_SESSION_CHANGED intent.
     */
    private static int sCurrentAudioSessionId = 0;
    
    // =========================================================================
    // SoundTouch Player Members (PRIMARY PLAYER)
    // =========================================================================
    
    /** 
     * SoundTouch-based audio player - DEFAULT for ALL playback.
     * Created in onCreate(), reused for all songs via reset() > setDataSource() > prepareAsync().
     * Follows MediaPlayer lifecycle pattern for consistency.
     */
    private SoundTouchPlayer mSoundTouchPlayer;
    
    /** 
     * Flag indicating if SoundTouch is currently active.
     * True when SoundTouchPlayer is the active player.
     * False when fallen back to MediaPlayer.
     */
    private boolean mIsUsingSoundTouch = false;
    
    /** 
     * Flag indicating if SoundTouch failed (prevents retry loop).
     * Once true, the service will use MediaPlayer for the remainder of the session.
     */
    private boolean mSoundTouchFailed = false;
    
    /** 
     * Flag indicating if SoundTouch is currently preparing (async operation in progress).
     * Used to prevent multiple simultaneous preparation attempts.
     */
    private final AtomicBoolean mIsPreparingSoundTouch = new AtomicBoolean(false);
    
    /** 
     * Handler for preparation timeout.
     * Used to detect when SoundTouchPlayer gets stuck during preparation.
     */
    private final Handler mPrepareTimeoutHandler = new Handler(Looper.getMainLooper());
    
    /** 
     * Timeout runnable for SoundTouch preparation.
     * Posts to mPrepareTimeoutHandler; if preparation takes too long, falls back to MediaPlayer.
     */
    private Runnable mPrepareTimeoutRunnable = null;
    
    /** 
     * Flag indicating if playback should start immediately after prepare.
     * Set to true when playSong() is called; set to false for pre-initialization only.
     */
    private boolean mShouldStartAfterPrepare = false;
    
    // =========================================================================
    // MediaPlayer Members (FALLBACK ONLY)
    // =========================================================================
    
    /** 
     * Legacy MediaPlayer instance - used ONLY when SoundTouch fails.
     * This is the fallback path; the service defaults to SoundTouchPlayer.
     */
    private MediaPlayer mMediaPlayer;
    
    // =========================================================================
    // Playback State
    // =========================================================================
    
    /** Current playlist of songs. Updated when user adds/removes folders. */
    private ArrayList<Song> mCurrentPlaylist;
    
    /** Index of the currently playing song in mCurrentPlaylist. -1 if no song playing. */
    private volatile int mCurrentIndex = -1;
    
    /** Flag indicating if playback is currently active (playing, not paused). */
    private volatile boolean mIsPlaying = false;
    
    /** 
     * Repeat mode: 0 = off (stop at end of playlist), 
     *              1 = repeat all (loop entire playlist), 
     *              2 = repeat one (repeat current song indefinitely).
     */
    private volatile int mRepeatMode = 0;
    
    /** Flag indicating if shuffle mode is enabled (random order playback). */
    private volatile boolean mIsShuffle = false;
    
    /** 
     * Timestamp when current playback started (for health checks - MediaPlayer only).
     * Used to detect playback stalls by measuring elapsed time without position progress.
     */
    private long mPlaybackStartTime = 0;
    
    // =========================================================================
    // Sort Mode State
    // =========================================================================
    
    /** Current sort mode for playlist display. Persisted to SharedPreferences. */
    private int mCurrentSortMode = SORT_TITLE_AZ;
    
    // =========================================================================
    // Health Check Components (MediaPlayer only)
    // =========================================================================
    
    /** Handler for periodic health checks (MediaPlayer fallback only). */
    private Handler mHealthHandler;
    
    /** Runnable for health check (MediaPlayer fallback only). */
    private Runnable mHealthCheckRunnable;
    
    /** Number of recovery attempts for current song (MediaPlayer fallback only). */
    private int mRecoveryAttempts = 0;
    
    // =========================================================================
    // Wake Lock for Background Playback
    // =========================================================================
    
    /** 
     * WakeLock to prevent device sleep during playback.
     * Acquired when playback starts, released when paused or stopped.
     * Uses PARTIAL_WAKE_LOCK flag to keep CPU running but allow screen to sleep.
     */
    private PowerManager.WakeLock mWakeLock;
    
    // =========================================================================
    // Audio Focus Management
    // =========================================================================
    
    /** Audio manager for focus management (request/abandon focus, ducking). */
    private AudioManager mAudioManager;
    
    /** Listener for audio focus changes (phone calls, other apps playing, etc.). */
    private AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
    
    /** 
     * Audio focus request for API 26+ (Android 8.0 Oreo and above).
     * Uses AudioFocusRequest.Builder for proper focus handling.
     */
    private AudioFocusRequest mAudioFocusRequest;
    
    // =========================================================================
    // Media Session
    // =========================================================================
    
    /** 
     * MediaSession for lock screen and headset controls.
     * Provides playback controls on lock screen, notification, and Bluetooth headsets.
     * Compatible with API 21+ (Android 5.0 Lollipop and above).
     */
    private MediaSession mMediaSession;
    
    // =========================================================================
    // Bluetooth State
    // =========================================================================
    
    /** Flag indicating if Bluetooth headset is connected. */
    private volatile boolean mIsBluetoothConnected = false;
    
    // =========================================================================
    // Thread Safety and Async Operations
    // =========================================================================
    
    /** Lock object for MediaPlayer operations (fallback only). */
    private final Object mPlayerLock = new Object();
    
    /** 
     * Flag indicating if a song transition is in progress.
     * Uses AtomicBoolean for thread-safe compare-and-set operations.
     */
    private final AtomicBoolean mIsTransitioning = new AtomicBoolean(false);
    
    /** 
     * Flag indicating if a song is being prepared (MediaPlayer fallback only).
     * Prevents multiple simultaneous preparation attempts.
     */
    private final AtomicBoolean mIsPreparingFallback = new AtomicBoolean(false);
    
    /** 
     * Global preparation ID counter for async operation cancellation.
     * Incremented each time a new preparation starts; stale callbacks check against current.
     */
    private final AtomicInteger mGlobalPrepId = new AtomicInteger(0);
    
    /** 
     * Current preparation ID (used to ignore stale callbacks).
     * When a stale OnPreparedListener callback arrives, it checks against this value.
     */
    private volatile int mCurrentPrepId = -1;
    
    /** Main thread handler for delayed operations (postDelayed tasks). */
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    
    // =========================================================================
    // Binder
    // =========================================================================
    
    /** 
     * Binder for activity binding.
     * Activities call bindService() and receive this binder to get a reference to MusicService.
     */
    private final IBinder mBinder = new LocalBinder();
    
    // =========================================================================
    // Playlist Management
    // =========================================================================
    
    /** 
     * History of shuffled indices for prev/next in shuffle mode.
     * Maintains the order of previously played songs to enable proper previous navigation.
     */
    private ArrayList<Integer> mShuffleHistory;
    
    /** Random number generator for shuffle mode. */
    private Random mRandom;
    
    /** Pending playlist for soft update (when updating playlist without stopping playback). */
    private ArrayList<Song> mPendingPlaylist = null;
    
    /** Flag indicating if a pending playlist exists. */
    private boolean mHasPendingPlaylist = false;
    
    // =========================================================================
    // Notification Service
    // =========================================================================
    
    /** Service for managing playback notifications (foreground notification with controls). */
    private NotificationService mNotificationService;
    
    // =========================================================================
    // Broadcast Receivers
    // =========================================================================
    
    /** Receiver for sync notification updates (SYNC_STARTED, SYNC_COMPLETE). */
    private BroadcastReceiver mUpdateNotificationReceiver;
    
    /** Receiver for playback parameter updates (pitch/tempo changes from EqualizerManager). */
    private BroadcastReceiver mPlaybackParamsReceiver;
    
    /** Receiver for clear playlist commands (when all folders removed). */
    private BroadcastReceiver mClearPlaylistReceiver;
    
    /** Receiver for theme color changes (updates notification appearance). */
    private BroadcastReceiver mThemeReceiver;
    
    /** Receiver for getting playing state (from MusicPlayer for persistence). */
    private BroadcastReceiver mGetPlayingStateReceiver;
    
    /** Receiver for sort mode updates (from PlaylistActivity). */
    private BroadcastReceiver mSortModeReceiver;
    
    // =========================================================================
    // Inner Classes
    // =========================================================================
    
    /**
     * Local binder for service binding.
     * 
     * <p>This class implements Android's standard Binder pattern for service binding.
     * Activities call {@link android.content.Context#bindService} with an Intent
     * targeting this service, and receive this binder in the
     * {@link android.content.ServiceConnection#onServiceConnected} callback.</p>
     * 
     * <h4>Usage Example:</h4>
     * <pre>
     * private ServiceConnection connection = new ServiceConnection() {
     *     @Override
     *     public void onServiceConnected(ComponentName name, IBinder service) {
     *         MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
     *         mMusicService = binder.getService();
     *         mIsBound = true;
     *     }
     *     
     *     @Override
     *     public void onServiceDisconnected(ComponentName name) {
     *         mMusicService = null;
     *         mIsBound = false;
     *     }
     * };
     * </pre>
     */
    public class LocalBinder extends Binder {
        
        /**
         * Returns the MusicService instance for the calling activity.
         * 
         * @return The MusicService instance (never null when called from onServiceConnected)
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }
    
    // =========================================================================
    // Sort Comparator Classes
    // =========================================================================
    
    /**
     * Comparator for sorting songs by title A-Z.
     * Null-safe: treats null titles as empty strings.
     */
    private class TitleAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleA.compareToIgnoreCase(titleB);
        }
    }
    
    /**
     * Comparator for sorting songs by title Z-A.
     * Null-safe: treats null titles as empty strings.
     */
    private class TitleZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String titleA = a.getTitle();
            String titleB = b.getTitle();
            if (titleA == null) titleA = "";
            if (titleB == null) titleB = "";
            return titleB.compareToIgnoreCase(titleA);
        }
    }
    
    /**
     * Comparator for sorting songs by artist A-Z, then by title A-Z.
     * Null-safe: treats null artists/titles as empty strings.
     */
    private class ArtistAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistA.compareToIgnoreCase(artistB);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by artist Z-A, then by title A-Z.
     * Null-safe: treats null artists/titles as empty strings.
     */
    private class ArtistZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String artistA = a.getArtist();
            String artistB = b.getArtist();
            if (artistA == null) artistA = "";
            if (artistB == null) artistB = "";
            int artistCompare = artistB.compareToIgnoreCase(artistA);
            if (artistCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return artistCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album A-Z, then by title A-Z.
     * Null-safe: treats null albums/titles as empty strings.
     */
    private class AlbumAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumA.compareToIgnoreCase(albumB);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by album Z-A, then by title A-Z.
     * Null-safe: treats null albums/titles as empty strings.
     */
    private class AlbumZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String albumA = a.getAlbum();
            String albumB = b.getAlbum();
            if (albumA == null) albumA = "";
            if (albumB == null) albumB = "";
            int albumCompare = albumB.compareToIgnoreCase(albumA);
            if (albumCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return albumCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre A-Z, then by title A-Z.
     * Null-safe: treats null genres/titles as empty strings.
     */
    private class GenreAZComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreA.compareToIgnoreCase(genreB);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by genre Z-A, then by title A-Z.
     * Null-safe: treats null genres/titles as empty strings.
     */
    private class GenreZAComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            String genreA = a.getGenre();
            String genreB = b.getGenre();
            if (genreA == null) genreA = "";
            if (genreB == null) genreB = "";
            int genreCompare = genreB.compareToIgnoreCase(genreA);
            if (genreCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return genreCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by oldest first (by file date), then by title.
     * Uses file.lastModified() timestamp for date comparison.
     */
    private class OldestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateA, dateB);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    /**
     * Comparator for sorting songs by newest first (by file date), then by title.
     * Uses file.lastModified() timestamp for date comparison.
     */
    private class NewestFirstComparator implements Comparator<Song> {
        @Override
        public int compare(Song a, Song b) {
            long dateA = getSongDate(a);
            long dateB = getSongDate(b);
            int dateCompare = Long.compare(dateB, dateA);
            if (dateCompare == 0) {
                String titleA = a.getTitle();
                String titleB = b.getTitle();
                if (titleA == null) titleA = "";
                if (titleB == null) titleB = "";
                return titleA.compareToIgnoreCase(titleB);
            }
            return dateCompare;
        }
    }
    
    // =========================================================================
    // Static Methods
    // =========================================================================
    
    /**
     * Sets the player state before update flag.
     * 
     * <p>This flag is used during folder updates to preserve playback state.
     * When set to true, the service will restore the playback position after
     * the playlist is rebuilt. This prevents the current song from restarting
     * from the beginning when the user adds or removes folders.</p>
     *
     * @param context Application context (used to access SharedPreferences)
     * @param need True if player state should be preserved during folder update
     */
    public static void setPlayerStateBeforeUpdate(@NonNull Context context, boolean need) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, need).apply();
    }
    
    /**
     * Gets the player state before update flag.
     *
     * @param context Application context (used to access SharedPreferences)
     * @return True if player state should be preserved during folder update
     */
    public static boolean getPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false);
    }
    
    /**
     * Clears the player state before update flag.
     * Called after the folder update completes to reset the flag.
     *
     * @param context Application context (used to access SharedPreferences)
     */
    public static void clearPlayerStateBeforeUpdate(@NonNull Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_PLAYER_STATE_BEFORE_UPDATE).apply();
    }
    
    /**
     * Returns the current audio session ID.
     * 
     * <p>This static method allows EqualizerActivity to get the audio session ID
     * without needing a reference to the service. The session ID is set by the
     * active player (SoundTouchPlayer or MediaPlayer) and broadcast to the activity.</p>
     *
     * @return The current audio session ID (0 if no session exists)
     */
    public static int getAudioSessionId() {
        return sCurrentAudioSessionId;
    }
    
    // =========================================================================
    // Service Lifecycle Methods
    // =========================================================================
    
    /**
     * Called when the service is created.
     * 
     * <p>This method initializes all service components including:
     * <ul>
     *   <li>Notification service for foreground playback notifications</li>
     *   <li>Audio manager for focus management</li>
     *   <li>Media session for lock screen controls</li>
     *   <li>Equalizer manager singleton</li>
     *   <li>Audio focus setup</li>
     *   <li>WakeLock for background playback</li>
     *   <li>SoundTouchPlayer as the default player</li>
     *   <li>Broadcast receivers for inter-component communication</li>
     * </ul>
     * </p>
     * 
     * <p>This method runs on the main thread and should complete quickly.
     * Heavy initialization is deferred or done on background threads.</p>
     */
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MusicService onCreate");
        
        // Initialize atomic flags
        mIsTransitioning.set(false);
        mIsPreparingFallback.set(false);
        
        // Initialize notification service for foreground playback notifications
        mNotificationService = new NotificationService(this);
        mNotificationService.updateSongInfo("Title", "Artist", null);
        mNotificationService.setPlayingState(false);
        
        // Initialize audio manager for focus management
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        
        // Load saved settings from SharedPreferences
        loadRepeatAndShuffle();
        loadSortMode();
        
        // Setup media session for lock screen controls (API 21+)
        setupMediaSession();
        
        // Initialize EqualizerManager singleton (creates if not exists)
        EqualizerManager.getInstance(this);
        
        // Initialize shuffle components
        mShuffleHistory = new ArrayList<Integer>();
        mRandom = new Random();
        
        // Setup audio focus for ducking/interruption handling
        setupAudioFocus();
        
        // Initialize health check handler (for MediaPlayer fallback only)
        mHealthHandler = new Handler(Looper.getMainLooper());
        
        // Initialize WakeLock to prevent device sleep during playback
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LlamaMusicPlayer::Playback");
            mWakeLock.setReferenceCounted(false);
            Log.d(TAG, "WakeLock initialized");
        }
        
        // Initialize SoundTouch player as the DEFAULT player
        initSoundTouchPlayer();
        
        // Register broadcast receivers for inter-component communication
        registerNotificationReceiver();
        registerPlaybackParamsReceiver();
        registerClearPlaylistReceiver();
        registerThemeReceiver();
        registerGetPlayingStateReceiver();
        registerSortModeReceiver();
        
        Log.d(TAG, "MusicService onCreate complete - SoundTouch is DEFAULT player");
    }
    
    /**
     * Initializes the SoundTouch player as the default player.
     * 
     * <p>This method creates the SoundTouchPlayer instance and sets up its
     * PlaybackListener to receive state change, preparation, completion, and
     * error callbacks. The SoundTouchPlayer follows the MediaPlayer lifecycle
     * pattern: reset() > setDataSource() > prepareAsync() > onPrepared() > start().</p>
     * 
     * <p>If SoundTouch library is not available or fails to initialize,
     * the service will automatically fall back to MediaPlayer for the
     * remainder of the session. This fallback is permanent for the session.</p>
     * 
     * <p>When initialization completes (or falls back), a broadcast is sent
     * to MusicPlayer to show a diagnostic toast indicating which player is active.
     * This helps with debugging and user awareness.</p>
     * 
     * <p><b>Preparation Timeout:</b> A 5-second timeout is set on preparation.
     * If SoundTouchPlayer gets stuck during prepareAsync(), the service falls
     * back to MediaPlayer to prevent infinite waiting.</p>
     */
    private void initSoundTouchPlayer() {
        if (mSoundTouchFailed) {
            Log.d(TAG, "SoundTouch already failed, skipping init");
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        if (!SoundTouch.isLibraryAvailable()) {
            Log.w(TAG, "SoundTouch library not available - falling back to MediaPlayer");
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
            return;
        }
        
        try {
            mSoundTouchPlayer = new SoundTouchPlayer(this);
            mSoundTouchPlayer.setListener(new SoundTouchPlayer.PlaybackListener() {
                @Override
                public void onStateChanged(SoundTouchPlayer.State newState, SoundTouchPlayer.State oldState) {
                    handleSoundTouchStateChange(newState, oldState);
                }
                
                @Override
                public void onPrepared() {
                    Log.d(TAG, "SoundTouchPlayer: onPrepared()");
                    mIsPreparingSoundTouch.set(false);
                    
                    // Cancel preparation timeout
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    
                    sendPlayerStatusBroadcast(true);
                    updatePlaybackParams();
                    
                    // Update audio session ID for equalizer attachment
                    sCurrentAudioSessionId = mSoundTouchPlayer.getAudioSessionId();
                    broadcastAudioSessionChanged(sCurrentAudioSessionId);
                    EqualizerManager.getInstance(MusicService.this)
                        .attachToAudioSession(sCurrentAudioSessionId);
                    
                    // Start playback if this was a user-initiated play (not just pre-initialization)
                    if (mShouldStartAfterPrepare) {
                        mShouldStartAfterPrepare = false;
                        mSoundTouchPlayer.start();
                    }
                    
                    broadcastUpdate();
                    createNotification();
                }
                
                @Override
                public void onCompletion() {
                    Log.d(TAG, "SoundTouchPlayer: onCompletion()");
                    handleCompletion();
                }
                
                @Override
                public void onPositionUpdate(long position) {
                    // Position updates handled by MusicPlayer's polling mechanism
                    // This callback is not needed for the service's core logic
                }
                
                @Override
                public void onError(@NonNull String error) {
                    Log.e(TAG, "SoundTouchPlayer error: " + error);
                    mIsPreparingSoundTouch.set(false);
                    if (mPrepareTimeoutRunnable != null) {
                        mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                        mPrepareTimeoutRunnable = null;
                    }
                    fallbackToMediaPlayer();
                }
            });
            
            mIsUsingSoundTouch = true;
            Log.d(TAG, "SoundTouchPlayer initialized successfully as DEFAULT player");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize SoundTouchPlayer", e);
            mSoundTouchFailed = true;
            mIsUsingSoundTouch = false;
            sendPlayerStatusBroadcast(false);
        }
    }
    
    /**
     * Handles SoundTouchPlayer state changes.
     * 
     * <p>This method maps SoundTouchPlayer states to MusicService state variables
     * and manages WakeLock, notification updates, and UI broadcasts.</p>
     * 
     * <p>Key state mappings:</p>
     * <ul>
     *   <li><b>STARTED</b> > mIsPlaying = true, acquire WakeLock</li>
     *   <li><b>PAUSED</b> > mIsPlaying = false, release WakeLock</li>
     *   <li><b>ERROR/RELEASED</b> > release WakeLock, clean up</li>
     * </ul>
     *
     * @param newState The new state from SoundTouchPlayer
     * @param oldState The previous state (for transition logging)
     */
    private void handleSoundTouchStateChange(SoundTouchPlayer.State newState, SoundTouchPlayer.State oldState) {
        switch (newState) {
            case STARTED:
                synchronized (mPlayerLock) {
                    mIsPlaying = true;
                }
                if (mWakeLock != null && !mWakeLock.isHeld()) {
                    mWakeLock.acquire();
                    Log.d(TAG, "WakeLock acquired");
                }
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
                break;
                
            case PAUSED:
                synchronized (mPlayerLock) {
                    mIsPlaying = false;
                }
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on pause");
                }
                broadcastUpdate();
                createNotification();
                updateMediaSessionPlaybackState();
                break;
                
            case COMPLETED:
                // Completion handled separately in onCompletion() callback
                // This state change is for information only
                break;
                
            case ERROR:
            case RELEASED:
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    Log.d(TAG, "WakeLock released on error/release");
                }
                break;
                
            default:
                // Other states (IDLE, INITIALIZED, PREPARING, PREPARED, STOPPED)
                // don't require additional handling
                break;
        }
    }
    
    /**
     * Sends a broadcast to MusicPlayer to show which player is active.
     * 
     * <p>This broadcast is used for diagnostic purposes to show a toast
     * indicating whether SoundTouchPlayer (primary) or MediaPlayer (fallback)
     * is currently active. This helps users verify that the SoundTouch
     * engine is working correctly.</p>
     *
     * @param isSoundTouchActive True if SoundTouch is active, false if using MediaPlayer fallback
     */
    private void sendPlayerStatusBroadcast(boolean isSoundTouchActive) {
        Intent intent = new Intent(ACTION_PLAYER_STATUS_UPDATE);
        intent.putExtra("player_type", isSoundTouchActive ? "SoundTouch" : "MediaPlayer");
        sendBroadcast(intent);
        Log.d(TAG, "Player status broadcast sent: " + (isSoundTouchActive ? "SoundTouch" : "MediaPlayer"));
    }
    
    /**
     * Falls back to MediaPlayer when SoundTouch fails.
     * 
     * <p>This method preserves the current playback position and song index
     * before switching to MediaPlayer. The fallback is permanent for the
     * remainder of the session (mSoundTouchFailed is set to true).</p>
     * 
     * <p>The fallback flow:</p>
     * <ol>
     *   <li>Save current index and position from SoundTouchPlayer</li>
     *   <li>Release SoundTouchPlayer resources</li>
     *   <li>Create and prepare MediaPlayer with the same song and position</li>
     *   <li>Start playback if SoundTouchPlayer was playing</li>
     * </ol>
     * 
     * <p>This ensures seamless playback continuation even when SoundTouch fails.</p>
     */
    private void fallbackToMediaPlayer() {
        if (!mIsUsingSoundTouch) {
            return; // Already using MediaPlayer
        }
        
        Log.w(TAG, "FALLBACK: Switching from SoundTouchPlayer to MediaPlayer");
        mIsUsingSoundTouch = false;
        mSoundTouchFailed = true;
        
        // Notify UI that fallback occurred (shows diagnostic toast)
        sendPlayerStatusBroadcast(false);
        
        int currentIndex = mCurrentIndex;
        int currentPosition = 0;
        boolean wasPlaying = mIsPlaying;
        
        if (mSoundTouchPlayer != null) {
            currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        if (currentIndex >= 0 && mCurrentPlaylist != null && 
            currentIndex < mCurrentPlaylist.size()) {
            Log.d(TAG, "Resuming playback at index " + currentIndex + 
                  " position " + currentPosition + " using MediaPlayer");
            prepareAndPlay(currentIndex, currentPosition);
            
            // Restore playing state if it was playing
            if (wasPlaying) {
                // prepareAndPlay starts playback automatically
            } else {
                // If it was paused, prepare but don't start
                // The MediaPlayer in prepareAndPlay will start, so we need to pause it
                if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                    mMediaPlayer.pause();
                    mIsPlaying = false;
                }
            }
        }
        
        Log.d(TAG, "Fallback to MediaPlayer complete");
    }
    
    // =========================================================================
    // Pre-initialization Methods
    // =========================================================================
    
    /**
     * Pre-initializes the current song without starting playback.
     * 
     * <p>This method provides two critical benefits:</p>
     * <ol>
     *   <li><b>Immediate song duration:</b> The UI can display total time
     *       without waiting for the user to press play.</li>
     *   <li><b>Early audio session creation:</b> The equalizer can attach
     *       to the audio session before playback starts.</li>
     * </ol>
     * 
     * <p>The method uses the MediaPlayer-like API: reset() > setDataSource() > prepareAsync()
     * The onPrepared callback will attach the equalizer but NOT start playback
     * (mShouldStartAfterPrepare is set to false).</p>
     * 
     * <p>This is called automatically after a playlist is set, ensuring the
     * first song is ready when the user navigates to the player.</p>
     */
    private void preInitializeCurrentSong() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
            Log.d(TAG, "preInitializeCurrentSong: No playlist, skipping");
            return;
        }
        
        int index = mCurrentIndex >= 0 ? mCurrentIndex : 0;
        if (index >= mCurrentPlaylist.size()) {
            index = 0;
        }
        
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.d(TAG, "preInitializeCurrentSong: Invalid song at index " + index);
            return;
        }
        
        // Use SoundTouch player for pre-initialization (DEFAULT)
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            // Set flag to NOT start playback after preparation
            mShouldStartAfterPrepare = false;
            
            // MediaPlayer-like flow: reset > setDataSource > prepareAsync
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(song.getPath());
            mSoundTouchPlayer.prepareAsync();
            
            Log.d(TAG, "preInitializeCurrentSong: Started pre-load for: " + song.getTitle());
        } else {
            Log.d(TAG, "preInitializeCurrentSong: SoundTouch not available, skipping pre-init");
        }
    }
    
    // =========================================================================
    // Service Lifecycle Methods (continued)
    // =========================================================================
    
    /**
     * Called when the service is started via startService().
     * 
     * <p>This method handles incoming commands from MusicPlayer and other components.
     * Supported actions:</p>
     * <ul>
     *   <li><b>ACTION_PLAY_PAUSE</b> - Toggle between play and pause states</li>
     *   <li><b>ACTION_NEXT</b> - Play the next song in the playlist</li>
     *   <li><b>ACTION_PREV</b> - Play the previous song in the playlist</li>
     *   <li><b>ACTION_CLOSE</b> - Close the app completely</li>
     *   <li><b>ACTION_STOP</b> - Stop playback and clear state</li>
     *   <li><b>ACTION_STOP_NOTIFICATION</b> - Remove the foreground notification</li>
     *   <li><b>PLAY_SONG</b> - Play a specific song (by path or position)</li>
     *   <li><b>UPDATE_PLAYBACK_PARAMS</b> - Update pitch and tempo settings</li>
     * </ul>
     *
     * @param intent The intent that started the service (may contain action and extras)
     * @param flags Additional data about the start request
     * @param startId A unique integer representing this start request
     * @return START_STICKY to ensure service restarts if killed by the system
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            if (action.equals("ACTION_PLAY_PAUSE")) {
                togglePlayPause();
            } else if (action.equals("ACTION_NEXT")) {
                playNext();
            } else if (action.equals("ACTION_PREV")) {
                playPrevious();
            } else if (action.equals("ACTION_CLOSE")) {
                handleCloseAction();
            } else if (action.equals("ACTION_STOP")) {
                stopCompletely();
            } else if (action.equals("ACTION_STOP_NOTIFICATION")) {
                if (mNotificationService != null) {
                    mNotificationService.stopForeground();
                }
            } else if (action.equals("PLAY_SONG")) {
                String songPath = intent.getStringExtra("song_path");
                if (songPath != null) {
                    playSongByPath(songPath);
                } else {
                    int position = intent.getIntExtra("position", -1);
                    if (position >= 0) {
                        playSong(position);
                    }
                }
            } else if (action.equals("UPDATE_PLAYBACK_PARAMS")) {
                updatePlaybackParams();
            }
        }
        return START_STICKY;
    }
    
    /**
     * Called when a client binds to the service.
     * 
     * <p>Activities bind to the service to obtain a reference for direct method calls.
     * The binding is typically done in onStart() and unbound in onStop().</p>
     *
     * @param intent The intent that was used to bind
     * @return The binder for service communication (LocalBinder instance)
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    
    /**
     * Called when the service is destroyed.
     * 
     * <p>This method releases all resources and saves playback state:
     * <ul>
     *   <li>Invalidates pending async preparations</li>
     *   <li>Saves full playback state to SharedPreferences</li>
     *   <li>Releases SoundTouchPlayer resources</li>
     *   <li>Releases MediaPlayer resources</li>
     *   <li>Stops foreground notification</li>
     *   <li>Releases MediaSession</li>
     *   <li>Abandons audio focus</li>
     *   <li>Unregisters broadcast receivers</li>
     * </ul>
     * </p>
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "MusicService onDestroy");
        
        // Cancel any pending async operations
        invalidateAllPreparations();
        
        // Save state before destruction
        saveFullState();
        savePlayerState();
        
        // Stop health monitoring (MediaPlayer fallback only)
        stopHealthMonitoring();
        
        // Release WakeLock if held
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
        }
        
        // Release SoundTouchPlayer resources
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.release();
            mSoundTouchPlayer = null;
        }
        
        // Release MediaPlayer resources
        releaseMediaPlayer();
        
        // Release notification service
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
            mNotificationService = null;
        }
        stopForeground(true);
        
        // Release MediaSession
        if (mMediaSession != null) {
            mMediaSession.setActive(false);
            mMediaSession.release();
            mMediaSession = null;
        }
        
        // Abandon audio focus
        abandonAudioFocus();
        
        // Clean up health handler
        if (mHealthHandler != null) {
            mHealthHandler.removeCallbacksAndMessages(null);
            mHealthHandler = null;
        }
        
        // Unregister broadcast receivers
        unregisterReceiverSafely(mUpdateNotificationReceiver);
        unregisterReceiverSafely(mPlaybackParamsReceiver);
        unregisterReceiverSafely(mClearPlaylistReceiver);
        unregisterReceiverSafely(mThemeReceiver);
        unregisterReceiverSafely(mGetPlayingStateReceiver);
        unregisterReceiverSafely(mSortModeReceiver);
        
        super.onDestroy();
        Log.d(TAG, "MusicService onDestroy complete");
    }
    
    /**
     * Called when the system is running low on memory.
     * 
     * <p>This method is only relevant for the MediaPlayer fallback path.
     * It checks if the MediaPlayer is in a bad state and attempts recovery
     * by re-preparing the current song.</p>
     *
     * @param level The memory trim level (e.g., TRIM_MEMORY_RUNNING_MODERATE)
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        
        // Only relevant for MediaPlayer fallback
        if (mIsUsingSoundTouch) return;
        
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) {
            synchronized (mPlayerLock) {
                if (mIsPlaying && mMediaPlayer != null) {
                    try {
                        if (!mMediaPlayer.isPlaying()) {
                            Log.w(TAG, "onTrimMemory: MediaPlayer not playing, recovering");
                            int currentPos = getCurrentPosition();
                            prepareAndPlay(mCurrentIndex, currentPos);
                        }
                    } catch (IllegalStateException e) {
                        Log.w(TAG, "onTrimMemory: MediaPlayer in invalid state, recovering");
                        int currentPos = getCurrentPosition();
                        prepareAndPlay(mCurrentIndex, currentPos);
                    }
                }
            }
        }
    }
    
    /**
     * Called when the task is removed from the recent apps list.
     * 
     * <p>This method saves the playback state so that when the user reopens
     * the app, playback resumes from where it left off.</p>
     *
     * @param rootIntent The intent that started the task
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        saveFullState();
        savePlayerState();
        super.onTaskRemoved(rootIntent);
    }
    
    // =========================================================================
    // Public API Methods for MusicPlayer
    // =========================================================================
    
    /**
     * Returns true if any player (SoundTouch or MediaPlayer) is actively playing.
     * 
     * <p>This method checks both the primary SoundTouchPlayer and the fallback
     * MediaPlayer to determine if audio is currently playing. Used by MusicPlayer
     * to determine the play/pause button state.</p>
     *
     * @return True if audio is currently playing from either player
     */
    public boolean isAnyPlayerPlaying() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPlaying();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            try {
                return mMediaPlayer.isPlaying();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * Returns true if any player is prepared and ready for playback.
     * 
     * <p>A player is considered "prepared" when it has successfully loaded a song
     * and is ready to play, regardless of whether it is currently playing or paused.
     * This is used by MusicPlayer to determine if resume is possible without restarting
     * the song.</p>
     *
     * @return True if a player has a loaded song ready to play
     */
    public boolean isAnyPlayerPrepared() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPrepared();
        }
        if (mMediaPlayer != null && isPlayerReady()) {
            return true;
        }
        return false;
    }
    
    /**
     * Returns true if the primary SoundTouch player is active.
     * 
     * <p>This method is used for diagnostic purposes and to determine
     * which player's state to query.</p>
     *
     * @return True if using SoundTouch, false if using MediaPlayer fallback
     */
    public boolean isUsingSoundTouch() {
        return mIsUsingSoundTouch;
    }
    
    // =========================================================================
    // Sort Mode Methods
    // =========================================================================
    
    /**
     * Loads the saved sort mode from SharedPreferences.
     * Default is SORT_TITLE_AZ (Title A-Z).
     */
    private void loadSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mCurrentSortMode = prefs.getInt(KEY_SORT_MODE, SORT_TITLE_AZ);
        Log.d(TAG, "Loaded sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Saves the current sort mode to SharedPreferences.
     * Called whenever the user changes the sort mode.
     */
    private void saveSortMode() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putInt(KEY_SORT_MODE, mCurrentSortMode).apply();
        Log.d(TAG, "Saved sort mode: " + mCurrentSortMode);
    }
    
    /**
     * Returns a Comparator for the specified sort mode.
     * 
     * <p>All comparators use secondary sorting by Title (A-Z) when primary keys
     * match to ensure consistent, predictable ordering.</p>
     *
     * @param sortMode The sort mode constant (SORT_TITLE_AZ, SORT_GENRE_ZA, etc.)
     * @return A Comparator&lt;Song&gt; that implements the requested sorting order
     */
    private Comparator<Song> getComparatorForSortMode(int sortMode) {
        switch (sortMode) {
            case SORT_TITLE_AZ: return new TitleAZComparator();
            case SORT_TITLE_ZA: return new TitleZAComparator();
            case SORT_ARTIST_AZ: return new ArtistAZComparator();
            case SORT_ARTIST_ZA: return new ArtistZAComparator();
            case SORT_ALBUM_AZ: return new AlbumAZComparator();
            case SORT_ALBUM_ZA: return new AlbumZAComparator();
            case SORT_GENRE_AZ: return new GenreAZComparator();
            case SORT_GENRE_ZA: return new GenreZAComparator();
            case SORT_OLDEST: return new OldestFirstComparator();
            case SORT_NEWEST: return new NewestFirstComparator();
            default: return new TitleAZComparator(); // Fallback
        }
    }
    
    /**
     * Gets the date/timestamp for a song using the file's last modified time.
     * 
     * <p>This method is reliable across all Android versions and doesn't require
     * additional permissions.</p>
     *
     * @param song The song to get the date for
     * @return The last modified timestamp in milliseconds since Unix epoch (0 if invalid)
     */
    private long getSongDate(@NonNull Song song) {
        if (song.getPath() == null) return 0;
        File file = new File(song.getPath());
        return file.lastModified();
    }
    
    /**
     * Reorders the current playlist according to the current sort mode.
     * 
     * <p>This method sorts the playlist in-place and updates mCurrentIndex
     * to maintain the currently playing song's position in the sorted order.</p>
     */
    private void reorderPlaylistByCurrentSort() {
        if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
        
        // Save current song path to find it after sorting
        String currentSongPath = null;
        if (mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
            Song currentSong = mCurrentPlaylist.get(mCurrentIndex);
            if (currentSong != null) currentSongPath = currentSong.getPath();
        }
        
        // Sort the playlist
        Collections.sort(mCurrentPlaylist, getComparatorForSortMode(mCurrentSortMode));
        
        // Find and update the current index in the sorted list
        if (currentSongPath != null) {
            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                Song song = mCurrentPlaylist.get(i);
                if (song != null && currentSongPath.equals(song.getPath())) {
                    mCurrentIndex = i;
                    saveCurrentPlayingIndex();
                    break;
                }
            }
        }
        
        Log.d(TAG, "Playlist reordered with sort mode: " + mCurrentSortMode);
    }
    
    // =========================================================================
    // Broadcast Receiver Registration
    // =========================================================================
    
    /**
     * Registers the notification receiver for sync updates.
     * Listens for SYNC_STARTED and SYNC_COMPLETE broadcasts from PlaylistService.
     */
    private void registerNotificationReceiver() {
        mUpdateNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("SYNC_STARTED".equals(action) || "SYNC_COMPLETE".equals(action)) {
                    if (mNotificationService != null) {
                        mNotificationService.updateSyncState();
                        refreshNotification();
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("SYNC_STARTED");
        filter.addAction("SYNC_COMPLETE");
        registerReceiver(mUpdateNotificationReceiver, filter);
    }
    
    /**
     * Registers the playback parameters receiver.
     * Listens for UPDATE_PLAYBACK_PARAMS broadcasts from EqualizerActivity
     * to apply pitch and tempo changes in real-time.
     */
    private void registerPlaybackParamsReceiver() {
        mPlaybackParamsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("UPDATE_PLAYBACK_PARAMS".equals(intent.getAction())) {
                    updatePlaybackParams();
                }
            }
        };
        registerReceiver(mPlaybackParamsReceiver, new IntentFilter("UPDATE_PLAYBACK_PARAMS"));
    }
    
    /**
     * Registers the clear playlist receiver.
     * Listens for CLEAR_PLAYLIST broadcasts to stop playback and clear state.
     */
    private void registerClearPlaylistReceiver() {
        mClearPlaylistReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("CLEAR_PLAYLIST".equals(intent.getAction())) {
                    stopCompletely();
                }
            }
        };
        registerReceiver(mClearPlaylistReceiver, new IntentFilter("CLEAR_PLAYLIST"));
    }
    
    /**
     * Registers the theme color change receiver.
     * Listens for THEME_COLOR_CHANGED broadcasts to update notification appearance.
     */
    private void registerThemeReceiver() {
        mThemeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("THEME_COLOR_CHANGED".equals(intent.getAction())) {
                    createNotification();
                }
            }
        };
        registerReceiver(mThemeReceiver, new IntentFilter("THEME_COLOR_CHANGED"));
    }
    
    /**
     * Registers the receiver for getting playing state.
     * Listens for GET_PLAYING_STATE broadcasts and responds with PLAYING_STATE_RESPONSE.
     */
    private void registerGetPlayingStateReceiver() {
        mGetPlayingStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("GET_PLAYING_STATE".equals(intent.getAction())) {
                    Intent responseIntent = new Intent("PLAYING_STATE_RESPONSE");
                    responseIntent.putExtra("is_playing", mIsPlaying);
                    sendBroadcast(responseIntent);
                    
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit().putBoolean(KEY_LAST_PLAYING, mIsPlaying).apply();
                }
            }
        };
        registerReceiver(mGetPlayingStateReceiver, new IntentFilter("GET_PLAYING_STATE"));
    }
    
    /**
     * Registers the sort mode update receiver.
     * Listens for UPDATE_SORT_MODE broadcasts from PlaylistActivity.
     */
    private void registerSortModeReceiver() {
        mSortModeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (ACTION_UPDATE_SORT_MODE.equals(intent.getAction())) {
                    int newSortMode = intent.getIntExtra(EXTRA_SORT_MODE, SORT_TITLE_AZ);
                    if (mCurrentSortMode != newSortMode) {
                        mCurrentSortMode = newSortMode;
                        saveSortMode();
                        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            reorderPlaylistByCurrentSort();
                            broadcastUpdate();
                        }
                        Log.d(TAG, "Sort mode updated to: " + newSortMode);
                    }
                }
            }
        };
        registerReceiver(mSortModeReceiver, new IntentFilter(ACTION_UPDATE_SORT_MODE));
    }
    
    /**
     * Safely unregisters a broadcast receiver, ignoring any exceptions.
     *
     * @param receiver The receiver to unregister (can be null)
     */
    private void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                Log.d(TAG, "Receiver already unregistered");
            }
        }
    }
    
    // =========================================================================
    // MediaPlayer Management (FALLBACK ONLY)
    // =========================================================================
    
    /**
     * Removes all listeners from a MediaPlayer.
     * 
     * <p>This prevents memory leaks and stale callbacks when resetting or releasing
     * the player.</p>
     *
     * @param player The MediaPlayer to clean (can be null)
     */
    private void removeAllListeners(MediaPlayer player) {
        if (player == null) return;
        try {
            player.setOnPreparedListener(null);
            player.setOnCompletionListener(null);
            player.setOnErrorListener(null);
            player.setOnBufferingUpdateListener(null);
            player.setOnInfoListener(null);
            player.setOnSeekCompleteListener(null);
        } catch (Exception ignored) {}
    }
    
    /**
     * Safely resets the MediaPlayer.
     * 
     * <p>This method stops any ongoing playback and resets the player to its
     * initial state. It catches all exceptions to prevent crashes.</p>
     */
    private void resetPlayerSafely() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try {
                    if (mMediaPlayer.isPlaying()) mMediaPlayer.stop();
                } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Releases the MediaPlayer and all associated resources.
     * 
     * <p>This method also releases the WakeLock if held and stops health monitoring.</p>
     */
    private void releaseMediaPlayer() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            if (mMediaPlayer != null) {
                removeAllListeners(mMediaPlayer);
                try { if (mMediaPlayer.isPlaying()) mMediaPlayer.stop(); } catch (Exception ignored) {}
                try { mMediaPlayer.reset(); } catch (Exception ignored) {}
                try { mMediaPlayer.release(); } catch (Exception ignored) {}
                mMediaPlayer = null;
            }
            mIsPlaying = false;
        }
    }
    
    /**
     * Gets or creates the MediaPlayer instance.
     * 
     * <p>This method implements lazy initialization of MediaPlayer and sets up
     * error handling for recovery attempts.</p>
     *
     * @return The MediaPlayer instance (never null)
     */
    private MediaPlayer getOrCreatePlayer() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) {
                mMediaPlayer = new MediaPlayer();
                mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e(TAG, "MediaPlayer error: what=" + what + " extra=" + extra);
                        
                        boolean wasPlaying = mIsPlaying;
                        mIsPlaying = false;
                        mIsPreparingFallback.set(false);
                        
                        createNotification();
                        broadcastUpdate();
                        
                        if (wasPlaying && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                            mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                            
                            final int recoverIndex = mCurrentIndex;
                            final int recoverPosition = getCurrentPosition();
                            
                            // Release current player and try to recover
                            releaseMediaPlayer();
                            
                            new Handler(Looper.getMainLooper()).postDelayed(() -> 
                                prepareAndPlay(recoverIndex, recoverPosition), 500);
                        }
                        return true;
                    }
                });
            }
            return mMediaPlayer;
        }
    }
    
    /**
     * Checks if the MediaPlayer is ready for playback.
     * 
     * <p>A player is considered ready if it has been prepared and can return
     * a valid duration.</p>
     *
     * @return True if the player is ready
     */
    private boolean isPlayerReady() {
        synchronized (mPlayerLock) {
            if (mMediaPlayer == null) return false;
            try { 
                mMediaPlayer.getDuration(); 
                return true; 
            } catch (Exception e) { 
                return false; 
            }
        }
    }
    
    // =========================================================================
    // Health Check Methods (MediaPlayer fallback only)
    // =========================================================================
    
    /**
     * Starts the playback health monitoring (MediaPlayer fallback only).
     * 
     * <p>This method periodically checks if the MediaPlayer is making progress.
     * If a stall is detected, it attempts recovery.</p>
     */
    private void startHealthMonitoring() {
        if (mHealthHandler == null) mHealthHandler = new Handler(Looper.getMainLooper());
        stopHealthMonitoring();
        mRecoveryAttempts = 0;
        mPlaybackStartTime = System.currentTimeMillis();
        mHealthCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkPlaybackHealth();
                if (mIsPlaying && mHealthHandler != null) {
                    mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
                }
            }
        };
        mHealthHandler.postDelayed(mHealthCheckRunnable, HEALTH_CHECK_INTERVAL_MS);
        Log.d(TAG, "Health monitoring started");
    }
    
    /**
     * Stops the playback health monitoring.
     */
    private void stopHealthMonitoring() {
        if (mHealthHandler != null && mHealthCheckRunnable != null) {
            mHealthHandler.removeCallbacks(mHealthCheckRunnable);
            mHealthCheckRunnable = null;
        }
    }
    
    /**
     * Checks if playback is healthy and attempts recovery if stalled.
     * Only used for MediaPlayer fallback.
     */
    private void checkPlaybackHealth() {
        if (!mIsPlaying) return;
        if (mIsUsingSoundTouch) return; // SoundTouch handles its own health
        
        try {
            int currentPosition = getCurrentPosition();
            
            // If position hasn't advanced significantly after several seconds
            if (currentPosition < 100 && mPlaybackStartTime > 0) {
                long elapsed = System.currentTimeMillis() - mPlaybackStartTime;
                if (elapsed > MAX_STALL_TIME_MS) {
                    Log.w(TAG, "Playback stall detected! Position=" + currentPosition + 
                          ", elapsed=" + elapsed + "ms");
                    recoverFromStall();
                }
            } else if (currentPosition > 100) {
                // Reset the start time once we have meaningful progress
                mPlaybackStartTime = System.currentTimeMillis();
            }
        } catch (Exception e) {
            Log.e(TAG, "Health check failed", e);
            recoverFromStall();
        }
    }
    
    /**
     * Attempts to recover from a playback stall (MediaPlayer fallback only).
     * 
     * <p>If recovery attempts exceed MAX_RECOVERY_ATTEMPTS, the song is skipped.</p>
     */
    private void recoverFromStall() {
        if (mRecoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
            Log.e(TAG, "Max recovery attempts reached, skipping song");
            mRecoveryAttempts = 0;
            playNext();
            return;
        }
        
        mRecoveryAttempts++;
        Log.w(TAG, "Attempting playback recovery (attempt " + mRecoveryAttempts + ")");
        
        final int currentIndex = mCurrentIndex;
        final int currentPosition = getSavedPosition();
        
        stopHealthMonitoring();
        
        if (mMediaPlayer != null) {
            try { if (mIsPlaying) mMediaPlayer.pause(); } catch (Exception ignored) {}
            releaseMediaPlayer();
        }
        
        mIsPlaying = false;
        
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (currentIndex >= 0 && mCurrentPlaylist != null && 
                currentIndex < mCurrentPlaylist.size()) {
                Log.d(TAG, "Restarting playback at index " + currentIndex);
                prepareAndPlay(currentIndex, currentPosition);
                sendBroadcast(new Intent("PLAYBACK_RECOVERED"));
            }
        }, 500);
    }
    
    // =========================================================================
    // Async Operation Management
    // =========================================================================
    
    /**
     * Invalidates all pending preparations.
     * 
     * <p>This method increments the global preparation ID, causing any
     * stale callbacks to be ignored.</p>
     */
    private void invalidateAllPreparations() {
        mCurrentPrepId = mGlobalPrepId.incrementAndGet();
    }
    
    /**
     * Acquires the transition lock.
     * 
     * <p>This prevents multiple simultaneous song transitions (e.g., rapid
     * next/prev button presses).</p>
     *
     * @return True if the lock was acquired, false if already locked
     */
    private boolean acquireTransitionLock() {
        return mIsTransitioning.compareAndSet(false, true);
    }
    
    /**
     * Releases the transition lock.
     */
    private void releaseTransitionLock() {
        mIsTransitioning.set(false);
    }
    
    // =========================================================================
    // Notification Methods
    // =========================================================================
    
    /**
     * Creates and updates the playback notification.
     * 
     * <p>The notification includes:</p>
     * <ul>
     *   <li>Song title and artist</li>
     *   <li>Album art (or placeholder)</li>
     *   <li>Play/pause, next, previous, and close buttons</li>
     *   <li>Sync status indicator (when playlist is updating)</li>
     * </ul>
     */
    private void createNotification() {
        if (mNotificationService == null) return;
        
        boolean hasSong = (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && 
                           mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size() && 
                           getCurrentSong() != null);
        
        if (hasSong) {
            Song song = getCurrentSong();
            if (song != null) {
                mNotificationService.updateSongInfo(song.getTitle(), song.getArtist(), song.getPath());
            }
        } else {
            mNotificationService.updateSongInfo(null, null, null);
        }
        mNotificationService.setPlayingState(mIsPlaying);
    }
    
    /**
     * Refreshes the notification.
     * 
     * <p>This method updates the notification's sync state and recreates it
     * with current playback information.</p>
     */
    public void refreshNotification() {
        if (mNotificationService != null) {
            mNotificationService.updateSyncState();
            createNotification();
        }
    }
    
    /**
     * Sets the album art for the notification.
     * 
     * @param art The album art bitmap (may be recycled)
     * @param placeholder The placeholder bitmap (may be recycled)
     * @param artPath The file path of the album art (used for caching)
     */
    public void setNotificationAlbumArt(Bitmap art, Bitmap placeholder, String artPath) {
        if (mNotificationService != null) {
            Bitmap safeArt = (art != null && !art.isRecycled()) ? art : null;
            Bitmap safePlaceholder = (placeholder != null && !placeholder.isRecycled()) ? placeholder : null;
            mNotificationService.setAlbumArt(safeArt, safePlaceholder, artPath);
        }
    }
    
    // =========================================================================
    // State Persistence Methods
    // =========================================================================
    
    /**
     * Saves the current player state to SharedPreferences.
     * 
     * <p>Saved data includes: current index, playback position, playing state,
     * repeat mode, shuffle state, and last song path.</p>
     */
    public void savePlayerState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_REPEAT_MODE, mRepeatMode)
            .putBoolean(KEY_SHUFFLE, mIsShuffle)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the full player state (alias for savePlayerState for consistency).
     */
    private void saveFullState() {
        savePlayerState();
    }
    
    /**
     * Gets the saved playback position from SharedPreferences.
     *
     * @return The saved position in milliseconds
     */
    public int getSavedPosition() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_CURRENT_POSITION, 0);
    }
    
    /**
     * Checks if playback was active before restart.
     * 
     * <p>Used to restore playback state after the app is killed and restarted.</p>
     *
     * @return True if was playing
     */
    public boolean wasPlayingBeforeRestart() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_LAST_PLAYING, false);
    }
    
    /**
     * Gets the saved song path from SharedPreferences.
     *
     * @return The saved song path, or null if none
     */
    public String getSavedSongPath() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_LAST_SONG_PATH, null);
    }
    
    /**
     * Saves the current playing index to SharedPreferences.
     */
    private void saveCurrentPlayingIndex() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putString(KEY_LAST_SONG_PATH, getCurrentSong() != null ? getCurrentSong().getPath() : null)
            .apply();
    }
    
    /**
     * Saves the playing state to SharedPreferences.
     */
    private void savePlayingState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(KEY_LAST_PLAYING, mIsPlaying)
            .putInt(KEY_CURRENT_POSITION, getCurrentPosition())
            .apply();
    }
    
    /**
     * Loads repeat and shuffle settings from SharedPreferences.
     */
    private void loadRepeatAndShuffle() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mRepeatMode = prefs.getInt(KEY_REPEAT_MODE, 0);
        mIsShuffle = prefs.getBoolean(KEY_SHUFFLE, false);
        Log.d(TAG, "Loaded repeat=" + mRepeatMode + ", shuffle=" + mIsShuffle);
    }
    
    // =========================================================================
    // Playlist Management Methods
    // =========================================================================
    
    /**
     * Sets the current playlist.
     * 
     * <p>This method is the main entry point for updating the playlist. It handles:
     * <ul>
     *   <li>Saving current playback state before changes</li>
     *   <li>Sorting the new playlist according to current sort mode</li>
     *   <li>Finding the current song in the new playlist (if preserveCurrentSong)</li>
     *   <li>Resetting the player if needed</li>
     *   <li>Pre-initializing the first song for immediate UI feedback</li>
     * </ul>
     * </p>
     *
     * @param playlist The new playlist (null or empty clears the playlist)
     * @param preserveCurrentSong True to try to preserve the currently playing song
     */
    public void setPlaylist(ArrayList<Song> playlist, boolean preserveCurrentSong) {
        mPendingPlaylist = null;
        mHasPendingPlaylist = false;
        
        synchronized (mPlayerLock) {
            invalidateAllPreparations();
            
            // Save current position to preferences BEFORE any changes
            int currentPosition = 0;
            boolean wasPlaying = false;
            String currentSongPath = null;
            
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                // Get current position from active player
                if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
                    currentPosition = (int) mSoundTouchPlayer.getCurrentPosition();
                    wasPlaying = mSoundTouchPlayer.isPlaying();
                } else if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        currentPosition = mMediaPlayer.getCurrentPosition();
                        wasPlaying = mMediaPlayer.isPlaying();
                    } catch (Exception e) {
                        currentPosition = getSavedPosition();
                    }
                }
                currentSongPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                
                // Save to SharedPreferences immediately
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_POSITION, currentPosition)
                    .putBoolean(KEY_LAST_PLAYING, wasPlaying)
                    .putString(KEY_LAST_SONG_PATH, currentSongPath)
                    .apply();
                
                Log.d(TAG, "Saved position before playlist update: " + currentPosition + "ms");
            }
            
            // Handle empty playlist
            if (playlist == null || playlist.isEmpty()) {
                resetPlayerSafely();
                if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
                mCurrentPlaylist = null;
                mCurrentIndex = -1;
                
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit()
                    .putInt(KEY_CURRENT_INDEX, -1)
                    .putInt(KEY_CURRENT_POSITION, 0)
                    .putBoolean(KEY_LAST_PLAYING, false)
                    .putString(KEY_LAST_SONG_PATH, null)
                    .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
                    .apply();
                
                if (mShuffleHistory != null) mShuffleHistory.clear();
                createNotification();
                broadcastUpdate();
                updateMediaSessionPlaybackState();
                return;
            }
            
            // Step 1: Sort the new playlist according to current sort mode
            ArrayList<Song> sortedPlaylist = new ArrayList<Song>(playlist);
            Collections.sort(sortedPlaylist, getComparatorForSortMode(mCurrentSortMode));
            
            // Step 2: Check if playlist is actually different (optimization)
            if (mCurrentPlaylist != null && playlist.size() == mCurrentPlaylist.size()) {
                boolean same = true;
                for (int i = 0; i < playlist.size(); i++) {
                    if (!playlist.get(i).getPath().equals(mCurrentPlaylist.get(i).getPath())) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    broadcastUpdate();
                    return;
                }
            }
            
            // Force player reset when not preserving current song
            if (!preserveCurrentSong) {
                Log.d(TAG, "setPlaylist: preserveCurrentSong=false, forcing full player reset");
                invalidateAllPreparations();
                if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
                resetPlayerSafely();
                mIsPlaying = false;
            }
            
            // Step 3: Find the current song in the new playlist (if preserveCurrentSong is true)
            int newIndex = -1;
            if (preserveCurrentSong) {
                if (mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                    mCurrentIndex < mCurrentPlaylist.size()) {
                    String currentPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                    for (int i = 0; i < sortedPlaylist.size(); i++) {
                        if (sortedPlaylist.get(i).getPath().equals(currentPath)) {
                            newIndex = i;
                            break;
                        }
                    }
                }
                // Fallback to saved path if current song not found
                if (newIndex == -1) {
                    String savedPath = getSavedSongPath();
                    if (savedPath != null) {
                        for (int i = 0; i < sortedPlaylist.size(); i++) {
                            if (sortedPlaylist.get(i).getPath().equals(savedPath)) {
                                newIndex = i;
                                break;
                            }
                        }
                    }
                }
            }
            
            // Step 4: Check if we actually need to reset the player
            boolean currentSongPositionChanged = (newIndex != -1 && newIndex != mCurrentIndex);
            boolean playlistStructureChanged = (mCurrentPlaylist != null && 
                                               mCurrentPlaylist.size() != sortedPlaylist.size());
            
            // Also check if the current song's path is different (song actually changed)
            boolean currentSongChanged = false;
            if (mCurrentPlaylist != null && mCurrentIndex >= 0 && mCurrentIndex < mCurrentPlaylist.size()) {
                String oldPath = mCurrentPlaylist.get(mCurrentIndex).getPath();
                if (newIndex >= 0 && newIndex < sortedPlaylist.size()) {
                    String newPath = sortedPlaylist.get(newIndex).getPath();
                    currentSongChanged = !oldPath.equals(newPath);
                }
            }
            
            boolean needsReset = currentSongPositionChanged || playlistStructureChanged || currentSongChanged;
            
            if (needsReset && preserveCurrentSong) {
                Log.d(TAG, "Playlist/song changed, resetting player");
                if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
                resetPlayerSafely();
            }
            
            // Step 5: Replace the entire playlist
            mCurrentPlaylist = sortedPlaylist;
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            // Step 6: Set the current index - respects preserveCurrentSong flag
            if (newIndex >= 0) {
                mCurrentIndex = newIndex;
            } else if (preserveCurrentSong) {
                // Only restore saved index when preserving the current song
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, -1);
                if (savedIndex >= 0 && savedIndex < sortedPlaylist.size()) {
                    mCurrentIndex = savedIndex;
                    Log.d(TAG, "Restored saved index: " + savedIndex);
                } else {
                    mCurrentIndex = 0;
                    Log.d(TAG, "No valid saved index, defaulting to 0");
                }
            } else {
                // When preserveCurrentSong == false, do NOT restore any saved index
                mCurrentIndex = -1;
                Log.d(TAG, "preserveCurrentSong=false, setting mCurrentIndex = -1");
            }
            
            saveCurrentPlayingIndex();
            
            // Step 7: Resume playback if needed (only when preserving current song)
            boolean wasPlayingBefore = wasPlayingBeforeRestart();
            int savedPosition = getSavedPosition();
            boolean isFolderUpdate = getPlayerStateBeforeUpdate(this);
            
            if (preserveCurrentSong && wasPlayingBefore && mCurrentPlaylist != null && mCurrentIndex >= 0 && 
                mCurrentIndex < mCurrentPlaylist.size()) {
                
                if (needsReset) {
                    // Need to restart playback from saved position
                    if (isFolderUpdate) {
                        int correctIndex = mCurrentIndex;
                        String savedPath = getSavedSongPath();
                        if (savedPath != null) {
                            for (int i = 0; i < mCurrentPlaylist.size(); i++) {
                                if (mCurrentPlaylist.get(i).getPath().equals(savedPath)) {
                                    correctIndex = i;
                                    break;
                                }
                            }
                        }
                        prepareAndPlay(correctIndex, savedPosition);
                        clearPlayerStateBeforeUpdate(this);
                    } else {
                        prepareAndPlay(mCurrentIndex, savedPosition);
                    }
                } else if (!mIsPlaying && mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
                    // Same song, just resume if it was playing
                    Log.d(TAG, "Same song, resuming playback without reset");
                    resume();
                }
                
            } else if (preserveCurrentSong && mCurrentPlaylist != null && mCurrentIndex >= 0 && needsReset) {
                prepareOnly(mCurrentIndex);
                mIsPlaying = false;
                createNotification();
            } else if (!preserveCurrentSong) {
                // Do not start playback automatically
                Log.d(TAG, "Playlist set without preserving song, waiting for explicit play command");
            }
            
            // =================================================================
            // Pre-initialize the current song for duration and session
            // This ensures the timer shows total time and equalizer is ready before play
            // =================================================================
            if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex >= 0) {
                mMainHandler.postDelayed(this::preInitializeCurrentSong, PRE_INIT_DELAY_MS);
            }
            
            broadcastUpdate();
        }
    }
    
    /**
     * Sets the current playlist without preserving the current song.
     *
     * @param playlist The new playlist
     */
    public void setPlaylist(ArrayList<Song> playlist) {
        setPlaylist(playlist, false);
    }
    
    /**
     * Stops playback and clears the playlist completely.
     * 
     * <p>This method:</p>
     * <ul>
     *   <li>Stops health monitoring and clears transition flags</li>
     *   <li>Releases SoundTouchPlayer and MediaPlayer resources</li>
     *   <li>Clears the playlist and current index</li>
     *   <li>Clears SharedPreferences state</li>
     *   <li>Detaches the equalizer and stops foreground notification</li>
     * </ul>
     */
    public void stopCompletely() {
        stopHealthMonitoring();
        synchronized (mPlayerLock) {
            mIsTransitioning.set(false);
            mIsPreparingFallback.set(false);
            mIsPreparingSoundTouch.set(false);
            
            invalidateAllPreparations();
            resetPlayerSafely();
            
            if (mSoundTouchPlayer != null) mSoundTouchPlayer.reset();
            
            if (mWakeLock != null && mWakeLock.isHeld()) mWakeLock.release();
            
            mCurrentPlaylist = null;
            mCurrentIndex = -1;
            mHasPendingPlaylist = false;
            mPendingPlaylist = null;
            
            if (mShuffleHistory != null) mShuffleHistory.clear();
            
            EqualizerManager.getInstance(this).detach();
            
            if (mNotificationService != null) mNotificationService.stopForeground();
        }
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, -1)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .putString(KEY_LAST_SONG_PATH, null)
            .putBoolean(KEY_PLAYER_STATE_BEFORE_UPDATE, false)
            .apply();
        
        broadcastUpdate();
        updateMediaSessionPlaybackState();
    }
    
    /**
     * Soft updates the playlist.
     * 
     * <p>This method stores a pending playlist that will be applied on the next
     * song transition (e.g., when the current song ends or user clicks next/prev).</p>
     *
     * @param newPlaylist The new playlist to apply on next transition
     */
    public void softUpdatePlaylist(ArrayList<Song> newPlaylist) {
        if (newPlaylist == null || newPlaylist.isEmpty()) {
            stopCompletely();
            return;
        }
        mPendingPlaylist = newPlaylist;
        mHasPendingPlaylist = true;
        savePlayerState();
        Log.d(TAG, "Soft update: pending playlist stored, size=" + newPlaylist.size());
    }
    
    // =========================================================================
    // Playback Control Methods
    // =========================================================================
    
    /**
     * Plays a song at the specified index.
     * 
     * <p>SoundTouchPlayer is the DEFAULT player for ALL playback.
     * MediaPlayer is used ONLY as a fallback when SoundTouch fails at runtime.</p>
     *
     * @param index The song index in the current playlist
     */
    public synchronized void playSong(int index) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.w(TAG, "playSong: invalid index " + index);
            return;
        }
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            playSongWithSoundTouch(index);
        } 
        // FALLBACK: Only if SoundTouch failed at runtime
        else {
            Log.w(TAG, "SoundTouch unavailable, using MediaPlayer fallback");
            prepareAndPlay(index, 0);
        }
    }
    
    /**
     * Plays a song using SoundTouchPlayer (DEFAULT) with MediaPlayer-like API.
     * 
     * <p>The flow is: reset() > setDataSource() > prepareAsync() > onPrepared() > start()</p>
     * <p>A 5-second timeout prevents infinite waiting if preparation gets stuck.</p>
     *
     * @param index Index of song to play in mCurrentPlaylist
     */
    private void playSongWithSoundTouch(int index) {
        Song song = mCurrentPlaylist.get(index);
        if (song == null || song.getPath() == null) {
            Log.e(TAG, "Invalid song at index " + index);
            fallbackToMediaPlayer();
            return;
        }
        
        try {
            // Cancel any pending timeout
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            
            // Set timeout for preparation (prevents infinite waiting)
            mPrepareTimeoutRunnable = () -> {
                Log.e(TAG, "SoundTouch preparation timeout for: " + song.getPath());
                mIsPreparingSoundTouch.set(false);
                fallbackToMediaPlayer();
            };
            mPrepareTimeoutHandler.postDelayed(mPrepareTimeoutRunnable, PREPARE_TIMEOUT_MS);
            
            mIsPreparingSoundTouch.set(true);
            mCurrentIndex = index;
            mShouldStartAfterPrepare = true; // Start when prepared
            
            // MediaPlayer-like flow: reset > setDataSource > prepareAsync
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(song.getPath());
            mSoundTouchPlayer.prepareAsync();
            
            createNotification();
            broadcastUpdate();
            savePlayerState();
            
        } catch (Exception e) {
            Log.e(TAG, "Error playing with SoundTouch", e);
            mIsPreparingSoundTouch.set(false);
            if (mPrepareTimeoutRunnable != null) {
                mPrepareTimeoutHandler.removeCallbacks(mPrepareTimeoutRunnable);
                mPrepareTimeoutRunnable = null;
            }
            fallbackToMediaPlayer();
        }
    }
    
    /**
     * Prepares and starts playback at the specified index and seek position.
     * 
     * <p>This is the FALLBACK method used ONLY when SoundTouch fails at runtime.
     * It uses the legacy MediaPlayer API.</p>
     *
     * @param index The song index in mCurrentPlaylist
     * @param seekPosition The position to seek to in milliseconds
     */
    private void prepareAndPlay(int index, int seekPosition) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            Log.w(TAG, "prepareAndPlay: invalid index " + index);
            return;
        }
        if (mIsPreparingFallback.get()) {
            Log.d(TAG, "Already preparing, skipping prepareAndPlay");
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) {
                Log.e(TAG, "Invalid song at index " + index);
                return;
            }
            
            player.setDataSource(song.getPath());
            
            final int finalSeek = seekPosition;
            final int finalIndex = index;
            
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) {
                        Log.d(TAG, "Preparation " + myPrepId + " cancelled - ignoring");
                        return;
                    }
                    
                    if (mMediaPlayer != mp) {
                        Log.w(TAG, "Stale player instance, ignoring onPrepared callback");
                        return;
                    }
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        int duration = mp.getDuration();
                        if (duration <= 0) {
                            Log.e(TAG, "Invalid duration: " + duration);
                            mIsPlaying = false;
                            broadcastUpdate();
                            return;
                        }
                        
                        if (finalSeek > 0 && finalSeek < duration - 500) {
                            mp.seekTo(finalSeek);
                        }
                        
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        
                        mCurrentIndex = finalIndex;
                        saveCurrentPlayingIndex();
                        
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                        mp.start();
                        mIsPlaying = true;
                        mPlaybackStartTime = System.currentTimeMillis();
                        startHealthMonitoring();
                        savePlayingState();
                        savePlayerState();
                        saveFullState();
                        requestAudioFocus();
                        
                        if (mWakeLock != null && !mWakeLock.isHeld()) {
                            mWakeLock.acquire();
                            Log.d(TAG, "WakeLock acquired");
                        }
                        
                        updateMediaSessionPlaybackState();
                        broadcastUpdate();
                        createNotification();
                        updatePlaybackParams();
                        
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Player in illegal state during onPrepared", e);
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparingFallback.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparingFallback.set(false);
        }
    }
    
    /**
     * Prepares a song without starting playback (for pre-initialization).
     * This is the FALLBACK version used when SoundTouch is unavailable.
     *
     * @param index The song index to prepare
     */
    private void prepareOnly(int index) {
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        final int myPrepId;
        synchronized (mPlayerLock) {
            myPrepId = mGlobalPrepId.incrementAndGet();
            mCurrentPrepId = myPrepId;
        }
        
        try {
            MediaPlayer player = getOrCreatePlayer();
            removeAllListeners(player);
            
            try {
                player.reset();
            } catch (IllegalStateException e) {
                releaseMediaPlayer();
                player = getOrCreatePlayer();
                player.reset();
            }
            
            Song song = mCurrentPlaylist.get(index);
            if (song == null || song.getPath() == null) return;
            
            player.setDataSource(song.getPath());
            
            final int finalIndex = index;
            mIsPreparingFallback.set(true);
            mCurrentIndex = finalIndex;
            
            player.setOnPreparedListener(mp -> {
                synchronized (mPlayerLock) {
                    if (mCurrentPrepId != myPrepId) return;
                    if (mMediaPlayer != mp) return;
                    
                    mIsPreparingFallback.set(false);
                    
                    try {
                        sCurrentAudioSessionId = mp.getAudioSessionId();
                        broadcastAudioSessionChanged(sCurrentAudioSessionId);
                        EqualizerManager.getInstance(MusicService.this)
                            .attachToAudioSession(sCurrentAudioSessionId);
                        mp.setOnCompletionListener(mp2 -> handleCompletion());
                    } catch (Exception e) {
                        Log.e(TAG, "Error in prepareOnly onPrepared", e);
                    }
                }
            });
            
            player.prepareAsync();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to set data source", e);
            mIsPreparingFallback.set(false);
        } catch (IllegalStateException e) {
            Log.e(TAG, "MediaPlayer in illegal state", e);
            mIsPreparingFallback.set(false);
        }
    }
    
    /**
     * Plays a song at the specified index and seek position.
     *
     * @param index The song index
     * @param position The position to seek to in milliseconds
     */
    public synchronized void playSongAtPosition(int index, int position) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null || index < 0 || index >= mCurrentPlaylist.size()) {
            return;
        }
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (!mSoundTouchFailed && mSoundTouchPlayer != null) {
            mShouldStartAfterPrepare = true;
            mSoundTouchPlayer.reset();
            mSoundTouchPlayer.setDataSource(mCurrentPlaylist.get(index).getPath());
            mSoundTouchPlayer.prepareAsync();
            if (position > 0) {
                // Seek will be applied after preparation
                mSoundTouchPlayer.seekTo(position);
            }
        } 
        // FALLBACK: Only if SoundTouch failed at runtime
        else {
            prepareAndPlay(index, position);
        }
        saveFullState();
    }
    
    /**
     * Plays a song by its file path.
     * 
     * <p>This method finds the song in the current playlist by its file path
     * and plays it. It is used by MusicPlayer when a specific song is selected
     * from the playlist or when handling incoming files.</p>
     *
     * @param filePath The file path of the song to play
     */
    public synchronized void playSongByPath(@NonNull String filePath) {
        mRecoveryAttempts = 0;
        if (mCurrentPlaylist == null) {
            Log.w(TAG, "playSongByPath: playlist is null");
            return;
        }
        for (int i = 0; i < mCurrentPlaylist.size(); i++) {
            if (mCurrentPlaylist.get(i).getPath().equals(filePath)) {
                playSong(i);
                return;
            }
        }
        Log.w(TAG, "playSongByPath: song not found in playlist: " + filePath);
    }
    
    /**
     * Plays the next song in the playlist.
     * 
     * <p>Handles both normal and shuffle modes. If shuffle is enabled, a random
     * song is selected that hasn't been played recently. The shuffle history
     * maintains the order of previously played songs for proper previous navigation.</p>
     * 
     * <p>Uses atomic transition lock to prevent multiple simultaneous next/prev commands.</p>
     */
    public synchronized void playNext() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Next");
            return;
        }
        
        try {
            if (mIsPreparingSoundTouch.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Next");
                return;
            }
            
            // Apply pending playlist if exists
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) {
                Log.d(TAG, "playNext: playlist is empty");
                return;
            }
            
            int nextIndex;
            if (mIsShuffle) {
                if (mShuffleHistory != null) {
                    if (mShuffleHistory.size() >= mCurrentPlaylist.size()) {
                        mShuffleHistory.clear();
                    }
                    do {
                        nextIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (nextIndex == mCurrentIndex && mCurrentPlaylist.size() > 1 && 
                             mShuffleHistory.contains(nextIndex));
                    mShuffleHistory.add(nextIndex);
                    if (mShuffleHistory.size() > mCurrentPlaylist.size() * 2) {
                        mShuffleHistory.remove(0);
                    }
                } else {
                    nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
                }
            } else {
                nextIndex = (mCurrentIndex + 1) % mCurrentPlaylist.size();
            }
            
            mCurrentIndex = nextIndex;
            playSong(nextIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                broadcastUpdate();
                createNotification();
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Plays the previous song in the playlist.
     * 
     * <p>In shuffle mode, this uses the shuffle history to go back to the
     * previously played song. In normal mode, it simply goes to the previous index.</p>
     */
    public synchronized void playPrevious() {
        mRecoveryAttempts = 0;
        if (!acquireTransitionLock()) {
            Log.d(TAG, "Transition already in progress, ignoring Previous");
            return;
        }
        
        try {
            if (mIsPreparingSoundTouch.get() || mIsPreparingFallback.get()) {
                Log.d(TAG, "Preparation in progress, ignoring Previous");
                return;
            }
            
            if (mHasPendingPlaylist && mPendingPlaylist != null) {
                ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
                Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
                mCurrentPlaylist = sortedPending;
                mPendingPlaylist = null;
                mHasPendingPlaylist = false;
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
                mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
                saveCurrentPlayingIndex();
                playSong(mCurrentIndex);
                return;
            }
            
            if (mCurrentPlaylist == null || mCurrentPlaylist.isEmpty()) return;
            
            int prevIndex;
            if (mIsShuffle && mShuffleHistory != null) {
                if (mShuffleHistory.size() >= 2) {
                    prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
                    mShuffleHistory.remove(mShuffleHistory.size() - 1);
                } else {
                    do {
                        prevIndex = mRandom.nextInt(mCurrentPlaylist.size());
                    } while (prevIndex == mCurrentIndex && mCurrentPlaylist.size() > 1);
                }
            } else {
                prevIndex = mCurrentIndex > 0 ? mCurrentIndex - 1 : mCurrentPlaylist.size() - 1;
            }
            
            mCurrentIndex = prevIndex;
            playSong(prevIndex);
            savePlayerState();
            saveFullState();
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                broadcastUpdate();
                createNotification();
            }, 50);
        } finally {
            new Handler(Looper.getMainLooper()).postDelayed(this::releaseTransitionLock, SONG_TRANSITION_DELAY_MS);
        }
    }
    
    /**
     * Toggles between play and pause states.
     * 
     * <p>This method is used by headset buttons, lock screen controls,
     * and the notification's play/pause button.</p>
     */
    public void togglePlayPause() {
        // SoundTouchPlayer is active and has a loaded song
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            if (mSoundTouchPlayer.isPlaying()) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        // MediaPlayer fallback is active
        if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
            if (mIsPlaying) {
                pause();
            } else {
                resume();
            }
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
            return;
        }
        
        // No active player but playlist exists - start playback from first song
        if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
            Song firstSong = mCurrentPlaylist.get(0);
            if (firstSong != null && firstSong.getPath() != null) {
                playSongByPath(firstSong.getPath());
            } else {
                playSong(0);
            }
        }
    }
    
    /**
     * Pauses playback.
     * 
     * <p>This method stops audio output and releases the WakeLock.
     * The current position is saved for potential resume.</p>
     */
    public void pause() {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPlaying()) {
            mSoundTouchPlayer.pause();
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on pause");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            stopHealthMonitoring();
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.pause();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot pause - invalid state", e);
                    }
                    mIsPlaying = false;
                    
                    if (mWakeLock != null && mWakeLock.isHeld()) {
                        mWakeLock.release();
                        Log.d(TAG, "WakeLock released on pause");
                    }
                    
                    savePlayingState();
                    savePlayerState();
                    saveFullState();
                    broadcastUpdate();
                    updateMediaSessionPlaybackState();
                    createNotification();
                }
            }
        }
    }
    
    /**
     * Resumes playback from a paused state.
     * 
     * <p>This method restores audio output, re-acquires the WakeLock,
     * and requests audio focus from the system.</p>
     */
    public void resume() {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && !mSoundTouchPlayer.isPlaying() && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.start();
            mIsPlaying = true;
            
            if (mWakeLock != null && !mWakeLock.isHeld()) {
                mWakeLock.acquire();
                Log.d(TAG, "WakeLock acquired on resume");
            }
            
            savePlayingState();
            savePlayerState();
            saveFullState();
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            createNotification();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                    try {
                        if (!mIsPlaying) {
                            requestAudioFocus();
                            updatePlaybackParams();
                            mMediaPlayer.start();
                            mIsPlaying = true;
                            mPlaybackStartTime = System.currentTimeMillis();
                            startHealthMonitoring();
                            
                            if (mWakeLock != null && !mWakeLock.isHeld()) {
                                mWakeLock.acquire();
                                Log.d(TAG, "WakeLock acquired on resume");
                            }
                            
                            savePlayingState();
                            savePlayerState();
                            saveFullState();
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            createNotification();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Resume failed - invalid state", e);
                        mIsPlaying = false;
                        broadcastUpdate();
                    }
                } else if (mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty() && mCurrentIndex < 0) {
                    // No current song, start from first
                    playSong(0);
                }
            }
        }
    }
    
    /**
     * Stops playback and resets the player.
     * 
     * <p>Unlike pause(), stop() resets the playback position to 0.
     * The player remains prepared but will start from the beginning when resumed.</p>
     */
    public void stop() {
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
            mIsPlaying = false;
        } else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && mIsPlaying && isPlayerReady()) {
                    try {
                        mMediaPlayer.stop();
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot stop - invalid state", e);
                    }
                    mIsPlaying = false;
                }
            }
        }
        savePlayingState();
        savePlayerState();
        saveFullState();
        broadcastUpdate();
        updateMediaSessionPlaybackState();
        createNotification();
    }
    
    /**
     * Seeks to the specified position in the current song.
     * 
     * <p>This method handles seek operations for both SoundTouchPlayer
     * and MediaPlayer fallback. The seek is applied immediately.</p>
     *
     * @param position The position in milliseconds
     */
    public void seekTo(int position) {
        // DEFAULT: Use SoundTouchPlayer
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.seekTo(position);
            broadcastUpdate();
            updateMediaSessionPlaybackState();
            savePlayerState();
            saveFullState();
        } 
        // FALLBACK: Use MediaPlayer
        else {
            synchronized (mPlayerLock) {
                if (mMediaPlayer != null && isPlayerReady()) {
                    try {
                        int duration = mMediaPlayer.getDuration();
                        if (position >= 0 && position < duration) {
                            mMediaPlayer.seekTo(position);
                            broadcastUpdate();
                            updateMediaSessionPlaybackState();
                            savePlayerState();
                            saveFullState();
                        }
                    } catch (IllegalStateException e) {
                        Log.e(TAG, "Cannot seek - invalid state", e);
                    }
                }
            }
        }
    }
    
    // =========================================================================
    // Playback Parameter Methods
    // =========================================================================
    
    /**
     * Updates playback parameters (speed and pitch) from the EqualizerManager.
     * 
     * <p>This method is called when the user adjusts the equalizer, pitch, or speed
     * controls in EqualizerActivity. The new parameters are applied in real-time
     * without interrupting playback.</p>
     */
    public void updatePlaybackParams() {
        EqualizerManager eq = EqualizerManager.getInstance(this);
        int speedLevel = eq.getSpeed();
        float tempo = 0.5f + (speedLevel / 2000.0f);
        int pitchLevel = eq.getPitch();
        float semitones = (pitchLevel - 1000) / (1000.0f / 6.0f);
        
        // DEFAULT: Use SoundTouchPlayer for ALL playback
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            mSoundTouchPlayer.setPitch(semitones);
            mSoundTouchPlayer.setTempo(tempo);
            Log.d(TAG, "SoundTouch: pitch=" + semitones + ", tempo=" + tempo);
            return;
        }
        
        // FALLBACK: Use MediaPlayer's PlaybackParams (API 23+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mMediaPlayer != null && isPlayerReady()) {
            try {
                float pitch = (float) Math.pow(2.0, semitones / 12.0);
                android.media.PlaybackParams params = mMediaPlayer.getPlaybackParams();
                params.setSpeed(tempo);
                params.setPitch(pitch);
                mMediaPlayer.setPlaybackParams(params);
                Log.d(TAG, "PlaybackParams: tempo=" + tempo + ", pitch=" + pitch);
            } catch (Exception e) {
                Log.e(TAG, "Failed to set playback params", e);
            }
        }
    }
    
    // =========================================================================
    // Completion Handler
    // =========================================================================
    
    /**
     * Handles song completion events.
     * 
     * <p>This method is called when a song finishes playing normally.
     * It determines what to do next based on the repeat mode:
     * <ul>
     *   <li>Repeat one (mode=2): seek to 0 and play again</li>
     *   <li>Repeat all (mode=1): play next song (wrap around to first at end)</li>
     *   <li>No repeat (mode=0): stop at end of playlist</li>
     * </ul>
     * </p>
     * 
     * <p>This method also sends a completion broadcast with the full duration
     * to ensure the UI seekbar fills completely to 100%.</p>
     */
    private void handleCompletion() {
        // Broadcast completion with full duration for seekbar fill
        broadcastSongCompletion();
        
        if (mCurrentPlaylist == null) {
            Log.e(TAG, "handleCompletion: playlist is null");
            mIsPlaying = false;
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released on completion - no playlist");
            }
            return;
        }
        
        // Apply pending playlist if exists
        if (mHasPendingPlaylist && mPendingPlaylist != null) {
            ArrayList<Song> sortedPending = new ArrayList<Song>(mPendingPlaylist);
            Collections.sort(sortedPending, getComparatorForSortMode(mCurrentSortMode));
            mCurrentPlaylist = sortedPending;
            mPendingPlaylist = null;
            mHasPendingPlaylist = false;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int savedIndex = prefs.getInt(KEY_CURRENT_INDEX, 0);
            mCurrentIndex = (savedIndex >= 0 && savedIndex < mCurrentPlaylist.size()) ? savedIndex : 0;
            saveCurrentPlayingIndex();
            playSong(mCurrentIndex);
            return;
        }
        
        if (mRepeatMode == 2) {
            // Repeat one: seek to 0 and play again
            if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
                mSoundTouchPlayer.seekTo(0);
                mSoundTouchPlayer.start();
            } else if (mMediaPlayer != null) {
                mMediaPlayer.seekTo(0);
                mMediaPlayer.start();
            }
        } else if (mRepeatMode == 1) {
            // Repeat all: play next (wraps to first)
            playNext();
        } else if (mCurrentIndex + 1 < mCurrentPlaylist.size()) {
            // Normal: play next if available
            playNext();
        } else {
            // End of playlist, stop playback
            mIsPlaying = false;
            
            if (mWakeLock != null && mWakeLock.isHeld()) {
                mWakeLock.release();
                Log.d(TAG, "WakeLock released - end of playlist");
            }
            
            if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
                mSoundTouchPlayer.stop();
            } else if (mMediaPlayer != null) {
                mMediaPlayer.seekTo(getDuration());
                mMediaPlayer.pause();
            }
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_CURRENT_POSITION, getDuration())
                .putBoolean(KEY_LAST_PLAYING, false)
                .apply();
            savePlayingState();
            savePlayerState();
            saveFullState();
            
            // Send final completion broadcast
            broadcastSongCompletion();
            updateMediaSessionPlaybackState();
            createNotification();
        }
    }
    
    /**
     * Broadcasts song completion with full duration for UI seekbar fill.
     * 
     * <p>This ensures the seekbar reaches 100% when the song ends,
     * fixing the issue where the seekbar would stop at 97-99% due to
     * rounding or timing issues.</p>
     */
    private void broadcastSongCompletion() {
        int duration = getDuration();
        
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", false);
        intent.putExtra("song_completed", true);
        intent.putExtra("completed_position", duration);
        intent.putExtra("duration", duration);
        sendBroadcast(intent);
        
        Log.d(TAG, "broadcastSongCompletion: duration=" + duration + "ms");
    }
    
    // =========================================================================
    // Getter Methods
    // =========================================================================
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * @return Current position, or 0 if not available
     */
    public int getCurrentPosition() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getCurrentPosition();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getCurrentPosition();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Returns the duration of the current song in milliseconds.
     * 
     * @return Duration, or 0 if not available
     */
    public int getDuration() {
        if (mSoundTouchPlayer != null && mSoundTouchPlayer.isPrepared()) {
            return (int) mSoundTouchPlayer.getDuration();
        }
        synchronized (mPlayerLock) {
            if (mMediaPlayer != null && mCurrentIndex >= 0 && isPlayerReady()) {
                try {
                    return mMediaPlayer.getDuration();
                } catch (Exception e) {
                    return 0;
                }
            }
        }
        return 0;
    }
    
    /**
     * Checks if playback is currently active.
     * 
     * @return True if playing, false otherwise
     */
    public boolean isPlaying() {
        if (mSoundTouchPlayer != null && mIsUsingSoundTouch) {
            return mSoundTouchPlayer.isPlaying();
        }
        return mIsPlaying && isPlayerReady() && isMediaPlayerPlaying(mMediaPlayer);
    }
    
    /**
     * Checks if a MediaPlayer is currently playing.
     *
     * @param player The MediaPlayer to check
     * @return True if playing, false otherwise
     */
    private boolean isMediaPlayerPlaying(MediaPlayer player) {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Returns the currently playing song.
     *
     * @return The current song, or null if none
     */
    public Song getCurrentSong() {
        return (mCurrentIndex >= 0 && mCurrentPlaylist != null && 
                mCurrentIndex < mCurrentPlaylist.size()) 
                ? mCurrentPlaylist.get(mCurrentIndex) : null;
    }
    
    /**
     * Returns the current playlist index.
     *
     * @return Current index, or -1 if none
     */
    public int getCurrentIndex() {
        return mCurrentIndex;
    }
    
    /**
     * Sets the current playlist index.
     *
     * @param index The new index
     */
    public void setCurrentIndex(int index) {
        mCurrentIndex = index;
        saveCurrentPlayingIndex();
        saveFullState();
    }
    
    /**
     * Returns the repeat mode.
     *
     * @return 0 = off, 1 = repeat all, 2 = repeat one
     */
    public int getRepeatMode() {
        return mRepeatMode;
    }
    
    /**
     * Sets the repeat mode.
     *
     * @param mode 0 = off, 1 = repeat all, 2 = repeat one
     */
    public void setRepeatMode(int mode) {
        mRepeatMode = mode;
        savePlayerState();
        saveFullState();
        Log.d(TAG, "Repeat mode set to: " + mode);
    }
    
    /**
     * Checks if shuffle mode is enabled.
     *
     * @return True if shuffle is on
     */
    public boolean isShuffle() {
        return mIsShuffle;
    }
    
    /**
     * Sets the shuffle mode.
     *
     * @param shuffle True to enable shuffle, false to disable
     */
    public void setShuffle(boolean shuffle) {
        mIsShuffle = shuffle;
        if (shuffle && mShuffleHistory != null) {
            mShuffleHistory.clear();
        }
        savePlayerState();
        saveFullState();
        Log.d(TAG, "Shuffle mode set to: " + shuffle);
    }
    
    /**
     * Sets the Bluetooth connection state.
     *
     * @param connected True if Bluetooth is connected
     */
    public void setBluetoothConnected(boolean connected) {
        mIsBluetoothConnected = connected;
        Log.d(TAG, "Bluetooth connected: " + connected);
    }
    
    // =========================================================================
    // Media Session Methods
    // =========================================================================
    
    /**
     * Sets up the MediaSession for lock screen controls.
     * 
     * <p>This provides playback controls on the lock screen, notification area,
     * and Bluetooth headsets. The session is active for the lifetime of the service.</p>
     */
    private void setupMediaSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                mMediaSession = new MediaSession(this, "LlamaMusicService");
                mMediaSession.setCallback(new MediaSession.Callback() {
                    @Override
                    public void onPlay() {
                        if (!mIsPlaying && mCurrentIndex >= 0) {
                            resume();
                        } else if (mCurrentIndex < 0 && mCurrentPlaylist != null && !mCurrentPlaylist.isEmpty()) {
                            playSong(0);
                        }
                    }
                    
                    @Override
                    public void onPause() {
                        if (mIsPlaying) {
                            pause();
                        }
                    }
                    
                    @Override
                    public void onSkipToNext() {
                        playNext();
                    }
                    
                    @Override
                    public void onSkipToPrevious() {
                        playPrevious();
                    }
                    
                    @Override
                    public void onStop() {
                        pause();
                    }
                    
                    @Override
                    public void onPlayFromMediaId(String mediaId, Bundle extras) {
                        if (mediaId != null) {
                            try {
                                playSong(Integer.parseInt(mediaId));
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                });
                mMediaSession.setActive(true);
                updateMediaSessionPlaybackState();
                Log.d(TAG, "MediaSession setup complete");
            } catch (Exception e) {
                Log.e(TAG, "Failed to setup MediaSession", e);
            }
        }
    }
    
    /**
     * Sets up audio focus for proper audio ducking and interruption handling.
     * 
     * <p>Audio focus is requested when playback starts and abandoned when paused/stopped.
     * This ensures the app behaves correctly when another app wants to play audio
     * (e.g., phone call, navigation instructions, another music player).</p>
     */
    private void setupAudioFocus() {
        mAudioFocusListener = focusChange -> handleAudioFocusChange(focusChange);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setOnAudioFocusChangeListener(mAudioFocusListener)
                .setAudioAttributes(audioAttributes)
                .build();
        }
        Log.d(TAG, "Audio focus setup complete");
    }
    
    /**
     * Refreshes metadata for a specific song in the playlist.
     * 
     * <p>This method is called when the user edits a song's metadata (title, artist,
     * album, genre, album art) in the MetadataEditor. It updates the in-memory
     * playlist, the database, and refreshes the notification and UI.</p>
     *
     * @param songPath The path of the song being edited
     * @param newTitle The new title (null for no change)
     * @param newArtist The new artist (null for no change)
     * @param newAlbum The new album (null for no change)
     * @param newGenre The new genre (null for no change)
     * @param albumArtBytes The new album art bytes (null for no change)
     * @param albumArtRemoved True if album art should be removed
     */
    public void refreshMetadataForSong(@NonNull String songPath, 
                                       @Nullable String newTitle, 
                                       @Nullable String newArtist, 
                                       @Nullable String newAlbum, 
                                       @Nullable String newGenre,
                                       @Nullable byte[] albumArtBytes,
                                       boolean albumArtRemoved) {
        synchronized (mPlayerLock) {
            if (mCurrentPlaylist == null) {
                Log.d(TAG, "refreshMetadataForSong: playlist is null, cannot refresh");
                return;
            }
            
            if (mCurrentIndex < 0 || mCurrentIndex >= mCurrentPlaylist.size()) {
                Log.d(TAG, "refreshMetadataForSong: invalid current index");
                return;
            }
            
            Song current = mCurrentPlaylist.get(mCurrentIndex);
            if (current == null) {
                Log.d(TAG, "refreshMetadataForSong: current song is null");
                return;
            }
            
            if (!songPath.equals(current.getPath())) {
                Log.d(TAG, "refreshMetadataForSong: song path mismatch - " + 
                      songPath + " vs " + current.getPath());
                return;
            }
            
            String finalTitle = (newTitle != null && !newTitle.isEmpty()) ? newTitle : current.getTitle();
            String finalArtist = (newArtist != null && !newArtist.isEmpty()) ? newArtist : current.getArtist();
            String finalAlbum = (newAlbum != null && !newAlbum.isEmpty()) ? newAlbum : current.getAlbum();
            String finalGenre = (newGenre != null && !newGenre.isEmpty()) ? newGenre : current.getGenre();
            
            Song updated = new Song(finalTitle, finalArtist, finalAlbum, finalGenre, songPath, current.getDuration(), null);
            if (current.getUri() != null) {
                updated.setUri(current.getUri());
            }
            
            if (albumArtRemoved) {
                Log.d(TAG, "Album art removed for song: " + songPath);
            }
            
            mCurrentPlaylist.set(mCurrentIndex, updated);
            
            SongDatabase.getInstance(this).insertSong(updated);
            
            if (mMediaSession != null) {
                mMediaSession.setMetadata(null);
            }
            
            broadcastUpdate();
            createNotification();
            updateMediaSessionPlaybackState();
            
            Log.d(TAG, "Metadata refreshed for: " + songPath);
        }
    }
    
    /**
     * Handles the close action from the notification.
     * 
     * <p>This method stops playback, clears state, and closes the app completely.
     * It is called when the user clicks the close button in the notification.</p>
     */
    private void handleCloseAction() {
        Log.d(TAG, "handleCloseAction: closing app");
        
        saveFullState();
        savePlayerState();
        
        invalidateAllPreparations();
        
        if (mSoundTouchPlayer != null) {
            mSoundTouchPlayer.stop();
        }
        resetPlayerSafely();
        
        if (mCurrentPlaylist != null) {
            mCurrentPlaylist.clear();
        }
        mCurrentIndex = -1;
        
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit()
            .putInt(KEY_CURRENT_INDEX, mCurrentIndex)
            .putInt(KEY_CURRENT_POSITION, 0)
            .putBoolean(KEY_LAST_PLAYING, false)
            .apply();
        
        if (mNotificationService != null) {
            mNotificationService.updateSongInfo(null, null, null);
            mNotificationService.setPlayingState(false);
            mNotificationService.stopForeground();
        }
        stopForeground(true);
        
        stopSelf();
        
        Intent closeIntent = new Intent(this, MusicPlayer.class);
        closeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        closeIntent.putExtra("close_app", true);
        startActivity(closeIntent);
    }
    
    /**
     * Requests audio focus from the system.
     * 
     * <p>This method uses the appropriate API based on Android version
     * (AudioFocusRequest for API 26+, legacy method for older versions).</p>
     */
    @SuppressWarnings("deprecation")
    private void requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.requestAudioFocus(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.requestAudioFocus(mAudioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }
    
    /**
     * Abandons audio focus.
     * 
     * <p>This releases audio focus so other apps can play audio uninterrupted.
     * Called when playback is paused or stopped.</p>
     */
    @SuppressWarnings("deprecation")
    private void abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null && mAudioManager != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else if (mAudioManager != null && mAudioFocusListener != null) {
            mAudioManager.abandonAudioFocus(mAudioFocusListener);
        }
    }
    
    /**
     * Broadcasts a playback state update to activities.
     * 
     * <p>This intent is received by MusicPlayer and PlaylistActivity to update
     * their UI (play/pause button state, current song highlight, etc.).</p>
     */
    private void broadcastUpdate() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("current_index", mCurrentIndex);
        intent.putExtra("is_playing", mIsPlaying);
        sendBroadcast(intent);
    }
    
    /**
     * Broadcasts an audio session change for equalizer attachment.
     * 
     * <p>This intent is received by EqualizerActivity to attach the equalizer
     * to the correct audio session when a new song is loaded.</p>
     *
     * @param sessionId The new audio session ID
     */
    private void broadcastAudioSessionChanged(int sessionId) {
        Intent intent = new Intent(ACTION_AUDIO_SESSION_CHANGED);
        intent.putExtra("audio_session_id", sessionId);
        sendBroadcast(intent);
        Log.d(TAG, "Audio session changed broadcast: " + sessionId);
    }
    
    /**
     * Updates the MediaSession playback state.
     * 
     * <p>This keeps the lock screen and Bluetooth controls in sync with
     * the actual playback state.</p>
     */
    private void updateMediaSessionPlaybackState() {
        if (mMediaSession != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                PlaybackState.Builder stateBuilder = new PlaybackState.Builder();
                long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                              PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS |
                              PlaybackState.ACTION_STOP;
                int state = mIsPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
                stateBuilder.setState(state, getCurrentPosition(), 1.0f);
                stateBuilder.setActions(actions);
                mMediaSession.setPlaybackState(stateBuilder.build());
            } catch (Exception e) {
                Log.e(TAG, "Failed to update MediaSession state", e);
            }
        }
    }
    
    /**
     * Handles media button events from Bluetooth headsets.
     * 
     * <p>When a Bluetooth headset is connected, the volume up/down buttons
     * are mapped to next/previous track. Otherwise, standard media buttons
     * are handled normally.</p>
     *
     * @param keyCode The key code of the pressed button (e.g., KEYCODE_MEDIA_NEXT)
     */
    public void handleMediaButton(int keyCode) {
        if (mIsBluetoothConnected) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                playNext();
            } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                playPrevious();
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                togglePlayPause();
                break;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext();
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrevious();
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (!mIsPlaying && mCurrentIndex >= 0) {
                    resume();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (mIsPlaying) {
                    pause();
                }
                break;
            default:
                Log.d(TAG, "Unhandled media button: " + keyCode);
                break;
        }
    }
    
    /**
     * Handles audio focus changes (phone calls, other apps playing, etc.).
     * 
     * <p>When another app requests audio focus or a phone call arrives,
     * this method pauses playback appropriately. When focus is regained,
     * playback can be resumed by the user (not automatically).</p>
     *
     * @param focusChange The type of focus change (e.g., AUDIOFOCUS_LOSS)
     */
    private void handleAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // Permanent or temporary loss - pause playback
                if (mIsPlaying) {
                    pause();
                    Log.d(TAG, "Audio focus lost - playback paused");
                }
                break;
                
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // Temporary loss where we can duck (lower volume) - not needed for music
                // SoundTouch doesn't need special handling, AudioTrack handles it
                Log.d(TAG, "Audio focus lost - ducking (handled by system)");
                break;
                
            case AudioManager.AUDIOFOCUS_GAIN:
                // Focus regained - no automatic resume (user must press play)
                Log.d(TAG, "Audio focus regained - ready to play");
                break;
                
            default:
                break;
        }
    }
}