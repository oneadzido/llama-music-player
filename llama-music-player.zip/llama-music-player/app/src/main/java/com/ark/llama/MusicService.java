/**
 * Llama Music Player – MusicService
 * ============================================================================
 * Background service that handles audio playback with independent pitch and
 * tempo control using a custom MediaExtractor/MediaCodec pipeline and the
 * SoundTouch native library. Supports all audio formats (MP3, AAC, FLAC, OGG,
 * etc.), repeat and shuffle modes, and works from Android 5.0 (API 21) upward.
 *
 * <p>Thread safety: All mutable state is guarded by the main handler or atomic
 * variables. Decoding and playback run on dedicated HandlerThreads.</p>
 *
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
package com.ark.llama;

import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * MusicService – Background playback service with pitch/tempo shifting.
 * All public methods are thread‑safe and can be called from any thread.
 */
public class MusicService extends Service implements AudioManager.OnAudioFocusChangeListener {

    // ========================================================================
    // Constants
    // ========================================================================
    private static final String TAG = "MusicService";
    private static final int QUEUE_CAPACITY = 16;                // number of audio frames in queue
    private static final int TIMEOUT_US = 10000;                // decoder timeout in microseconds
    private static final int SEEK_TOLERANCE_US = 500000;        // 0.5 seconds
    private static final float MIN_SPEED = 0.5f;
    private static final float MAX_SPEED = 1.5f;
    private static final float MIN_PITCH_SEMITONES = -6.0f;
    private static final float MAX_PITCH_SEMITONES = 6.0f;

    // ========================================================================
    // Member Variables
    // ========================================================================
    private final IBinder mBinder = new LocalBinder();
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread mDecodeThread;
    private Handler mDecodeHandler;
    private HandlerThread mPlaybackThread;
    private Handler mPlaybackHandler;

    private MediaExtractor mExtractor;
    private MediaCodec mDecoder;
    private AudioTrack mAudioTrack;
    private PitchShifter mPitchShifter;
    private BlockingQueue<short[]> mAudioQueue;                 // queue of raw PCM frames
    private PowerManager.WakeLock mWakeLock;
    private AudioManager mAudioManager;

    private final AtomicBoolean mIsDecoding = new AtomicBoolean(false);
    private final AtomicBoolean mIsPlaying = new AtomicBoolean(false);
    private final AtomicBoolean mIsPaused = new AtomicBoolean(false);
    private final AtomicBoolean mInputEOS = new AtomicBoolean(false);
    private final AtomicBoolean mOutputEOS = new AtomicBoolean(false);
    private final AtomicLong mSeekPositionUs = new AtomicLong(-1);
    private final AtomicBoolean mSeekPending = new AtomicBoolean(false);

    private ArrayList<Song> mPlaylist = new ArrayList<>();
    private int mCurrentIndex = -1;
    private int mRepeatMode = 0;                // 0=off, 1=all, 2=one
    private boolean mShuffle = false;
    private Random mRandom = new Random();
    private ArrayList<Integer> mShuffleHistory = new ArrayList<>();

    private int mSampleRate = 44100;
    private int mChannelCount = 2;
    private int mAudioSessionId = 0;
    private long mDurationUs = 0;
    private long mCurrentPositionUs = 0;

    private float mCurrentSpeed = 1.0f;
    private float mCurrentPitchSemitones = 0.0f;

    // For Android O+ audio focus request
    private Object mAudioFocusRequest;

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Binder for activities to obtain a reference to this service.
     */
    public class LocalBinder extends Binder {
        /**
         * Returns the MusicService instance.
         *
         * @return the service instance
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    // ========================================================================
    // Lifecycle Methods
    // ========================================================================

    /**
     * Called when the service is created. Initialises threads, wake lock and audio focus.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Llama:Playback");
        mWakeLock.setReferenceCounted(false);

        mAudioQueue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);

        mDecodeThread = new HandlerThread("AudioDecoder");
        mDecodeThread.start();
        mDecodeHandler = new Handler(mDecodeThread.getLooper());

        mPlaybackThread = new HandlerThread("AudioPlayback");
        mPlaybackThread.start();
        mPlaybackHandler = new Handler(mPlaybackThread.getLooper());

        setupAudioFocus();
    }

    /**
     * Called when the service receives a start command. Handles playback actions.
     *
     * @param intent  the intent containing the action
     * @param flags   additional flags
     * @param startId start ID
     * @return START_STICKY to restart the service if killed
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "PLAY_SONG":
                    String path = intent.getStringExtra("song_path");
                    if (path != null) playSongByPath(path);
                    break;
                case "ACTION_PLAY":
                    play();
                    break;
                case "ACTION_PAUSE":
                    pause();
                    break;
                case "ACTION_NEXT":
                    next();
                    break;
                case "ACTION_PREV":
                    previous();
                    break;
                case "ACTION_STOP":
                    stop();
                    break;
                case "ACTION_SEEK":
                    int pos = intent.getIntExtra("position", 0);
                    seekTo(pos);
                    break;
            }
        }
        return START_STICKY;
    }

    /**
     * Binds the service to an activity.
     *
     * @param intent the intent used to bind
     * @return the binder object
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /**
     * Called when the service is destroyed. Releases all resources.
     */
    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        stopPlayback();
        if (mDecodeThread != null) mDecodeThread.quitSafely();
        if (mPlaybackThread != null) mPlaybackThread.quitSafely();
        if (mWakeLock.isHeld()) mWakeLock.release();
        abandonAudioFocus();
        super.onDestroy();
    }

    // ========================================================================
    // Playback Control (public API)
    // ========================================================================

    /**
     * Sets the current playlist.
     *
     * @param playlist the list of songs to play
     */
    public void setPlaylist(@NonNull ArrayList<Song> playlist) {
        mPlaylist = new ArrayList<>(playlist);
        if (mShuffle) buildShuffleHistory();
    }

    /**
     * Returns the current playlist.
     *
     * @return a copy of the playlist
     */
    @NonNull
    public ArrayList<Song> getPlaylist() {
        return mPlaylist;
    }

    /**
     * Returns the currently playing song, or null if none.
     *
     * @return the current song
     */
    @Nullable
    public Song getCurrentSong() {
        if (mCurrentIndex >= 0 && mCurrentIndex < mPlaylist.size())
            return mPlaylist.get(mCurrentIndex);
        return null;
    }

    /**
     * Returns the current playback position in milliseconds.
     *
     * @return position in ms
     */
    public int getCurrentPosition() {
        return (int) (mCurrentPositionUs / 1000);
    }

    /**
     * Returns the total duration of the current song in milliseconds.
     *
     * @return duration in ms
     */
    public int getDuration() {
        return (int) (mDurationUs / 1000);
    }

    /**
     * Returns true if playback is active (not paused and not stopped).
     *
     * @return true if playing
     */
    public boolean isPlaying() {
        return mIsPlaying.get() && !mIsPaused.get();
    }

    /**
     * Plays or resumes playback.
     */
    public void play() {
        if (mPlaylist.isEmpty()) return;
        if (mCurrentIndex < 0) mCurrentIndex = 0;

        if (mAudioTrack != null && mIsPaused.get()) {
            // Resume from pause
            requestAudioFocus();
            mAudioTrack.play();
            mIsPaused.set(false);
            mIsPlaying.set(true);
            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);
        } else {
            // Start fresh playback
            startPlayback(mCurrentIndex);
        }
        broadcastState();
    }

    /**
     * Pauses playback.
     */
    public void pause() {
        if (mAudioTrack != null && mIsPlaying.get() && !mIsPaused.get()) {
            mAudioTrack.pause();
            mIsPaused.set(true);
            mIsPlaying.set(false);
            if (mWakeLock.isHeld()) mWakeLock.release();
            broadcastState();
        }
    }

    /**
     * Stops playback and releases resources.
     */
    public void stop() {
        stopPlayback();
        mIsPlaying.set(false);
        mIsPaused.set(false);
        if (mWakeLock.isHeld()) mWakeLock.release();
        broadcastState();
    }

    /**
     * Skips to the next song.
     */
    public void next() {
        if (mPlaylist.isEmpty()) return;
        int nextIndex = (mShuffle) ? getNextShuffleIndex() : (mCurrentIndex + 1) % mPlaylist.size();
        startPlayback(nextIndex);
    }

    /**
     * Skips to the previous song.
     */
    public void previous() {
        if (mPlaylist.isEmpty()) return;
        int prevIndex;
        if (mShuffle && mShuffleHistory.size() >= 2) {
            prevIndex = mShuffleHistory.get(mShuffleHistory.size() - 2);
            mShuffleHistory.remove(mShuffleHistory.size() - 1);
        } else {
            prevIndex = (mCurrentIndex > 0) ? mCurrentIndex - 1 : mPlaylist.size() - 1;
        }
        startPlayback(prevIndex);
    }

    /**
     * Seeks to the specified position in milliseconds.
     *
     * @param positionMs position in milliseconds
     */
    public void seekTo(int positionMs) {
        if (mExtractor != null) {
            long seekUs = positionMs * 1000L;
            mSeekPositionUs.set(seekUs);
            mSeekPending.set(true);
            mExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            if (mDecoder != null) mDecoder.flush();
            mAudioQueue.clear();
            mCurrentPositionUs = seekUs;
            broadcastState();
        }
    }

    /**
     * Plays the song at the given index.
     *
     * @param index playlist index
     */
    public void playSong(int index) {
        if (index >= 0 && index < mPlaylist.size()) startPlayback(index);
    }

    /**
     * Plays the song identified by its file path.
     *
     * @param path absolute file path
     */
    public void playSongByPath(@NonNull String path) {
        for (int i = 0; i < mPlaylist.size(); i++) {
            if (path.equals(mPlaylist.get(i).getPath())) {
                startPlayback(i);
                break;
            }
        }
    }

    // ========================================================================
    // Effect Control
    // ========================================================================

    /**
     * Sets playback speed.
     *
     * @param speed multiplier (0.5f – 1.5f)
     */
    public void setSpeed(float speed) {
        mCurrentSpeed = Math.max(MIN_SPEED, Math.min(MAX_SPEED, speed));
        if (mPitchShifter != null) mPitchShifter.setTempo(mCurrentSpeed);
    }

    /**
     * Sets pitch shift.
     *
     * @param semitones shift in semitones (-6.0f – +6.0f)
     */
    public void setPitchSemitones(float semitones) {
        mCurrentPitchSemitones = Math.max(MIN_PITCH_SEMITONES, Math.min(MAX_PITCH_SEMITONES, semitones));
        if (mPitchShifter != null) mPitchShifter.setPitch(mCurrentPitchSemitones);
    }

    /**
     * Returns the current speed multiplier.
     *
     * @return speed (0.5 – 1.5)
     */
    public float getCurrentSpeed() { return mCurrentSpeed; }

    /**
     * Returns the current pitch shift in semitones.
     *
     * @return semitones (-6.0 – +6.0)
     */
    public float getCurrentPitchSemitones() { return mCurrentPitchSemitones; }

    /**
     * Returns the audio session ID for equalizer attachment.
     *
     * @return audio session ID
     */
    public int getAudioSessionId() { return mAudioSessionId; }

    // ========================================================================
    // Repeat / Shuffle
    // ========================================================================

    /**
     * Sets repeat mode.
     *
     * @param mode 0 = off, 1 = all, 2 = one
     */
    public void setRepeatMode(int mode) { mRepeatMode = mode; }

    /**
     * Returns the current repeat mode.
     *
     * @return repeat mode
     */
    public int getRepeatMode() { return mRepeatMode; }

    /**
     * Enables or disables shuffle.
     *
     * @param shuffle true to enable shuffle
     */
    public void setShuffle(boolean shuffle) { mShuffle = shuffle; if (shuffle) buildShuffleHistory(); }

    /**
     * Returns true if shuffle is enabled.
     *
     * @return shuffle state
     */
    public boolean isShuffle() { return mShuffle; }

    // ========================================================================
    // Internal Playback Implementation
    // ========================================================================

    /**
     * Starts playback of the song at the given playlist index.
     * Stops current playback, opens the file, and begins decoding/playback loops.
     *
     * @param index playlist index
     */
    private void startPlayback(int index) {
        stopPlayback();
        mCurrentIndex = index;
        Song song = mPlaylist.get(index);
        File audioFile = new File(song.getPath());
        if (!audioFile.exists() || !audioFile.canRead()) {
            Log.e(TAG, "File not readable: " + song.getPath());
            next();
            return;
        }

        try {
            // Setup extractor
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(audioFile.getAbsolutePath());

            // Find audio track
            int audioTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrackIndex = i;
                    break;
                }
            }
            if (audioTrackIndex == -1) throw new IOException("No audio track");

            mExtractor.selectTrack(audioTrackIndex);
            MediaFormat format = mExtractor.getTrackFormat(audioTrackIndex);
            mSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            mChannelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mDurationUs = format.containsKey(MediaFormat.KEY_DURATION) ? format.getLong(MediaFormat.KEY_DURATION) : 0;
            mCurrentPositionUs = 0;

            // Setup decoder
            String mime = format.getString(MediaFormat.KEY_MIME);
            mDecoder = MediaCodec.createDecoderByType(mime);
            mDecoder.configure(format, null, null, 0);
            mDecoder.start();

            // Setup pitch shifter
            mPitchShifter = new PitchShifter(mSampleRate, mChannelCount);
            mPitchShifter.setTempo(mCurrentSpeed);
            mPitchShifter.setPitch(mCurrentPitchSemitones);

            // Setup audio track
            initAudioTrack();

            // Request audio focus
            requestAudioFocus();

            // Start audio track
            mAudioTrack.play();

            // Reset state
            mIsPlaying.set(true);
            mIsPaused.set(false);
            mInputEOS.set(false);
            mOutputEOS.set(false);
            mAudioQueue.clear();

            // Start threads
            mIsDecoding.set(true);
            mDecodeHandler.post(this::decodeLoop);
            mPlaybackHandler.post(this::playbackLoop);

            if (!mWakeLock.isHeld()) mWakeLock.acquire(10 * 60 * 1000L);
            broadcastState();

        } catch (Exception e) {
            Log.e(TAG, "Failed to start playback", e);
            next();
        }
    }

    /**
     * Initialises the AudioTrack with current sample rate and channel count.
     */
    private void initAudioTrack() {
        if (mAudioTrack != null) {
            mAudioTrack.release();
        }
        int channelConfig = (mChannelCount == 1) ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
        int bufferSize = AudioTrack.getMinBufferSize(mSampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT);
        // Use a larger buffer to avoid underruns
        bufferSize = Math.max(bufferSize, mSampleRate * mChannelCount * 2 / 10); // 100ms buffer

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        AudioFormat format = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(mSampleRate)
                .setChannelMask(channelConfig)
                .build();
        mAudioTrack = new AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        mAudioSessionId = mAudioTrack.getAudioSessionId();
        EqualizerManager.getInstance(this).attachToAudioSession(mAudioSessionId);
    }

    /**
     * Decoding loop: reads encoded data from extractor, decodes to PCM, and queues it.
     */
    private void decodeLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;

        while (mIsDecoding.get() && !mOutputEOS.get()) {
            if (mSeekPending.getAndSet(false)) {
                mDecoder.flush();
                inputDone = false;
                mInputEOS.set(false);
                continue;
            }

            // Feed input
            if (!inputDone) {
                int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
                if (inputIndex >= 0) {
                    ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                    if (inputBuffer != null) {
                        int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                        if (sampleSize < 0) {
                            mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                            mInputEOS.set(true);
                        } else {
                            long presentationUs = mExtractor.getSampleTime();
                            mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationUs, 0);
                            mExtractor.advance();
                        }
                    }
                }
            }

            // Get output
            int outputIndex = mDecoder.dequeueOutputBuffer(info, TIMEOUT_US);
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                if (outputBuffer != null && info.size > 0) {
                    int sampleCount = info.size / 2; // 16-bit PCM
                    short[] pcm = new short[sampleCount];
                    outputBuffer.order(ByteOrder.LITTLE_ENDIAN);
                    outputBuffer.asShortBuffer().get(pcm);

                    // Queue PCM frame
                    try {
                        mAudioQueue.offer(pcm, 50, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }

                    if (info.presentationTimeUs > 0) {
                        mCurrentPositionUs = info.presentationTimeUs;
                    }
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    mOutputEOS.set(true);
                    mAudioQueue.offer(new short[0]); // sentinel
                }
            }
        }
    }

    /**
     * Playback loop: takes PCM frames from queue, applies pitch/tempo, and writes to AudioTrack.
     */
    private void playbackLoop() {
        while (mIsDecoding.get() && !mOutputEOS.get()) {
            short[] pcm;
            try {
                pcm = mAudioQueue.poll(50, TimeUnit.MILLISECONDS);
                if (pcm == null) continue;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            if (pcm.length == 0) break; // EOS

            // Apply pitch/tempo
            short[] processed = pcm;
            if (mPitchShifter != null && (mCurrentSpeed != 1.0f || mCurrentPitchSemitones != 0f)) {
                int frames = pcm.length / mChannelCount;
                mPitchShifter.putFrames(pcm, frames);
                int avail = mPitchShifter.numFrames();
                if (avail > 0) {
                    short[] shifted = new short[avail * mChannelCount];
                    int received = mPitchShifter.receiveFrames(shifted, avail);
                    if (received > 0) processed = shifted;
                }
            }

            // Write to AudioTrack
            if (mAudioTrack != null && mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                mAudioTrack.write(processed, 0, processed.length);
            }
        }

        // Song finished
        mMainHandler.post(this::onSongCompletion);
    }

    /**
     * Called when the current song ends. Handles repeat modes and advances to next song.
     */
    private void onSongCompletion() {
        if (mRepeatMode == 2) { // repeat one
            startPlayback(mCurrentIndex);
        } else if (mRepeatMode == 1) { // repeat all
            int nextIndex = (mCurrentIndex + 1) % mPlaylist.size();
            startPlayback(nextIndex);
        } else if (mCurrentIndex + 1 < mPlaylist.size()) {
            startPlayback(mCurrentIndex + 1);
        } else {
            stop(); // end of playlist
        }
    }

    /**
     * Stops playback and releases all resources.
     */
    private void stopPlayback() {
        mIsDecoding.set(false);
        if (mDecodeThread != null) mDecodeThread.getLooper().quitSafely();
        if (mPlaybackThread != null) mPlaybackThread.getLooper().quitSafely();

        if (mAudioTrack != null) {
            mAudioTrack.pause();
            mAudioTrack.flush();
            mAudioTrack.stop();
            mAudioTrack.release();
            mAudioTrack = null;
        }
        if (mPitchShifter != null) {
            mPitchShifter.close();
            mPitchShifter = null;
        }
        if (mDecoder != null) {
            mDecoder.stop();
            mDecoder.release();
            mDecoder = null;
        }
        if (mExtractor != null) {
            mExtractor.release();
            mExtractor = null;
        }
        mAudioQueue.clear();
    }

    // ========================================================================
    // Shuffle Helpers
    // ========================================================================

    /**
     * Builds a random order of playlist indices for shuffle mode.
     */
    private void buildShuffleHistory() {
        mShuffleHistory.clear();
        for (int i = 0; i < mPlaylist.size(); i++) mShuffleHistory.add(i);
        Collections.shuffle(mShuffleHistory, mRandom);
    }

    /**
     * Returns the next index in shuffle order.
     *
     * @return playlist index
     */
    private int getNextShuffleIndex() {
        if (mShuffleHistory.isEmpty()) buildShuffleHistory();
        int next = mShuffleHistory.remove(0);
        mShuffleHistory.add(next);
        return next;
    }

    // ========================================================================
    // Audio Focus
    // ========================================================================

    /**
     * Sets up audio focus for Android O and above.
     */
    private void setupAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            mAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(this)
                    .build();
        }
    }

    /**
     * Requests audio focus from the system.
     */
    private void requestAudioFocus() {
        if (mAudioManager == null) return;
        int result;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            result = mAudioManager.requestAudioFocus((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            result = mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Log.w(TAG, "Audio focus request denied");
        }
    }

    /**
     * Abandons audio focus.
     */
    private void abandonAudioFocus() {
        if (mAudioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mAudioFocusRequest != null) {
            mAudioManager.abandonAudioFocusRequest((android.media.AudioFocusRequest) mAudioFocusRequest);
        } else {
            mAudioManager.abandonAudioFocus(this);
        }
    }

    /**
     * Called when audio focus changes.
     *
     * @param focusChange the new focus state
     */
    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // Lower volume – not implemented, we just continue
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (!isPlaying() && mIsPaused.get()) {
                    play();
                }
                break;
        }
    }

    // ========================================================================
    // Broadcast Updates
    // ========================================================================

    /**
     * Sends a broadcast with current playback state.
     */
    private void broadcastState() {
        Intent intent = new Intent("UPDATE_PLAYER");
        intent.putExtra("is_playing", isPlaying());
        intent.putExtra("position", getCurrentPosition());
        intent.putExtra("duration", getDuration());
        sendBroadcast(intent);
    }
}