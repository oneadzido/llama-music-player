package com.ark.llama;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter for displaying folders in the FolderManager RecyclerView.
 * 
 * <p>This adapter handles both regular folder items and the special "Loose Tracks"
 * entry. It provides touch feedback, theme support, and debounced click handling
 * for remove buttons.</p>
 * 
 * <p>Follows Google's recommendations for ViewHolder pattern and efficient list updates.</p>
 * 
 * @see FolderManager
 * @see RecyclerView.Adapter
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {

    /** Application context for accessing resources and services. */
    private final Context context;
    
    /** List of folder items to display. */
    private final List<FolderItem> folders;
    
    /** Listener for folder removal events. */
    @NonNull
    private final OnFolderRemoveListener removeListener;
    
    /** Helper for applying theme colors to UI elements. */
    private final ThemeHelper themeHelper;
    
    /** Theme manager for getting current color. */
    private final ThemeManager themeManager;

    /**
     * Flag indicating whether remove buttons should be enabled.
     * Disabled during playlist updates to prevent race conditions.
     */
    private boolean shouldEnableRemoveButtons = true;

    /**
     * Listener interface for folder removal events.
     * 
     * <p>Activities that use this adapter must implement this interface
     * to handle folder removal operations.</p>
     */
    public interface OnFolderRemoveListener {
        
        /**
         * Called when a regular folder is removed.
         * 
         * @param folderUriString The URI string of the folder to remove
         * @param position The position of the folder in the list
         */
        void onFolderRemove(@NonNull String folderUriString, int position);
        
        /**
         * Called when the Loose Tracks entry is removed.
         */
        void onLooseTracksRemove();
    }

    /**
     * Represents a folder item in the list.
     * 
     * <p>Can be either a real folder (with a URI) or the special
     * "Loose Tracks" entry that displays uncategorized songs.</p>
     */
    public static class FolderItem {
        
        /** The URI string of the folder, or "LOOSE_TRACKS" for the special entry. */
        @NonNull
        public final String uriString;
        
        /** The display name shown to the user. */
        @NonNull
        public final String displayName;
        
        /** True if this is the special Loose Tracks entry. */
        public final boolean isLooseTracks;
        
        /** Number of loose tracks (only valid if isLooseTracks is true). */
        public final int looseTracksCount;

        /**
         * Constructor for real folder items.
         * 
         * @param uriString The URI string of the folder
         * @param displayName The display name of the folder
         */
        public FolderItem(@NonNull String uriString, @NonNull String displayName) {
            this.uriString = uriString;
            this.displayName = displayName;
            this.isLooseTracks = false;
            this.looseTracksCount = 0;
        }

        /**
         * Constructor for the special "Loose Tracks" item.
         * 
         * @param looseTracksCount The number of loose tracks to display
         */
        public FolderItem(int looseTracksCount) {
            this.uriString = "LOOSE_TRACKS";
            this.displayName = "Loose Tracks [" + looseTracksCount + " song" 
                + (looseTracksCount != 1 ? "s" : "") + "]";
            this.isLooseTracks = true;
            this.looseTracksCount = looseTracksCount;
        }
    }

    /**
     * Constructs a new FolderAdapter.
     * 
     * @param context The application context
     * @param folders The list of folder items to display
     * @param listener The listener for folder removal events
     */
    public FolderAdapter(@NonNull Context context, @NonNull List<FolderItem> folders, 
                         @NonNull OnFolderRemoveListener listener) {
        this.context = context;
        this.folders = folders;
        this.removeListener = listener;
        this.themeHelper = ThemeHelper.getInstance(context);
        this.themeManager = ThemeManager.getInstance(context);
    }

    /**
     * Enables all remove buttons in the list.
     * 
     * <p>Use this method to re-enable remove buttons after a playlist update
     * completes or when returning to normal operation.</p>
     */
    public void enableRemoveButtons() {
        this.shouldEnableRemoveButtons = true;
        notifyDataSetChanged();
    }

    /**
     * Disables all remove buttons in the list.
     * 
     * <p>Use this method during playlist updates to prevent folder modifications
     * while the playlist is being rebuilt. The visual state of all remove buttons
     * is updated immediately.</p>
     */
    public void disableRemoveButtons() {
        this.shouldEnableRemoveButtons = false;
        notifyDataSetChanged();
    }

    /**
     * Creates a new ViewHolder for a folder item.
     * 
     * @param parent The parent ViewGroup
     * @param viewType The view type (not used)
     * @return A new FolderViewHolder
     */
    @NonNull
    @Override
    public FolderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_folder, parent, false);
        return new FolderViewHolder(view);
    }

    /**
     * Binds data to a ViewHolder at the specified position.
     * 
     * <p>This method configures the folder icon, folder name, remove button state,
     * and touch feedback for the list item.</p>
     *
     * @param holder The ViewHolder to bind data to
     * @param position The position in the list
     */
    @Override
    public void onBindViewHolder(@NonNull final FolderViewHolder holder, int position) {
        if (position < 0 || position >= folders.size()) {
            return;
        }
        
        final FolderItem item = folders.get(position);
        if (item == null) {
            return;
        }
        
        final View itemView = holder.itemView;
        final Button removeButton = holder.removeButton;

        // Configure folder icon with FontAwesome and theme color
        if (holder.folderIcon != null) {
            holder.folderIcon.setTypeface(FontAwesome.getTypeface());
            holder.folderIcon.setText(FontAwesome.FOLDER);
            // Apply theme color to folder icon
            if (themeManager != null && themeHelper != null) {
                themeHelper.setThemeColor(themeManager.getCurrentColor());
                holder.folderIcon.setTextColor(themeHelper.getThemeColorInt());
            }
        }

        // Set folder display name
        if (holder.folderName != null) {
            holder.folderName.setText(item.displayName);
        }

        // Configure remove button based on enabled state with theme color
        if (removeButton != null) {
            configureRemoveButton(removeButton, item, holder);
        }

        // Add touch feedback for list items (darken on press)
        itemView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setBackgroundColor(Color.parseColor("#2A2A2A"));
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setBackgroundColor(Color.TRANSPARENT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Configures the remove button based on current enabled state.
     * 
     * @param removeButton The button to configure
     * @param item The folder item associated with this button
     * @param holder The ViewHolder containing the button
     */
    private void configureRemoveButton(@NonNull Button removeButton, 
                                        @NonNull FolderItem item, 
                                        @NonNull FolderViewHolder holder) {
        
        // Set enabled state and apply theme styling
        removeButton.setEnabled(shouldEnableRemoveButtons);
        
        // Apply theme color to remove button
        if (themeManager != null && themeHelper != null) {
            themeHelper.setThemeColor(themeManager.getCurrentColor());
            themeHelper.updateButton(removeButton, shouldEnableRemoveButtons);
        }
        
        // Add touch animation for visual feedback
        animateButton(removeButton);
        
        if (shouldEnableRemoveButtons) {
            removeButton.setOnClickListener(createRemoveClickListener(item, holder));
        } else {
            removeButton.setOnClickListener(null);
        }
    }
    
    /**
     * Adds a scale animation to a button for visual touch feedback.
     * 
     * @param button The button to animate
     */
    private void animateButton(@NonNull final Button button) {
        final float SCALE_DOWN = 0.97f;
        final float SCALE_NORMAL = 1.0f;
        final int ANIMATION_DURATION_MS = 80;
        
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(SCALE_DOWN)
                                   .scaleY(SCALE_DOWN)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(SCALE_NORMAL)
                                   .scaleY(SCALE_NORMAL)
                                   .setDuration(ANIMATION_DURATION_MS)
                                   .start();
                        break;
                        
                    default:
                        break;
                }
                return false;
            }
        });
    }

    /**
     * Creates a click listener for the remove button with debouncing protection.
     * 
     * <p>Debouncing prevents rapid multiple clicks that could cause errors.</p>
     *
     * @param item The folder item associated with this button
     * @param holder The ViewHolder containing the button
     * @return A new View.OnClickListener
     */
    @NonNull
    private View.OnClickListener createRemoveClickListener(@NonNull final FolderItem item, 
                                                             @NonNull final FolderViewHolder holder) {
        return new View.OnClickListener() {
            private long lastClickTime = 0;
            private static final long DEBOUNCE_DELAY_MS = 250;

            @Override
            public void onClick(@NonNull View view) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastClickTime < DEBOUNCE_DELAY_MS) {
                    return; // Debounce rapid clicks
                }
                lastClickTime = currentTime;

                int position = holder.getAdapterPosition();
                if (position == RecyclerView.NO_POSITION) {
                    return;
                }

                if (item.isLooseTracks) {
                    removeListener.onLooseTracksRemove();
                } else {
                    removeListener.onFolderRemove(item.uriString, position);
                }
            }
        };
    }

    /**
     * Returns the total number of items in the list.
     * 
     * @return The number of folder items
     */
    @Override
    public int getItemCount() {
        return folders.size();
    }

    /**
     * Updates the folder list with new data.
     * 
     * <p>This method clears the existing list and adds all items from the new list,
     * then notifies the adapter that the data has changed.</p>
     *
     * @param newFolders The new list of folder items
     */
    public void updateFolders(@NonNull List<FolderItem> newFolders) {
        folders.clear();
        folders.addAll(newFolders);
        notifyDataSetChanged();
    }

    /**
     * Removes an item at the specified position with proper animation.
     * 
     * @param position The position of the item to remove
     */
    public void removeItem(int position) {
        if (position >= 0 && position < folders.size()) {
            folders.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, folders.size() - position);
        }
    }

    /**
     * ViewHolder for folder items following Google's ViewHolder pattern.
     * 
     * <p>This class caches references to the views within each item layout
     * to improve performance during scrolling.</p>
     */
    static class FolderViewHolder extends RecyclerView.ViewHolder {
        
        /** TextView displaying the folder icon. */
        @Nullable
        final TextView folderIcon;
        
        /** TextView displaying the folder name. */
        @Nullable
        final TextView folderName;
        
        /** Button for removing the folder. */
        @Nullable
        final Button removeButton;

        /**
         * Constructs a new FolderViewHolder.
         * 
         * @param itemView The item view for this ViewHolder
         */
        FolderViewHolder(@NonNull View itemView) {
            super(itemView);
            folderIcon = (TextView) itemView.findViewById(R.id.folderIcon);
            folderName = (TextView) itemView.findViewById(R.id.folderName);
            removeButton = (Button) itemView.findViewById(R.id.removeButton);
        }
    }
}