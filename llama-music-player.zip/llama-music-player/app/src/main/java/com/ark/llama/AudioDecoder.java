package com.ark.llama;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * AudioDecoder - Decodes audio files to 16-bit PCM for SoundTouch processing.
 * 
 * <p>Fixed buffer underrun by increasing buffer to 2MB and adding compaction.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class AudioDecoder {
    
    private static final String TAG = "AudioDecoder";
    private static final long TIMEOUT_US = 10000;
    
    /** Increased to 2MB to prevent underruns (was 512KB). */
    private static final int DEFAULT_BUFFER_SIZE = 2 * 1024 * 1024;
    
    private static final int MAX_FRAMES_PER_READ = 8192;
    private static final int MIN_SAMPLE_RATE = 8000;
    private static final int MAX_SAMPLE_RATE = 192000;
    private static final int MIN_CHANNELS = 1;
    private static final int MAX_CHANNELS = 2;
    
    @Nullable private MediaExtractor mExtractor;
    @Nullable private MediaCodec mDecoder;
    @Nullable private MediaFormat mFormat;
    private int mTrackIndex = -1;
    private volatile boolean mIsInitialized = false;
    private long mDurationUs = 0;
    private int mDurationMs = 0;
    private int mContainerSampleRate = 44100;
    private int mContainerChannels = 2;
    private int mActualSampleRate = 0;
    private int mActualChannels = 0;
    private boolean mOutputFormatValidated = false;
    @Nullable private String mMimeType = null;
    private long mCurrentPositionUs = 0;
    private boolean mIsEOS = false;
    
    /** Larger buffer to hold several seconds of PCM. */
    @Nullable private byte[] mPcmBuffer;
    private int mPcmBufferPosition = 0;   // read cursor
    private int mPcmBufferLength = 0;     // valid data length
    
    public AudioDecoder() {
        Log.d(TAG, "AudioDecoder instance created");
    }
    
    public boolean open(@NonNull String filePath) {
        Log.d(TAG, "open: " + filePath);
        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);
            mTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mTrackIndex = i;
                    mFormat = format;
                    mMimeType = mime;
                    Log.d(TAG, "Found audio track: " + mime);
                    break;
                }
            }
            if (mTrackIndex == -1) {
                Log.e(TAG, "No audio track found");
                release();
                return false;
            }
            mExtractor.selectTrack(mTrackIndex);
            extractContainerProperties();
            mDecoder = MediaCodec.createDecoderByType(mMimeType);
            mDecoder.configure(mFormat, null, null, 0);
            mDecoder.start();
            mPcmBuffer = new byte[DEFAULT_BUFFER_SIZE];
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mIsEOS = false;
            mOutputFormatValidated = false;
            mCurrentPositionUs = 0;
            mIsInitialized = true;
            Log.d(TAG, "open success: " + mMimeType + ", " + getSampleRate() + "Hz, " +
                  getChannels() + "ch, duration=" + mDurationMs + "ms, buffer=" + DEFAULT_BUFFER_SIZE + " bytes");
            return true;
        } catch (IOException | IllegalArgumentException e) {
            Log.e(TAG, "open failed", e);
            release();
            return false;
        }
    }
    
    public int read(@NonNull short[] buffer, int frames) {
        if (!mIsInitialized) {
            Log.e(TAG, "read: not initialized");
            return -1;
        }
        if (frames <= 0) return 0;
        int safeFrames = Math.min(frames, MAX_FRAMES_PER_READ);
        int channels = getChannels();
        int samplesNeeded = safeFrames * channels;
        int samplesRead = 0;
        
        try {
            while (samplesRead < samplesNeeded && !mIsEOS) {
                // If buffer has data, copy as much as possible
                if (mPcmBufferPosition < mPcmBufferLength) {
                    int bytesRemaining = mPcmBufferLength - mPcmBufferPosition;
                    int samplesRemaining = bytesRemaining / 2;
                    int toRead = Math.min(samplesRemaining, samplesNeeded - samplesRead);
                    for (int i = 0; i < toRead; i++) {
                        int byteOffset = mPcmBufferPosition + (i * 2);
                        short sample = (short) ((mPcmBuffer[byteOffset + 1] << 8) | 
                                                 (mPcmBuffer[byteOffset] & 0xFF));
                        buffer[samplesRead + i] = sample;
                    }
                    samplesRead += toRead;
                    mPcmBufferPosition += toRead * 2;
                    
                    // Compact buffer if we've consumed a significant portion
                    if (mPcmBufferPosition > 0 && mPcmBufferPosition >= mPcmBufferLength / 2) {
                        compactBuffer();
                    }
                }
                
                // If we still need more samples, try to decode more
                if (samplesRead < samplesNeeded && !mIsEOS) {
                    feedDecoder();
                    drainDecoder();
                    
                    // If after draining we still have no data and not EOS, wait a bit
                    if (mPcmBufferPosition >= mPcmBufferLength && !mIsEOS) {
                        Thread.sleep(5);
                    }
                }
            }
            int framesRead = samplesRead / channels;
            if (framesRead == 0 && mIsEOS) {
                Log.d(TAG, "read: EOS reached, returning 0");
            } else if (framesRead > 0 && framesRead < frames) {
                Log.v(TAG, "read: " + framesRead + "/" + frames + " frames");
            }
            return framesRead;
        } catch (InterruptedException e) {
            Log.w(TAG, "read interrupted", e);
            Thread.currentThread().interrupt();
            return -1;
        } catch (Exception e) {
            Log.e(TAG, "read error", e);
            return -1;
        }
    }
    
    /** Compacts the buffer by moving remaining data to the front. */
    private void compactBuffer() {
        if (mPcmBufferPosition > 0 && mPcmBufferPosition < mPcmBufferLength) {
            int remaining = mPcmBufferLength - mPcmBufferPosition;
            System.arraycopy(mPcmBuffer, mPcmBufferPosition, mPcmBuffer, 0, remaining);
            mPcmBufferLength = remaining;
            mPcmBufferPosition = 0;
        } else if (mPcmBufferPosition >= mPcmBufferLength) {
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
        }
    }
    
    public void seekTo(int positionMs) {
        if (!mIsInitialized) return;
        try {
            long seekTimeUs = Math.max(0, Math.min(positionMs * 1000L, mDurationUs));
            if (mExtractor != null) {
                mExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            if (mDecoder != null) {
                mDecoder.flush();
            }
            mIsEOS = false;
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mCurrentPositionUs = seekTimeUs;
            Log.d(TAG, "seekTo: " + positionMs + "ms");
        } catch (Exception e) {
            Log.e(TAG, "seekTo error", e);
        }
    }
    
    public int getCurrentPosition() {
        return (int) (mCurrentPositionUs / 1000);
    }
    
    public int getDuration() {
        return mDurationMs;
    }
    
    public int getSampleRate() {
        return mActualSampleRate > 0 ? mActualSampleRate : mContainerSampleRate;
    }
    
    public int getChannels() {
        return mActualChannels > 0 ? mActualChannels : mContainerChannels;
    }
    
    @Nullable
    public String getMimeType() {
        return mMimeType;
    }
    
    public boolean isInitialized() {
        return mIsInitialized;
    }
    
    public boolean isEOS() {
        return mIsEOS;
    }
    
    public void release() {
        Log.d(TAG, "release");
        mIsInitialized = false;
        mIsEOS = false;
        if (mDecoder != null) {
            try { mDecoder.stop(); mDecoder.release(); } catch (Exception e) { Log.e(TAG, "release decoder error", e); }
            mDecoder = null;
        }
        if (mExtractor != null) {
            try { mExtractor.release(); } catch (Exception e) { Log.e(TAG, "release extractor error", e); }
            mExtractor = null;
        }
        mPcmBuffer = null;
        mFormat = null;
        mMimeType = null;
        mTrackIndex = -1;
        mPcmBufferPosition = 0;
        mPcmBufferLength = 0;
        mOutputFormatValidated = false;
        mDurationUs = 0;
        mDurationMs = 0;
        mCurrentPositionUs = 0;
        mActualSampleRate = 0;
        mActualChannels = 0;
    }
    
    private void extractContainerProperties() {
        if (mFormat == null) return;
        if (mFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mDurationUs = mFormat.getLong(MediaFormat.KEY_DURATION);
            mDurationMs = (int) (mDurationUs / 1000);
        }
        if (mFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            mContainerSampleRate = mFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        }
        if (mFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            mContainerChannels = mFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mContainerChannels = Math.max(MIN_CHANNELS, Math.min(MAX_CHANNELS, mContainerChannels));
        }
        Log.d(TAG, "Container: " + mContainerSampleRate + "Hz, " + mContainerChannels + "ch");
    }
    
    private void feedDecoder() {
        if (mDecoder == null || mExtractor == null) return;
        try {
            int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
            if (inputIndex >= 0) {
                ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                if (inputBuffer != null) {
                    inputBuffer.clear();
                    int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                    if (sampleSize >= 0) {
                        long presentationTimeUs = mExtractor.getSampleTime();
                        mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                        mExtractor.advance();
                    } else {
                        mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        Log.d(TAG, "EOS queued to decoder");
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "feedDecoder error", e);
        }
    }
    
    private void drainDecoder() {
        if (mDecoder == null) return;
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        try {
            int outputIndex = mDecoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US);
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                if (!mOutputFormatValidated) {
                    MediaFormat outputFormat = mDecoder.getOutputFormat();
                    if (outputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        mActualSampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        Log.d(TAG, "Actual sample rate: " + mActualSampleRate);
                    }
                    if (outputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        mActualChannels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        Log.d(TAG, "Actual channels: " + mActualChannels);
                    }
                    mOutputFormatValidated = true;
                }
                if (bufferInfo.size > 0 && outputBuffer != null) {
                    if (bufferInfo.presentationTimeUs > 0) {
                        mCurrentPositionUs = bufferInfo.presentationTimeUs;
                    }
                    outputBuffer.position(bufferInfo.offset);
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                    
                    // Compact buffer to maximize free space before copying
                    compactBuffer();
                    
                    int remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                    int toCopy = Math.min(bufferInfo.size, remainingSpace);
                    if (toCopy > 0) {
                        outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                        mPcmBufferLength += toCopy;
                    } else {
                        Log.e(TAG, "PCM buffer full, cannot copy " + bufferInfo.size + " bytes - increase buffer size");
                        // We cannot drop data, so we will increase buffer dynamically (fallback)
                        if (remainingSpace == 0) {
                            // Try to expand buffer (safe fallback)
                            byte[] newBuffer = new byte[mPcmBuffer.length + DEFAULT_BUFFER_SIZE];
                            System.arraycopy(mPcmBuffer, 0, newBuffer, 0, mPcmBufferLength);
                            mPcmBuffer = newBuffer;
                            remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                            toCopy = Math.min(bufferInfo.size, remainingSpace);
                            if (toCopy > 0) {
                                outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                                mPcmBufferLength += toCopy;
                                Log.w(TAG, "Expanded buffer to " + mPcmBuffer.length + " bytes");
                            }
                        }
                    }
                }
                mDecoder.releaseOutputBuffer(outputIndex, false);
            }
            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                mIsEOS = true;
                Log.d(TAG, "Decoder EOS reached");
            }
        } catch (Exception e) {
            Log.e(TAG, "drainDecoder error", e);
        }
    }
}