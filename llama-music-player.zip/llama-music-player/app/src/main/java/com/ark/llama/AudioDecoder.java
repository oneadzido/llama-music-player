package com.ark.llama;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * AudioDecoder - Decodes audio files to 16-bit PCM for SoundTouch processing.
 * 
 * <p>Fixed buffer underrun by increasing buffer to 2MB and adding compaction.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is designed to be used from a single thread (the playback thread).
 * The read() method uses Object.wait() for synchronization allowing immediate
 * wakeup when new data becomes available or when the decoder is closed.</p>
 * 
 * <h3>Buffer Management</h3>
 * <p>The PCM buffer uses a compaction strategy to maintain a sliding window of
 * decoded audio data. When more than half the buffer is consumed, the remaining
 * data is moved to the front, maximizing available space for new data.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class AudioDecoder {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "AudioDecoder";
    
    /** Timeout for decoder operations in microseconds (10ms). */
    private static final long TIMEOUT_US = 10000;
    
    /** Default PCM buffer size (2MB) - increased to prevent buffer underruns. */
    private static final int DEFAULT_BUFFER_SIZE = 2 * 1024 * 1024;
    
    /** Maximum frames to read per decoder call. */
    private static final int MAX_FRAMES_PER_READ = 8192;
    
    /** Minimum supported sample rate (8kHz). */
    private static final int MIN_SAMPLE_RATE = 8000;
    
    /** Maximum supported sample rate (192kHz). */
    private static final int MAX_SAMPLE_RATE = 192000;
    
    /** Minimum number of audio channels (mono). */
    private static final int MIN_CHANNELS = 1;
    
    /** Maximum number of audio channels (stereo). */
    private static final int MAX_CHANNELS = 2;
    
    /** Maximum wait time for decoder when not ready (milliseconds) - used with Object.wait. */
    private static final int DECODER_WAIT_MS = 100;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** MediaExtractor for reading audio tracks from file. */
    @Nullable private MediaExtractor mExtractor;
    
    /** MediaCodec decoder for converting compressed audio to PCM. */
    @Nullable private MediaCodec mDecoder;
    
    /** MediaFormat of the selected audio track. */
    @Nullable private MediaFormat mFormat;
    
    /** Index of the selected audio track. */
    private int mTrackIndex = -1;
    
    /** Flag indicating if the decoder is properly initialized. */
    private volatile boolean mIsInitialized = false;
    
    /** Duration of the audio file in microseconds. */
    private long mDurationUs = 0;
    
    /** Duration of the audio file in milliseconds. */
    private int mDurationMs = 0;
    
    /** Sample rate from container format (may differ from actual decoder output). */
    private int mContainerSampleRate = 44100;
    
    /** Channel count from container format (may differ from actual decoder output). */
    private int mContainerChannels = 2;
    
    /** Actual sample rate from decoder output (validated after first frame). */
    private int mActualSampleRate = 0;
    
    /** Actual channel count from decoder output (validated after first frame). */
    private int mActualChannels = 0;
    
    /** Flag indicating if decoder output format has been validated. */
    private boolean mOutputFormatValidated = false;
    
    /** MIME type of the audio track (e.g., "audio/mpeg", "audio/flac"). */
    @Nullable private String mMimeType = null;
    
    /** Current playback position in microseconds. */
    private long mCurrentPositionUs = 0;
    
    /** Flag indicating if end of stream has been reached. */
    private boolean mIsEOS = false;
    
    /** Larger buffer to hold several seconds of PCM. */
    @Nullable private byte[] mPcmBuffer;
    
    /** Read cursor position in the PCM buffer. */
    private int mPcmBufferPosition = 0;
    
    /** Valid data length in the PCM buffer. */
    private int mPcmBufferLength = 0;
    
    /** Lock object for decoder operations. */
    private final Object mDecoderLock = new Object();
    
    /** Flag indicating if the decoder is in the process of releasing. */
    private volatile boolean mIsReleasing = false;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new AudioDecoder instance.
     * 
     * <p>The decoder is not initialized until {@link #open(String)} is called.</p>
     */
    public AudioDecoder() {
        Log.d(TAG, "AudioDecoder instance created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Opens an audio file for decoding.
     * 
     * <p>This method initializes the MediaExtractor, selects the first audio track,
     * creates and configures the MediaCodec decoder, and prepares the PCM buffer.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @return true if successful, false otherwise
     */
    public boolean open(@NonNull String filePath) {
        Log.d(TAG, "open: " + filePath);
        try {
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);
            mTrackIndex = -1;
            
            // Find the first audio track
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mTrackIndex = i;
                    mFormat = format;
                    mMimeType = mime;
                    Log.d(TAG, "Found audio track: " + mime);
                    break;
                }
            }
            
            if (mTrackIndex == -1) {
                Log.e(TAG, "No audio track found");
                release();
                return false;
            }
            
            mExtractor.selectTrack(mTrackIndex);
            extractContainerProperties();
            
            mDecoder = MediaCodec.createDecoderByType(mMimeType);
            mDecoder.configure(mFormat, null, null, 0);
            mDecoder.start();
            
            mPcmBuffer = new byte[DEFAULT_BUFFER_SIZE];
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mIsEOS = false;
            mOutputFormatValidated = false;
            mCurrentPositionUs = 0;
            mIsInitialized = true;
            mIsReleasing = false;
            
            // Wake up any waiting threads to signal readiness
            synchronized (mDecoderLock) {
                mDecoderLock.notifyAll();
            }
            
            Log.d(TAG, "open success: " + mMimeType + ", " + getSampleRate() + "Hz, " +
                  getChannels() + "ch, duration=" + mDurationMs + "ms, buffer=" + DEFAULT_BUFFER_SIZE + " bytes");
            return true;
            
        } catch (IOException | IllegalArgumentException e) {
            Log.e(TAG, "open failed", e);
            release();
            return false;
        }
    }
    
    /**
     * Reads PCM audio data into the provided buffer.
     * 
     * <p>This method reads up to the specified number of frames (each frame contains
     * one sample per channel). If not enough data is available, it will decode more
     * data from the source file. If the decoder is not ready, it will wait using
     * Object.wait() for proper thread synchronization.</p>
     * 
     * <p>The method returns the actual number of frames read, which may be less than
     * requested if end of stream is reached or if the decoder is closed.</p>
     *
     * @param buffer The destination buffer for PCM samples (16-bit signed)
     * @param frames The number of stereo frames to read
     * @return Number of frames actually read, or -1 on error
     */
    public int read(@NonNull short[] buffer, int frames) {
        if (!mIsInitialized) {
            Log.e(TAG, "read: not initialized");
            return -1;
        }
        if (frames <= 0) return 0;
        
        int safeFrames = Math.min(frames, MAX_FRAMES_PER_READ);
        int channels = getChannels();
        int samplesNeeded = safeFrames * channels;
        int samplesRead = 0;
        
        try {
            while (samplesRead < samplesNeeded && !mIsEOS && !mIsReleasing) {
                // If buffer has data, copy as much as possible
                if (mPcmBufferPosition < mPcmBufferLength) {
                    int bytesRemaining = mPcmBufferLength - mPcmBufferPosition;
                    int samplesRemaining = bytesRemaining / 2;
                    int toRead = Math.min(samplesRemaining, samplesNeeded - samplesRead);
                    
                    for (int i = 0; i < toRead; i++) {
                        int byteOffset = mPcmBufferPosition + (i * 2);
                        short sample = (short) ((mPcmBuffer[byteOffset + 1] << 8) | 
                                                 (mPcmBuffer[byteOffset] & 0xFF));
                        buffer[samplesRead + i] = sample;
                    }
                    samplesRead += toRead;
                    mPcmBufferPosition += toRead * 2;
                    
                    // Compact buffer if we've consumed a significant portion
                    if (mPcmBufferPosition > 0 && mPcmBufferPosition >= mPcmBufferLength / 2) {
                        compactBuffer();
                    }
                }
                
                // If we still need more samples, try to decode more
                if (samplesRead < samplesNeeded && !mIsEOS && !mIsReleasing) {
                    feedDecoder();
                    drainDecoder();
                    
                    // If after draining we still have no data and not EOS, wait using Object.wait
                    if (mPcmBufferPosition >= mPcmBufferLength && !mIsEOS && !mIsReleasing) {
                        synchronized (mDecoderLock) {
                            // The wait will be interrupted immediately when release() is called
                            mDecoderLock.wait(DECODER_WAIT_MS);
                        }
                    }
                }
            }
            
            int framesRead = samplesRead / channels;
            if (framesRead == 0 && mIsEOS) {
                Log.d(TAG, "read: EOS reached, returning 0");
            } else if (framesRead > 0 && framesRead < frames) {
                Log.v(TAG, "read: " + framesRead + "/" + frames + " frames");
            }
            return framesRead;
            
        } catch (InterruptedException e) {
            Log.w(TAG, "read interrupted", e);
            Thread.currentThread().interrupt();
            return -1;
        } catch (Exception e) {
            Log.e(TAG, "read error", e);
            return -1;
        }
    }
    
    /**
     * Compacts the buffer by moving remaining data to the front.
     * 
     * <p>This method is called when more than half the buffer has been consumed.
     * It moves the remaining valid data to the beginning of the buffer and resets
     * the read position, maximizing available space for new data.</p>
     */
    private void compactBuffer() {
        if (mPcmBufferPosition > 0 && mPcmBufferPosition < mPcmBufferLength) {
            int remaining = mPcmBufferLength - mPcmBufferPosition;
            System.arraycopy(mPcmBuffer, mPcmBufferPosition, mPcmBuffer, 0, remaining);
            mPcmBufferLength = remaining;
            mPcmBufferPosition = 0;
        } else if (mPcmBufferPosition >= mPcmBufferLength) {
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
        }
    }
    
    /**
     * Seeks to the specified position in the audio file.
     * 
     * <p>This method flushes the decoder and resets the PCM buffer to ensure
     * clean playback from the new position.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(int positionMs) {
        if (!mIsInitialized) return;
        try {
            long seekTimeUs = Math.max(0, Math.min(positionMs * 1000L, mDurationUs));
            if (mExtractor != null) {
                mExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            if (mDecoder != null) {
                mDecoder.flush();
            }
            mIsEOS = false;
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mCurrentPositionUs = seekTimeUs;
            
            // Wake up any waiting decoder threads
            synchronized (mDecoderLock) {
                mDecoderLock.notifyAll();
            }
            
            Log.d(TAG, "seekTo: " + positionMs + "ms");
        } catch (Exception e) {
            Log.e(TAG, "seekTo error", e);
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     *
     * @return Current position in milliseconds
     */
    public int getCurrentPosition() {
        return (int) (mCurrentPositionUs / 1000);
    }
    
    /**
     * Returns the total duration of the audio file in milliseconds.
     *
     * @return Duration in milliseconds
     */
    public int getDuration() {
        return mDurationMs;
    }
    
    /**
     * Returns the sample rate of the decoded audio.
     * 
     * <p>If the decoder output format hasn't been validated yet, this returns
     * the container sample rate as a fallback.</p>
     *
     * @return Sample rate in Hz
     */
    public int getSampleRate() {
        return mActualSampleRate > 0 ? mActualSampleRate : mContainerSampleRate;
    }
    
    /**
     * Returns the number of audio channels.
     * 
     * <p>If the decoder output format hasn't been validated yet, this returns
     * the container channel count as a fallback.</p>
     *
     * @return Number of channels (1 for mono, 2 for stereo)
     */
    public int getChannels() {
        return mActualChannels > 0 ? mActualChannels : mContainerChannels;
    }
    
    /**
     * Returns the MIME type of the audio track.
     *
     * @return MIME type string (e.g., "audio/mpeg"), or null if not available
     */
    @Nullable
    public String getMimeType() {
        return mMimeType;
    }
    
    /**
     * Checks if the decoder is initialized and ready for use.
     *
     * @return true if initialized, false otherwise
     */
    public boolean isInitialized() {
        return mIsInitialized;
    }
    
    /**
     * Checks if end of stream has been reached.
     *
     * @return true if EOS, false otherwise
     */
    public boolean isEOS() {
        return mIsEOS;
    }
    
    /**
     * Releases all resources held by the decoder.
     * 
     * <p>This method must be called when the decoder is no longer needed to prevent
     * memory leaks. After release, the decoder cannot be used again unless open()
     * is called again.</p>
     */
    public void release() {
        Log.d(TAG, "release");
        
        mIsReleasing = true;
        mIsInitialized = false;
        mIsEOS = false;
        
        // Wake up any waiting threads before releasing
        synchronized (mDecoderLock) {
            mDecoderLock.notifyAll();
        }
        
        if (mDecoder != null) {
            try { 
                mDecoder.stop(); 
                mDecoder.release(); 
            } catch (Exception e) { 
                Log.e(TAG, "release decoder error", e); 
            }
            mDecoder = null;
        }
        if (mExtractor != null) {
            try { 
                mExtractor.release(); 
            } catch (Exception e) { 
                Log.e(TAG, "release extractor error", e); 
            }
            mExtractor = null;
        }
        mPcmBuffer = null;
        mFormat = null;
        mMimeType = null;
        mTrackIndex = -1;
        mPcmBufferPosition = 0;
        mPcmBufferLength = 0;
        mOutputFormatValidated = false;
        mDurationUs = 0;
        mDurationMs = 0;
        mCurrentPositionUs = 0;
        mActualSampleRate = 0;
        mActualChannels = 0;
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Extracts container properties from the audio track format.
     * 
     * <p>This method reads duration, sample rate, and channel count from the
     * container format. These values may be overridden by actual decoder output
     * later.</p>
     */
    private void extractContainerProperties() {
        if (mFormat == null) return;
        
        if (mFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mDurationUs = mFormat.getLong(MediaFormat.KEY_DURATION);
            mDurationMs = (int) (mDurationUs / 1000);
        }
        
        if (mFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            mContainerSampleRate = mFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        }
        
        if (mFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            mContainerChannels = mFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mContainerChannels = Math.max(MIN_CHANNELS, Math.min(MAX_CHANNELS, mContainerChannels));
        }
        
        Log.d(TAG, "Container: " + mContainerSampleRate + "Hz, " + mContainerChannels + "ch");
    }
    
    /**
     * Feeds compressed audio data to the decoder.
     * 
     * <p>This method reads samples from the MediaExtractor and queues them to
     * the MediaCodec decoder. When no more samples are available, it queues an
     * end-of-stream buffer.</p>
     */
    private void feedDecoder() {
        if (mDecoder == null || mExtractor == null) return;
        if (mIsReleasing) return;
        
        try {
            int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
            if (inputIndex >= 0) {
                ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                if (inputBuffer != null) {
                    inputBuffer.clear();
                    int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                    
                    if (sampleSize >= 0) {
                        long presentationTimeUs = mExtractor.getSampleTime();
                        mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                        mExtractor.advance();
                    } else {
                        // End of stream - queue EOS buffer
                        mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        Log.d(TAG, "EOS queued to decoder");
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "feedDecoder error", e);
        }
    }
    
    /**
     * Drains decoded PCM data from the decoder.
     * 
     * <p>This method retrieves decoded output buffers from the MediaCodec,
     * validates the output format on the first frame, and copies the PCM data
     * into the internal buffer. If the buffer becomes full, it attempts to
     * expand it dynamically.</p>
     */
    private void drainDecoder() {
        if (mDecoder == null) return;
        if (mIsReleasing) return;
        
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        try {
            int outputIndex = mDecoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US);
            
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                
                // Validate output format on first frame
                if (!mOutputFormatValidated) {
                    MediaFormat outputFormat = mDecoder.getOutputFormat();
                    if (outputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        mActualSampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        Log.d(TAG, "Actual sample rate: " + mActualSampleRate);
                    }
                    if (outputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        mActualChannels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        Log.d(TAG, "Actual channels: " + mActualChannels);
                    }
                    mOutputFormatValidated = true;
                }
                
                // Copy decoded PCM data to internal buffer
                if (bufferInfo.size > 0 && outputBuffer != null) {
                    if (bufferInfo.presentationTimeUs > 0) {
                        mCurrentPositionUs = bufferInfo.presentationTimeUs;
                    }
                    
                    outputBuffer.position(bufferInfo.offset);
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                    
                    // Compact buffer to maximize free space before copying
                    compactBuffer();
                    
                    int remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                    int toCopy = Math.min(bufferInfo.size, remainingSpace);
                    
                    if (toCopy > 0) {
                        outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                        mPcmBufferLength += toCopy;
                    } else {
                        // Buffer full - attempt dynamic expansion
                        Log.w(TAG, "PCM buffer full, cannot copy " + bufferInfo.size + " bytes - expanding buffer");
                        if (remainingSpace == 0) {
                            byte[] newBuffer = new byte[mPcmBuffer.length + DEFAULT_BUFFER_SIZE];
                            System.arraycopy(mPcmBuffer, 0, newBuffer, 0, mPcmBufferLength);
                            mPcmBuffer = newBuffer;
                            remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                            toCopy = Math.min(bufferInfo.size, remainingSpace);
                            if (toCopy > 0) {
                                outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                                mPcmBufferLength += toCopy;
                                Log.d(TAG, "Expanded buffer to " + mPcmBuffer.length + " bytes");
                            }
                        }
                    }
                }
                
                mDecoder.releaseOutputBuffer(outputIndex, false);
            }
            
            // Check for end of stream
            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                mIsEOS = true;
                Log.d(TAG, "Decoder EOS reached");
                
                // Wake up any waiting threads to signal EOS
                synchronized (mDecoderLock) {
                    mDecoderLock.notifyAll();
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "drainDecoder error", e);
        }
    }
}