package com.ark.llama;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * AudioDecoder - Decodes audio files to 16-bit PCM for SoundTouch processing.
 * 
 * <p>This class handles decoding of various audio formats (MP3, FLAC, OGG, M4A, AAC, WAV)
 * to 16-bit PCM format using Android's MediaCodec and MediaExtractor APIs. It is designed
 * specifically to work with {@link SoundTouchPlayer} which requires PCM data for pitch
 * and tempo manipulation.</p>
 * 
 * <h3>Supported Audio Formats</h3>
 * <ul>
 *   <li>MP3 (.mp3) - via MediaExtractor/MediaCodec</li>
 *   <li>FLAC (.flac) - via MediaExtractor/MediaCodec</li>
 *   <li>OGG (.ogg) - via MediaExtractor/MediaCodec</li>
 *   <li>M4A (.m4a) - via MediaExtractor/MediaCodec</li>
 *   <li>AAC (.aac) - via MediaExtractor/MediaCodec</li>
 *   <li>WAV (.wav) - via MediaExtractor/MediaCodec</li>
 * </ul>
 * 
 * <h3>Processing Pipeline</h3>
 * <pre>
 * Audio File → MediaExtractor → MediaCodec → PCM Data (short[]) → SoundTouchPlayer
 * </pre>
 * 
 * <h3>Key Features</h3>
 * <ul>
 *   <li>Automatic detection of audio track in media files</li>
 *   <li>Seeking to any position in the audio stream (millisecond precision)</li>
 *   <li>Progressive decoding for streaming playback</li>
 *   <li>Extraction of audio metadata (duration, sample rate, channels, bit rate)</li>
 *   <li>Thread-safe operations with proper synchronization</li>
 *   <li>Efficient buffer management to prevent memory leaks</li>
 * </ul>
 * 
 * <h3>Pre-load Support</h3>
 * <p>This decoder supports pre-loading via {@link #open(String)} which initializes
 * the extractor and decoder without reading any PCM data. This allows:
 * <ul>
 *   <li>Immediate access to song duration for UI display</li>
 *   <li>Early detection of audio properties (sample rate, channels)</li>
 *   <li>Faster response when playback begins</li>
 * </ul>
 * </p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * AudioDecoder decoder = new AudioDecoder();
 * 
 * // Open and pre-load audio file
 * if (decoder.open("/sdcard/Music/song.mp3")) {
 *     int duration = decoder.getDuration();      // Duration in milliseconds
 *     int sampleRate = decoder.getSampleRate();  // Sample rate in Hz
 *     int channels = decoder.getChannels();      // 1 = mono, 2 = stereo
 *     
 *     // Read PCM data in chunks
 *     short[] pcmBuffer = new short[4096 * channels];
 *     int framesRead = decoder.read(pcmBuffer, 4096);
 *     
 *     // Seek to a position (e.g., 30 seconds)
 *     decoder.seekTo(30000);
 *     
 *     // Clean up
 *     decoder.release();
 * }
 * </pre>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All methods should be called from the same
 * thread, or external synchronization should be used when calling from multiple
 * threads. The {@link SoundTouchPlayer} handles proper synchronization.</p>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #release()} when the decoder is no longer needed to
 * free native resources and prevent memory leaks.</p>
 * 
 * @see MediaExtractor
 * @see MediaCodec
 * @see SoundTouchPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class AudioDecoder {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for this class. */
    private static final String TAG = "AudioDecoder";
    
    /** Timeout for decoder operations in microseconds (10 milliseconds). */
    private static final long TIMEOUT_US = 10000;
    
    /** Default buffer size for PCM output (48KB). */
    private static final int DEFAULT_BUFFER_SIZE = 48 * 1024;
    
    /** Maximum frames to read in a single operation. */
    private static final int MAX_FRAMES_PER_READ = 8192;
    
    /** Minimum sample rate supported (8 kHz). */
    private static final int MIN_SAMPLE_RATE = 8000;
    
    /** Maximum sample rate supported (192 kHz). */
    private static final int MAX_SAMPLE_RATE = 192000;
    
    /** Minimum channels supported (mono). */
    private static final int MIN_CHANNELS = 1;
    
    /** Maximum channels supported (stereo). */
    private static final int MAX_CHANNELS = 2;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** Media extractor for reading audio file containers. */
    @Nullable
    private MediaExtractor mExtractor;
    
    /** Media decoder for converting compressed audio to PCM. */
    @Nullable
    private MediaCodec mDecoder;
    
    /** Format of the selected audio track. */
    @Nullable
    private MediaFormat mFormat;
    
    /** Index of the selected audio track (0-based). */
    private int mTrackIndex = -1;
    
    /** Flag indicating if decoder is ready for use. */
    private volatile boolean mIsInitialized = false;
    
    /** Duration of the audio file in microseconds (from MediaFormat). */
    private long mDurationUs = 0;
    
    /** Duration of the audio file in milliseconds (cached for performance). */
    private int mDurationMs = 0;
    
    /** Sample rate in Hz (e.g., 44100, 48000). */
    private int mSampleRate = 44100;
    
    /** Number of audio channels (1 = mono, 2 = stereo). */
    private int mChannels = 2;
    
    /** Bit rate in bits per second (from MediaFormat). */
    private int mBitRate = 0;
    
    /** MIME type of the audio track (e.g., "audio/mpeg", "audio/flac"). */
    @Nullable
    private String mMimeType = null;
    
    /** Current playback position in microseconds (updated from decoder). */
    private long mCurrentPositionUs = 0;
    
    /** Flag indicating end of stream has been reached. */
    private boolean mIsEOS = false;
    
    /** Input buffers from the decoder (used for feeding compressed data). */
    @Nullable
    private ByteBuffer[] mInputBuffers;
    
    /** Output buffers from the decoder (used for retrieving PCM data). */
    @Nullable
    private ByteBuffer[] mOutputBuffers;
    
    /** Buffer info for decoder output (contains size, flags, presentation time). */
    @Nullable
    private MediaCodec.BufferInfo mBufferInfo;
    
    /** Buffer for accumulating PCM data across multiple decoder outputs. */
    @Nullable
    private byte[] mPcmBuffer;
    
    /** Current read position in the PCM buffer (in bytes). */
    private int mPcmBufferPosition = 0;
    
    /** Valid data length in the PCM buffer (in bytes). */
    private int mPcmBufferLength = 0;
    
    /** Flag indicating output format has been set (sample rate/channels known). */
    private boolean mOutputFormatSet = false;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new AudioDecoder instance.
     * 
     * <p>The decoder is not initialized until {@link #open(String)} is called.
     * This allows for lazy initialization and reuse of the decoder object.</p>
     */
    public AudioDecoder() {
        // Initialization deferred to open() method
        Log.d(TAG, "AudioDecoder instance created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Opens an audio file for decoding and pre-loads its metadata.
     * 
     * <p>This method performs the following steps:
     * <ol>
     *   <li>Creates and configures a MediaExtractor for the file</li>
     *   <li>Finds the first audio track in the file</li>
     *   <li>Extracts audio properties (duration, sample rate, channels)</li>
     *   <li>Creates and configures a MediaCodec decoder for the track</li>
     *   <li>Starts the decoder and prepares buffers</li>
     * </ol>
     * </p>
     * 
     * <p>After successful open, the decoder is ready for reading PCM data
     * via {@link #read(short[], int)} and seeking via {@link #seekTo(int)}.</p>
     *
     * @param filePath Absolute path to the audio file (must be readable)
     * @return true if successful, false otherwise (file not found, no audio track, etc.)
     */
    public boolean open(@NonNull String filePath) {
        Log.d(TAG, "open: Opening file: " + filePath);
        
        try {
            // Create and configure extractor
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);
            
            // Find the first audio track
            mTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mTrackIndex = i;
                    mFormat = format;
                    mMimeType = mime;
                    Log.d(TAG, "open: Found audio track " + i + " with MIME: " + mime);
                    break;
                }
            }
            
            if (mTrackIndex == -1) {
                Log.e(TAG, "open: No audio track found in file: " + filePath);
                release();
                return false;
            }
            
            // Select the audio track
            mExtractor.selectTrack(mTrackIndex);
            
            // Extract audio properties from the format
            extractAudioProperties();
            
            // Create and configure decoder
            mDecoder = MediaCodec.createDecoderByType(mMimeType);
            mDecoder.configure(mFormat, null, null, 0);
            mDecoder.start();
            
            // Initialize buffers and state
            mInputBuffers = mDecoder.getInputBuffers();
            mOutputBuffers = mDecoder.getOutputBuffers();
            mBufferInfo = new MediaCodec.BufferInfo();
            mPcmBuffer = new byte[DEFAULT_BUFFER_SIZE];
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mIsEOS = false;
            mOutputFormatSet = false;
            mCurrentPositionUs = 0;
            
            mIsInitialized = true;
            
            Log.d(TAG, "open: Success - " + mMimeType + ", " + mSampleRate + "Hz, " +
                  mChannels + "ch, duration=" + mDurationMs + "ms");
            return true;
            
        } catch (IOException e) {
            Log.e(TAG, "open: Failed to open file: " + filePath, e);
            release();
            return false;
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "open: Invalid file path or unsupported format: " + filePath, e);
            release();
            return false;
        } catch (Exception e) {
            Log.e(TAG, "open: Unexpected error", e);
            release();
            return false;
        }
    }
    
    /**
     * Reads PCM data from the audio file into the provided buffer.
     * 
     * <p>This method decodes audio data and fills the provided short array with
     * 16-bit PCM samples in interleaved format. For stereo audio, the sample
     * order is L, R, L, R, etc.</p>
     * 
     * <p>The method will continue reading until either:
     * <ul>
     *   <li>The requested number of frames has been read</li>
     *   <li>The end of the audio stream is reached</li>
     *   <li>An error occurs</li>
     * </ul>
     * </p>
     *
     * @param buffer Short array to fill with PCM samples (must be large enough)
     * @param frames Maximum number of stereo frames to read (each frame = channels samples)
     * @return Number of frames actually read, or -1 on error
     */
    public int read(@NonNull short[] buffer, int frames) {
        if (!mIsInitialized) {
            Log.e(TAG, "read: Decoder not initialized, call open() first");
            return -1;
        }
        
        if (frames <= 0) {
            Log.w(TAG, "read: frames must be positive, got " + frames);
            return 0;
        }
        
        // Clamp frames to reasonable limit to prevent buffer overflow
        int safeFrames = Math.min(frames, MAX_FRAMES_PER_READ);
        int samplesNeeded = safeFrames * mChannels;
        int samplesRead = 0;
        
        try {
            while (samplesRead < samplesNeeded && !mIsEOS) {
                // If we have data in the PCM buffer, use it first
                if (mPcmBufferPosition < mPcmBufferLength) {
                    int bytesRemaining = mPcmBufferLength - mPcmBufferPosition;
                    int samplesRemaining = bytesRemaining / 2; // 2 bytes per short
                    int toRead = Math.min(samplesRemaining, samplesNeeded - samplesRead);
                    
                    // Copy from PCM buffer to output buffer (byte to short conversion)
                    for (int i = 0; i < toRead; i++) {
                        int byteOffset = mPcmBufferPosition + (i * 2);
                        short sample = (short) ((mPcmBuffer[byteOffset + 1] << 8) | 
                                                 (mPcmBuffer[byteOffset] & 0xFF));
                        buffer[samplesRead + i] = sample;
                    }
                    
                    samplesRead += toRead;
                    mPcmBufferPosition += toRead * 2;
                }
                
                // If we still need more samples, feed and drain the decoder
                if (samplesRead < samplesNeeded && !mIsEOS) {
                    feedDecoder();
                    drainDecoder();
                }
            }
            
            int framesRead = samplesRead / mChannels;
            if (framesRead > 0 && framesRead < frames) {
                Log.v(TAG, "read: Read " + framesRead + " frames (requested " + frames + ")");
            }
            return framesRead;
            
        } catch (Exception e) {
            Log.e(TAG, "read: Error reading audio", e);
            return -1;
        }
    }
    
    /**
     * Seeks to the specified position in the audio file.
     * 
     * <p>This method flushes the decoder and resets the extractor to the
     * nearest sync frame near the requested position. The seek operation
     * has millisecond precision but may snap to the nearest key frame.</p>
     * 
     * <p>After seeking, the next call to {@link #read(short[], int)} will
     * return PCM data starting from the new position.</p>
     *
     * @param positionMs Position in milliseconds to seek to (0 = beginning)
     */
    public void seekTo(int positionMs) {
        if (!mIsInitialized) {
            Log.w(TAG, "seekTo: Decoder not initialized");
            return;
        }
        
        try {
            // Clamp position to valid range
            long seekTimeUs = Math.max(0, Math.min(positionMs * 1000L, mDurationUs));
            
            // Seek in extractor (to nearest sync frame)
            if (mExtractor != null) {
                mExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                Log.d(TAG, "seekTo: Extractor seeked to " + seekTimeUs + "us");
            }
            
            // Flush decoder to reset internal state
            if (mDecoder != null) {
                mDecoder.flush();
                Log.d(TAG, "seekTo: Decoder flushed");
            }
            
            // Reset internal state
            mIsEOS = false;
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mOutputFormatSet = false;
            mCurrentPositionUs = seekTimeUs;
            
            // Refresh buffers after flush
            if (mDecoder != null) {
                mInputBuffers = mDecoder.getInputBuffers();
                mOutputBuffers = mDecoder.getOutputBuffers();
            }
            
            Log.d(TAG, "seekTo: Completed to " + positionMs + "ms");
            
        } catch (IllegalStateException e) {
            Log.e(TAG, "seekTo: Decoder in illegal state", e);
        } catch (Exception e) {
            Log.e(TAG, "seekTo: Error seeking to " + positionMs + "ms", e);
        }
    }
    
    /**
     * Returns the current playback position in milliseconds.
     * 
     * <p>The position is tracked based on the presentation timestamps
     * of decoded audio frames. This provides accurate position information
     * even during seeking operations.</p>
     *
     * @return Current position in milliseconds, or 0 if not available
     */
    public int getCurrentPosition() {
        if (!mIsInitialized) {
            return 0;
        }
        return (int) (mCurrentPositionUs / 1000);
    }
    
    /**
     * Returns the duration of the audio file in milliseconds.
     * 
     * <p>This value is extracted from the MediaFormat during {@link #open(String)}
     * and represents the total length of the audio stream.</p>
     *
     * @return Duration in milliseconds, or 0 if unknown
     */
    public int getDuration() {
        return mDurationMs;
    }
    
    /**
     * Returns the sample rate of the audio file in Hz.
     * 
     * <p>Common values include 44100 Hz (CD quality) and 48000 Hz (DVD quality).</p>
     *
     * @return Sample rate in Hz, or 44100 as default if unknown
     */
    public int getSampleRate() {
        return mSampleRate;
    }
    
    /**
     * Returns the number of audio channels.
     * 
     * <p>Returns 1 for mono audio, 2 for stereo audio.</p>
     *
     * @return Number of channels (1 or 2)
     */
    public int getChannels() {
        return mChannels;
    }
    
    /**
     * Returns the bit rate of the audio file in bits per second.
     * 
     * <p>This value is extracted from the MediaFormat and represents the
     * average bit rate of the compressed audio.</p>
     *
     * @return Bit rate in bps, or 0 if unknown
     */
    public int getBitRate() {
        return mBitRate;
    }
    
    /**
     * Returns the MIME type of the audio track.
     * 
     * <p>Examples: "audio/mpeg", "audio/flac", "audio/mp4a-latm", "audio/ogg"</p>
     *
     * @return MIME type string, or null if unknown
     */
    @Nullable
    public String getMimeType() {
        return mMimeType;
    }
    
    /**
     * Checks if the decoder is initialized and ready for use.
     *
     * @return true if initialized, false otherwise
     */
    public boolean isInitialized() {
        return mIsInitialized;
    }
    
    /**
     * Checks if the end of stream has been reached.
     * 
     * <p>Once EOS is true, further calls to {@link #read(short[], int)} will
     * return -1 or 0. The decoder must be {@link #seekTo(int)} or re-opened
     * to read more data.</p>
     *
     * @return true if end of stream has been reached, false otherwise
     */
    public boolean isEOS() {
        return mIsEOS;
    }
    
    /**
     * Releases all decoder resources and frees native memory.
     * 
     * <p>This method must be called when the decoder is no longer needed
     * to prevent memory leaks. After release, the decoder cannot be used
     * again and must be re-opened with {@link #open(String)}.</p>
     * 
     * <p>It is safe to call this method multiple times. Subsequent calls
     * will have no effect.</p>
     */
    public void release() {
        Log.d(TAG, "release: Releasing resources");
        
        mIsInitialized = false;
        mIsEOS = false;
        
        // Release decoder (must be done before extractor)
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
                Log.d(TAG, "release: Decoder released");
            } catch (Exception e) {
                Log.e(TAG, "release: Error releasing decoder", e);
            }
            mDecoder = null;
        }
        
        // Release extractor
        if (mExtractor != null) {
            try {
                mExtractor.release();
                Log.d(TAG, "release: Extractor released");
            } catch (Exception e) {
                Log.e(TAG, "release: Error releasing extractor", e);
            }
            mExtractor = null;
        }
        
        // Clear buffer references
        mInputBuffers = null;
        mOutputBuffers = null;
        mBufferInfo = null;
        mPcmBuffer = null;
        mFormat = null;
        mMimeType = null;
        
        // Reset state
        mTrackIndex = -1;
        mPcmBufferPosition = 0;
        mPcmBufferLength = 0;
        mOutputFormatSet = false;
        mDurationUs = 0;
        mDurationMs = 0;
        mCurrentPositionUs = 0;
        
        Log.d(TAG, "release: Resources released");
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Extracts audio properties from the MediaFormat.
     * 
     * <p>This method reads the following keys from the format:
     * <ul>
     *   <li>{@link MediaFormat#KEY_DURATION} - duration in microseconds</li>
     *   <li>{@link MediaFormat#KEY_SAMPLE_RATE} - sample rate in Hz</li>
     *   <li>{@link MediaFormat#KEY_CHANNEL_COUNT} - number of channels</li>
     *   <li>{@link MediaFormat#KEY_BIT_RATE} - bit rate in bps</li>
     * </ul>
     * </p>
     */
    private void extractAudioProperties() {
        if (mFormat == null) {
            Log.w(TAG, "extractAudioProperties: Format is null");
            return;
        }
        
        // Extract duration
        if (mFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mDurationUs = mFormat.getLong(MediaFormat.KEY_DURATION);
            mDurationMs = (int) (mDurationUs / 1000);
            Log.d(TAG, "extractAudioProperties: Duration = " + mDurationMs + "ms");
        } else {
            Log.w(TAG, "extractAudioProperties: No duration in format");
        }
        
        // Extract sample rate
        if (mFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            mSampleRate = mFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            // Validate sample rate
            if (mSampleRate < MIN_SAMPLE_RATE || mSampleRate > MAX_SAMPLE_RATE) {
                Log.w(TAG, "extractAudioProperties: Unusual sample rate: " + mSampleRate);
            }
            Log.d(TAG, "extractAudioProperties: Sample rate = " + mSampleRate + "Hz");
        } else {
            Log.w(TAG, "extractAudioProperties: No sample rate in format, using default");
        }
        
        // Extract channel count
        if (mFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            mChannels = mFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            // Validate channel count
            if (mChannels < MIN_CHANNELS || mChannels > MAX_CHANNELS) {
                Log.w(TAG, "extractAudioProperties: Unusual channel count: " + mChannels);
                mChannels = Math.max(MIN_CHANNELS, Math.min(MAX_CHANNELS, mChannels));
            }
            Log.d(TAG, "extractAudioProperties: Channels = " + mChannels);
        } else {
            Log.w(TAG, "extractAudioProperties: No channel count in format, using default");
        }
        
        // Extract bit rate (optional)
        if (mFormat.containsKey(MediaFormat.KEY_BIT_RATE)) {
            mBitRate = mFormat.getInteger(MediaFormat.KEY_BIT_RATE);
            Log.d(TAG, "extractAudioProperties: Bit rate = " + mBitRate + "bps");
        }
    }
    
    /**
     * Feeds compressed audio data to the decoder.
     * 
     * <p>This method reads samples from the extractor and queues them
     * to the decoder's input buffers. It handles both regular samples
     * and end-of-stream signaling.</p>
     * 
     * <p>This method is called internally by {@link #read(short[], int)}
     * when more PCM data is needed.</p>
     */
    private void feedDecoder() {
        if (mDecoder == null || mExtractor == null) {
            Log.w(TAG, "feedDecoder: Decoder or extractor is null");
            return;
        }
        
        try {
            int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
            if (inputIndex >= 0 && mInputBuffers != null) {
                ByteBuffer inputBuffer = mInputBuffers[inputIndex];
                inputBuffer.clear();
                
                int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                
                if (sampleSize >= 0) {
                    long presentationTimeUs = mExtractor.getSampleTime();
                    mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                    mExtractor.advance();
                    Log.v(TAG, "feedDecoder: Queued sample, size=" + sampleSize + 
                          ", time=" + presentationTimeUs + "us");
                } else {
                    // End of stream - queue empty buffer with EOS flag
                    mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    Log.d(TAG, "feedDecoder: End of stream reached");
                }
            }
        } catch (IllegalStateException e) {
            Log.e(TAG, "feedDecoder: Decoder in illegal state", e);
        } catch (Exception e) {
            Log.e(TAG, "feedDecoder: Unexpected error", e);
        }
    }
    
    /**
     * Drains decoded PCM data from the decoder.
     * 
     * <p>This method retrieves output buffers from the decoder and
     * stores the PCM data in the internal buffer for reading by
     * {@link #read(short[], int)}.</p>
     * 
     * <p>This method also updates the current playback position based on
     * the presentation timestamps of decoded frames.</p>
     */
    private void drainDecoder() {
        if (mDecoder == null) {
            Log.w(TAG, "drainDecoder: Decoder is null");
            return;
        }
        
        try {
            int outputIndex = mDecoder.dequeueOutputBuffer(mBufferInfo, TIMEOUT_US);
            
            if (outputIndex >= 0 && mOutputBuffers != null) {
                ByteBuffer outputBuffer = mOutputBuffers[outputIndex];
                
                // Get output format on first valid output (contains actual sample rate/channels)
                if (!mOutputFormatSet) {
                    MediaFormat outputFormat = mDecoder.getOutputFormat();
                    if (outputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        int newSampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        if (newSampleRate != mSampleRate) {
                            Log.d(TAG, "drainDecoder: Output sample rate = " + newSampleRate);
                            mSampleRate = newSampleRate;
                        }
                    }
                    if (outputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        int newChannels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        if (newChannels != mChannels) {
                            Log.d(TAG, "drainDecoder: Output channels = " + newChannels);
                            mChannels = newChannels;
                        }
                    }
                    mOutputFormatSet = true;
                }
                
                // Copy PCM data to buffer if available
                if (mBufferInfo.size > 0 && outputBuffer != null) {
                    // Update current position from presentation timestamp
                    if (mBufferInfo.presentationTimeUs > 0) {
                        mCurrentPositionUs = mBufferInfo.presentationTimeUs;
                    }
                    
                    // Copy PCM data to internal buffer
                    outputBuffer.position(mBufferInfo.offset);
                    outputBuffer.limit(mBufferInfo.offset + mBufferInfo.size);
                    
                    int remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                    int toCopy = Math.min(mBufferInfo.size, remainingSpace);
                    
                    if (toCopy > 0) {
                        outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                        mPcmBufferLength += toCopy;
                        Log.v(TAG, "drainDecoder: Copied " + toCopy + " bytes, total=" + mPcmBufferLength);
                    } else {
                        Log.w(TAG, "drainDecoder: PCM buffer full, cannot copy more data");
                    }
                }
                
                // Release output buffer back to decoder
                mDecoder.releaseOutputBuffer(outputIndex, false);
            }
            
            // Check for end of stream
            if (mBufferInfo != null && 
                (mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                mIsEOS = true;
                Log.d(TAG, "drainDecoder: End of stream flag detected");
            }
            
        } catch (IllegalStateException e) {
            Log.e(TAG, "drainDecoder: Decoder in illegal state", e);
        } catch (Exception e) {
            Log.e(TAG, "drainDecoder: Unexpected error", e);
        }
    }
}