package com.ark.llama;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * AudioDecoder - Decodes audio files to 16-bit PCM for SoundTouch processing.
 * 
 * <p>This class provides high-performance audio decoding using Android's MediaCodec
 * and MediaExtractor APIs. It supports a wide range of audio formats including
 * MP3, AAC, FLAC, OGG, M4A, and WAV.</p>
 * 
 * <h3>Architecture</h3>
 * <pre>
 * Audio File (MP3/AAC/FLAC/OGG)
 *        ▼
 * MediaExtractor - extracts audio track
 *        ▼
 * MediaCodec - decodes to PCM
 *        ▼
 * Internal Buffer (2MB) - holds decoded PCM
 *        ▼
 * {@link #read(short[], int)} - provides PCM samples to SoundTouch
 * </pre>
 * 
 * <h3>Buffer Management</h3>
 * <p>The decoder uses a 2MB internal buffer to hold decoded PCM data, which
 * prevents underruns during playback. The buffer automatically compacts when
 * partially consumed and can expand dynamically if needed.</p>
 * 
 * <h3>Audio Format Support</h3>
 * <ul>
 *   <li>MP3 (all bitrates and sample rates)</li>
 *   <li>AAC (including HE-AAC and AAC-LC)</li>
 *   <li>FLAC (Free Lossless Audio Codec)</li>
 *   <li>OGG (Vorbis)</li>
 *   <li>M4A (MPEG-4 Audio)</li>
 *   <li>WAV (PCM, not compressed)</li>
 * </ul>
 * 
 * <h3>Output Format</h3>
 * <p>The decoder always outputs 16-bit PCM samples in interleaved format.
 * For stereo audio, the sample order is L, R, L, R, etc.</p>
 * 
 * <h3>Seeking</h3>
 * <p>The decoder supports seeking to any position within the audio file using
 * {@link #seekTo(int)}. Seeking uses {@link MediaExtractor#SEEK_TO_CLOSEST_SYNC}
 * to find the nearest sync frame, which ensures correct decoding at the seek position.</p>
 * 
 * <h3>Thread Safety</h3>
 * <p>This class is not thread-safe. All methods should be called from the same thread,
 * or external synchronization should be used when calling from multiple threads.</p>
 * 
 * <h3>Resource Management</h3>
 * <p>Always call {@link #release()} when the decoder is no longer needed to free
 * native resources and prevent memory leaks.</p>
 * 
 * <h3>Usage Example</h3>
 * <pre>
 * AudioDecoder decoder = new AudioDecoder();
 * 
 * // Open and initialize decoder
 * if (decoder.open("/sdcard/Music/song.mp3")) {
 *     // Get audio format information
 *     int sampleRate = decoder.getSampleRate();  // e.g., 44100
 *     int channels = decoder.getChannels();      // 1 or 2
 *     int duration = decoder.getDuration();      // in milliseconds
 *     
 *     // Read PCM frames
 *     short[] pcmBuffer = new short[8192 * channels];
 *     int framesRead = decoder.read(pcmBuffer, 8192);
 *     
 *     // Seek to 30 seconds
 *     decoder.seekTo(30000);
 *     
 *     // Clean up
 *     decoder.release();
 * }
 * </pre>
 * 
 * <h3>Integration with SoundTouchPlayer</h3>
 * <p>This decoder is used by {@link SoundTouchPlayer} to read decoded PCM frames,
 * which are then processed by the official SoundTouch library for pitch and tempo
 * changes before being sent to AudioTrack for playback.</p>
 * 
 * @see MediaCodec
 * @see MediaExtractor
 * @see SoundTouchPlayer
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.1
 * @since 1.0
 */
public class AudioDecoder {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Log tag for debugging and error tracking. */
    private static final String TAG = "AudioDecoder";
    
    /** Timeout in microseconds for dequeue operations (10ms). */
    private static final long TIMEOUT_US = 10000;
    
    /** 
     * Default buffer size in bytes (2MB).
     * This size can hold several seconds of PCM audio, ensuring smooth
     * playback even during brief system load spikes.
     */
    private static final int DEFAULT_BUFFER_SIZE = 2 * 1024 * 1024;
    
    /** Maximum number of frames to read per operation (8192 frames = ~186ms at 44.1kHz). */
    private static final int MAX_FRAMES_PER_READ = 8192;
    
    /** Minimum supported sample rate in Hz (8kHz for low-quality audio). */
    private static final int MIN_SAMPLE_RATE = 8000;
    
    /** Maximum supported sample rate in Hz (192kHz for high-resolution audio). */
    private static final int MAX_SAMPLE_RATE = 192000;
    
    /** Minimum number of channels (mono). */
    private static final int MIN_CHANNELS = 1;
    
    /** Maximum number of channels (stereo). */
    private static final int MAX_CHANNELS = 2;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** MediaExtractor for reading audio tracks from files. */
    @Nullable private MediaExtractor mExtractor;
    
    /** MediaCodec for decoding compressed audio to PCM. */
    @Nullable private MediaCodec mDecoder;
    
    /** MediaFormat of the selected audio track. */
    @Nullable private MediaFormat mFormat;
    
    /** Index of the selected audio track in the extractor. */
    private int mTrackIndex = -1;
    
    /** Flag indicating if the decoder has been initialized successfully. */
    private volatile boolean mIsInitialized = false;
    
    /** Duration of the audio file in microseconds. */
    private long mDurationUs = 0;
    
    /** Duration of the audio file in milliseconds (cached for convenience). */
    private int mDurationMs = 0;
    
    /** Sample rate from the container format (may be overridden by actual output). */
    private int mContainerSampleRate = 44100;
    
    /** Channel count from the container format (may be overridden by actual output). */
    private int mContainerChannels = 2;
    
    /** Actual sample rate from decoder output (more accurate than container). */
    private int mActualSampleRate = 0;
    
    /** Actual channel count from decoder output (more accurate than container). */
    private int mActualChannels = 0;
    
    /** Flag indicating if output format has been validated from decoder. */
    private boolean mOutputFormatValidated = false;
    
    /** MIME type of the audio track (e.g., "audio/mpeg", "audio/mp4a-latm"). */
    @Nullable private String mMimeType = null;
    
    /** Current playback position in microseconds (updated during decoding). */
    private long mCurrentPositionUs = 0;
    
    /** Flag indicating if end-of-stream has been reached. */
    private boolean mIsEOS = false;
    
    /** 
     * Internal PCM buffer for storing decoded audio.
     * Size is DEFAULT_BUFFER_SIZE (2MB) to prevent underruns.
     */
    @Nullable private byte[] mPcmBuffer;
    
    /** Read cursor position within the PCM buffer. */
    private int mPcmBufferPosition = 0;
    
    /** Valid data length within the PCM buffer. */
    private int mPcmBufferLength = 0;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new AudioDecoder instance.
     * 
     * <p>The decoder is initially uninitialized. Call {@link #open(String)} to
     * open and configure the decoder for a specific audio file.</p>
     */
    public AudioDecoder() {
        Log.d(TAG, "AudioDecoder instance created");
    }
    
    // ========================================================================
    // Public API Methods
    // ========================================================================
    
    /**
     * Opens and initializes the decoder for the specified audio file.
     * 
     * <p>This method performs the following steps:</p>
     * <ol>
     *   <li>Creates and configures a MediaExtractor for the file</li>
     *   <li>Finds the first audio track in the file</li>
     *   <li>Extracts container properties (sample rate, channels, duration)</li>
     *   <li>Creates and configures a MediaCodec decoder for the audio format</li>
     *   <li>Starts the decoder and allocates the internal PCM buffer</li>
     * </ol>
     * 
     * <p>After successful opening, the decoder is ready to read PCM frames
     * via {@link #read(short[], int)}.</p>
     *
     * @param filePath Absolute path to the audio file (e.g., "/sdcard/Music/song.mp3")
     * @return true if the decoder was opened successfully, false otherwise
     */
    public boolean open(@NonNull String filePath) {
        Log.d(TAG, "open: " + filePath);
        try {
            // Initialize MediaExtractor
            mExtractor = new MediaExtractor();
            mExtractor.setDataSource(filePath);
            
            // Find first audio track
            mTrackIndex = -1;
            for (int i = 0; i < mExtractor.getTrackCount(); i++) {
                MediaFormat format = mExtractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    mTrackIndex = i;
                    mFormat = format;
                    mMimeType = mime;
                    Log.d(TAG, "Found audio track: " + mime);
                    break;
                }
            }
            
            if (mTrackIndex == -1) {
                Log.e(TAG, "No audio track found");
                release();
                return false;
            }
            
            // Select the audio track for extraction
            mExtractor.selectTrack(mTrackIndex);
            extractContainerProperties();
            
            // Initialize decoder
            mDecoder = MediaCodec.createDecoderByType(mMimeType);
            mDecoder.configure(mFormat, null, null, 0);
            mDecoder.start();
            
            // Allocate PCM buffer
            mPcmBuffer = new byte[DEFAULT_BUFFER_SIZE];
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mIsEOS = false;
            mOutputFormatValidated = false;
            mCurrentPositionUs = 0;
            mIsInitialized = true;
            
            Log.d(TAG, "open success: " + mMimeType + ", " + getSampleRate() + "Hz, " +
                  getChannels() + "ch, duration=" + mDurationMs + "ms, buffer=" + DEFAULT_BUFFER_SIZE + " bytes");
            return true;
            
        } catch (IOException | IllegalArgumentException e) {
            Log.e(TAG, "open failed", e);
            release();
            return false;
        }
    }
    
    /**
     * Reads PCM frames from the decoder into the provided buffer.
     * 
     * <p>This method returns decoded 16-bit PCM samples in interleaved format.
     * For stereo audio, the sample order is L, R, L, R, etc.</p>
     * 
     * <p>The method will block until at least one frame is available or the
     * end of the stream is reached. If the internal buffer runs low, more
     * data is automatically decoded from the source file.</p>
     *
     * @param buffer The short array to receive the PCM samples
     * @param frames The number of stereo frames to read (each frame = channels samples)
     * @return Number of frames actually read, or -1 if an error occurred.
     *         Returns 0 if end-of-stream is reached with no more data.
     * @throws NullPointerException if buffer is null
     * @throws IllegalArgumentException if frames is less than or equal to 0
     */
    public int read(@NonNull short[] buffer, int frames) {
        if (!mIsInitialized) {
            Log.e(TAG, "read: not initialized");
            return -1;
        }
        if (frames <= 0) return 0;
        
        int safeFrames = Math.min(frames, MAX_FRAMES_PER_READ);
        int channels = getChannels();
        int samplesNeeded = safeFrames * channels;
        int samplesRead = 0;
        
        try {
            while (samplesRead < samplesNeeded && !mIsEOS) {
                // If buffer has data, copy as much as possible
                if (mPcmBufferPosition < mPcmBufferLength) {
                    int bytesRemaining = mPcmBufferLength - mPcmBufferPosition;
                    int samplesRemaining = bytesRemaining / 2;
                    int toRead = Math.min(samplesRemaining, samplesNeeded - samplesRead);
                    
                    for (int i = 0; i < toRead; i++) {
                        int byteOffset = mPcmBufferPosition + (i * 2);
                        short sample = (short) ((mPcmBuffer[byteOffset + 1] << 8) | 
                                                 (mPcmBuffer[byteOffset] & 0xFF));
                        buffer[samplesRead + i] = sample;
                    }
                    
                    samplesRead += toRead;
                    mPcmBufferPosition += toRead * 2;
                    
                    // Compact buffer if we've consumed a significant portion
                    if (mPcmBufferPosition > 0 && mPcmBufferPosition >= mPcmBufferLength / 2) {
                        compactBuffer();
                    }
                }
                
                // If we still need more samples, try to decode more
                if (samplesRead < samplesNeeded && !mIsEOS) {
                    feedDecoder();
                    drainDecoder();
                    
                    // If after draining we still have no data and not EOS, wait a bit
                    if (mPcmBufferPosition >= mPcmBufferLength && !mIsEOS) {
                        Thread.sleep(5);
                    }
                }
            }
            
            int framesRead = samplesRead / channels;
            if (framesRead == 0 && mIsEOS) {
                Log.d(TAG, "read: EOS reached, returning 0");
            } else if (framesRead > 0 && framesRead < frames) {
                Log.v(TAG, "read: " + framesRead + "/" + frames + " frames");
            }
            return framesRead;
            
        } catch (InterruptedException e) {
            Log.w(TAG, "read interrupted", e);
            Thread.currentThread().interrupt();
            return -1;
        } catch (Exception e) {
            Log.e(TAG, "read error", e);
            return -1;
        }
    }
    
    /**
     * Compacts the internal PCM buffer by moving remaining data to the front.
     * 
     * <p>This method is called when a significant portion of the buffer has
     * been consumed. It shifts any remaining data to the beginning of the
     * buffer, freeing up space for more decoded data.</p>
     */
    private void compactBuffer() {
        if (mPcmBufferPosition > 0 && mPcmBufferPosition < mPcmBufferLength) {
            int remaining = mPcmBufferLength - mPcmBufferPosition;
            System.arraycopy(mPcmBuffer, mPcmBufferPosition, mPcmBuffer, 0, remaining);
            mPcmBufferLength = remaining;
            mPcmBufferPosition = 0;
        } else if (mPcmBufferPosition >= mPcmBufferLength) {
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
        }
    }
    
    /**
     * Seeks to the specified position in the audio file.
     * 
     * <p>Seeking uses {@link MediaExtractor#SEEK_TO_CLOSEST_SYNC} to find the
     * nearest sync frame before or at the requested position. This ensures
     * correct decoding after the seek operation.</p>
     * 
     * <p>The decoder and internal buffer are flushed after seeking to prevent
     * stale audio data from being played.</p>
     *
     * @param positionMs Position in milliseconds (0 to duration)
     */
    public void seekTo(int positionMs) {
        if (!mIsInitialized) return;
        
        try {
            long seekTimeUs = Math.max(0, Math.min(positionMs * 1000L, mDurationUs));
            
            if (mExtractor != null) {
                mExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            }
            
            if (mDecoder != null) {
                mDecoder.flush();
            }
            
            mIsEOS = false;
            mPcmBufferPosition = 0;
            mPcmBufferLength = 0;
            mCurrentPositionUs = seekTimeUs;
            
            Log.d(TAG, "seekTo: " + positionMs + "ms");
        } catch (Exception e) {
            Log.e(TAG, "seekTo error", e);
        }
    }
    
    /**
     * Returns the current playback position.
     * 
     * <p>This position is updated from the decoder's presentation timestamps
     * during decoding, providing accurate position information even after seeks.</p>
     *
     * @return Current position in milliseconds
     */
    public int getCurrentPosition() {
        return (int) (mCurrentPositionUs / 1000);
    }
    
    /**
     * Returns the total duration of the audio file.
     *
     * @return Duration in milliseconds, or 0 if not available
     */
    public int getDuration() {
        return mDurationMs;
    }
    
    /**
     * Returns the sample rate of the decoded audio.
     * 
     * <p>This method returns the actual sample rate from the decoder output
     * if available, falling back to the container sample rate.</p>
     *
     * @return Sample rate in Hz (e.g., 44100, 48000)
     */
    public int getSampleRate() {
        return mActualSampleRate > 0 ? mActualSampleRate : mContainerSampleRate;
    }
    
    /**
     * Returns the number of audio channels.
     * 
     * <p>This method returns the actual channel count from the decoder output
     * if available, falling back to the container channel count.</p>
     *
     * @return Number of channels (1 for mono, 2 for stereo)
     */
    public int getChannels() {
        return mActualChannels > 0 ? mActualChannels : mContainerChannels;
    }
    
    /**
     * Returns the MIME type of the audio track.
     *
     * @return MIME type string (e.g., "audio/mpeg"), or null if not available
     */
    @Nullable
    public String getMimeType() {
        return mMimeType;
    }
    
    /**
     * Checks if the decoder has been initialized successfully.
     *
     * @return true if initialized and ready for reading
     */
    public boolean isInitialized() {
        return mIsInitialized;
    }
    
    /**
     * Checks if the end of the stream has been reached.
     *
     * @return true if all audio data has been decoded
     */
    public boolean isEOS() {
        return mIsEOS;
    }
    
    /**
     * Releases all resources held by the decoder.
     * 
     * <p>This method stops the decoder, releases the MediaExtractor, and
     * frees all internal buffers. After calling release, the decoder cannot
     * be used again. A new AudioDecoder instance must be created.</p>
     */
    public void release() {
        Log.d(TAG, "release");
        
        mIsInitialized = false;
        mIsEOS = false;
        
        if (mDecoder != null) {
            try {
                mDecoder.stop();
                mDecoder.release();
            } catch (Exception e) {
                Log.e(TAG, "release decoder error", e);
            }
            mDecoder = null;
        }
        
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Exception e) {
                Log.e(TAG, "release extractor error", e);
            }
            mExtractor = null;
        }
        
        mPcmBuffer = null;
        mFormat = null;
        mMimeType = null;
        mTrackIndex = -1;
        mPcmBufferPosition = 0;
        mPcmBufferLength = 0;
        mOutputFormatValidated = false;
        mDurationUs = 0;
        mDurationMs = 0;
        mCurrentPositionUs = 0;
        mActualSampleRate = 0;
        mActualChannels = 0;
    }
    
    // ========================================================================
    // Private Helper Methods
    // ========================================================================
    
    /**
     * Extracts container properties from the selected audio track.
     * 
     * <p>This method retrieves duration, sample rate, and channel count
     * from the MediaFormat of the audio track. These values may be refined
     * later when the actual decoder output format is known.</p>
     */
    private void extractContainerProperties() {
        if (mFormat == null) return;
        
        if (mFormat.containsKey(MediaFormat.KEY_DURATION)) {
            mDurationUs = mFormat.getLong(MediaFormat.KEY_DURATION);
            mDurationMs = (int) (mDurationUs / 1000);
        }
        
        if (mFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            mContainerSampleRate = mFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        }
        
        if (mFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            mContainerChannels = mFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            mContainerChannels = Math.max(MIN_CHANNELS, Math.min(MAX_CHANNELS, mContainerChannels));
        }
        
        Log.d(TAG, "Container: " + mContainerSampleRate + "Hz, " + mContainerChannels + "ch");
    }
    
    /**
     * Feeds encoded audio data from the extractor to the decoder.
     * 
     * <p>This method dequeues an input buffer from the decoder, reads encoded
     * sample data from the extractor, and queues it for decoding. When the
     * end of the stream is reached, an EOS (End-Of-Stream) buffer is queued
     * to signal the decoder that no more input will be provided.</p>
     */
    private void feedDecoder() {
        if (mDecoder == null || mExtractor == null) return;
        
        try {
            int inputIndex = mDecoder.dequeueInputBuffer(TIMEOUT_US);
            if (inputIndex >= 0) {
                ByteBuffer inputBuffer = mDecoder.getInputBuffer(inputIndex);
                if (inputBuffer != null) {
                    inputBuffer.clear();
                    int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                    
                    if (sampleSize >= 0) {
                        long presentationTimeUs = mExtractor.getSampleTime();
                        mDecoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0);
                        mExtractor.advance();
                    } else {
                        // End of stream - queue EOS buffer
                        mDecoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        Log.d(TAG, "EOS queued to decoder");
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "feedDecoder error", e);
        }
    }
    
    /**
     * Drains decoded PCM data from the decoder to the internal buffer.
     * 
     * <p>This method dequeues output buffers from the decoder, extracts the
     * decoded PCM data, and copies it to the internal buffer. It also validates
     * the output format (sample rate and channels) from the first decoded buffer.</p>
     * 
     * <p>The buffer is dynamically expanded if the internal buffer becomes full,
     * though this should not happen under normal operation with the 2MB buffer size.</p>
     */
    private void drainDecoder() {
        if (mDecoder == null) return;
        
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        
        try {
            int outputIndex = mDecoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US);
            if (outputIndex >= 0) {
                ByteBuffer outputBuffer = mDecoder.getOutputBuffer(outputIndex);
                
                // Validate output format from the first buffer
                if (!mOutputFormatValidated) {
                    MediaFormat outputFormat = mDecoder.getOutputFormat();
                    
                    if (outputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        mActualSampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        Log.d(TAG, "Actual sample rate: " + mActualSampleRate);
                    }
                    
                    if (outputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        mActualChannels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        Log.d(TAG, "Actual channels: " + mActualChannels);
                    }
                    
                    mOutputFormatValidated = true;
                }
                
                // Copy decoded PCM data to internal buffer
                if (bufferInfo.size > 0 && outputBuffer != null) {
                    // Update current position from presentation timestamp
                    if (bufferInfo.presentationTimeUs > 0) {
                        mCurrentPositionUs = bufferInfo.presentationTimeUs;
                    }
                    
                    outputBuffer.position(bufferInfo.offset);
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                    
                    // Compact buffer to maximize free space before copying
                    compactBuffer();
                    
                    int remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                    int toCopy = Math.min(bufferInfo.size, remainingSpace);
                    
                    if (toCopy > 0) {
                        outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                        mPcmBufferLength += toCopy;
                    } else {
                        Log.e(TAG, "PCM buffer full, cannot copy " + bufferInfo.size + " bytes - increase buffer size");
                        
                        // Dynamic buffer expansion (safety fallback)
                        if (remainingSpace == 0) {
                            byte[] newBuffer = new byte[mPcmBuffer.length + DEFAULT_BUFFER_SIZE];
                            System.arraycopy(mPcmBuffer, 0, newBuffer, 0, mPcmBufferLength);
                            mPcmBuffer = newBuffer;
                            remainingSpace = mPcmBuffer.length - mPcmBufferLength;
                            toCopy = Math.min(bufferInfo.size, remainingSpace);
                            
                            if (toCopy > 0) {
                                outputBuffer.get(mPcmBuffer, mPcmBufferLength, toCopy);
                                mPcmBufferLength += toCopy;
                                Log.w(TAG, "Expanded buffer to " + mPcmBuffer.length + " bytes");
                            }
                        }
                    }
                }
                
                mDecoder.releaseOutputBuffer(outputIndex, false);
            }
            
            // Check for end-of-stream
            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                mIsEOS = true;
                Log.d(TAG, "Decoder EOS reached");
            }
            
        } catch (Exception e) {
            Log.e(TAG, "drainDecoder error", e);
        }
    }
}