/**
 * Llama Music Player - Pitch Shifter JNI Wrapper
 * ============================================================================
 * This file implements the Java Native Interface (JNI) wrapper for the
 * SoundTouch audio processing library. It provides native methods for:
 * - Loading audio files (MP3, AAC, FLAC, OGG, etc.)
 * - Setting pitch shift amount (-6 to +6 semitones)
 * - Setting tempo multiplier (0.5x to 1.5x)
 * - Processing PCM audio frames through SoundTouch
 * 
 * The SoundTouch library handles the actual pitch and tempo shifting
 * using WSOLA (Waveform Similarity Overlap-Add) algorithm.
 * 
 * This wrapper uses 16-bit integer samples (short) for compatibility
 * with Android's AudioTrack class.
 * 
 * File Location: /app/src/main/cpp/pitch_shifter.cpp
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 * 
 * @see PitchShifter.java for the Java counterpart
 * @see SoundTouchPlayer.java for Android integration
 */

#include <jni.h>
#include <android/log.h>
#include "soundtouch/SoundTouch.h"

#define LOG_TAG "PitchShifter"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace soundtouch;

/**
 * JNI function: nativeCreate
 * Creates a new SoundTouch instance and returns its pointer as a jlong.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference (PitchShifter instance)
 * @return Native pointer cast to jlong (0 if creation fails)
 */
extern "C" JNIEXPORT jlong JNICALL
Java_com_ark_llama_PitchShifter_nativeCreate(JNIEnv *env, jobject thiz) {
    SoundTouch *st = new SoundTouch();
    if (st == nullptr) {
        LOGE("Failed to create SoundTouch instance");
        return 0;
    }
    LOGD("SoundTouch instance created: %p", st);
    return reinterpret_cast<jlong>(st);
}

/**
 * JNI function: nativeSetSampleRate
 * Sets the sample rate for the SoundTouch processor.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param rate Sample rate in Hz (e.g., 44100)
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetSampleRate(JNIEnv *env, jobject thiz,
                                                     jlong handle, jint rate) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeSetSampleRate");
        return;
    }
    st->setSampleRate(static_cast<uint>(rate));
    LOGD("Sample rate set to %d Hz", rate);
}

/**
 * JNI function: nativeSetChannels
 * Sets the number of audio channels (1 for mono, 2 for stereo).
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param channels Number of channels (1 or 2)
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetChannels(JNIEnv *env, jobject thiz,
                                                   jlong handle, jint channels) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeSetChannels");
        return;
    }
    st->setChannels(static_cast<uint>(channels));
    LOGD("Channels set to %d", channels);
}

/**
 * JNI function: nativeSetPitch
 * Sets the pitch shift amount in semitones.
 * 
 * Range: -6.0 to +6.0 semitones
 * Positive values raise the pitch, negative values lower it.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param pitch Pitch shift in semitones
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetPitch(JNIEnv *env, jobject thiz,
                                                jlong handle, jfloat pitch) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeSetPitch");
        return;
    }
    st->setPitchSemiTones(static_cast<double>(pitch));
    LOGD("Pitch set to %.2f semitones", pitch);
}

/**
 * JNI function: nativeSetTempo
 * Sets the tempo (speed) multiplier.
 * 
 * Range: 0.5x to 1.5x
 * - 0.5 = half speed (50% slower)
 * - 1.0 = normal speed
 * - 1.5 = 1.5x speed (50% faster)
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param tempo Tempo multiplier
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetTempo(JNIEnv *env, jobject thiz,
                                                jlong handle, jfloat tempo) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeSetTempo");
        return;
    }
    st->setTempo(static_cast<double>(tempo));
    LOGD("Tempo set to %.2fx", tempo);
}

/**
 * JNI function: nativePutFrames
 * Feeds PCM audio frames into the SoundTouch processor.
 * 
 * The samples are expected to be 16-bit integer PCM in interleaved format.
 * For stereo, the order is L, R, L, R, ...
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param samples Array of short audio samples (16-bit PCM)
 * @param frames Number of frames (each frame = channels samples)
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativePutFrames(JNIEnv *env, jobject thiz,
                                                 jlong handle, jshortArray samples,
                                                 jint frames) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativePutFrames");
        return;
    }
    
    jshort *samplesArray = env->GetShortArrayElements(samples, nullptr);
    if (samplesArray == nullptr) {
        LOGE("Failed to get sample array elements");
        return;
    }
    
    st->putSamples(reinterpret_cast<const SAMPLETYPE *>(samplesArray),
                   static_cast<uint>(frames));
    
    env->ReleaseShortArrayElements(samples, samplesArray, JNI_ABORT);
}

/**
 * JNI function: nativeReceiveFrames
 * Retrieves processed audio frames from the SoundTouch processor.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @param output Array to receive processed samples
 * @param maxFrames Maximum number of frames to retrieve
 * @return Number of frames actually retrieved
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_ark_llama_PitchShifter_nativeReceiveFrames(JNIEnv *env, jobject thiz,
                                                     jlong handle, jshortArray output,
                                                     jint maxFrames) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeReceiveFrames");
        return 0;
    }
    
    jshort *outputArray = env->GetShortArrayElements(output, nullptr);
    if (outputArray == nullptr) {
        LOGE("Failed to get output array elements");
        return 0;
    }
    
    uint received = st->receiveSamples(reinterpret_cast<SAMPLETYPE *>(outputArray),
                                        static_cast<uint>(maxFrames));
    
    env->ReleaseShortArrayElements(output, outputArray, 0);
    return static_cast<jint>(received);
}

/**
 * JNI function: nativeNumFrames
 * Returns the number of frames currently available in the pipeline.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 * @return Number of frames available
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_ark_llama_PitchShifter_nativeNumFrames(JNIEnv *env, jobject thiz,
                                                 jlong handle) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeNumFrames");
        return 0;
    }
    return static_cast<jint>(st->numSamples());
}

/**
 * JNI function: nativeFlush
 * Flushes any remaining audio data from the pipeline.
 * Call this after processing all input to retrieve remaining output.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeFlush(JNIEnv *env, jobject thiz,
                                             jlong handle) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeFlush");
        return;
    }
    st->flush();
    LOGD("Pipeline flushed");
}

/**
 * JNI function: nativeClear
 * Clears all internal buffers in the pipeline.
 * Resets the processor's internal state.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeClear(JNIEnv *env, jobject thiz,
                                             jlong handle) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeClear");
        return;
    }
    st->clear();
    LOGD("Pipeline cleared");
}

/**
 * JNI function: nativeDestroy
 * Destroys the SoundTouch instance and releases all resources.
 * 
 * @param env JNI environment pointer
 * @param thiz Java object reference
 * @param handle Native pointer to SoundTouch instance
 */
extern "C" JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeDestroy(JNIEnv *env, jobject thiz,
                                               jlong handle) {
    SoundTouch *st = reinterpret_cast<SoundTouch *>(handle);
    if (st == nullptr) {
        LOGE("Invalid handle in nativeDestroy (already destroyed?)");
        return;
    }
    delete st;
    LOGD("SoundTouch instance destroyed");
}