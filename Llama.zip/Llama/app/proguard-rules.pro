#
# Llama Music Player - ProGuard Rules
# ============================================================================
# These ProGuard rules optimize and obfuscate the application while preserving
# necessary classes and methods for proper functionality.
#
# Author: Richard Korbla Adzido
# Version: 1.0.0
# Since: 1.0
# ============================================================================

# ============================================================================
# Jaudiotagger Library Rules
# ============================================================================
# The jaudiotagger library is used for reading ID3 tags from music files.
# All classes must be preserved to prevent runtime crashes.

# Keep all jaudiotagger classes
-keep class org.jaudiotagger.** { *; }

# Suppress warnings about missing classes (some optional dependencies)
-dontwarn org.jaudiotagger.**

# Keep annotations for proper library functionality
-keepattributes *Annotation*
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# ============================================================================
# Model Classes (Serialization)
# ============================================================================
# These classes are serialized/deserialized and must be preserved.

-keep class com.ark.llama.Song { *; }
-keep class com.ark.llama.SongDatabase { *; }
-keep class com.ark.llama.MusicLibrary { *; }
-keep class com.ark.llama.PlaylistService { *; }

# ============================================================================
# Services & Receivers
# ============================================================================
# Android components that can be invoked by the system must be preserved.

-keep class com.ark.llama.BluetoothReceiver { *; }
-keep class com.ark.llama.MusicService { *; }

# ============================================================================
# Equalizer & Pitch Shifter
# ============================================================================
# Audio effect classes and native methods must be preserved.

-keep class com.ark.llama.EqualizerManager { *; }
-keep class com.ark.llama.PitchShifter { *; }

# Keep native method names for JNI binding
-keepclassmembers class com.ark.llama.PitchShifter {
    native <methods>;
}

# ============================================================================
# SoundTouch Native Library
# ============================================================================
# SoundTouch native library wrapper classes.

-keep class com.ark.llama.SoundTouch { *; }
-keepclassmembers class com.ark.llama.SoundTouch {
    native <methods>;
}

# ============================================================================
# Utility Classes
# ============================================================================
# Utility classes used throughout the application.

-keep class com.ark.llama.CharacterMapper { *; }
-keep class com.ark.llama.FontAwesome { *; }

# ============================================================================
# Theme Classes
# ============================================================================
# Theme management and notification classes.

-keep class com.ark.llama.ThemeManager { *; }
-keep class com.ark.llama.ThemeHelper { *; }
-keep class com.ark.llama.NotificationHelper { *; }
-keep class com.ark.llama.ToastManager { *; }

# ============================================================================
# AndroidX Rules
# ============================================================================
# Keep AndroidX library classes (they already have their own ProGuard rules,
# but we ensure they are not stripped).

-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# ============================================================================
# Media Playback
# ============================================================================
# Keep media framework classes.

-keep class android.media.** { *; }
-dontwarn android.media.**

# ============================================================================
# General Android Rules
# ============================================================================

# Keep signature and annotation attributes
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# Keep all Android components (Activities, Services, Receivers, Dialogs, Fragments)
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.app.Fragment
-keep public class * extends android.support.v4.app.Fragment

# Keep all View constructors (required for XML inflation)
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Enum Rules
# ============================================================================
# Keep enum values() and valueOf() methods.

-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ============================================================================
# AsyncTask Rules
# ============================================================================
# Keep AsyncTask classes and their methods.

-keep class * extends android.os.AsyncTask { *; }

# ============================================================================
# Native Method Rules
# ============================================================================
# Keep native method names.

-keepclasseswithmembernames class * {
    native <methods>;
}

# ============================================================================
# Serialization Rules
# ============================================================================
# Keep serialization-related fields and methods.

-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Parcelable Rules
# ============================================================================
# Keep Parcelable creators.

-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Remove Logging in Release
# ============================================================================
# Strip all log calls from release builds for better performance and security.

-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ============================================================================
# Optimization Flags
# ============================================================================

# Number of optimization passes
-optimizationpasses 5

# Don't preverify (speeds up dex conversion)
-dontpreverify

# Allow access modification for better optimization
-allowaccessmodification

# Repackage all classes into default package
-repackageclasses ''

# Keep attributes needed for debugging and proper functionality
-keepattributes Exceptions,InnerClasses,Signature,Deprecated,SourceFile,LineNumberTable

# ============================================================================
# Debugging Support
# ============================================================================
# Keep source file names and line numbers for better stack traces.

-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable