/**
 * SoundTouch - Audio Processing Library
 * ============================================================================
 * SoundTouch is an open-source audio processing library for changing the
 * tempo, pitch, and playback rate of audio streams independently.
 * 
 * This header defines the public API for the SoundTouch library.
 * 
 * Key features:
 * - Independent tempo (speed) control
 * - Independent pitch (key) shifting
 * - Real-time processing
 * - Supports mono and stereo audio
 * - Configurable quality vs. speed settings
 * 
 * Original SoundTouch library by Olli Parviainen
 * Modified for Android compatibility with 16-bit integer samples
 * 
 * @see https://www.surina.net/soundtouch/
 * ============================================================================
 */

#ifndef SOUNDTOUCH_H
#define SOUNDTOUCH_H

#include <stdint.h>

namespace soundtouch {

/// SoundTouch library version string
#define SOUNDTOUCH_VERSION "2.3.1"

/// SoundTouch library version id (major * 10000 + minor * 100 + patch)
#define SOUNDTOUCH_VERSION_ID 20301

/**
 * Sample type configuration.
 * 
 * SOUNDTOUCH_INTEGER_SAMPLES: Use 16-bit integer samples (short)
 * SOUNDTOUCH_FLOAT_SAMPLES: Use 32-bit floating point samples (float)
 * 
 * For Android, we use integer samples for better compatibility with
 * Android's AudioTrack class which uses 16-bit PCM.
 */
#ifndef SOUNDTOUCH_INTEGER_SAMPLES
#define SOUNDTOUCH_FLOAT_SAMPLES
#endif

#ifdef SOUNDTOUCH_INTEGER_SAMPLES
typedef short SAMPLETYPE;
#else
typedef float SAMPLETYPE;
#endif

/**
 * SoundTouch - Main audio processing class.
 * 
 * This class provides methods for processing audio streams with
 * independent tempo, pitch, and rate control.
 */
class SoundTouch {
public:
    /// Constructor - creates a new SoundTouch instance
    SoundTouch();
    
    /// Destructor - releases all resources
    ~SoundTouch();

    /// Sets the sample rate of the audio stream (Hz)
    void setSampleRate(int sampleRate);
    
    /// Sets the number of channels (1 = mono, 2 = stereo)
    void setChannels(int channels);
    
    /// Sets the pitch shift amount in semitones
    void setPitch(double pitch);
    
    /// Sets the tempo change multiplier (0.5x to 2.0x)
    void setTempo(double tempo);
    
    /// Sets the rate change multiplier (0.5x to 2.0x)
    void setRate(double rate);
    
    /// Sets a processing setting value
    void setSetting(int settingId, int value);
    
    /// Gets a processing setting value
    int getSetting(int settingId) const;
    
    /// Puts samples into the processing pipeline (float version)
    void putSamples(const float* samples, uint numSamples);
    
    /// Puts samples into the processing pipeline (short version)
    void putSamples(const short* samples, uint numSamples);
    
    /// Receives processed samples from the pipeline (float version)
    uint receiveSamples(float* output, uint maxSamples);
    
    /// Receives processed samples from the pipeline (short version)
    uint receiveSamples(short* output, uint maxSamples);
    
    /// Returns the number of samples currently available in the pipeline
    uint numSamples() const;
    
    /// Flushes the last samples from the pipeline
    void flush();
    
    /// Clears all internal buffers
    void clear();
    
    /// Returns the number of channels (1 or 2)
    int numChannels() const;
    
    /**
     * Processing settings IDs.
     * 
     * SETTING_USE_QUICKSEEK: 0=normal quality, 1=quick but lower quality
     * SETTING_USE_AA_FILTER: 0=disable anti-alias filter, 1=enable
     * SETTING_AA_FILTER_LENGTH: Length of anti-alias filter (default 32)
     * SETTING_SEQUENCE_MS: Processing sequence length in milliseconds
     * SETTING_SEEKWINDOW_MS: Seek window length for tempo detection
     * SETTING_OVERLAP_MS: Overlap length for smooth transitions
     */
    static const int SETTING_USE_QUICKSEEK = 0;
    static const int SETTING_USE_AA_FILTER = 1;
    static const int SETTING_AA_FILTER_LENGTH = 2;
    static const int SETTING_SEQUENCE_MS = 3;
    static const int SETTING_SEEKWINDOW_MS = 4;
    static const int SETTING_OVERLAP_MS = 5;
    
private:
    /**
     * Opaque pointer to internal implementation (PImpl idiom).
     * This hides implementation details from the public API,
     * allowing the internal structure to change without affecting
     * code that uses the library.
     */
    void* pImpl;
};

} // namespace soundtouch

#endif // SOUNDTOUCH_H