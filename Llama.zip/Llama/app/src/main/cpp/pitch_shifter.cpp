/**
 * Llama Music Player - Pitch Shifter JNI Wrapper
 * ============================================================================
 * This file implements the JNI interface for the SoundTouch audio processing
 * library, providing pitch shifting and tempo adjustment capabilities.
 * 
 * The SoundTouch library is used to process audio in real-time, allowing
 * independent control of pitch (key) and tempo (speed) without affecting
 * the other parameter.
 * 
 * Key features:
 * - Independent pitch control (-6 to +6 semitones)
 * - Independent tempo control (0.5x to 2.0x speed)
 * - Real-time processing with low latency
 * - Supports both mono and stereo audio
 * - 16-bit integer sample processing for Android compatibility
 * 
 * Author: Richard Korbla Adzido
 * Version: 1.0.0
 * Since: 1.0
 * ============================================================================
 */

#include <jni.h>
#include <android/log.h>
#include <vector>
#include "soundtouch/SoundTouch.h"
#include "soundtouch/STTypes.h"

// ============================================================================
// Logging Macros
// ============================================================================

/** Log tag for identifying log messages from this library */
#define LOG_TAG "PitchShifter"

/** Debug logging macro (verbose, removed in release builds) */
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

/** Info logging macro (general information) */
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

/** Error logging macro (critical errors) */
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Use SoundTouch namespace for cleaner code
using namespace soundtouch;

// ============================================================================
// JNI Function Implementations
// ============================================================================

extern "C" {

/**
 * Creates a new SoundTouch instance.
 * 
 * This function allocates a SoundTouch object on the heap and configures it
 * for optimal quality settings for music playback.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @return Native handle (pointer cast to jlong), or 0 on failure
 */
JNIEXPORT jlong JNICALL
Java_com_ark_llama_PitchShifter_nativeCreate(JNIEnv *env, jobject thiz) {
    try {
        // Allocate SoundTouch instance
        SoundTouch *st = new SoundTouch();
        if (st == NULL) {
            LOGE("Failed to allocate SoundTouch instance");
            return 0;
        }
        
        // Configure for best quality (slower but better sound)
        st->setSetting(SETTING_USE_QUICKSEEK, 0);     // Disable quick seek for better quality
        st->setSetting(SETTING_USE_AA_FILTER, 1);     // Enable anti-alias filter
        st->setSetting(SETTING_SEQUENCE_MS, 40);      // Processing sequence length
        st->setSetting(SETTING_SEEKWINDOW_MS, 15);    // Seek window for tempo detection
        st->setSetting(SETTING_OVERLAP_MS, 8);        // Overlap length for smooth transitions
        
        LOGI("SoundTouch instance created successfully");
        return reinterpret_cast<jlong>(st);
        
    } catch (const std::exception& e) {
        LOGE("Exception creating SoundTouch: %s", e.what());
        return 0;
    } catch (...) {
        LOGE("Unknown error creating SoundTouch");
        return 0;
    }
}

/**
 * Sets the sample rate for the SoundTouch processor.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param rate Sample rate in Hz (e.g., 44100)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetSampleRate(JNIEnv *env, jobject thiz, jlong handle, jint rate) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeSetSampleRate");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->setSampleRate(rate);
    LOGD("Sample rate set to %d", rate);
}

/**
 * Sets the number of audio channels.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param channels Number of channels (1 = mono, 2 = stereo)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetChannels(JNIEnv *env, jobject thiz, jlong handle, jint channels) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeSetChannels");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->setChannels(channels);
    LOGD("Channels set to %d", channels);
}

/**
 * Sets the pitch shift amount in semitones.
 * 
 * Positive values raise the pitch, negative values lower it.
 * Range is approximately -6 to +6 semitones.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param pitch Pitch shift in semitones (float)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetPitch(JNIEnv *env, jobject thiz, jlong handle, jfloat pitch) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeSetPitch");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->setPitch(pitch);
    LOGD("Pitch set to %.2f semitones", pitch);
}

/**
 * Sets the tempo (speed) multiplier.
 * 
 * Values < 1.0 slow down, > 1.0 speed up.
 * Range is approximately 0.5x to 2.0x.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param tempo Tempo multiplier (float)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeSetTempo(JNIEnv *env, jobject thiz, jlong handle, jfloat tempo) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeSetTempo");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->setTempo(tempo);
    LOGD("Tempo set to %.2fx", tempo);
}

/**
 * Feeds audio frames into the pitch shifter for processing.
 * 
 * The buffer contains interleaved samples (L,R,L,R for stereo).
 * Each frame contains channels samples.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param samples Array of 16-bit PCM samples
 * @param frames Number of stereo frames to put
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativePutFrames(JNIEnv *env, jobject thiz, jlong handle,
                                                 jshortArray samples, jint frames) {
    // Validate parameters
    if (handle == 0) {
        LOGE("Invalid handle in nativePutFrames");
        return;
    }
    if (samples == NULL) {
        LOGE("Null samples array in nativePutFrames");
        return;
    }
    if (frames <= 0) {
        LOGD("Zero frames to put, skipping");
        return;
    }
    
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    jshort *buf = env->GetShortArrayElements(samples, NULL);
    
    if (buf != NULL) {
        // Put samples into processing pipeline
        st->putSamples(buf, frames);
        env->ReleaseShortArrayElements(samples, buf, JNI_ABORT);
        LOGD("Put %d frames", frames);
    }
}

/**
 * Retrieves processed audio frames from the pitch shifter.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @param output Array to receive processed 16-bit PCM samples
 * @param maxFrames Maximum number of frames to retrieve
 * @return Number of frames actually retrieved
 */
JNIEXPORT jint JNICALL
Java_com_ark_llama_PitchShifter_nativeReceiveFrames(JNIEnv *env, jobject thiz, jlong handle,
                                                     jshortArray output, jint maxFrames) {
    // Validate parameters
    if (handle == 0) {
        LOGE("Invalid handle in nativeReceiveFrames");
        return 0;
    }
    if (output == NULL) {
        LOGE("Null output array in nativeReceiveFrames");
        return 0;
    }
    if (maxFrames <= 0) {
        return 0;
    }
    
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    int channels = st->numChannels();
    if (channels <= 0) {
        LOGE("Invalid channels: %d", channels);
        return 0;
    }
    
    // Use vector for dynamic buffer management
    std::vector<SAMPLETYPE> buffer(maxFrames * channels);
    
    // Receive processed samples
    uint receivedFrames = st->receiveSamples(buffer.data(), maxFrames);
    
    if (receivedFrames > 0) {
        // Copy processed samples to Java output array
        // SAMPLETYPE is short when SOUNDTOUCH_INTEGER_SAMPLES is defined
        env->SetShortArrayRegion(output, 0, receivedFrames * channels, buffer.data());
        LOGD("Received %d frames", receivedFrames);
    }
    
    return receivedFrames;
}

/**
 * Returns the number of frames currently available in the pipeline.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 * @return Number of frames available
 */
JNIEXPORT jint JNICALL
Java_com_ark_llama_PitchShifter_nativeNumFrames(JNIEnv *env, jobject thiz, jlong handle) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeNumFrames");
        return 0;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    uint numSamples = st->numSamples();
    int channels = st->numChannels();
    if (channels <= 0) return 0;
    return numSamples / channels;
}

/**
 * Flushes any remaining audio data from the pipeline.
 * 
 * Call this after processing all input to ensure all audio is retrieved.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeFlush(JNIEnv *env, jobject thiz, jlong handle) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeFlush");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->flush();
    LOGD("Flushed");
}

/**
 * Clears all internal buffers in the pipeline.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeClear(JNIEnv *env, jobject thiz, jlong handle) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeClear");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    st->clear();
    LOGD("Cleared");
}

/**
 * Destroys the SoundTouch instance and frees memory.
 * 
 * @param env JNI environment pointer
 * @param thiz Reference to the Java PitchShifter object
 * @param handle Native handle (pointer to SoundTouch)
 */
JNIEXPORT void JNICALL
Java_com_ark_llama_PitchShifter_nativeDestroy(JNIEnv *env, jobject thiz, jlong handle) {
    if (handle == 0) {
        LOGE("Invalid handle in nativeDestroy");
        return;
    }
    SoundTouch *st = reinterpret_cast<SoundTouch*>(handle);
    delete st;
    LOGI("SoundTouch instance destroyed");
}

} // extern "C"